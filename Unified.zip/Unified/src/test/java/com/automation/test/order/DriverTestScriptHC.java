package com.automation.test.order;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.TestNG;
import org.testng.annotations.Test;

import com.automation.utilities.PropertyReader;

public class DriverTestScriptHC {
	static String FileNameNew;
	static Map<String ,String> Arvalidation = new HashMap<String, String>();
	@Test
	
	public void DriverScript() throws Exception {
	
			//method to call classes
			
		System.out.println("HC Servers List :"+System.getenv("HCServers"));
		if(System.getenv("HCServers")!=null)
		{
			IPupdate("COAInstall");
			IPupdate("COAChange");
			//IPupdate("COAMove");
			IPupdate("C2GInstall");
			IPupdate("C2GChange");
			//IPupdate("C2GMove");
			
		}
			
		  //for(int i=0;i<=1;i++){
			   String TestNGXmlPath=new File(System.getProperty("user.dir")).getAbsolutePath(); 
			 
		       //Close IE Browser And IEDriverServer.exe
		         Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
		         Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
		         TestNG runner=new TestNG();

	           //Create A List Of String
		         List<String> suitefiles=new ArrayList<String>();
		
	           //Find TESTNG.XML Path 
				 File file = new File(TestNGXmlPath+"/coa_Regression.xml");	 

	           //Add XML File Which You Have To Execute
		         suitefiles.add(file.toString());

	           //Now Set XML File For Execution
		         runner.setTestSuites(suitefiles);

	           //Finally Execute The Runner Using Run Method
		         runner.run();
		         
		       //Close IE Browser And IEDriverServer.exe
		         Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
		         Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
		      try{
		    	  Ordering_Report  Orp = new Ordering_Report();
				  Orp.OrderingReport();
				  System.out.println("Method executed succesfully"); 
		      }catch(Exception e) {
		    	  
		      }
		      
		      
	}
	
	public void IPupdate(String sheetname) throws IOException
	{
			String result = System.getenv("HCServers");
			//String result = "10.118.6.74_COA_BAU_02";
			String[] IPs= result.split(",");
			System.out.println(result.split(","));
			for(int i=0;i<IPs.length;i++)
			{
				File file =    new File(System.getProperty("user.dir")+"\\Files\\RunManager.xlsx");
		        FileInputStream inputStream = new FileInputStream(file);

		        Workbook RunManger = null;
		        RunManger = new XSSFWorkbook(inputStream);
		        Sheet sheet = RunManger.getSheet(sheetname);
		        int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		        Row row = sheet.getRow(i+2);
		        
		        String[] IP = IPs[i].split("_");
		        for(int j=2;j<=rowCount;j++)
		        {
		        	row = sheet.getRow(j);
		        	try{
		        	String cell = row.getCell(9).getStringCellValue().trim();
		        	String env = row.getCell(11).getStringCellValue().trim();
		        	String App = row.getCell(3).getStringCellValue().trim();
		        	if(cell.equalsIgnoreCase("No")&&env.equals(IP[2])&&App.equals(IP[1]))
		        	{
		        		if(IP[3].startsWith("LB")&&App.equals("COA"))
		        		{
		        		row.createCell(13).setCellValue(IP[0]);
		        		row.createCell(12).setCellValue("https://"+IP[0]+"/Cofee/content/preordering/login/login.aspx");
		        		System.out.println("Getting the Current URL"+"http://"+IP[0]+"/Cofee/content/preordering/login/login.aspx");
		        		row.createCell(9).setCellValue("yes");
		        			break;
		        		}
		        		else if(!IP[3].startsWith("LB")&&App.equals("COA"))  {
		        			row.createCell(13).setCellValue(IP[0]);
		        			row.createCell(12).setCellValue("http://"+IP[0]+"/cofee/Content/Preordering/testpage.aspx");
			        		System.out.println("Getting the Current URL"+"http://"+IP[0]+"/cofee/Content/Preordering/testpage.aspx");
			        		row.createCell(9).setCellValue("yes");
			        		break;
		        		}
		        		else if(IP[3].startsWith("LB")&&App.equals("C2G"))  {
		        			row.createCell(13).setCellValue(IP[0]);
		        			row.createCell(12).setCellValue("https://"+IP[0]+"/CoFEE/Content/PreOrderingD2D/Login/Login.aspx");
			        		System.out.println("Getting the Current URL"+"http://"+IP[0]+"/CoFEE/Content/PreOrderingD2D/Login/Login.aspx");
			        		row.createCell(9).setCellValue("yes");
			        		break;
		        		}
		        		else if(!IP[3].startsWith("LB")&&App.equals("C2G"))  {
		        			row.createCell(13).setCellValue(IP[0]);
		        			row.createCell(12).setCellValue("http://"+IP[0]+"/cofee/content/preorderingD2D/login.aspx");
			        		System.out.println("Getting the Current URL"+"http://"+IP[0]+"/cofee/content/preorderingD2D/login.aspx");
			        		row.createCell(9).setCellValue("yes");
			        		break;
		        		}
		        		
		        			
		        	}
		        	}
		        
		        	catch (Exception e1){
		        		System.out.println(e1);
		        	}
		        }
		    inputStream.close();
		    FileOutputStream outputStream = new FileOutputStream(file);

		   
		    RunManger.write(outputStream);

		    
		    outputStream.close();
			}
			
	}
	
}

