package com.automation.test.order;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class HTTPRequest {

	public JSONObject getJSONResponse(String url) throws ClientProtocolException, IOException, ParseException {
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(url);
		HttpResponse response = client.execute(request);
		HttpEntity responseEntity = response.getEntity();
		String XMLresponse = EntityUtils.toString(responseEntity);
		InputStream is = new ByteArrayInputStream(XMLresponse.getBytes());
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new InputStreamReader(is));
		JSONObject jsonObj = (JSONObject) obj;
		return jsonObj;
	}
	
	public JSONObject getJSONArrayResponse(String url) throws ClientProtocolException, IOException, ParseException {
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(url);
		HttpResponse response = client.execute(request);
		HttpEntity responseEntity = response.getEntity();
		String XMLresponse = EntityUtils.toString(responseEntity);
		InputStream is = new ByteArrayInputStream(XMLresponse.getBytes());
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new InputStreamReader(is));
		JSONObject jsonObj = (JSONObject) obj;
		return jsonObj;
	}

	public JSONObject getJSONObjectResponse(String url, String credentials)
			throws ClientProtocolException, IOException, ParseException, InterruptedException {
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(url);
		request.setHeader("Authorization", "Basic " + credentials);
		HttpResponse response = client.execute(request);
		HttpEntity responseEntity = response.getEntity();
		String XMLresponse = EntityUtils.toString(responseEntity);
		InputStream is = new ByteArrayInputStream(XMLresponse.getBytes());
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new InputStreamReader(is));
		JSONObject jsonObj = (JSONObject) obj;
		return jsonObj;
	}

	public JSONArray getJSONArrayResponse(String url, String credentials)
			throws ClientProtocolException, IOException, ParseException {
		HttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(url);
		request.setHeader("Authorization", "Basic " + credentials);
		HttpResponse response = client.execute(request);
		HttpEntity responseEntity = response.getEntity();
		String XMLresponse = EntityUtils.toString(responseEntity);
		InputStream is = new ByteArrayInputStream(XMLresponse.getBytes());
		JSONParser parser = new JSONParser();
		Object obj = parser.parse(new InputStreamReader(is));
		JSONArray jsonArr = (JSONArray) obj;
		return jsonArr;
	}

	@SuppressWarnings("unchecked")
	public JSONArray getJSONObjectArrayFromArray(JSONArray jsonArr, String key, String value) {
		JSONArray jsonArray = new JSONArray();
		for (Object jsonObj : jsonArr) {
			JSONObject obj = (JSONObject) jsonObj;
			if (obj.containsKey(key) && obj.get(key).toString().contains(value)) {
				jsonArray.add(obj);
			}
		}
		return jsonArray;
	}
}
