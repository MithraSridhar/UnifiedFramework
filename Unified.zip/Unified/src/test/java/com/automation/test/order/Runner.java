package com.automation.test.order;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlInclude;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

public class Runner {

    public static void main(String[] args) {

	TestNG testng = new TestNG();
	List<XmlSuite> suites = new ArrayList<XmlSuite>();

	XmlSuite suite = new XmlSuite();
	suite.setName("suite");

	XmlTest test = new XmlTest(suite);
	test.setName("test");

	List<XmlClass> classes = new ArrayList<XmlClass>();

	classes.add(new XmlClass("com.automation.utilities.preRequisitesConfig"));
	classes.add(new XmlClass("com.automation.test.order.SimplexCOAInstallDynamic"));
	classes.add(new XmlClass("com.automation.test.order.SimplexCOAChangeTestCase"));
	classes.add(new XmlClass("com.automation.test.order.SimplexCOAMoveDynamic"));

	test.setXmlClasses(classes);
	suites.add(suite);
	testng.setXmlSuites(suites);
	testng.run();

    }

}
