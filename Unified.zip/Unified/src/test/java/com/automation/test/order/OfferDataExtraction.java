package com.automation.test.order;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

import com.automation.utilities.FilePaths;

public class OfferDataExtraction {
	public static HashMap<String, HashMap> offerinfo;
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MMMM-dd");
	boolean testRun = false;
	int testRunCol = 0;
	static File createFolder;
	static FileOutputStream fos;
	static FileInputStream filePath;
	static XSSFWorkbook excelWorkBook;
	static XSSFSheet Sheet;
	static boolean compatibilityTest = false;
	String[] browser = { "chrome", "firefox", "internet explorer" };
	static DateFormat dateformat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
	static Date date = new Date();
	static String startTime = "";
	public static String loadtime[] = new String[5];

	// read data from Excel file
	@Test
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public synchronized HashMap<String, HashMap> getExcelDataExtraction(String fileName, String sheetName, boolean doubleFlag)
			throws IOException {
		try {
			// System.out.println("Entered Get Excel");
			InputStream filePath = new FileInputStream(
					FilePaths.testDataSheetPath + "/" + fileName);
			XSSFWorkbook excelWorkBook = new XSSFWorkbook(filePath);
			// System.out.println("Assigned Excel");
			XSSFSheet excelWorkSheet = excelWorkBook.getSheet(sheetName);
			Iterator<Row> iterateRow = excelWorkSheet.iterator();
			HashMap<String, HashMap> excelDataArray = new HashMap<String, HashMap>();
			int columnCount = excelWorkSheet.getRow(excelWorkSheet.getFirstRowNum()).getLastCellNum();
			// System.out.println("Total Heading count - "+columnCount);
			while (iterateRow.hasNext()) {
				Row row = iterateRow.next();
				HashMap<String, String> excelData = new HashMap<String, String>();
				String key = null;
				for (int i = 0; i < columnCount; i++) {
					if (row.getRowNum() == 0) {
						excelData.put(row.getCell(i).getStringCellValue(), "");

					} else {
						try {

							String cellValue = "";
							try {
								switch (row.getCell(i).getCellType()) {
								case Cell.CELL_TYPE_STRING:
									cellValue = row.getCell(i).getStringCellValue();
									break;
								case Cell.CELL_TYPE_NUMERIC:
									if (DateUtil.isCellDateFormatted(row.getCell(i))) {
										cellValue = String
												.valueOf(dateFormat.format(row.getCell(i).getDateCellValue()));
									} else {
										if (doubleFlag) {
											DecimalFormat formate = new DecimalFormat("#.00");
											double value = row.getCell(i).getNumericCellValue();
											cellValue = String.valueOf(formate.format(value));
										} else
											cellValue = String.valueOf((long) row.getCell(i).getNumericCellValue());
										// System.out.println(cellValue);
									}
									break;
								case Cell.CELL_TYPE_BLANK:
									cellValue = "";
									break;
								case Cell.CELL_TYPE_FORMULA:
									switch (row.getCell(i).getCachedFormulaResultType()) {
									case Cell.CELL_TYPE_NUMERIC:
										if (DateUtil.isCellDateFormatted(row.getCell(i))) {
											cellValue = String
													.valueOf(dateFormat.format(row.getCell(i).getDateCellValue()));
										} else {
											if (doubleFlag) {
												DecimalFormat formate = new DecimalFormat("#.00");
												double value = row.getCell(i).getNumericCellValue();
												cellValue = String.valueOf(formate.format(value));
											} else
												cellValue = String.valueOf((long) row.getCell(i).getNumericCellValue());
											break;
										}
									case Cell.CELL_TYPE_STRING:
										cellValue = row.getCell(i).getStringCellValue();
										break;
									}
								}
							} catch (NullPointerException e) {
								cellValue = "";
							}

							String heading = excelWorkSheet.getRow(0).getCell(i).toString();

							if (i == 0) {
								key = cellValue.trim();
							} else {
								excelData.put(heading, cellValue.trim());
							}

						} catch (NullPointerException e) {
						}
					}
				}
				if (row.getRowNum() != 0 && !excelData.isEmpty() && !key.isEmpty()) {

					excelDataArray.put(key, excelData);

				}
			}
			filePath.close();
			System.out.println(excelDataArray);
			return excelDataArray;
		} catch (IOException e) {
			// System.out.println("There are a problem with Test Data, please
			// proceed before proceeding with test");
			e.printStackTrace();
			throw e;
		}
	}

}
