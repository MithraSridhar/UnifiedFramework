package com.automation.test.order;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.TestNG;
import org.testng.annotations.Test;

import com.automation.utilities.PropertyReader;

public class DriverTestScript {
	static String FileNameNew;

	static float threadwaitTime = 1;
	static int counter = 0;
	static int startCount = 5;
	static int MaxCount = 30;
	//static int projectId= 0;
	static int projectId= 0;
	//static int versionId= 0;
	static int test_suite= 0;
	//static int cycleId= 0;
	static String Apikey= null;
	static String username= "";
	static String encryptedpwd= "";
	static Map<String, String> Arvalidation = new HashMap<String, String>();

	@Test
	public void DriverScript() throws IOException, InvalidFormatException, ClassNotFoundException, SQLException {
		// DAAS ds = new DAAS();
		// ds.Dataservice();
		// Create Object For TESTNG CLASS

		for (int i = 0; i < 3; i++) {

			String TestNGXmlPath = new File(System.getProperty("user.dir")).getAbsolutePath();

			//incremental thread  related files

			try{
				threadwaitTime = (float) Double.parseDouble(new String(Files.readAllBytes(Paths.get(TestNGXmlPath+"/threadwaitTime.txt"))).trim());
				startCount = Integer.parseInt(new String(Files.readAllBytes(Paths.get(TestNGXmlPath+"/startCount.txt"))).trim());
				MaxCount = Integer.parseInt(new String(Files.readAllBytes(Paths.get(TestNGXmlPath+"/MaxCount.txt"))).trim());
				}
				catch(Exception ex){
					ex.printStackTrace();
				}
			
			

			//Jira related files
			try{
				/*projectId = Integer.parseInt(new String(Files.readAllBytes(Paths.get(TestNGXmlPath+"/projectId.txt"))).trim());
				versionId = Integer.parseInt(new String(Files.readAllBytes(Paths.get(TestNGXmlPath+"/versionId.txt"))).trim());
				cycleId = Integer.parseInt(new String(Files.readAllBytes(Paths.get(TestNGXmlPath+"/cycleId.txt"))).trim());
				username = new String(Files.readAllBytes(Paths.get(TestNGXmlPath+"/username.txt"))).trim();
				encryptedpwd = new String(Files.readAllBytes(Paths.get(TestNGXmlPath+"/encryptedpwd.txt"))).trim();
				*/
				projectId = Integer.parseInt(new String(Files.readAllBytes(Paths.get(TestNGXmlPath+"/projectId.txt"))).trim());
				test_suite = Integer.parseInt(new String(Files.readAllBytes(Paths.get(TestNGXmlPath+"/test_suite.txt"))).trim());
				Apikey = new String(Files.readAllBytes(Paths.get(TestNGXmlPath+"/Apikey.txt"))).trim();
			}
			catch(Exception ex){
				ex.printStackTrace();
			}
			
			// Close IE Browser And IEDriverServer.exe
			Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
			Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
			TestNG runner = new TestNG();

			// Create A List Of String
			List<String> suitefiles = new ArrayList<String>();

			// Find TESTNG.XML Path
			File file = new File(TestNGXmlPath + "/coa_Regression.xml");

			// Add XML File Which You Have To Execute
			suitefiles.add(file.toString());

			// Now Set XML File For Execution
			runner.setTestSuites(suitefiles);

			// Finally Execute The Runner Using Run Method
			runner.run();

			// Close IE Browser And IEDriverServer.exe
			Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe");
			Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");

			try (BufferedReader br = new BufferedReader(new FileReader(TestNGXmlPath + "/Report/Resultname.txt"))) {
				String sCurrentLine;
				while ((sCurrentLine = br.readLine()) != null) {
					FileNameNew = sCurrentLine;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			FileInputStream fileInputStreamReport = null;
			Workbook workbookReport = null;
			try {
			
				fileInputStreamReport = new FileInputStream(FileNameNew + "/ExcelReport.xlsx");
				System.out.println(FileNameNew);
				workbookReport = new XSSFWorkbook(fileInputStreamReport);
				int SheetNameReport = 0;
				if (workbookReport != null) {
					FormulaEvaluator evaluatorReport = workbookReport.getCreationHelper().createFormulaEvaluator();
					Sheet sheet = workbookReport.getSheetAt(SheetNameReport);
					int Rowcount = sheet.getLastRowNum() - sheet.getFirstRowNum();
					Row row = sheet.getRow(0);
					int StatusColumn = 0;
					int testIDColumn = 0;
					for (int j = 0; j < row.getLastCellNum(); j++) {
						if (row.getCell(j).getStringCellValue().equalsIgnoreCase("TestResult")) {
							StatusColumn = j;
						}
						if (row.getCell(j).getStringCellValue().equalsIgnoreCase("testId")) {
							testIDColumn = j;
						}

					}

					for (int roe = 1; roe <= Rowcount; roe++) {
						Row rownew = sheet.getRow(roe);
						String Statusn = rownew.getCell(StatusColumn).getStringCellValue().trim();
						String TestColu = rownew.getCell(testIDColumn).getStringCellValue().trim();
						if (Statusn.equalsIgnoreCase("Passed")) {
							Arvalidation.put(TestColu, "Passed");
						}
					}
				}

			} catch (Exception ex) {
				
				ex.printStackTrace();

			}
			finally{
				
				fileInputStreamReport.close();

			}
			
			try{
			FileInputStream fileInputStream = null;
			Workbook workbook = null;
			String fileName = null;
			for (Map.Entry<String, String> entry : Arvalidation.entrySet()) {
				System.out.println(entry.getKey());
				
				try{
				 fileName = new File(System.getProperty("user.dir")).getAbsolutePath() + "/Files/RunManager.xlsx";				
				
				fileInputStream = new FileInputStream(fileName);
				if (fileName.endsWith(".xlsx")) {
					workbook = new XSSFWorkbook(fileInputStream);
				} else if (fileName.endsWith(".xls")) {
					workbook = new HSSFWorkbook(fileInputStream);
				} else if (fileName.endsWith(".xlsm")) {
					workbook = WorkbookFactory.create(fileInputStream);
				}

				// Validation
				String SheetName = "";
				if (workbook != null) {
					
					
					if (entry.getKey().contains("COA") && entry.getKey().contains("Install")) {
						SheetName = "COAInstall";
					} else if (entry.getKey().contains("COA") && entry.getKey().contains("Change")) {
						SheetName ="COAChange";
					} else if (entry.getKey().contains("COA") && entry.getKey().contains("Move")) {
						SheetName ="COAMove";
					} else if (entry.getKey().contains("C2G") && entry.getKey().contains("Install")) {
						SheetName = "C2GInstall";
					} else if (entry.getKey().contains("C2G") && entry.getKey().contains("Change")) {
						SheetName ="C2GChange";
					} else if (entry.getKey().contains("C2G") && entry.getKey().contains("Move")) {
						SheetName ="C2GMove";
					}

					FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
					Sheet sheet = workbook.getSheet(SheetName);
					int Rowcount = sheet.getLastRowNum() - sheet.getFirstRowNum();
					Row row = sheet.getRow(1);
					int Statusint = 0;
					for (int j = 0; j < row.getLastCellNum(); j++) {
						if (row.getCell(j).getStringCellValue().equalsIgnoreCase("Test_Run")) {
							Statusint = j;
							break;
						}
					}
					Cell cell = null;
					String KeyName = entry.getKey().split("\\.")[0].split("_")[2];
					System.out.println(KeyName);
					for (int j = 2; j < Rowcount; j++) {
						Row rownew = sheet.getRow(j);
						int actualval= 0;
						try{
							actualval = (int) rownew.getCell(0).getNumericCellValue();
						}
						catch(Exception e){				
							
									try {
										if (actualval == 0) {

											actualval = Integer.parseInt(rownew.getCell(0).getStringCellValue());

										}
									}
							catch(Exception ex){				

							System.out.println("numeric value is empty="+rownew.getRowNum());
							}
						}
						int keyval = Integer.parseInt(KeyName);
						if (actualval == keyval) {
							cell = sheet.getRow(j).getCell(Statusint);
							System.out.println(cell.getStringCellValue());
							cell.setCellValue("No");
							break;
						}

					}

					

				}
				}
				
				catch(Exception ex){
					
					ex.printStackTrace();
				}
				finally{
					
					fileInputStream.close();
					FileOutputStream output_file = new FileOutputStream(fileName);
					workbook.write(output_file);
					output_file.flush();
					output_file.close();
				}
				
				
			}
			
			}
			catch(Exception ex){
				
				ex.printStackTrace();
			}
		}

	}

	synchronized void Modulewait(Thread thread) {

		
		
		if (counter <=  MaxCount) {
			try {
				int setinterval = counter / startCount;
				int waittime = (int) (DriverTestScript.threadwaitTime * setinterval * 1000 * 60);
				counter++;

				thread.sleep(waittime);

			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		
		
	}


}
