package com.automation.test.order;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;

public class DAAS {

	
	public void Dataservice() throws IOException, SQLException, ClassNotFoundException
	//public static void main(String[] args)  throws IOException, ClassNotFoundException, SQLException 
	{
		URL url;
        HttpURLConnection connection = null;
        Connection con = null;
        File file =    new File(System.getProperty("user.dir")+"\\Files\\RunManager.xlsx");
        System.out.println(file);
        FileInputStream inputStream = new FileInputStream(file);
        Workbook RunManger = null;
        RunManger = new XSSFWorkbook(inputStream);
        Sheet sheet = RunManger.getSheet("COAChange");
        int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
        Row row1 = sheet.getRow(2);
        for(int j=2;j<=rowCount;j++)
        {
        	row1 = sheet.getRow(j);
        	String cell = row1.getCell(2).getStringCellValue().trim();
        	System.out.println("cell"+cell);
        	String Accnumber;
        	try {
        		Accnumber= row1.getCell(33).getStringCellValue().trim();
        	}
        	catch(Exception e){
        		Accnumber= "NA";
        	}
        	System.out.println(Accnumber);
        	if(!(cell.isEmpty()) && (Accnumber.isEmpty()))
        	{
        		String targetURL = "http://10.118.43.115:1030/acctwithprods/offset/0/limit/1/";
        		Class.forName("com.mysql.cj.jdbc.Driver");  
        		con=DriverManager.getConnection("jdbc:mysql://10.118.3.212:3306/ito_automation?useSSL=false","root","Itoautomation!@#123");  
				Statement stmt=con.createStatement();  
        		ResultSet rs=stmt.executeQuery("Select * from ito_automation.testdataconditions where Test_Data_Condition='"+cell+"'");  
				Map<String, Object> retMap = new HashMap<String, Object>();
		
					while(rs.next()) 
					{
						String row= "";
						ResultSetMetaData metadata = rs.getMetaData();
						int columnCount = metadata.getColumnCount();
						System.out.println(columnCount);
						for(int i= 3;i<=columnCount; i++)
						{
							String Keyname=metadata.getColumnName(i);
							String kn = Keyname.replaceAll("[^a-zA-Z ]+", "");
							System.out.println("After Removing the _:::"+kn);
							row = rs.getString(i);
							if(StringUtils.isNotEmpty(row))
							{
								JSONObject obj = new JSONObject();
				
								try {
					
									retMap.put(kn, row);
					
									} catch (JSONException e) {
				 
										e.printStackTrace();
									}
				}
				
			}
			String json = new ObjectMapper().writeValueAsString(retMap);
			
	        try {
		          //Create connection
		          url = new URL(targetURL);
		          System.out.println(url);
		          connection = (HttpURLConnection)url.openConnection();
		          
		          connection.setRequestMethod("POST");
		          connection.setRequestProperty("Content-Type", 
		               "application/json");

		          connection.setUseCaches (false);
		          connection.setDoInput(true);
		          connection.setDoOutput(true);
		          
		          //Send request
		          DataOutputStream wr = new DataOutputStream (
		                      connection.getOutputStream ());
		          wr.writeBytes (json.toString());
		          wr.flush ();
		          wr.close ();
		          
		          //Get Response    
		         InputStream is = connection.getInputStream();
		          
		          BufferedReader rd = new BufferedReader(new InputStreamReader(is));
		         
		          String line;
		          StringBuffer response = new StringBuffer(); 
		          while((line = rd.readLine()) != null) {
		        	  response.append(line);
		        	  response.append('\r');
		          }
		          rd.close();
		         String vsd = response.toString();
		         vsd = vsd.replaceAll("[\\[\\]]","");
		         JSONObject obj = new JSONObject(vsd);
		        String txt = obj.get("visionid").toString();
		        String acctsk = obj.get("acctSk").toString();
		        System.out.println(txt);
		        //Setting the value  
		        row1.createCell(33).setCellValue(txt);
		        //Create connection for PUT request
		          HttpClient client = new DefaultHttpClient();
		          HttpEntity putPageEntity = null;
		          HttpPut putPageRequest = new HttpPut("http://10.118.43.115:1030/acctwithprods/");
		          JSONObject obj1 = new JSONObject();
		          obj1.put("acctSk",acctsk );
		          obj1.put("refreshreload","Reserved");
		      	StringEntity entity = new StringEntity(obj1.toString(), ContentType.APPLICATION_JSON);
		      	putPageRequest.setEntity(entity);

		      	HttpResponse putPageResponse = client.execute(putPageRequest);
		      	putPageEntity = putPageResponse.getEntity();
		      	System.out.println("Put Page Request returned " + putPageResponse.getStatusLine().toString());
		      	
		      	if (putPageResponse.getStatusLine().getStatusCode() == 200 || putPageResponse.getStatusLine().getStatusCode() == 204) {
					
		            BufferedReader br = new BufferedReader(
		                    new InputStreamReader((putPageResponse.getEntity().getContent())));
		            String output;
		           System.out.println("Output from Server ...." + putPageResponse.getStatusLine().getStatusCode() + "\n");
		            while ((output = br.readLine()) != null) {
		               // System.out.println(output);
		            }
		        }
		        else{
		           // logger.error(response.getStatusLine().getStatusCode());

		            throw new RuntimeException("Failed : HTTP error code : "
		                    + putPageResponse.getStatusLine().getStatusCode());
		        }
		       
		       
		        } catch (Exception e) {

		          e.printStackTrace();

		        }
		}
			      	        
	     
	      }
		
	}
        con.close();
        inputStream.close();
        FileOutputStream outputStream = new FileOutputStream(file);
        RunManger.write(outputStream);
        outputStream.close();

	}
}
