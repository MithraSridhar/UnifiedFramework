package com.automation.test.order;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.apache.commons.codec.binary.Base64;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.DatatypeConverter;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UploadInQTest {
	
	Timestamp startime;
	Timestamp endtime;
	public void setStartime() {
		 Date date= new Date();
		 long time = date.getTime();
		this.startime = new Timestamp(time);
	}

	public void setEndtime() {
		 Date date= new Date();
		 long time = date.getTime();
		this.endtime = new Timestamp(time);
	}

	


	static HashMap<String, HashMap<String, String>> Testcases = new HashMap<String, HashMap<String, String>>();

	synchronized public void getTCdetail(String Apikey) {
		ObjectMapper mapper = new ObjectMapper();

		try {

			JsonNode rootNode = mapper.readTree(getTCdetails(Apikey));
			JsonNode idNode = rootNode.path("items");

			// Pretty print
			String prettyformated = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(idNode);

			List<items> Tc = Arrays.asList(mapper.readValue(prettyformated, items[].class));

			for (items tc : Tc) {

				Testcases.put(tc.getName(), new HashMap<String, String>());
				Testcases.get(tc.getName()).put("id", String.valueOf(tc.getId()));
				Testcases.get(tc.getName()).put("testcase_id", String.valueOf(tc.getTest_case().getId()));

			}

		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	
		 synchronized public void UpdateQTest(String Filelocation, String
		 TestID,String testCaseName) {

		try {
			String executionid = null;
			int Testcaseid = 0;

			//String jiraID = null;
			String executionStatus = "0";

			/*String Filelocation = "C:\\Users\\babuvi5\\unifiedframework";
			String TestID = "COA_Install_5";
			String testCaseName = "Install double flex bundle with speed 500m and Mundo total package 2yr with deposit";*/

			// override

			if (DriverTestScript.projectId != 0 && DriverTestScript.test_suite != 0
					&& !DriverTestScript.Apikey.isEmpty()) {

				
				//String TestcaseNumber = TestID.replace("COA_", "");
				//TestcaseNumber = TestcaseNumber.replace("C2G", "");

				if (Testcases.size() == 0) {

					try {
						getTCdetail(DriverTestScript.Apikey);
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}

				Iterator<Entry<String, HashMap<String, String>>> itr = Testcases.entrySet().iterator();

				while (itr.hasNext()) {
					Entry<String, HashMap<String, String>> entry = itr.next();
					//System.out.println(entry.getKey().toLowerCase());

					if (entry.getKey().toLowerCase().contains(TestID.toLowerCase())) {

						String entryvalue = entry.getKey().toLowerCase().replaceAll("[^a-zA-Z0-9]", "");
						String testCaseNamevalue = testCaseName.toLowerCase().replaceAll("[^a-zA-Z0-9]", "");

						if (entryvalue.contains(testCaseNamevalue.toLowerCase())) {

							executionid = entry.getValue().get("id");
							Testcaseid=Integer.parseInt(entry.getValue().get("testcase_id"));
							break;
						}
					}

				}

				if (!executionStatus.equalsIgnoreCase("1")) {

					
					ApproveTestcase(Testcaseid);
					String url = "https://onetest.vpc.verizon.com/api/v3/projects/" + DriverTestScript.projectId
							+ "/test-runs/"+executionid+"/test-logs";

					File reportlocation = new File(Filelocation + "\\" + TestID);

					try {

						// ByteArrayEntity file=new
						// ByteArrayEntity(fileContent);
						
					 
						 DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
						 
						testlogqtest log = new testlogqtest();
						log.setExe_start_date(dateFormat.format((startime)));
						log.setExe_end_date(dateFormat.format((endtime)));
						log.setNote("note");
						log.setStatus(new status());
						log.getStatus().setId("601");
						log.getStatus().setName("Passed");
						log.getStatus().setColor("#0cdda8");
						log.getStatus().setActive(true);
						log.getStatus().setIs_default(false);
						// File Size in MB
						File docfile = new File(reportlocation.getAbsolutePath() + "\\" + TestID + ".docx");
						//System.out.println(docfile.length());
						float fileSize = docfile.length() / 1024 / 1024;
						//fileSize = 60;
						if (fileSize <= 45) {

							byte[] fileContent = Files.readAllBytes(docfile.toPath());

							attachements[] attach = new attachements[1];
							for (int i = 0; i < attach.length; i++) {
								attach[i] = new attachements();
								attach[i].setName(testCaseName + "_" + i + ".docx");
								attach[i].setContent_type(
										"application/vnd.openxmlformats-officedocument.wordprocessingml.document");
								attach[i].setData(DatatypeConverter.printBase64Binary(fileContent));
							}
							log.setAttachement(attach);

						} else {
							File[] listOfFiles = reportlocation.listFiles();
							int pngcount = 0;
							for (File file : listOfFiles) {

								if (file.getName().contains(".png")) {
									pngcount++;
								}

							}

							attachements[] attach = new attachements[pngcount];
							int loc = 0;
							for (int i = 0; i < listOfFiles.length; i++) {
							
								if (listOfFiles[i].getName().contains(".png")) {

									byte[] fileContent = Files.readAllBytes(listOfFiles[i].toPath());

									attach[loc] = new attachements();
									attach[loc].setName(loc + ".png");
									attach[loc].setContent_type("image/png");
									attach[loc].setData(DatatypeConverter.printBase64Binary(fileContent));

									loc++;
								}

							}
							log.setAttachement(attach);

						}
						ObjectMapper mapper = new ObjectMapper();
						String json = mapper.writeValueAsString(log);

						HttpClient client = HttpClientBuilder.create().build();
						HttpPost post = new HttpPost(url);
						post.setHeader("Authorization",DriverTestScript.Apikey);
						//System.out.println("-------------------");
						//System.out.println(json);

						//System.out.println("----------------------");
						StringEntity input1 = new StringEntity(json);
						post.setEntity(input1);
						post.setHeader("Content-type", "application/json");

						HttpResponse response = client.execute(post);
						//System.out.println(response.getStatusLine());

					}

					catch (Exception ex) {
						ex.printStackTrace();

					}

				}

			}

		} catch (Exception ex) {
			ex.printStackTrace();

		}
	}

	synchronized String getTCdetails(String Apikey) {
		String apiOutput = "";

		try {
			HttpGet post = new HttpGet("https://onetest.vpc.verizon.com/api/v3/projects/" + DriverTestScript.projectId
					+ "/test-runs?parentId=" + DriverTestScript.test_suite
					+ "&parentType=test-suite&page=1&pageSize=999");

			post.setHeader("Authorization", Apikey);
			HttpResponse response = new DefaultHttpClient().execute(post);
			int responseCode = response.getStatusLine().getStatusCode();
			HttpEntity httpEntity = response.getEntity();
			apiOutput = EntityUtils.toString(httpEntity);
			//System.out.println(apiOutput);

		} catch (Exception e) {

			e.printStackTrace();
		}

		return apiOutput;

	}
	
	synchronized String ApproveTestcase(int testcase_id) {
		String apiOutput = "";

		try {
			HttpPut put = new HttpPut("https://onetest.vpc.verizon.com/api/v3/projects/"+DriverTestScript.projectId+"/test-cases/"+testcase_id+"/approve");

			put.setHeader("Authorization", DriverTestScript.Apikey);
			HttpResponse response = new DefaultHttpClient().execute(put);
			int responseCode = response.getStatusLine().getStatusCode();
			
			//System.out.println(responseCode);

		} catch (Exception e) {

			e.printStackTrace();
		}

		return apiOutput;

	}

}

@JsonIgnoreProperties(ignoreUnknown = true)
class items {

	@JsonProperty("id")
	Integer id;

	@JsonProperty("name")
	String name;

	@JsonProperty("test_case")
	testcase test_case;

	public testcase getTest_case() {
		return test_case;
	}

	public void setTest_case(testcase test_case) {
		this.test_case = test_case;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}

@JsonIgnoreProperties(ignoreUnknown = true)
class testcase {

	@JsonProperty("id")
	Integer id;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}

@JsonIgnoreProperties(ignoreUnknown = true)

class testlogqtest {

	@JsonProperty("exe_start_date")
	String exe_start_date;

	public String getExe_start_date() {
		return exe_start_date;
	}

	public void setExe_start_date(String exe_start_date) {
		this.exe_start_date = exe_start_date;
	}

	public String getExe_end_date() {
		return exe_end_date;
	}

	public void setExe_end_date(String exe_end_date) {
		this.exe_end_date = exe_end_date;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public status getStatus() {
		return status;
	}

	public void setStatus(status status) {
		this.status = status;
	}

	@JsonProperty("exe_end_date")
	String exe_end_date;

	@JsonProperty("note")
	String note;

	@JsonProperty("status")
	status status;

	public attachements[] getAttachement() {
		return attachement;
	}

	public void setAttachement(attachements[] attachement) {
		this.attachement = attachement;
	}

	@JsonProperty("attachments")
	attachements[] attachement;

}

@JsonIgnoreProperties(ignoreUnknown = true)

class status {
	@JsonProperty("id")
	String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@JsonProperty("name")
	String name;

	@JsonProperty("is_default")
	boolean is_default;

	public boolean isIs_default() {
		return is_default;
	}

	public void setIs_default(boolean is_default) {
		this.is_default = is_default;
	}

	@JsonProperty("color")
	String color;

	@JsonProperty("active")
	boolean active;

}

@JsonIgnoreProperties(ignoreUnknown = true)
class attachements {

	@JsonProperty("name")
	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent_type() {
		return content_type;
	}

	public void setContent_type(String content_type) {
		this.content_type = content_type;
	}

	@JsonProperty("content_type")
	String content_type;

	@JsonProperty("data")
	String data;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

}
