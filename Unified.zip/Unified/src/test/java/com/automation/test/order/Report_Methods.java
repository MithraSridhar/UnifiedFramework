package com.automation.test.order;

import java.awt.List;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.ListIterator;
import java.util.TimeZone;

import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Reporter;


public class Report_Methods {
	
	 static	InputStream fil;
	 static BufferedWriter bw;
	 static FileWriter   fw;
	 static XSSFWorkbook excel_wb;
	 static String runTime ;

	 

	public static void create_message() throws IOException
	 { bw.write("<html>");
		bw.write("<br>"); 
		bw.write("<font face= Arial size=3>Hi All </font>");
		bw.write("<br>"); 
	//	bw.write("<img id=1 src=cid:testReport.gif width=100 height=100 align=right>"); 
		bw.write("<br>"); 
		bw.write("<font face= Arial size=3>Please find  below the health check Report for Optix Ordering ...</font>");
		bw.write("<br>"); 
	 }
	
	
	public static void create_table(ArrayList<String> ListColumnNames) throws IOException 
	 { 
		ArrayList<Integer> ColindexList = new ArrayList<Integer>();
		String font_col;
	
	 ListIterator<String> listIter1 = ListColumnNames.listIterator();
	 while (listIter1.hasNext()) {
		 String ColName =listIter1.next();
	     if (ColName.equals("testName") || ColName.equals("session")) {
	    	 String alignment="left"; 
	     }	 
	 }
	  ColindexList = getColStringData(ListColumnNames);
	
		   RichTextString StringValue; 
		 //  XSSFSheet sheet = excel_wb.getSheet("ResultSheet");// Get First sheet
		   XSSFSheet sheet = excel_wb.getSheetAt(0);     // Get First sheet
		   int totalRows = sheet.getPhysicalNumberOfRows();
		   String ColData;

			bw.write("<p>");
			bw.write("<font face= Arial size=3 color=#000080><u><b>  Execution Summary  </u></b></font>");
			bw.write("</p>");
			
	       bw.write("<table border=1 style=width: 100% cellpadding=10 cellspacing=2>");
	       bw.write("<tr bgcolor=  MidnightBlue  >");
	       
	       
	       //writing header
	
	       bw.write("<th &nbsp><font face= Arial size=2 color= Snow > IP  </font></th>");
	       bw.write("<th &nbsp><font face= Arial size=2 color= Snow > Environment  </font></th>");
	       bw.write("<th &nbsp><font face= Arial size=2 color= Snow > Application  </font></th>");
	       bw.write("<th &nbsp><font face= Arial size=2 color= Snow > FlowType  </font></th>");
		   bw.write("<th &nbsp><font face= Arial size=2 color= Snow > TestName  </font></th>");  
		   bw.write("<th &nbsp><font face= Arial size=2 color= Snow > TotalSteps  </font></th>");  
		   bw.write("<th &nbsp><font face= Arial size=2 color= Snow > Status  </font></th>"); 
		   bw.write("<th &nbsp><font face= Arial size=2 color= Snow > MON  </font></th>");
		   bw.write("<th &nbsp><font face= Arial size=2 color= Snow > ErrorMessage  </font></th>"); 
		   bw.write("<th &nbsp><font face= Arial size=2 color= Snow > Session  </font></th>");  

	       
	      //writing body
		   		      
	   for(int row=1;row<=totalRows-1;row++)
	       {
		    bw.write("<tr bgcolor=  #F0F8FF>");
			ListIterator<Integer> listIter = ColindexList.listIterator();
	    	while(listIter.hasNext())
	    	   { 
	    		 XSSFRow dataRow = sheet.getRow(row); //get row 1 to row n (rows containing data)
				 XSSFCell cell = dataRow.getCell(listIter.next()); //Get the cells for each of the indexes
				 
			     String cellValue= cell.getStringCellValue();
			     if(cellValue.equals("Passed"))			     
			         {  font_col = "ForestGreen ";	}	  
			     else if(cellValue.equals("Failed"))
			    	 { font_col = "FireBrick"; }
			     else
			         { font_col = "MistyRose  "; }
			    	 	   
	    		 bw.write("<th align='left' bgcolor="+font_col+" &nbsp><font face= Arial size=2>"+cellValue+"</font></th>"); 
	    	   }
	    	    bw.write("</tr>"); 
	       } 
	       
	   bw.write("</table>");   
	       
	 }
	
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------	
	public static ArrayList<Integer> getColStringData(ArrayList<String> ListColumnNames){	
				
		HashMap<String, Integer> map = new HashMap<String,Integer>(); //Create map
		ArrayList<Integer> colIndexList= new ArrayList<Integer>(); 
		
		XSSFSheet sheet = excel_wb.getSheetAt(0);// Get First sheet
		//int totalRows = sheet.getLastRowNum();
		int totalRows = sheet.getPhysicalNumberOfRows();
		ArrayList<String> ColDataList = new ArrayList<String>();
		
		XSSFRow row = sheet.getRow(0); //Get first row
		//following is boilerplate from the java doc
		short minColIx = row.getFirstCellNum(); //get the first column index for a row
		short maxColIx = row.getLastCellNum(); //get the last column index for a row
		for(short colIx=minColIx; colIx<maxColIx; colIx++) { //loop from first to last index
		   XSSFCell cell = row.getCell(colIx); //get the cell
		   map.put(cell.getStringCellValue(),cell.getColumnIndex()); //add the cell contents (name of column) and cell index to the map
		 }
		
		ListIterator<String> listIter = ListColumnNames.listIterator();
    	while(listIter.hasNext()){
    		int idxForColumnName = map.get(listIter.next()); //get the column index for the column with header name = "Column1"
    		colIndexList.add(idxForColumnName);
    	}	 
		return colIndexList;	
	}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------	
		public ArrayList<Integer> getColIntegerData(String columnName){	
			
			
			HashMap<String, Integer> map = new HashMap<String,Integer>(); //Create map
			
			XSSFSheet sheet = excel_wb.getSheetAt(0);// Get First sheet
			int totalRows = sheet.getPhysicalNumberOfRows();
			
			XSSFRow row = sheet.getRow(0); //Get first row
			//following is boilerplate from the java doc
			short minColIx = row.getFirstCellNum(); //get the first column index for a row
			short maxColIx = row.getLastCellNum(); //get the last column index for a row
			for(short colIx=minColIx; colIx<maxColIx; colIx++) { //loop from first to last index
			   XSSFCell cell = row.getCell(colIx); //get the cell
			   map.put(cell.getStringCellValue(),cell.getColumnIndex()); //add the cell contents (name of column) and cell index to the map
			 }
			
			int idxForColumnName = map.get(columnName); //get the column index for the column with header name = "Column1"
			
			ArrayList<Integer> listOfColumnData   = new ArrayList<Integer>();
			
			for(int x = 1; x<=totalRows; x++){
			 XSSFRow dataRow = sheet.getRow(x); //get row 1 to row n (rows containing data)
			 XSSFCell cell = dataRow.getCell(idxForColumnName); //Get the cells for each of the indexes
		     Integer cellValue= (int) cell.getNumericCellValue();


			 listOfColumnData.add(cellValue);
			}
			return listOfColumnData;	
		}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------	
		public void create_statistics() throws IOException
		{
			 bw.write("<br>"); 
			bw.write("<table border=1 style=width: 100% cellpadding=10 cellspacing=4>");
			  bw.write("<tr bgcolor=  	GreenYellow >");
			  bw.write("<th colspan=&nbsp><font face= Arial size=2>Execution Time </font></th>");
			  bw.write("<th colspan=&nbsp><font face= Arial size=2>"+runTime+"</font></th>");
			  bw.write("</table>");
		}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------		
	
	public void create_salutation() throws IOException
	{
		 bw.write("<br>"); 
		 bw.write("<font face= Arial size=3 color=#000080 ><b><i>Thanks and Regards,</font>");
		 bw.write("<br>");
		 bw.write("<font face= Arial size=3 color=#000080 >AUTOMATION TEAM </font></b></i>");
		 bw.write("<br>");
		 bw.write("</html>");
	}
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------
	public String get_DateIST(){
		SimpleDateFormat sd = new SimpleDateFormat("dd.MM.yyyy 'at' HH:mm:ss z");			
	        Date date = new Date();
	        // Use the full Olson zone ID instead.
	        sd.setTimeZone(TimeZone.getTimeZone("IST"));
	        System.out.println(sd.format(date));
	        return sd.format(date);
	}
	
	
	
	
	


//------------------------------------------------------------------Ends here ---------------------------------------------------------------------------------------------------------------------
}
