package com.automation.test.order;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.utilities.ExcelDataExtraction;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.ScriptDriver;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;

public class SimplexCOAInstallDynamic {

	ExcelDataExtraction excelDataExtraction = new ExcelDataExtraction();




	@Test(dataProvider = "Verizon")
	public void testInstallFlow(HashMap<String, String> data) throws Exception {
		UploadInQTest uploadInQTest = new UploadInQTest();
		WebDriver driver = null;
		ReportStatus report = null;
		String testCaseName = "";
		String testId = "";
		String environment = "";
		Logger logger = null;

		try {

			try {
				new DriverTestScript().Modulewait(Thread.currentThread());
				uploadInQTest.setStartime();
			} catch (Exception ex) {
			}

			testId = "COA_Install_" + data.get("S_No");
			System.out.println("Running " + testId + "Test case");
			testCaseName = data.get("TestCase_Name");
			logger = CustomDriver.getThreadLogger(Thread.currentThread(), testId);
			logger.error("Running " + testId + "Test case");
			InitiateDriver iDriver = new InitiateDriver(data.get("Browser"));
			driver = iDriver.getDriver();
			report = new ReportStatus(driver, testId);
			report.report("Simplex", data);

			// Word doc to capture screenshot

			WordprocessingMLPackage myDoc = WordprocessingMLPackage.createPackage();
			report.InitScreenshot(myDoc);

			List<String> scenario = excelDataExtraction.getScenarioDriver(data.get("S_No"));
			Set<Object> scenarioObject = ScriptDriver.uniqueInstance("com.automation.ui.pages", scenario, driver,
					testId, report, data);
			ScriptDriver scriptDriver = new ScriptDriver();
			scriptDriver.runner(scenario, scenarioObject);
			if (!report.getReportValue("TestResult").equals("Failed"))
				report.updateMainReport("TestResult", "Passed");
		} catch (UnreachableBrowserException e) {
			report = new ReportStatus(driver, testId);
			report.report("Simplex", data);
			report.updateMainReport("ErrorMessage", "Unable to launch the Browser : " + data.get("Browser"));
			report.updateMainReport("comments", "Unable to launch the Browser : " + data.get("Browser"));
			report.updateMainReport("TestResult", "Failed");
			report.updateMainReport("session", "No Session");
			report.updateMainReport("TestResult", "Failed");
		} catch (Exception e) {
			if (report == null) {
				report = new ReportStatus(driver, testId);
				report.report("Simplex", data);
			}
			e.printStackTrace();
			report.updateMainReport("TestResult", "Failed");

			// report.updateMainReport("comments", e.getCause()+"");//To get the
			// comments in main report
			if (driver != null) {
				report.updateMainReport("screenshot", e.toString());
				report.updateMainReport("session", driver.getCurrentUrl());
			}
			logger.error("TestCase Failed...", e);

		} finally {

			report.addScreenshotdocToWord();
			if (driver != null) {
				if (!report.getReportValue("TestResult").equals("Failed")) {
					report.updateMainReport("session", driver.getCurrentUrl());
					try {
						// new
						// UploadInJira().UpdateJira(ReportStatus.getCurrentExecutionPath().toString(),
						// testId,testCaseName,
						// data.get("Username"), data.get("Password"));
						uploadInQTest.setEndtime();

						uploadInQTest.UpdateQTest(ReportStatus.getCurrentExecutionPath().toString(), testId,
								testCaseName);
					} catch (Exception ex) {

					}
				}
				driver.close();
				driver.quit();
			}
		}
	}

	// @DataProvider(name = "Verizon")
		@DataProvider(parallel = true, name = "Verizon")
		@SuppressWarnings("rawtypes")
		public Iterator<Object[]> getExcelData() throws IOException {
			ArrayList<HashMap<String, String>> excelData = excelDataExtraction.getExcelDataExtraction("RunManager.xlsx",
					"COAInstall", false);
			HashMap<String, HashMap> offervalidations = null;
			try {
				if (OfferDataExtraction.offerinfo==null) {
					OfferDataExtraction.offerinfo = new OfferDataExtraction()
							.getExcelDataExtraction("Validtaion Points_Input Sheet.xlsx", "Validation components", false);
				}
				offervalidations = new OfferDataExtraction().getExcelDataExtraction("Validtaion Points_Input Sheet.xlsx",
						"COA Install_Validations", false);

			} catch (Exception ex) {

			}
			List<Object[]> dataArray = new ArrayList<Object[]>();
			for (HashMap data : excelData) {

				if (offervalidations!=null) {
					HashMap<String, String> offervalidation = offervalidations.get(data.get("S_No"));
					if (offervalidation!=null) {

						Iterator<Map.Entry<String, String>> itr = offervalidation.entrySet().iterator();

						while (itr.hasNext()) {
							Map.Entry<String, String> entry = itr.next();

							data.put(entry.getKey(), entry.getValue());

						}
					}
				}
				dataArray.add(new Object[] { data });
			}
			return dataArray.iterator();
		}
}
