/*package com.automation.test.order;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.commons.codec.binary.Base64;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.DatatypeConverter;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UploadInJira {

	static HashMap<String, HashMap<String, String>> Testcases = new HashMap<String, HashMap<String, String>>();

	synchronized public void getTCdetail(String userName, String Pwd) {
		ObjectMapper mapper = new ObjectMapper();

		try {

			JsonNode rootNode = mapper.readTree(getTCdetails(userName, Pwd));
			JsonNode idNode = rootNode.path("executions");

			// Pretty print
			String prettyStaff1 = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(idNode);

			List<execution> Tc = Arrays.asList(mapper.readValue(prettyStaff1, execution[].class));

			for (execution tc : Tc) {

				Testcases.put(tc.getSummary(), new HashMap<String, String>());
				Testcases.get(tc.getSummary()).put("id", tc.getId());
				Testcases.get(tc.getSummary()).put("issueKey", tc.getIssueKey());
				Testcases.get(tc.getSummary()).put("executionStatus", tc.getExecutionStatus());

			}

		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	synchronized public void UpdateJira(String Filelocation, String TestID,String testCaseName, String userName, String Pwd) {

		try {
			String executionid = null;
			String jiraID = null;
			String executionStatus = null;

			if (DriverTestScript.projectId != 0 && DriverTestScript.versionId != 0 && DriverTestScript.cycleId != 0) {

				if (!DriverTestScript.username.equalsIgnoreCase("")
						&& !DriverTestScript.encryptedpwd.equalsIgnoreCase("")) {

					userName = DriverTestScript.username;
					Pwd = DriverTestScript.encryptedpwd;

				}
				
				
				byte[] decryptedPasswordBytes = java.util.Base64.getDecoder().decode(Pwd);
				String decryptedPassword = new String(decryptedPasswordBytes);
				String TestcaseNumber=TestID.replace("COA_", "");
				TestcaseNumber=TestcaseNumber.replace("C2G", "");

				if (Testcases.size()==0) {

					getTCdetail(userName, decryptedPassword);

				}

				Iterator<Entry<String, HashMap<String, String>>> itr = Testcases.entrySet().iterator();

				while (itr.hasNext()) {
					Entry<String, HashMap<String, String>> entry = itr.next();
					System.out.println(entry.getKey().toLowerCase());
					
						if (entry.getKey().toLowerCase().contains(TestcaseNumber.toLowerCase())){
						
							String entryvalue= entry.getKey().toLowerCase().replaceAll("[^a-zA-Z0-9]", "");
							String testCaseNamevalue= testCaseName.toLowerCase().replaceAll("[^a-zA-Z0-9]", "");
							
							if (entryvalue.contains(testCaseNamevalue.toLowerCase())) {					
						
						executionid = entry.getValue().get("id");
						jiraID = entry.getValue().get("issueKey");
						executionStatus = entry.getValue().get("executionStatus");
						break;
						}
					}

				}

				if (!executionStatus.equalsIgnoreCase("1")) {

					String url = "https://onejira.verizon.com/rest/api/2/issue/" + jiraID + "/attachments";

					

					File reportlocation = new File(Filelocation + "\\" + TestID);

					File docfile = new File(reportlocation.getAbsolutePath() + "\\" + TestID + ".docx");

					// File Size in MB
					float fileSize = docfile.length() / 1024 / 1024;

					if (fileSize <= 9) {

						try {
							HttpClient client = HttpClientBuilder.create().build();
							HttpPost post = new HttpPost(url);
							post.setHeader("Authorization", basicAuthHeader(userName, decryptedPassword));
							post.setHeader("X-Atlassian-Token", "nocheck");
							HttpEntity reqEntity = MultipartEntityBuilder.create()
									.setMode(HttpMultipartMode.BROWSER_COMPATIBLE)
									.addBinaryBody("file", new FileInputStream(docfile),
											ContentType.APPLICATION_OCTET_STREAM, docfile.getName())
									.build();
							post.setEntity(reqEntity);
							post.setHeader(reqEntity.getContentType());
							HttpResponse response = client.execute(post);
							passinJira(userName, decryptedPassword, executionid);

						}

						catch (Exception ex) {
							ex.printStackTrace();

						}

					} else {

						try {
							HttpClient client = HttpClientBuilder.create().build();
							HttpPost post = new HttpPost(url);
							post.setHeader("Authorization", basicAuthHeader(userName, decryptedPassword));
							post.setHeader("X-Atlassian-Token", "nocheck");

							MultipartEntityBuilder MultipartEntitybuilder = MultipartEntityBuilder.create()
									.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);

							File[] listOfFiles = reportlocation.listFiles();

							for (File file : listOfFiles) {

								if (file.getName().contains(".png")) {

									MultipartEntitybuilder.addBinaryBody("file", new FileInputStream(file),
											ContentType.APPLICATION_OCTET_STREAM, file.getName());

								}

							}
							HttpEntity reqEntity = MultipartEntitybuilder.build();
							post.setEntity(reqEntity);
							post.setHeader(reqEntity.getContentType());
							HttpResponse response = client.execute(post);
							passinJira(userName, decryptedPassword, executionid);

						}

						catch (Exception ex) {
							ex.printStackTrace();

						}

					}


				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();

		}
	}

	synchronized void passinJira(String userName, String Pwd, String executionid) {

		String data = "{\"status\":\"1\"}";

		System.out.println(data);
		try {
			HttpPut post = new HttpPut("https://onejira.verizon.com/rest/zapi/latest/execution/"+executionid+"/execute");
			String encoding = new String(Base64.encodeBase64((userName.toString() + ":" + Pwd.toString()).getBytes()));
			post.setHeader("Authorization", "Basic " + encoding);
			StringEntity input1 = new StringEntity(data, "UTF-8");
			input1.setContentType("application/json");
			post.setEntity(input1);
			HttpResponse response = new DefaultHttpClient().execute(post);
			int responseCode = response.getStatusLine().getStatusCode();
			HttpEntity httpEntity = response.getEntity();
			String apiOutput = EntityUtils.toString(httpEntity);
			System.out.println(apiOutput);

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public static String basicAuthHeader(String user, String pass) {
		if (user == null || pass == null)
			return null;
		try {
			byte[] bytes = (user + ":" + pass).getBytes("UTF-8");
			String base64 = DatatypeConverter.printBase64Binary(bytes);
			return "Basic " + base64;
		} catch (IOException ioe) {
			throw new RuntimeException("Stop the world, Java broken: " + ioe, ioe);
		}
	}

	synchronized String getTCdetails(String userName, String Pwd) {
		String apiOutput = "";

		if (DriverTestScript.projectId != 0 && DriverTestScript.versionId != 0 && DriverTestScript.cycleId != 0) {

			try {
				HttpGet post = new HttpGet(
						"https://onejira.verizon.com/rest/zapi/latest/execution?projectId=" + DriverTestScript.projectId
								+ "&versionId=" + DriverTestScript.versionId + "&cycleId=" + DriverTestScript.cycleId);
				String encoding = new String(
						Base64.encodeBase64((userName.toString() + ":" + Pwd.toString()).getBytes()));
				post.setHeader("Authorization", "Basic " + encoding);
				HttpResponse response = new DefaultHttpClient().execute(post);
				int responseCode = response.getStatusLine().getStatusCode();
				HttpEntity httpEntity = response.getEntity();
				apiOutput = EntityUtils.toString(httpEntity);
				System.out.println(apiOutput);

			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return apiOutput;

	}

}

@JsonIgnoreProperties(ignoreUnknown = true)
class execution {

	@JsonProperty("id")
	String id;
	@JsonProperty("executionStatus")
	String executionStatus;
	@JsonProperty("issueKey")
	String issueKey;
	@JsonProperty("summary")
	String summary;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getExecutionStatus() {
		return executionStatus;
	}

	public void setExecutionStatus(String executionStatus) {
		this.executionStatus = executionStatus;
	}

	public String getIssueKey() {
		return issueKey;
	}

	public void setIssueKey(String issueKey) {
		this.issueKey = issueKey;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

}
*/