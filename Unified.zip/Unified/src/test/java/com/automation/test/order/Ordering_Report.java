package com.automation.test.order;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Ordering_Report extends Report_Methods{

	public static void main(String[] args) throws IOException {
		//Ordering_Report or = new Ordering_Report();
		//or.OrderingReport();
	}
		// TODO Auto-generated method stub
	String TestNGXmlPath=new File(System.getProperty("user.dir")).getAbsolutePath();
	public  void OrderingReport() throws IOException{
		Report_Methods RM = new Report_Methods();
		
		String fileName = new File(System.getProperty("user.dir")).getAbsolutePath()+"/Report/Execution_Report/FinalResult/ExcelReport.xlsx";
		String filehtmlName = new File(System.getProperty("user.dir")).getAbsolutePath()+"/Report/Execution_Report/FinalResult/Report.html";
		
	    
       /* FileInputStream fileInputStreamReport = null;
        Workbook workbookReport = null;
        fileInputStreamReport = new FileInputStream(FileNameNew+"/ExcelReport.xlsx");
        System.out.println(FileNameNew);
        workbookReport = new XSSFWorkbook(fileInputStreamReport);*/
			
		//opening output excel file  in read mode
		    fil = new FileInputStream(fileName);
		    excel_wb = new XSSFWorkbook(fil);
		    
		    fw= new FileWriter(filehtmlName);
	    	bw = new BufferedWriter(fw); 
	    	
	        runTime = RM.get_DateIST();
	    	
	    	ArrayList<String> listColNames= new ArrayList<String>();
	    	
	    	listColNames.add("IP");
	    	listColNames.add("Environment");
	    	listColNames.add("Application");
	    	listColNames.add("FlowType"); 
	    	listColNames.add("ManualTestCaseName");
	    	listColNames.add("totalSteps");
	    	listColNames.add("TestResult");
	    	listColNames.add("MON");
	    	listColNames.add("ErrorMessage");
	    	listColNames.add("session");
	    	
	    	
	    	
	    	
	    	//RM.create_message();
	    	//RM.create_statistics();
	    	RM.create_table(listColNames);
	    	//RM.create_salutation();
	    	
	    	
	    	System.out.println("file is written");

	    	//close the file being updated ; write  and close the excel
	    	         RM.fil.close();	


	    	// stop writting and close file
	    		     bw.close();  //(close the bufferredwrite)
	    			 fw.close();

	}

}


