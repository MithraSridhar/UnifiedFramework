package com.automation.ui.pages;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_CallingFrom_PageObjects;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

public class SimplexCallingFromPage extends Simplex_CallingFrom_PageObjects {

    String objectValue = "";

    static boolean windows = InitiateDriver.windows;
    

    String description = "", expected = "", actual = "", failure = "", getUrl;
    By by;
    String testId;
    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);
    /**
     * SimplexCallingFromPage constructor invokes the super class constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     *             
     *             
     */
    public SimplexCallingFromPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, windows, report, data);
	this.testId = testId;
    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     */
    public static SimplexCallingFromPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexCallingFromPage.class, testId, report, data);
    }

    /**
     * Navigation start for Calling From Page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void start() throws Exception {

	setIterator();

	System.out.println("Calling from page..");
	if (get("FlowType").equalsIgnoreCase("Install")) {

	    setCustomerInfo();

	}
	else if(get("FlowType").equalsIgnoreCase("Change") && !get("Search_Value_Type").isEmpty()){
	
		AdvancedSearch();
	} 
	else if(get("FlowType").equalsIgnoreCase("SmartChange")){  //Anu added
		
		SmartCartFlow();
	}
	else { // For all other flows

	    setAccountSearchInfo();
	}

    }
	
	 private void SmartCartFlow() throws Exception,UserDefinedException  { //Anu added
    	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
    	try{
    		System.out.println("Calling From Page-->In Account search Tab, Smart Cart Flow");
    	    // Give Customer info
    	    strDescription = "Negotiating Account Search details";
    	    strExpected = "Giving Account Search details";
    	    strActual = "Giving Account Search Details in Calling From Page was successful";
    	    strFailed = "Giving Account Search Details in Calling From Page was not successful";
    	    getUrl = ", URL Launched --> " + returnURL();
    	    String agencyId = get("AgencyID").trim();
    	    String Search_Value_Type = get("Search_Value_Type").trim();
    	    String txtLineOfBusiness = get("LOB_Type").trim();
    	    String accNo =get("Search_Value").trim();
    	    String callingPartyName = get("Calling_Party_Name").trim();
    	    String alternatePhone = get("Alternate_Phone_No").trim();
    	   
    	    
    	    if(isDisplayed(txtSearchCallingPartyName, "", 30))
    	    {
    	    	System.out.println("Calling Party Name Text Box Displayed");
    	    }
    	    try{
    	    	if (!agencyId.isEmpty()) {	 
    		    	   
    		    	   if(isDisplayed(acstSearch_SalesProfile))
    		    	   {
    		    	   	   clickUsingJavaScript(acstSearch_SalesProfile, "");
    		    	   }
    				waitForLoader();
    				if (isDisplayed(salesProfileSave, "", 30)) {
    		    	//setSalesProfileInfo();
    				if (!agencyId.trim().isEmpty()) {
    				    selectDropDownUsingVisibleText(selectAgencyID, "", agencyId);
    				    report.reportPass("Verify Agency ID in sales Profile", "Agency ID " +agencyId+ " should be selected", "Agency ID "+agencyId+" is selected");
    				}

    				
    				    clickUsingJavaScript(salesProfileSave, "");
    				    report.reportPass("Verify Save is clicked in sales Profile", "Save should be clicked", "Save is clicked");
    				  waitForLoader();
    				}	    
    		    }
    	    	if (isDisplayed(newaccount, "", 30)){
    	    		clickUsingJavaScript(newaccount, ""); 
    	    		
    	    		waitForLoader();
    	    		
    	    		if (isDisplayed(txtAlternatePhoneNumber, strFailed, 0)) {
    	                waitForLoader();    	                
    	                mouseclick(txtAlternatePhoneNumber, strFailed);
    	                waitForLoader();
    	                clickUsingJavaScript(txtAlternatePhoneNumber, "");
    	               
    	                setText(txtAlternatePhoneNumber, objectValue, alternatePhone);
    	                report.reportPass("Enter alternate phone no.", "Alternate phone no should be entered.", "Selected "+alternatePhone+" alternate phone no.");
    	             }
    	    		
    	    		if (isDisplayed(lineOfBusiness, "", 0)){
    	    			lineOfBusiness.sendKeys(Keys.TAB);
    	    			waitForLoader();
    	    			selectDropDownUsingValue(lineOfBusiness, "", txtLineOfBusiness);
    	    			System.out.println("LOB Consumer is selected");    	    			
    	    		}
    	    }
    	    		 waitForLoader();
    	    		 if (isDisplayed(searchtab, "", 30)){
    	    			 clickUsingJavaScript(searchtab, "");    	    			 
    	    		 }
    	    	
    	    	
    	    	if (isDisplayed(txtNewACCallingPartyName1, strFailed,0)) {

    	               setText(txtNewACCallingPartyName1, objectValue, callingPartyName);
    	               report.reportPass("Enter calling party name", "Calling party name should be entered.", "Entered "+callingPartyName+" calling party name.");
    	               waitForLoader();
    	            }
    	    	if (isDisplayed(txboxAccountsearch, strFailed)) {
    				
    				clickUsingJavaScript(txboxAccountsearch, objectValue);
    				setText(txboxAccountsearch, objectValue, accNo);
    				waitForLoader();    				
    				report.reportPass("Account search tab -- Enter account no.", "Account no should be selected.", "Entered "+accNo+" account number.");
    				Thread.sleep(2000);    				
    				waitForLoader();
    			    }
    	    	  if (isDisplayed(btnNext, "")) {
    					Actions action = new Actions(driver);
    					action.moveToElement(driver.findElement(By.xpath("//button[@ng-click='moveNextPage()']"))).perform();
    					clickUsingJavaScript(btnNext, "");
    					report.reportPass("Click on next button of Account search tab.", "Next button should be clicked on Account search tab.", "Clicked on Next button of Account search tab.");
    					waitForLoader();    				
    				    }
    				    if (isDisplayed(AccountNtFound, "", 6)) {
    					    strFailed = "Account search was not Success";
    					    String strtxt = AccountNtFound.getText();
    					    report.reportFail("Verify Account Pull is Succssfull or not.", "Account putll is not Successful",
    					    strFailed);
    					report.updateMainReport("comments", strFailed + strtxt);
    					report.updateMainReport("ErrorMessage", strFailed+strtxt);
    					logger.error(strFailed);
    					captureErrorMsg(strFailed);
    					throw new UserDefinedException(strFailed); 
    			
    					}
    				    if (isDisplayed(salesProfileSave, "", 30))
    				    	clickUsingJavaScript(salesProfileSave, "");
    					
    					waitForLoader();
    					if (isDisplayed(btnNext, "")) {
        					Actions action = new Actions(driver);
        					action.moveToElement(driver.findElement(By.xpath("//button[@ng-click='moveNextPage()']"))).perform();
        					clickUsingJavaScript(btnNext, "");
        					report.reportPass("Click on next button of Account search tab.", "Next button should be clicked on Account search tab.", "Clicked on Next button of Account search tab.");
        					waitForLoader();    				
        				    }
    	    	
    	    }
            catch(Exception e){
              strFailed = "Failed in Sales Profile Info, Required Agency ID is not displayed post clicking Agency ID dropdown";
                report.reportFail("Verify in sales Profile Info.", "Required Agency ID is not displayed post clicking Agency ID dropdow",
                        strFailed);
                    report.updateMainReport("comments", strFailed);
                    report.updateMainReport("ErrorMessage", strFailed);
                    logger.error(strFailed);
                    captureErrorMsg(strFailed);
                    throw new UserDefinedException(strFailed);
            }

    	    
    	}
		
	
    	catch (Exception exe) {
    	    exe.printStackTrace();
    	    
    	}
    }

    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void navigateTo() throws Exception {

	// To increment the navigation iteration
	int i = TestIterator.getIterator(testId);
	TestIterator.setIterator(testId, ++i);

    }

    public void setCustomerInfo() throws Exception {

        String strDescription = "", strExpected = "", strActual = "", strFailed = "";
        try {
        	System.out.println("Calling From Page-->In Customer Info");
            // Give Customer info
            strDescription = "Enter customer info details";
            strExpected = "Customer details should be entered.";
            strActual = "Entered customer details.";
            strFailed = "Unable to enter customer details..Failed in calling from page.";
            getUrl = ", URL Launched --> " + returnURL();

            waitForLoader();
            
            try{
            waitForElementDisplay(btnNewAccount, objectValue, pageTimeoutInSeconds);
            } catch (Exception e) {

                      strFailed = "Failed in Calling from page, Customer info page was not displayed even after "+pageTimeoutInSeconds+" secs.";
                      report.reportFail("Verify Whether New Account is displayed", "New Account should be displayed", strFailed);
                      report.updateMainReport("comments", strFailed);
                      report.updateMainReport("ErrorMessage", strFailed);
                      logger.error(strFailed);
                      captureErrorMsg(strFailed);
                      throw new UserDefinedException(strFailed);             
                      
                   }
               if (isDisplayed(btnNewAccount, "", 0)) {
                   clickUsingJavaScript(btnNewAccount, objectValue);

                   report.reportPass("Click on New account." + getUrl, "New account should be clicked.", "Clicked on Account.");
                   //maximizeBrowserWindow();
               }

               waitForLoader();
        
            // For GUI Validations...
            if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
               UIValidations_NewAccountTab();
               UIValidation_Customer_Info_Tab();
            }

            String callingPartyName = get("Calling_Party_Name").trim();
            String callBackNo = get("Call_Back_No").trim();
            String email = get("Email_ID").trim();

           

            waitForLoader();

            try {
               waitForElementDisplay(txtNewACCallingPartyName, objectValue, pageTimeoutInSeconds);
            } catch (Exception e) {

               strFailed = "Failed in Calling from page, Customer info page was not displayed even after "+pageTimeoutInSeconds+" secs.";
               report.reportFail("Enter calling party name.", "Calling party name should be entered.", strFailed);
               report.updateMainReport("comments", strFailed);
               report.updateMainReport("ErrorMessage", strFailed);
               logger.error(strFailed);
               captureErrorMsg(strFailed);
               throw new UserDefinedException(strFailed);             
               
            }

            // Calling party
            if (isDisplayed(txtNewACCallingPartyName, strFailed,0)) {

               setText(txtNewACCallingPartyName, objectValue, callingPartyName);
               report.reportPass("Enter calling party name", "Calling party name should be entered.", "Entered "+callingPartyName+" calling party name.");

            }
            // Call Back no
            if (isDisplayed(txtNewACCallBackNo, strFailed,0)) {

               setText(txtNewACCallBackNo, objectValue, callBackNo);
               report.reportPass("Enter call back no.", "Call back no should be entered.", "Entered "+callBackNo+" call back no.");
               waitForLoader();
            }

            // Reason for call
            if (isDisplayed(dropdwnNewACReasonForCall, strFailed, 0)) {

               String reasonForCall = get("Reason_For_Call").trim();
               selectDropDownUsingVisibleText(dropdwnNewACReasonForCall, objectValue, reasonForCall);
               clickUsingJavaScript(dropdwnNewACReasonForCall, "");
               report.reportPass("Select reason for call.", "Reason for call should be selected.", "Selected "+reasonForCall+" reason for call.");
            }

            // Alternative phone no
            if (isDisplayed(txtAlternatePhoneNumber, strFailed, 0)) {
               waitForLoader();
               String alternatePhone = get("Alternate_Phone_No").trim();
               mouseclick(txtAlternatePhoneNumber, strFailed);
               waitForLoader();
               clickUsingJavaScript(txtAlternatePhoneNumber, "");
               setText(txtAlternatePhoneNumber, objectValue, alternatePhone);
               report.reportPass("Enter alternate phone no.", "Alternate phone no should be entered.", "Selected "+alternatePhone+" alternate phone no.");
            }
            String Browser = get("Browser").trim();

            // Line of Business type
            if (isDisplayed(lineOfBusiness, "", 0)) {

               String txtLineOfBusiness = get("LOB_Type").trim();
               if(Browser.equalsIgnoreCase("IE"))
          		{
         			WebElement dropdown = driver.findElement(By.xpath("//select[@id='lineOfBusiness']"));
         	        Select select = new Select(dropdown);
         	        select.selectByValue(txtLineOfBusiness);
         	        WebElement webElement = driver.findElement(By.xpath("//select[@id='lineOfBusiness']"));
         	        webElement.sendKeys(Keys.TAB);
         	        webElement.sendKeys(Keys.ENTER);
          		
          		}
          		else
          		{
          			selectDropDownUsingVisibleText(lineOfBusiness, "", txtLineOfBusiness);
          		}
                  
               selectDropDownUsingVisibleText(lineOfBusiness, "", txtLineOfBusiness);
               report.reportPass("Select line of business", "Line of business should be selected.", "Selected line of business: " + txtLineOfBusiness);

            }

            //click(LabelEmail);
            
            // Email
            if (isDisplayed(txtEmail, strFailed)) {
               clickUsingJavaScript(txtEmail, "");
               setText(txtEmail, objectValue, email);
               clickUsingJavaScript(txtEmail, "");
               report.reportPass("Enter email.", "Email id should be entered.", "Entered "+email+" email id.");
            }
            waitForLoader();
            // next button
            if (isDisplayed(btnNext, "")) {
               clickUsingJavaScript(btnNext, "");
               report.reportPass("Click on next button of customer info tab.", "Next button should be clicked on customer info tab.", "Clicked on Next button of Customer info tab.");
               waitForLoader();
            }
            
            
            if (!isDisplayed(currentActiveTab, "address-search", 15)) {
               
               strFailed = "Failed in Calling from page, Address Search tab is not displayed post clicking next button in Customer info tab.";
               report.reportFail("Address Search tab is active or not.", "Address Search tab should be active", strFailed);
               report.updateMainReport("comments", strFailed);
               report.updateMainReport("ErrorMessage", strFailed);
               logger.error(strFailed);
               captureErrorMsg(strFailed);
               throw new UserDefinedException(strFailed);
               
            }

        } catch (Exception exe) {
            if (!isUserDefinedException(exe)) {
               report.reportFail(strDescription + getUrl, strExpected, strFailed);
               report.updateMainReport("ErrorMessage", strFailed);
               captureErrorMsg("Failed in Internet section.");
            }

            throw exe;
        }

        setSearchAndVerifyAddress();
     }


    public void setSearchAndVerifyAddress() throws Exception {

        String strDescription = "", strExpected = "", strActual = "", strFailed = "";
        try {
        	System.out.println("Calling From Page-->In Address Search  & Verify Address Tab");
            // Search for an existing account no
            strDescription = "Search and verify address details.";
            strExpected = "Giving Address info in details";
            strActual = "Search and verify address in Calling From Page was successful";
            strFailed = "Search and verify address in Calling From Page was not successful";
            getUrl = ", URL Launched --> " + returnURL();

            waitForLoader();

            // For GUI Validations...***
            if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
               UIValidations_AddressSearchTab();
            }

            // Gopal Update 10/04/2017 
            
            if(get("FlowType").trim().equalsIgnoreCase("Change") && (!get("Zipcode").trim().isEmpty()))
            {
            	 waitForLoader();
                 if (isDisplayed(btnNext, "")) {
                     clickUsingJavaScript(btnNext, "");
                     report.reportPass("Click on next button of Address search tab.", "Next button should be clicked on address search tab.", "Clicked on Next button of address search tab.");

                 }

                 waitForLoader();
                 waitForLoader();
                 
                 if (isDisplayed(firstMultipleAddress, "", 3)) {
                     clickUsingJavaScript(firstMultipleAddress, "");
                     report.reportPass("Click on First Address in the Multiple Addresses", "First Address in the Multiple Addresses should be clicked", "Clicked on First Address in the Multiple Addresses");
                     clickUsingJavaScript(btnNext, "");
                     waitForLoader();
                     waitForLoader();
                     report.reportPass("Click on Next Button", "Next Button should be clicked", "Clicked on Next Button");
                 }
                 else if(isDisplayed(SingleAddress, "", 3))
                 {
                	 clickUsingJavaScript(SingleAddress, "");
                     report.reportPass("Click on Single Addresses", "Single Addresses should be clicked", "Single Address in the Multiple Addresses");
                     clickUsingJavaScript(btnNext, "");
                     waitForLoader();
                     waitForLoader();
                     report.reportPass("Click on Next Button", "Next Button should be clicked", "Clicked on Next Button");
                 }
                   
                   
            }
            else{


            String txtZipcode = get("Zipcode").trim();
            String txtAddress = get("Address").trim();

                     
            
            
            if (!get("FlowType").equalsIgnoreCase("SuppMove") && !get("FlowType").equalsIgnoreCase("Change")) {
               waitForLoader();
                      waitForLoader();
                      
                    //Vikram script start 
                      //Advance address search 
                      if(get("FlowType").equalsIgnoreCase("Install") && get("Application").equalsIgnoreCase("CoA") && get("Search_Value_Type").equalsIgnoreCase("Advance_address")){
                   	   
                    	  //vikram script start - Advance address search field values
                          String adv_HouseNumber = get("HouseNumber").trim();
                          String adv_StreetDirection = get("StreetDirection").trim();
                          String adv_StreetName = get("StreetName").trim();
                          String adv_StreetType = get("StreetType").trim();
                          String adv_DirectionalSuffix = get("DirectionalSuffix").trim();
                          String adv_Structure = get("Structure").trim();
                          String adv_BuildingDetails = get("BuildingDetails").trim();
                          String adv_Floor = get("Floor").trim();
                          String adv_Unit = get("Unit").trim();
                          String adv_UnitDetails = get("UnitDetails").trim();
                          String adv_City = get("City").trim();
                          String adv_State = get("State").trim();
                          //Vikram script end 
                          
                   	   clickUsingJavaScript(AdvancedSearchLink, "");
                   	   waitForLoader();
                      	
                   	   if (isDisplayed(addressHouseNumber, "", 3) && !adv_HouseNumber.isEmpty()) {
                              setText(addressHouseNumber, objectValue, adv_HouseNumber);
                              report.reportPass("Advance Address search tab -- enter house number .", "house number should be entered.", "Entered "+ adv_HouseNumber +" house number.");
                              waitForLoader();
                              System.out.println("Entered House number");                                  
                          }
                   	   
                   	   if (isDisplayed(addressStreetDirection, "", 3) && !adv_StreetDirection.isEmpty()) {
                   		   //Actions action = new Actions(driver);
                              //action.moveToElement(addressStreetDirection).click().build().perform(); 
                   		   selectDropDownUsingVisibleText(addressStreetDirection, "", adv_StreetDirection);         			    
                              report.reportPass("Advance Address search tab -- enter house number .", "house number should be entered.", "Entered "+ adv_StreetDirection +" street direction.");
                              waitForLoader();      
                              System.out.println("Entered street direction");
                          }
                   	   
                   	   if (isDisplayed(addressStreetName, "", 3) && !adv_StreetName.isEmpty()) {
                   		   
                              setText(addressStreetName, objectValue, adv_StreetName);
                              report.reportPass("Advance Address search tab -- enter house number .", "house number should be entered.", "Entered "+ adv_StreetName +" street name.");
                              waitForLoader();    
                              System.out.println("Entered street name");
                          } 
                   	   
                   	   if (isDisplayed(addressStreetType, "", 3) && !adv_StreetType.isEmpty()) {
                   		   
                   		   selectDropDownUsingVisibleText(addressStreetType, "", adv_StreetType);
                              report.reportPass("Advance Address search tab -- enter directional sufix.", "house number should be entered.", "Entered "+ adv_StreetType +" street type.");
                              waitForLoader();    
                              System.out.println("Entered entered street type");
                          }
                   	   
                   	   if (isDisplayed(addressDirectionalSuffix, "", 3) && !adv_DirectionalSuffix.isEmpty()) {
                   		   
                   		   selectDropDownUsingVisibleText(addressDirectionalSuffix, "", adv_DirectionalSuffix);
                              report.reportPass("Advance Address search tab -- enter directional sufix.", "house number should be entered.", "Entered "+ adv_DirectionalSuffix +" directional sufix.");
                              waitForLoader();    
                              System.out.println("Entered entered directional sufix");
                          }
                   	   
                   	   if (isDisplayed(addressStructure, "", 3) && !adv_Structure.isEmpty()) {
                   		   
                   		   selectDropDownUsingVisibleText(addressStructure, "", adv_Structure);
                              report.reportPass("Advance Address search tab -- enter structure.", "house number should be entered.", "Entered "+ adv_Structure +" structure.");
                              waitForLoader();    
                              System.out.println("Entered structure");
                          }
                   	   
                   	   if (isDisplayed(addressBuildingDetails, "", 3) && !adv_BuildingDetails.isEmpty()) {
                   		   
                   		   setText(addressBuildingDetails, objectValue, adv_BuildingDetails);
                              report.reportPass("Advance Address search tab -- enter street tye.", "house number should be entered.", "Entered "+ adv_BuildingDetails +" building details.");
                              waitForLoader();    
                              System.out.println("Entered building details");
                          }
                   	   

                   	   if (isDisplayed(addressFloor, "", 3) && !adv_Floor.isEmpty()) {
                   		   
                   		   setText(addressFloor, objectValue, adv_Floor);
                              report.reportPass("Advance Address search tab -- enter street tye.", "house number should be entered.", "Entered "+ adv_Floor +" floor number.");
                              waitForLoader();    
                              System.out.println("Entered Floor");
                          }
                   	   
                   	   
                   	   if (isDisplayed(addressUnit, "", 3) && !adv_Unit.isEmpty()) {
                   		   
                   		   selectDropDownUsingVisibleText(addressUnit, "", adv_Unit);
                              report.reportPass("Advance Address search tab -- enter street tye.", "house number should be entered.", "Entered "+ adv_StreetType +" unit.");
                              waitForLoader();    
                              System.out.println("Entered Unit");
                          }
                   	   
                   	   if (isDisplayed(addressUnitDetails, "", 3) && !adv_UnitDetails.isEmpty()) {
                   		   
                   		   setText(addressUnitDetails, objectValue, adv_UnitDetails);
                              report.reportPass("Advance Address search tab -- enter street tye.", "house number should be entered.", "Entered "+ adv_UnitDetails +" unit details.");
                              waitForLoader();    
                              System.out.println("Entered Unit details");
                          }

                   	   if (isDisplayed(addressCity, "", 3) && !adv_City.isEmpty()) {
       	   
                   		   setText(addressCity, objectValue, adv_City);
                   		   report.reportPass("Advance Address search tab -- enter street tye.", "house number should be entered.", "Entered "+ adv_City +" city.");
                   		   waitForLoader();    
                   		   System.out.println("Entered city");
                   	   }

                   	   if (isDisplayed(addressState, "", 3) && !adv_State.isEmpty()) {
       	   
                   		   selectDropDownUsingVisibleText(addressState, "", adv_State);
                   		   report.reportPass("Advance Address search tab -- enter street tye.", "house number should be entered.", "Entered "+ adv_State +" state.");
                   		   waitForLoader();    
                   		   System.out.println("Entered state");
                   	   }
                   	   
                   	   if (isDisplayed(addressZipCode, "", 3) && !txtZipcode.isEmpty()) {
                   		   
                   		   setText(addressZipCode, objectValue, txtZipcode);
                   		   report.reportPass("Advance Address search tab -- enter street tye.", "house number should be entered.", "Entered "+ txtZipcode +" zip code.");
                   		   waitForLoader();    
                   		   System.out.println("Entered zip code");
                   	   }
                   	   
                   	   if (isDisplayed(btnNext, "")) {
                              clickUsingJavaScript(btnNext, "");
                              report.reportPass("Click on next button of Address search tab.", "Next button should be clicked on address search tab.", "Clicked on Next button of address search tab.");
                          }  
                          waitForLoader();
                         
                      }
                      // vikram script end   
                      
                      
               if (isDisplayed(zipCode, strFailed, 3)) {
                   setText(zipCode, objectValue, txtZipcode);
                   report.reportPass("Address search tab -- enter zip code.", "Zip code should be entered.", "Entered "+txtZipcode+" zip code.");
                   waitForLoader();
                   Actions action = new Actions(driver);
                      action.moveToElement(driver.findElement(By.xpath("//input[@id='addressAddress']"))).click().build().perform();
        
               }
               waitForLoader();
               
        
               if (isDisplayed(address, strFailed, pageTimeoutInSeconds)) {
                   
                   clickUsingJavaScript(address, txtAddress);
                   clearText(address, txtAddress);
                setText(address, "", txtAddress);
                report.reportPass("Address search tab -- Enter address.", "Address should be entered.", "Entered "+txtAddress+" address.");
                report.reportPass("Address search tab -- Enter address.", "Address should be entered.", "Entered "+txtAddress+" address.");
                if (isDisplayed(currentActiveTab, "verify-address", 4)) {
                    
                }
                else  if (isDisplayed(btnNext, "")) {
                    clickUsingJavaScript(btnNext, "");
                    report.reportPass("Click on next button of Address search tab.", "Next button should be clicked on address search tab.", "Clicked on Next button of address search tab.");

                }  
                waitForLoader();
                waitForLoader();
            }
                

              if (isDisplayed(firstMultipleAddress, "", 3)) {
                   clickUsingJavaScript(firstMultipleAddress, "");
                   report.reportPass("Click on First Address in the Multiple Addresses", "First Address in the Multiple Addresses should be clicked", "Clicked on First Address in the Multiple Addresses");
                   clickUsingJavaScript(btnNext, "");
                   waitForLoader();
                   waitForLoader();
                   report.reportPass("Click on Next Button", "Next Button should be clicked", "Clicked on Next Button");
                   
               
            // advance search
               if (isDisplayed(AdvancsearchNew, "", 2)) {
            	   
            	   clickUsingJavaScript(AdvancsearchNew, "");
       		    report.reportPass(strDescription, strExpected, strActual);
       		 
       		    AdvanceSearch();  
       		
         
       		  }
              if ((isDisplayed(salesProfileInformationTab, "", 5))) {  
            	   setSalesProfileInfo();
            	   report.reportPass(strDescription, strExpected, strActual); 
               }
               else if (isDisplayed(currentActiveTab, "availableServices", 4)) {
              	   setSalesProfileInfo();  
                }
                 else if (isDisplayed(currentActiveTab, "verify-address", 4)) {
            	   if (isDisplayed(btnNext, "",6)) {
                       clickUsingJavaScript(btnNext, "");
                       report.reportPass("Click on next button of verify Address tab.", "Next button should be clicked on verify address tab.", "Clicked on Next button of verify address tab.");
                      
                       waitForLoader();
                       waitForLoader();
                       waitForLoader();
                       waitForLoader();
                       waitForLoader();
                   }
              	   setSalesProfileInfo();  
                }
                 
               }
        
               else if ((isDisplayed(salesProfileInformationTab, "", 5))) {  
            	   setSalesProfileInfo();
            	   report.reportPass(strDescription, strExpected, strActual); 
               }
               else{
			   if(get("Application").equalsIgnoreCase("CoA") &&	!get("FlowType").contains("Move")){
               if (!isDisplayed(currentActiveTab, "verify-address", 30)) {
                   strFailed = "Failed in Calling from page,Verify address tab is not displayed post clicking next button in Address Search tab.";
                   report.reportFail("Verify address tab is active or not.", "Verify address tab should be active",
                          strFailed);
                      report.updateMainReport("comments", strFailed);
                      report.updateMainReport("ErrorMessage", strFailed);
                      logger.error(strFailed);
                      captureErrorMsg(strFailed);
                      throw new UserDefinedException(strFailed);
                   
               }
			   }
               

               if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
            	   if (isDisplayed(currentActiveTab, "verify-address", 10)) {
                   UIValidation_Verify_Address_Tab();
            	   }
               }

               waitForLoader();
               if ((isDisplayed(currentActiveTab, "availableServices", 6))) {
            	
            	   if (isDisplayed(btnNext, "",6)) {
                       clickUsingJavaScript(btnNext, "");
                       report.reportPass("Click on next button of verify Address tab.", "Next button should be clicked on verify address tab.", "Clicked on Next button of verify address tab.");
                      
                       waitForLoader();
                   }
                 
               }
               
               else{
            	   
               
               if (isDisplayed(btnNext, "",6)) {
                   clickUsingJavaScript(btnNext, "");
                   report.reportPass("Click on next button of verify Address tab.", "Next button should be clicked on verify address tab.", "Clicked on Next button of verify address tab.");
                  
                   waitForLoader();
               }
               
               if(get("Application").equalsIgnoreCase("COA")){

               if ((isDisplayed(salesProfileInformationTab, "", 2))) {
                     
                   
                  
               }else{
            	   if ((!isDisplayed(currentActiveTab, "availableServices", pageTimeoutInSeconds))) {
                       strFailed = "Failed in Calling from page,AvailableServices or salesprofile tab not displayed post clicking next button in Verify address tab tab.";
                       report.reportFail("Verify Available service tab or sales profile tab active or not.", "Available serivce tab or sales profile tab should be active",
                              strFailed);
                          report.updateMainReport("comments", strFailed);
                          report.updateMainReport("ErrorMessage", strFailed);
                          logger.error(strFailed);
                          captureErrorMsg(strFailed);
                          throw new UserDefinedException(strFailed);      
                       
            	   
               } 
               }
               }
               else{
            	   
            	   if ((!isDisplayed(currentActiveTab, "availableServices", pageTimeoutInSeconds))) {
                       strFailed = "Failed in Calling from page,AvailableServices or salesprofile tab not displayed post clicking next button in Verify address tab tab.";
                       report.reportFail("Verify Available service tab or sales profile tab active or not.", "Available serivce tab or sales profile tab should be active",
                              strFailed);
                          report.updateMainReport("comments", strFailed);
                          report.updateMainReport("ErrorMessage", strFailed);
                          logger.error(strFailed);
                          captureErrorMsg(strFailed);
                          throw new UserDefinedException(strFailed);      
                       
            	   
               }
               }
               setSalesProfileInfo();
               }

               report.reportPass(strDescription + getUrl, strExpected, strActual);

            }

            }
            }
        } catch (Exception exe) {
            exe.printStackTrace();
            if (!isUserDefinedException(exe)) {
               report.reportFail(strDescription + getUrl, strExpected, strFailed);
               report.updateMainReport("ErrorMessage", strFailed);
            }

            throw exe;
        }

      //  if((get("Application").equalsIgnoreCase("C2G") &&(! get("FlowType").equalsIgnoreCase("Move"))) || get("Application").equalsIgnoreCase("CoA") ){
    //        setSalesProfileInfo();

      //  }
        
      

     }

     public void setSalesProfileInfo() throws Exception {

        String strDescription = "", strExpected = "", strActual = "", strFailed = "";
        try {
        	System.out.println("Calling From Page-->In Sales Profile Info Tab");
            // Give Customer info
            strDescription = "Entering sales profile info details.";
            strExpected = "Giving sales profile info in details";
            strActual = "Giving sales profile info in Calling From Page was successful";
            strFailed = "Giving sales profile info in Calling From Page was not successful";
            getUrl = ", URL Launched --> " + returnURL();
            String agencyId = get("AgencyID").trim();
            String Browser = get("Browser").trim();
            String txtLineOfBusiness = get("LOB_Type").trim();

            // For GUI Validations...
         /*   if (get("GUI_Validations").equalsIgnoreCase("Yes")&&(get("Application")).equalsIgnoreCase("COA")) {
               UIValidations_SalesProfile();
            }
         // Gopal Update on 10/04/2017
            if(get("FlowType").trim().equalsIgnoreCase("Change") && (!get("Zipcode").trim().isEmpty()))
            {
            	 if (isDisplayed(salesProfileSave, "", 0) && isDisplayed(agencyDD, "", 0)) {
                     clickUsingJavaScript(salesProfileSave, "");
                     waitForLoader();
                 }
            }


            if (!get("FlowType").equalsIgnoreCase("SuppMove") && !get("FlowType").equalsIgnoreCase("Change")
                   && !(get("FlowType").equalsIgnoreCase("Install") && get("Application").equalsIgnoreCase("C2G"))) {
                   */
              if (!agencyId.trim().isEmpty()) {
            	   if(Browser.equalsIgnoreCase("IE"))
             		{
            		   if(isDisplayed(acstSearch_SalesProfile))
          	    	   {
          	    	   	   clickUsingJavaScript(acstSearch_SalesProfile, "");
          	    	   }
            		WebElement dropdown = driver.findElement(By.xpath("//select[@id='agencyDD']"));
                    Select select = new Select(dropdown);
                    select.selectByValue(agencyId);
                    WebElement webElement = driver.findElement(By.xpath("//select[@id='agencyDD']"));
                    webElement.sendKeys(Keys.TAB);
                    webElement.sendKeys(Keys.ENTER);
             		
             		}
             		else
             		{
             			
             			 if(isDisplayed(acstSearch_SalesProfile))
          	    	   {
          	    	   	   clickUsingJavaScript(acstSearch_SalesProfile, "");
          	    	   }
          			waitForLoader();
          			if (isDisplayed(salesProfileSave, "", 30)) {
          	    	//setSalesProfileInfo();
          			if (!agencyId.trim().isEmpty()) {
          			    selectDropDownUsingVisibleText(selectAgencyID, "", agencyId);
          			    report.reportPass("Verify Agency ID in sales Profile", "Agency ID " +agencyId+ " should be selected", "Agency ID "+agencyId+" is selected");
          			}

          			
          			    clickUsingJavaScript(salesProfileSave, "");
          			    report.reportPass("Verify Save is clicked in sales Profile", "Save should be clicked", "Save is clicked");
          			    waitForLoader();
          				waitForLoader();
          			}	    
          	    }
               }


             /*  if (isDisplayed(salesProfileSave, "", 0) && isDisplayed(agencyDD, "", 0)) {
                   clickUsingJavaScript(salesProfileSave, "");
                   waitForLoader();
               }
               */

               report.reportPass(strDescription + getUrl, strExpected, strActual);

               if (!isDisplayed(currentActiveTab, "availableServices", 5)) {
                   
                   strFailed = "Failed in Calling from page, AvailableServices is not displayed post clicking next button in Verify address tab tab.";
                   report.reportFail("Verify Available service tab active or not.", "Available serivce tab should be active",
                          strFailed);
                      report.updateMainReport("comments", strFailed);
                      report.updateMainReport("ErrorMessage", strFailed);
                      logger.error(strFailed);
                      captureErrorMsg(strFailed);
                      throw new UserDefinedException(strFailed);      
                  
                  
               }
            

        } catch (Exception exe) {
            if (!isUserDefinedException(exe)) {
               report.reportFail(strDescription + getUrl, strExpected, strFailed);
               report.updateMainReport("ErrorMessage", strFailed);
               captureErrorMsg("Failed in Internet section.");
            }

            throw exe;
        }

        setAvailableServicesInfo();

     }

    public void setAvailableServicesInfo() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	try {
		System.out.println("Calling From Page-->In Available Service Tab");
	    strDescription = "Entering available services info details";
	    strExpected = "Giving available services info in details";
	    strActual = "Giving available services info in Calling From Page was successful";
	    strFailed = "Giving available services info in Calling From Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();
	    String Browser = get("Browser").trim();

	    if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
		UIValidation_Available_Services_Tab();
	    }

	    // Line of Business -- added by Shiva
	    if (isDisplayed(lineOfBusiness, "", 0)) {

		String txtLineOfBusiness = get("LOB_Code").trim();
		if(Browser.contains("Chrome"))
		{
		selectDropDownUsingVisibleText(lineOfBusiness, "", txtLineOfBusiness);
		}
		else
		{
			
			WebElement dropdown = driver.findElement(By.xpath("//select[@id='lineOfBusiness']"));
	        Select select = new Select(dropdown);
	        select.selectByValue(txtLineOfBusiness);
	        waitForLoader();
	        WebElement webElement = driver.findElement(By.xpath("//select[@id='lineOfBusiness']"));
	        webElement.sendKeys(Keys.TAB);
	        webElement.sendKeys(Keys.ENTER);
		}
		
		report.reportPass("Select line of business Code", "Line of business code should be selected.", "Selected line of business code: " + txtLineOfBusiness);

	    }

	    // ***************************************************** IPTV
	    // ***************************************
	    // IPTV
	    if (get("IPTV").equalsIgnoreCase("Yes")) {
		try {
		    if (isDisplayed(availableServ_Iptv)) {
			report.reportPass("IPTV service", "Fios IPTV should be displayed.", "Fios IPTV is displayed and so the account is IPTV enabled.");
		    } else {
			report.reportFail("IPTV service", "Fios IPTV should be displayed.", "Fios IPTV is not displayed and so the account is not IPTV enabled.");
			report.updateMainReport("ErrorMessage", "Fios IPTV is not displayed and so the account is not IPTV enabled.");
			throw new UserDefinedException("Fios IPTV is not displayed in Available services section in calling form page and so the account is not IPTV enabled.");

		    }

		} catch (Exception exe) {
		    exe.printStackTrace();
		    report.reportFail("IPTV service", "Fios IPTV should be displayed.", "Fios IPTV is not displayed and so the account is not IPTV enabled.");
		    report.updateMainReport("ErrorMessage", "Fios IPTV is not displayed and so the account is not IPTV enabled.");
		    throw new UserDefinedException("Fios IPTV is not displayed in Available services section in calling form page and so the account is not IPTV enabled.");
		}

	    }

	    // ***************************************************** IPTV
	    // ***************************************

         //Gopal Update on 10/04/2017 need to push to stash 
	    
	    if(get("FlowType").trim().equalsIgnoreCase("Change") && (!get("Zipcode").trim().isEmpty()))
        {
		    if (isDisplayed(btnNext, "")) {
			    clickUsingJavaScript(btnNext, "");
			    waitForLoader();
			}
        }
	    if (!get("FlowType").equalsIgnoreCase("SuppMove") && !get("FlowType").equalsIgnoreCase("Change")) {
	    	
	    	
	    	waitForLoader();
	    	// PresaleMessage Validation
			
			if(get("PresaleMessage").contains("Fios"))  {
			
			strDescription = "Early Order Eligible.";
	        strExpected = "Presale message should display as per Mock up";
	        strActual = "presale message is Displaying as : ";
	        strFailed = "Presale Message NotDisplayed as per Mock up";
	        getUrl = ", URL Launched --> " + returnURL();
			
	        String  Presale_Message = getTextFromElement(PresaleMsg,"");
	        
	        System.out.println(get("PresaleMessage"));
	        System.out.println(Presale_Message);
	        		
	        if(Presale_Message.equals(get("PresaleMessage")))		
			{
				report.reportPass(strDescription +getUrl, strExpected, strActual + Presale_Message);
				if(Presale_Message.contains("FAST")){
					report.reportPass(strDescription +getUrl, "FIOS Presale Order not eligible", "Please create FAST ticket to register customer for notifications when Fios ordering is available");
					driver.quit();			
					
				}
				
			}
			
			else
			{
				report.reportFail(strDescription +getUrl, strExpected, strFailed);
				report.updateMainReport("comments", strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				logger.error(strFailed);
				captureErrorMsg(strFailed);
				throw new UserDefinedException(strFailed);	
			}
	    	
	    	
		waitForLoader();
			}

		if (isDisplayed(btnNext, "")) {
		    clickUsingJavaScript(btnNext, "");
		    waitForLoader();
		}

		
		 waitForLoader();
		 waitForLoader();
		 waitForPageToLoad(driver);

		if (isDisplayed(currentActiveTab, "availableServices", 5)) {
		    strFailed = "Failed in Calling from page, RG page or products page  not displayed post clicking next button in Available service tab tab.";
		    report.reportFail("Verify RG page or products page displayed or not.", "RG page or products page should be displayed",
			    strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);				
			
		}
		
		
	    }
	    
	     /* if(get("FlowType").equalsIgnoreCase("Install")){
			 try {
					waitForElementDisplay(snapshot, objectValue, 150);
					System.out.println("Snapshot is Loaded even after 150 seconds");
					 report.reportPass("Verify Whether Snapshot is Loaded", "Check Whether Snapshot is Loaded", "Snapshot is Loaded");
				    } catch (Exception e) {
				    	System.out.println("Snapshot is not displayed");
				        String strFailed1="Snapshot is not Loaded";
					    report.reportFail("Verify Whether Snapshot is Loaded", "Check Whether Snapshot is Loaded", "Snapshot is not Loaded even after 150 seconds");
					    report.updateMainReport("comments", strFailed1);
					    report.updateMainReport("ErrorMessage", strFailed1);
					    logger.error(strFailed1);
					    captureErrorMsg(strFailed1);
					    throw new UserDefinedException(strFailed1);
				    	
			            

				    }
		
	       }*/

	} catch (Exception exe) {
	    
	    if (!isUserDefinedException(exe)) {
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		captureErrorMsg("Failed in Internet section.");
	    }
	    throw exe;
	}
    }

    public void setAccountSearchInfo() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	try {
		System.out.println("Calling From Page-->In Account search Tab");
	    // Give Customer info
	    strDescription = "Negotiating Account Search details";
	    strExpected = "Giving Account Search details";
	    strActual = "Giving Account Search Details in Calling From Page was successful";
	    strFailed = "Giving Account Search Details in Calling From Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();

	   // maximizeBrowserWindow();
	    waitForLoader();

	    String callingPartyName = get("Calling_Party_Name").trim();
	    String callBackNo = get("Call_Back_No").trim();
	    String reasonForCall = get("Reason_For_Call").trim();
	    String agencyId = get("AgencyID").trim();
        String AdvancedSearch =get("AdvancedSearch").trim();
        String ACHCancel =get("ACHCancel").trim();
        String accNo =get("Search_Value").trim();


        if(isDisplayed(txtSearchCallingPartyName, "", 30))
	    {
	    	System.out.println("Calling Party Name Text Box Displayed");
	    }

        try{
	    
        	// Gopal Update on 10/04/2017 

            if(get("FlowType").trim().equalsIgnoreCase("Change") && (!get("Zipcode").trim().isEmpty()))
            {

            	setSearchAndVerifyAddress();
            }
	       if (!agencyId.isEmpty()) {	 
	    	   
	    	   if(isDisplayed(acstSearch_SalesProfile))
	    	   {
	    	   	   clickUsingJavaScript(acstSearch_SalesProfile, "");
	    	   }
			waitForLoader();
			if (isDisplayed(salesProfileSave, "", 30)) {
	    	//setSalesProfileInfo();
			if (!agencyId.trim().isEmpty()) {
			    selectDropDownUsingVisibleText(selectAgencyID, "", agencyId);
			    report.reportPass("Verify Agency ID in sales Profile", "Agency ID " +agencyId+ " should be selected", "Agency ID "+agencyId+" is selected");
			}

			
			    clickUsingJavaScript(salesProfileSave, "");
			    report.reportPass("Verify Save is clicked in sales Profile", "Save should be clicked", "Save is clicked");
			    waitForLoader();
				waitForLoader();
			}	    
	    }
        }
        catch(Exception e){
          strFailed = "Failed in Sales Profile Info, Required Agency ID is not displayed post clicking Agency ID dropdown";
            report.reportFail("Verify in sales Profile Info.", "Required Agency ID is not displayed post clicking Agency ID dropdow",
                    strFailed);
                report.updateMainReport("comments", strFailed);
                report.updateMainReport("ErrorMessage", strFailed);
                logger.error(strFailed);
                captureErrorMsg(strFailed);
                throw new UserDefinedException(strFailed);
        }

	    
	    // Calling Party Name
	    
	    if (isDisplayed(txtSearchCallingPartyName, strFailed)) {
        mouseclick(txtSearchCallingPartyName,strFailed);
        waitForLoader();
		setText(txtSearchCallingPartyName, objectValue, callingPartyName);
		report.reportPass("Account search tab -- Enter calling party name.", "Calling party name should be entered.", "Entered " + callingPartyName+" calling party name.");
	    }

	    if (!callBackNo.isEmpty()) {
		// Call Back no
		if (isDisplayed(txtSearchCallBackNo, strFailed)) {

		    setText(txtSearchCallBackNo, objectValue, callBackNo);
		    report.reportPass("Account search tab -- Enter callback no.", "Call back no should be entered.", "Entered " + callBackNo+" call back no.");
		}
	    }

	    if (!reasonForCall.isEmpty()) {
		// Reason for call
		if (isDisplayed(dropdwnSearchReasonForCall, strFailed)) {

		    selectDropDownUsingVisibleText(dropdwnSearchReasonForCall, objectValue, reasonForCall);
		    report.reportPass("Select reason for call.", "Reason for call should be selected.", "Selected "+reasonForCall+" reason for call.");
		}
	    }
        //  for ACH Cancel Order By Gopal 
        
        if(AdvancedSearch.equalsIgnoreCase("Yes"))
        {
               clickUsingJavaScript(advancedsearch, "");
               report.reportPass("Click on Advanced Search Link", "Adavanced Search Link should be clicked", "Advanced Search Link is clicking");
               waitForLoader();
               if(isDisplayed(SavedAltChannelOrder, "", 5))
               {
                     clickUsingJavaScript(SavedAltChannelOrder, "");
                     report.reportPass("Click on Saved Alt Channel Order Link", "Saved Alt Channel Order Link should be clicked", "Saved Alt Channel Order Link is clicking");
                     waitForLoader();
               }
               if(!ACHCancel.isEmpty())
               {
                     if(isDisplayed(TxtSavedAlternateChannelOrder, "", 5))
                     {
                            setText(TxtSavedAlternateChannelOrder, "", accNo);
                            report.reportPass("Entered account details in Saved Alternate Channel Order Box", "Account details should be Entered into Saved Alternate Channel Order Box", "Enetering account details into Saved Alternate Channel Order Box");
                            waitForLoader();
                            
                            clickUsingJavaScript(btnSavedAlternateChannelOrder, "");
                            report.reportPass("Click on Saved Alternate Channel Order Button", "Saved Alternate Channel Order Button should be clicked", "Saved Alternate Channel Order Button is clicking");
                            waitForLoader();
                     }
                     if(isDisplayed(btnOpenCancelOrder, "", 5) && ACHCancel.equalsIgnoreCase("Yes"))
                     {
                            clickUsingJavaScript(btnOpenCancelOrder, "");
                            report.reportPass("Click on Open Cancel Order Button", "Open Cancel Order Button should be clicked", "Open Cancel Order Button is clicking");
                            waitForLoader();
                     }//Gopal 11/10
                     if(isDisplayed(drpcancelreason, "", 5) && ACHCancel.equalsIgnoreCase("Yes"))
                     {
                            selectDropDownUsingValue(drpcancelreason, "", "Address Not Qualified - No Re-issue (Remarks Required)");
                            report.reportPass("Select cancel reason from dropdown", "cancel reason should be selected from dropdown", "cancel reason is selecting from dropdown");
                            waitForLoader();
                            
                     }
                     if(isDisplayed(btnOpenCancelOrder, "", 5))
                     {
                            clickUsingJavaScript(btnOpenCancelOrder, "");
                            report.reportPass("Click on Open Cancel Order Button", "Open Cancel Order Button should be clicked", "Open Cancel Order Button is clicking");
                            waitForLoader();
                     }
                     if(isDisplayed(drpcancelreason, "", 5))
                     {
                            selectDropDownUsingValue(drpcancelreason, "", "Address Not Qualified - No Re-issue (Remarks Required)");
                            report.reportPass("Select cancel reason from dropdown", "cancel reason should be selected from dropdown", "cancel reason is selecting from dropdown");
                            waitForLoader();
                            
                     }
                     if(ACHCancel.equalsIgnoreCase("Yes"))
                     {
                            if(isDisplayed(btnCancelOrder, "", 5))
                            {
                                   clickUsingJavaScript(btnCancelOrder, "");
                                   report.reportPass("Click on Cancel Order Button", "Cancel Order Button should be clicked", "Cancel Order Button is clicking");
                                   waitForLoader();
                                   
                                   clickUsingJavaScript(btnClose, "");
                                   report.reportPass("Click on Close Button", "Close Button should be clicked", "Close Button is clicking");
                                   waitForLoader();
                                   
                            }
                     }
                     else if(ACHCancel.equalsIgnoreCase("Resume"))
                     {
                    	 if(isDisplayed(ResumeOrder, "", 5))
                         {
                                clickUsingJavaScript(ResumeOrder, "");
                                report.reportPass("Click on Resume Order Button", "Resume Order Button should be clicked", "Resume Order Button is clicking");
                                waitForLoader();
                                waitForLoader();
                         }
                     }
                     else
                     {
                            report.reportPass("Not click on Cancel Order Button", "Cancel Order Button should not be clicked", "Cancel Order Button is not clicking");
                     }
                     
               }
               
		        }
		        else
		        {
			    // Account no
			    if (isDisplayed(txboxAccountsearch, strFailed)) {
				
				clickUsingJavaScript(txboxAccountsearch, objectValue);
				setText(txboxAccountsearch, objectValue, accNo);
				waitForLoader();
				if(!get("Application").equalsIgnoreCase("C2G")){
					
		       /*driver.findElement(by.id("advancedSearch")).sendKeys(Keys.CONTROL,"a");
				waitForLoader();
				driver.findElement(by.id("advancedSearch")).sendKeys(Keys.CONTROL,"x");
				waitForLoader();
				driver.findElement(by.id("advancedSearch")).sendKeys(Keys.CONTROL + "v");
				waitForLoader();
				*/
				report.reportPass("Account search tab -- Enter account no.", "Account no should be selected.", "Entered "+accNo+" account number.");
				Thread.sleep(2000);
				}
				waitForLoader();
			    }
		        
			    // next button
			    if (isDisplayed(btnNext, "")) {
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//button[@ng-click='moveNextPage()']"))).perform();
				clickUsingJavaScript(btnNext, "");
				report.reportPass("Click on next button of Account search tab.", "Next button should be clicked on Account search tab.", "Clicked on Next button of Account search tab.");
				waitForLoader();
				waitForLoader();
				waitForLoader();
				waitForLoader();
			    }
			    if (isDisplayed(AccountNtFound, "", 6)) {
				    strFailed = "Account search was not Success";
				    String strtxt = AccountNtFound.getText();
				    report.reportFail("Verify Account Pull is Succssfull or not.", "Account putll is not Successful",
				    strFailed);
				report.updateMainReport("comments", strFailed + strtxt);
				report.updateMainReport("ErrorMessage", strFailed+strtxt);
				logger.error(strFailed);
				captureErrorMsg(strFailed);
				throw new UserDefinedException(strFailed); 
		
				}
				waitForLoader();
		
			    /*
			     * // next button if (isDisplayed(Button_SimplexUX, "Next", 1)) {
			     * 
			     * clickUsingJavaScript(Button_SimplexUX, "Next"); waitForLoader();
			     * }
			     */
			    report.reportPass(strDescription + getUrl, strExpected, strActual);
		        }

	} catch (Exception exe) {
	    exe.printStackTrace();
	    if (!isUserDefinedException(exe)) {
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		captureErrorMsg("Account search was not successful");
		report.updateMainReport("ErrorMessage", strFailed);
	    }

	    throw exe;
	}

	SearchResultOpen();
    }

    // Click on Open button in Account search flow
    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void SearchResultOpen() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	try {
	    // Give Customer info
	    strDescription = "Clicking on Open button in Search Result Page";
	    strExpected = "Open results link should be cliked.";
	    strActual = "Clicked on open results link";
	    strFailed = "Unable to click on results open link due to unavailability.";
	    String NoSafeGuardText=get("NoSafeGuardText");
	    getUrl = ", URL Launched --> " + returnURL();
	    waitForLoader();

	    if (get("GUI_Validations").toString().equalsIgnoreCase("AccountRetreival")) {
		waitForElementDisplay(labelSearchResultCustomerName_LiveAccount, objectValue, 40);
		put("Customer_Name", labelSearchResultCustomerName_LiveAccount.getText());
		put("Customer_Address", labelSearchResultCustomerAddress_LiveAccount.getText());
	    }
	    
			//maximizeBrowserWindow();
			// waitForLoader();
	    
	    if (isDisplayed(ExpandPendingOrder, "", 2)) {		
		    if (!getAttribute(ExpandPendingOrder, objectValue, "class").contains("open")) {
			    pageScroll(ExpandPendingOrder, objectValue, true);
			    clickUsingJavaScript(ExpandPendingOrder, objectValue);
			}
		    }

			if (isDisplayed(btnOpenSearchResult, "", 2)) {
				System.out.println(btnOpenSearchResultList.size());
				
		/*******************To Open Live Account*******************************/
				if(!get("LiveAccount").isEmpty()){
					mouseclick(btnOpenLiveAccount, "");
				    clickUsingJavaScript(btnOpenLiveAccount, "");
				    waitForLoader();
				    waitForLoader();
				    waitForLoader();
					
				}
				/*******************To Open First Result*******************************/
				else{
			    mouseclick(btnOpenSearchResult, "");
			    clickUsingJavaScript(btnOpenSearchResult, "");
			    waitForLoader();
			    waitForLoader();
			    waitForLoader();
				}
			}
			  waitForLoader();
		    
			  if ((get("FlowType").toLowerCase().contains("move") && !get("FlowType").equalsIgnoreCase("SuppMove")) || get("ToSafeGuarded").equalsIgnoreCase("No")|| get("SafeGuard").equalsIgnoreCase("yes")|| get("FlowType").toLowerCase().contains("stack")) {
			if(get("SafeGuard").equalsIgnoreCase("yes")&& get("Application").equalsIgnoreCase("COA")){
			    safeGuard();
				}
			else if(get("SafeGuard").equalsIgnoreCase("yes")&& get("Application").equalsIgnoreCase("C2G"))
			{
				safeGuard();
				if(get("FlowType").toLowerCase().contains("move")  && !get("FlowType").equalsIgnoreCase("SuppMove")){
					
				    rgMoving();
				    
					}
				
			}
			else if(get("FlowType").toLowerCase().contains("move")  && !get("FlowType").equalsIgnoreCase("SuppMove")){
				
			    rgMoving();
			    //Madhu
				}
				else if(!get("ETF").isEmpty() && get("ChangeType").toLowerCase().contains("ETFDisconnect")){
				    rgmovingdisconnect();
				    //Naresh
					}
				else if(get("FlowType").toLowerCase().contains("stack")) {
			    	
			    	rgmoveStack();
				}
	} else {
		 try {
				waitForElementDisplay(dashboardSection, objectValue, pageTimeoutInSeconds);
				System.out.println("Snapshot Dashboard is displayed");
				 report.reportPass("Verify Whether Snapshot Dashboard is dispalyed", "Check Whether Snapshot Dashboard is dispalyed", "Snapshot Dashboard is dispalyed");
				 if(get("SafeGuardOption").contains("yes")){
					 List<WebElement>ele = driver.findElements(by.xpath("*//span[contains(text(),'"+NoSafeGuardText+"')]"));
					 for(int i=0;i<=ele.size();i++){
						String eletext = ele.get(i).getText();
						System.out.println(eletext);
						if(eletext.contains(NoSafeGuardText)){
							report.reportPass("Verify Activity time line loaded", "Activity Timeline shoould load----"+eletext, "Acitivity Time Line Loaded");
						}
						else
						{
							report.reportFail("Verify Activity time line loaded", "Activity Timeline shoould load", "Acitivity Time Line not Loaded");
						}
						break;
					}
					 
				 }
			    } catch (Exception e) {
			    	System.out.println("Snapshot  Dashboard is not displayed");
		               report.reportPass("Verify Whether Snapshot Dashboard is dispalyed", "Check Whether Snapshot Dashboard is dispalyed", "Snapshot Dashboard is not dispalyed");

			    }
	  
	}
		

	}

	catch (Exception exe) {
	    if (!isUserDefinedException(exe)) {
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		captureErrorMsg("Failed in Search  Results Open");
	    }

	    throw exe;
	}
//	if (get("GUI_Validations").toString().equalsIgnoreCase("AccountRetreival")) {
//	    setAccountRetrievedValidationNewUI();
//	}

	
    }

    /**
     * 
     * Optimized code and increased performance.
     * 
     * @LastUPdatedBy SHiva
     * @throws Exception
     */
    // Click on Moving Radio button in COA Move flow

    public void rgMoving() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	String getUrl = "";
	try {
	    waitForLoader();
	    waitForLoader();
	    pause();
	    // Give Customer info
	    strDescription = "Clicking on Moving/DoccAgreement button in RG Page.";
	    strExpected = "Click Moving/DoccAgreement button in RG Page";
	    strActual = "Moving/DoccAgreement button in RG Page was successfully clicked ";
	    strFailed = "Clicking on Moving/DoccAgreement button in RG Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();
	    waitForLoader();
	    switchToDefaultcontent();
	    // DOCC Agreement
	    if (get("FlowType").contains("Move")  && (get("Application").equalsIgnoreCase("C2G"))) {

	  	  if(isDisplayed(btnYesDoccAgreement, "", 10)){
  			if (btnYesDoccAgreementList.size() > 0) {
  			    waitForElementDisplay(btnYesDoccAgreement, objectValue, pageTimeoutInSeconds);

  			    if (isDisplayed(btnYesDoccAgreement, objectValue)) {
  				clickUsingJavaScript(btnYesDoccAgreement, objectValue);
  				report.reportPass(strDescription + getUrl, strExpected, strActual);

  			    }
  			}
  		    }
	    }
	    if ((get("FlowType").contains("Move") && !get("FlowType").equalsIgnoreCase("SuppMove")) || get("FlowType").equalsIgnoreCase("MoveAsIs")) {
		waitForLoader();
		waitForLoader();
		waitForLoader();
		waitForLoader();
		switchToDefaultcontent();
		 try {
				waitForElementDisplay(snapshot, objectValue, pageTimeoutInSeconds);
				 
			    } catch (Exception e) {
              
			    }
		 
		 if(isDisplayed(NotificationMessage, "", 3))
			{
			clickUsingJavaScript(NotificationMessage, objectValue);

			waitForLoader();
			}
			if(isDisplayed(MessageAlert, "", 6)){
		clickUsingJavaScript(MessageAlert, objectValue);

		waitForLoader();
		
	    }
		if (!ordersTab.getAttribute("class").contains("active")) {

		    clickUsingJavaScript(ordersTab, objectValue);
		    waitForPageToLoad(driver);

		}
		waitForLoader();
		waitForPageToLoad(driver);
		waitForLoader();
		//waitForElementDisplay(btnMoving, "", pageTimeoutInSeconds);

		  if (isDisplayed(btnRGMoving, "", 5)) {
			    clickUsingJavaScript(btnRGMoving, objectValue);
			}
			else if(isDisplayed(IWantTolink, objectValue, 5)){
				 clickUsingJavaScript(IWantTolink, objectValue);
				 waitForLoader();
				 if (isDisplayed(btnMoving, "", 5)) {
					    clickUsingJavaScript(btnMoving, objectValue);
					    waitForLoader();
					}
				}
			else {
			    report.reportFail("Click on RG moving", "RG Moving button should be clicked.", "RG moving button is not displayed.");
			}

			report.reportPass(strDescription + getUrl, strExpected, strActual);

		    }

	} catch (Exception exe) {
	    if (!isUserDefinedException(exe)) {
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		captureErrorMsg("Failed in Internet section.");
	    }
	    throw exe;
	}
	setSearchAndVerifyAddress();
    }

    // Click DoCCAgreement After account search
    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */

    public void clickDoCCAgreement() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	String getUrl = "";
	try {
	    // Give Customer info
	    strDescription = "Clicking on Moving/DoccAgreement button in RG Page";
	    strExpected = "Click Moving/DoccAgreement button in RG Page";
	    strActual = "Moving/DoccAgreement button in RG Page was successfully clicked ";
	    strFailed = "Clicking on Moving/DoccAgreement button in RG Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();

	    waitForLoader();
	    // DOCC Agreement
	    if (!get("FlowType").equalsIgnoreCase("Install")) {

		if (btnYesDoccAgreementList.size() > 0) {
		    waitForElementDisplay(btnYesDoccAgreement, objectValue, 30);

		    if(isDisplayed(btnYesDoccAgreement, "", 20)){
		    if (btnYesDoccAgreement.isDisplayed()) {
			clickUsingJavaScript(btnYesDoccAgreement, objectValue);
			report.reportPass(strDescription + getUrl, strExpected, strActual);

		    }
		}
		}
	    }

	} catch (Exception exe) {
		 if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				 report.updateMainReport("comments", strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in Internet section.");
			    }

			    throw exe;  
	}
    }

    /**
     * @Name: safeGuard
     * @Description: Used to perform Safe Guard verification.
     * @author : Yuvaraj
     * @Return Type: No return type
     * @throws Throws
     *             Exception
     */
    //Changes on 03/16-Dinesh
    //Changes on 05/29/18 - Gopal
    public void safeGuard() throws Exception {
    	

    	
    	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
    	String getUrl = "";

    	try {
    		System.out.println("Calling From Page-->In Safeguard Screen");
    	    // Give Customer info
    	    strDescription = "Enter SafeGuard Options in Customer Validation Page";
    	    strExpected = "SafeGuard Details to be entered and enabled successfully.";
    	    strActual = "SafeGuard Details are entered and enabled successfully";
    	    strFailed = "SafeGuard Details are either not entered correctly or not enabled properly.";
    	    getUrl = ", URL Launched --> " + returnURL();

    	    waitForLoader();

    	    waitForLoader();
    	    String safeGuardOption = get("SafeGuardOption");
    	    String safeGuardInput = get("SafeGuardInput");
    	    String ToSafeGuarded = get("ToSafeGuarded");
    	    String NoSafeGuardText = get("NoSafeGuardText");
    	    String TicketNoWithoutSG = get("TicketNoWithoutSG");
    	    String ZipCodeWithoutSG = get("ZipCodeWithoutSG");

    	    pause();
    	    // Safe Guard Functionality
    	    if (get("SafeGuard").equalsIgnoreCase("yes")) {
    	    	
    	    	waitForLoader();
    	    	waitForLoader();

    		if (safeGuard_CustomerValidationScreen.size() > 0) {
    		} else if (isDisplayed(safeGuardIconCoA, safeGuardInput, 5)) {
    		    // Sage Guard icon
    			
    		    clickUsingJavaScript(safeGuardIconCoA, objectValue);
    		    report.reportPass(strDescription, "Safe Guard Icon to be clicked.", "Safe Guard Icon is selected successfully.");
    		    waitForLoader();
    		}
    		 else if (isDisplayed(safeGuardIcon, safeGuardInput, 5)) {
    			    // Sage Guard icon
    			    clickUsingJavaScript(safeGuardIcon, objectValue);
    			    report.reportPass(strDescription, "Safe Guard Icon to be clicked.", "Safe Guard Icon is selected successfully.");
    			    waitForLoader();
    			}

    		try {

    			pause();
    		    // Safe Guard Option  ***
    		    if (isDisplayed(safeGuardOptionRB, safeGuardOption,8) && (!ToSafeGuarded.equalsIgnoreCase("No"))) {

    			clickUsingJavaScript(safeGuardOptionRB, safeGuardOption);
    			report.reportPass("Safe Guard Radio button Option", "Safe Guard Radio button Option to be selecetd",
    				"Safe Guard Radio button Option is selected with value: " + safeGuardOption);

    			// Input Field
    			setText(safeGuardOptionInputField, safeGuardOption, safeGuardInput);
    			report.reportPass("Safe Guard Option Input field", "Safe Guard Option Input field value to be eneterd",
    				"Safe Guard Option Input field is entered with value: " + safeGuardInput);


    			pause();
    			// Verify button
    			if (isDisplayed(safeGuardVerifyButton)) {
    			    clickUsingJavaScript(safeGuardVerifyButton, objectValue);
    			    report.reportPass("Verify Button", "Verify Button to be clicked", "Verify Button is selected successfully");
    			    waitForLoader();

    				clickDoCCAgreement();
    				waitForLoader();
    				waitForPageToLoad(driver);    				
    				

    			} 
    			else {
    			    report.reportFail("Verify Button", "Verify Button to be clicked", "Verify Button is not selected in SafeGuard screen");
    			    report.updateMainReport("ErrorMessage", "Not As Expected");
    			    throw new UserDefinedException("Failed in Safe Guard Screen.");
    			}
    			 if (isDisplayed(safeGuardWarningMsg, strFailed)) {
    				report.reportPass("Safe Guard Screen Warning Message", "Safe Guard Screen Warning Message",
    					"Safe Guard  Screen Warning Message is displayed with text value: " + safeGuard_FullWarningMsg.getText());
    			
    				
    				   clickUsingJavaScript(safeGuardFailureButton, objectValue);
    				    report.reportPass("SafeGuard Failure Button", "SafeGuard Failure Button to be clicked", "SafeGuard Failure Button is selected successfully");
    				    waitForLoader();
    				    
    				    if (isDisplayed(safeGuardFailureMsg, strFailed)) {
    				    	
    				    	setText(safeGuardFailureMsg, safeGuardOption, "SafeGuard Failed");
    				    
    						report.reportPass("Safe Guard Screen Failure Message", "Safe Guard Screen Failure Message",
    						"Safe Guard  Screen Failure Message is entered with text");
    						  waitForLoader();
    						  
    						  report.reportPass("SafeGuard Failure Save andClose Button", "SafeGuard Failure Save andClose Button to be clicked", "SafeGuard Failure Save andClose Button is clicked successfully");
    						  //report.updateMainReport("status", "Passed");
    						   clickUsingJavaScript(safeGuardFailureSaveandCont, objectValue);
    						   
    						  //  driver.quit();
    				    }
    				
    			  }
    			 
    			// Product and services icon
    						/*if (isDisplayed(sg_ProductServicesIcon)) {
    						if (!sg_ProductServicesIcon.getAttribute("class").contains("active")) {
    						    clickUsingJavaScript(sg_ProductServicesIcon, objectValue);
    						    report.reportPass("Product & Services icon", "Product & Services icon is already displayed,if not select the icon to display",
    							    "Product & Services icon is selected to display the page.");
    						}}*/
    					

    		    }
    		    
    		    else if(ToSafeGuarded.equalsIgnoreCase("No")){
    		    	
    		    	clickUsingJavaScript(WOsafeGuardingTab, safeGuardOption);
    		    	report.reportPass(strDescription, "WithOut safeGuardingTab Icon to be clicked.", "WithOut safeGuardingTab Icon is selected successfully.");
    		    	waitForLoader();
    		    	try{
    		    	clickUsingJavaScript(WOsafeGuardingOptionsRB, safeGuardOption);
    		    	report.reportPass(strDescription, "WithOut safeGuardingTab Icon to be clicked.", "WithOut safeGuardingTab Icon is selected successfully.");
    		    	}
    		    	catch(Exception exe){
    		    		strFailed = "Failed in Serving the Customer without Safeguard, beacuse "+safeGuardOption+" is not present";
    		    		report.reportFail("Validation of Non Safaeguarding", "Serve Customer without safeguarding", strFailed);
    		    		report.updateMainReport("comments", strFailed);
    		    		report.updateMainReport("ErrorMessage", strFailed);
    		    		logger.error(strFailed);
    		    		captureErrorMsg(strFailed);
    		    		throw new UserDefinedException(strFailed);	
    		    	}
    		    	waitForLoader();
    		    	
    		    	if(isDisplayed(sg_txtnoSafeguardtab, ToSafeGuarded, 5))
    		    	{
    		    		clearText(sg_txtnoSafeguardtab, ZipCodeWithoutSG);
    		    		waitForLoader();
    		    		setText(sg_txtnoSafeguardtab, safeGuardInput, NoSafeGuardText);
    		    		waitForLoader();
    		    		report.reportPass(strDescription, "WithOut safeGuardingTab Icon to be clicked.", "WithOut safeGuardingTab Icon is selected successfully.");
    		    	}
    		    	
    		    	if(safeGuardOption.equalsIgnoreCase("Master Order")){
    		    	
    		    	
    		    	clickUsingJavaScript(WOsafeGuardingOptionsLink, safeGuardOption);
    		    	waitForLoader();
    		    	
    		    	
    		    	}
                else if(safeGuardOption.equalsIgnoreCase("Change Due Date") ){
                	
                	
    		    		
                	 clickUsingJavaScript(optionLinkDisplayed, safeGuardOption);
     		    	 waitForLoader();
     		    	 waitForLoader();
     		    	 waitForLoader();
                	 String strURLContent="Checkout/DueDate";	    	    		      	 
                	 String strURLContentnot= "ContainerGatewaySvc";
                	 waitForLoader();
     		    	 waitForLoader();
     		    	 waitForLoader();
     		    	 waitForLoader(); 
     		    	 waitForLoader();
     		    	 waitForLoader(); 
     		    	 waitForLoader();
     		    	 waitForLoader(); 
     		    	 waitForLoader();
     		    	 waitForLoader();
     		    	 waitForLoader();
     		    	 switchToWindowWithURL2Param(strURLContent, strURLContentnot);
      		    	 maximizeBrowserWindow();
      		    	 report.reportPass("Duedate Window Page", "Verify Whether Duedate Window Page Should be Displayed", "Duedate Window Page is Displaying");
      		    	 waitForLoader();
      		    	 waitForLoader();
      		    	 waitForLoader();
    		         selectDropDownUsingVisibleText(missedAppointmentCOde,objectValue,"SO-Subscriber Other");
    		         
    		         report.reportPass("Duedate Window Page", "Verify Whether missed Appointment COde Should be Displayed", "missed Appointment COde is Displaying");
    		         
    		         // Click On First Available DueDate
    				    pageScroll(fourthAvailableDate, objectValue, true);
    				    mouseOver(fourthAvailableDate, objectValue);
    				    if (!isDisplayed(lnkTimeSlots, "", 1)) {
    					pageScroll(fourthAvailableDate, objectValue, true);
    					clickUsingJavaScript(fourthAvailableDate, objectValue);

    				    } else {
    					// Click On First Available TimeSlots
    					clickUsingJavaScript(lnkTimeSlots, objectValue);
    				    }
    				    
    				    report.reportPass("Click lnk TimeSlots", "Verify lnk TimeSlots is clicked", "lnk TimeSlots is clicked");
    				    
    				    clickUsingJavaScript(btnSubmitDueDate, safeGuardOption);
        		    	waitForLoader();
        		    	report.reportPass("Click Submit DueDate button", "Verify Whether Submit DueDate button is clicked", "Submit DueDate button is clicked");
    		    	}
    		    	
    		    	else if(safeGuardOption.equalsIgnoreCase("Mail Information to the Customer") ){

    		    		clickUsingJavaScript(btnContinueNoSG, safeGuardOption);
        		    	waitForLoader();
        		    	report.reportPass("Click Continue button", "Verify Whether Continue button is clicked", "Continue button is clicked");
    		    	}
                   else if(safeGuardOption.equalsIgnoreCase("Where is My Tech") ){
    		    		
    		    		
        		    	clickUsingJavaScript(masterOrderNumber, safeGuardOption);
        		    	waitForLoader();
        		    	report.reportPass("Click Master Order Number If Exists", "Verify Whether Master Order Number is clicked", "Master Order Number is clicked");
    		    		setText(enterMON, TicketNoWithoutSG, get("SafeGuardInput"));
    		    		setText(enterZipCode, TicketNoWithoutSG, ZipCodeWithoutSG);
    		    		pageScroll(getTechDetails, ZipCodeWithoutSG, true);
    		    		clickUsingJavaScript(getTechDetails, safeGuardOption);
    		    		report.reportPass("Click Get Tech Details", "Verify Whether Get Tech Details is clicked", "Get Tech Details is clicked");
        		    	waitForLoader();
        		    	clickUsingJavaScript(btnContinueNoSG, safeGuardOption);
        		    	waitForLoader();
        		    	report.reportPass("Click Continue button", "Verify Whether Continue button is clicked", "Continue button is clicked");
    		    	
    		    	}
                   
    		    	else if(safeGuardOption.equalsIgnoreCase("Get Ticket Status") ){
    		    		
    		    		setText(ticketNoWithoutSG, ToSafeGuarded, TicketNoWithoutSG);
        		    	waitForLoader();
        		    	
        		    	setText(ticketNoWithoutSG, ToSafeGuarded, ZipCodeWithoutSG);
        		    	waitForLoader();
        		    	
        		    	clickUsingJavaScript(optionLinkDisplayed, "Get Status");
                        waitForLoader();
        		    	
        		    	clickUsingJavaScript(btnContinueNoSG, safeGuardOption);
        		    	waitForLoader();
    		    	}
    		    	waitForLoader();
    		    	waitForLoader();
    		    	waitForLoader();
    		    	waitForLoader();	
    		    	waitForLoader();
    		    	waitForLoader();
    		    	waitForLoader();
    		    	waitForLoader();
    		    	waitForLoader();	
    		    	waitForLoader();
    		    	waitForLoader();
    		    	waitForLoader();	
    		    	waitForLoader();
    		    	waitForLoader();
    		    	waitForLoader();	
    		    	waitForLoader();
    		    	waitForLoader();
    		    	waitForLoader();	
    		    	waitForLoader();
    		    	pause();
    		    	pause();
    		    	String strURLContent="FlowType=Change&ProcessType=CONTAINERVIEW";	    	       		                          	
       		        switchToWindowWithURL(strURLContent);
       		        
       		        report.reportPass("Safefaurd page is Updated with Duedate" , "Due Date has to Be updated.", "Duedate is Updated Successfully");
       		        
                   	if(isDisplayed(sg_BtnClose, "", 1)){
					clickUsingJavaScript(sg_BtnClose, objectValue);
    		    	}
					
    		    	
    		    	
    		    }
    		    else if(safeGuardOption.equalsIgnoreCase("OTP using MTN(Heightened)") ){
    		    	pageScroll(OTPusingMTNHeightened, ZipCodeWithoutSG, true);
    		    	clickUsingJavaScript(OTPusingMTNHeightened, objectValue);
    		    	report.reportPass("Check Whether OTP  using MTN is clicked", "Verify Whether OTP  using MTN is clicked", "OTP  using MTN is clicked Successfully");
    		    	waitForLoader();
    		    	setText(EnterMtnOTP, objectValue, safeGuardInput);
    		    	waitForLoader();
    		    	
    		    	clickUsingJavaScript(sendTemporaryPIN, objectValue);
    		    	report.reportPass("Check Whether OTP is Sent to Mobile Number", "Verify Whether OTP is Sent to Mobile Number", "OTP is Sent to Mobile Number Successfully");
    		    	waitForLoader();
		    	}
				else if(safeGuardOption.equalsIgnoreCase("OTP using Email(Heightened)") ){
					
					pageScroll(OTPusingEmailHeightened, ZipCodeWithoutSG, true);			
					clickUsingJavaScript(OTPusingEmailHeightened, objectValue);
					report.reportPass("Check Whether OTP  using Email is clicked", "Verify Whether OTP  using Email is clicked", "OTP  using Email is clicked Successfully");
    		    	waitForLoader();
    		    	setText(EnterEmailOTP, objectValue, safeGuardInput);
    		    	waitForLoader();
    		    	
    		    	clickUsingJavaScript(sendTemporaryPIN, objectValue);
    		    	report.reportPass("Check Whether OTP is Sent to Email", "Verify Whether OTP is Sent to Email", "OTP is Sent to Email Successfully");
    		    	waitForLoader();
				}     

    		} catch (Exception e) {
    		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
    		    throw e;
    		}

    	    }

    	} catch (Exception e) {
    	    e.printStackTrace();
    	    report.reportFail(strDescription + getUrl, strExpected, strFailed);
    	    report.updateMainReport("ErrorMessage.", strFailed);
    	    throw e;
    	}

    
    }
    // ******** GUI Validation methods...***************************

    public void UIValidations_NewAccountTab() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";

	if (get("CallingFromGUI").equalsIgnoreCase("Yes")) {
	    try {

		waitForLoader();
		// Check for Account Tab is Active
		String pageName = "New Account Tab,Customer Info tab";

		guiValidateVisibility(NewAccount, pageName, "New Account", "New Account Tab is Active", "New Account Tab is Not Active");

		// Check if Customer Info tab is Active
		guiValidateVisibility(customerInfoTab, pageName, "customerInfoTab", "Customer Info Tab is Active", "Customer Info Tab is Not Active");

		// waitForLoader();
		if(get("Application").equalsIgnoreCase("COA")){

		// Check for Agency Link is Present
		strDescription = "Verifying Agency Links";
		strExpected = "Agency Link Should be Present";
		strActual = "Agency Link is Available";
		strFailed = "Agency Link is Not Present";

		if (isDisplayed(AgencyLink, "", 0)) {
		    report.reportPass(strDescription, strExpected, strActual);
		    clickUsingJavaScript(AgencyLink, objectValue);
		    waitForLoader();
		    report.reportPass("verify to Click on Agency Link", "Click on Agency Link", "Clicked On Agency Link");
		    clickUsingJavaScript(AgencySave, objectValue);
		    report.reportPass("verify to Click on Save Button", "Click on Save Button", "Clicked On Save Button");
		    waitForLoader();
		    if (isDisplayed(NewAccount, "")) {
			report.reportPass("Check if Back on New Account Section", "New Acount Section should be Displayed", "On New Account Section");
		    } else {
			report.reportFail("Check if Back on New Account Section", "New Acount Section should be Displayed", "NOT On New Account Section");
			report.updateMainReport("ErrorMessage", "NOT On New Account Section");
		    }
		} else {
		    report.reportFail(strDescription, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}
		waitForLoader();

	/*	if (isDisplayed(AlertMsg, "", 0)) {

		    // Capturing Alert Message
		    String ele = getTextFromElement(AlertMsg, objectValue);
		    report.reportPass("Alert Msg in New Account", "Validate Alert Msg in New Account", "Alert message is Displayed and Captured" + ele);
		} else {
		    report.reportFail("Alert Msg in New Account", "Validate Alert Msg in New Account", "Alert message is NOT Displayed");
		    report.updateMainReport("ErrorMessage", "Alert message is NOT Displayed");
		}
		*/
		
		}

		// waitForLoader();

		// Check for Next Button is Enabled

		if (isEnabled(btnNext, "")) {
		    report.reportPass("Verify If Next Button is Enabled", "Next Button Should be Enabled", "Next Button is Enabled");
		} else {
		    report.reportFail("Verify If Next Button is Enabled", "Next Button Should be Enabled", "Next Button is NOT Enabled");
		    report.updateMainReport("ErrorMessage", "Next Button is NOT Enabled");
		}

		// Without entering the Mandatory fields Click on Next Button
		strDescription = "Without entering the Mandatory fields Click on Next Button";
		strExpected = "Should throw an Error";
		strActual = "Invalid Email Error Displayed";
		strFailed = "Invalid Email Error Not Displayed";

		if (isDisplayed(btnNext, "", 0)) {
		    clickUsingJavaScript(btnNext, objectValue);

		    if (isDisplayed(NextErrorCustomerInfo, "", 3)) {
			report.reportPass(strDescription, strExpected, strActual);
		    } else {
			report.reportFail(strDescription, strExpected, strFailed);
			report.updateMainReport("ErrorMessage", strFailed);

		    }
		}

		// waitForLoader();

		// validating Invalid Email ID

		String callingPartyName = get("Calling_Party_Name");
		setText(txtNewACCallingPartyName, objectValue, callingPartyName);

		String callBackNo = get("Call_Back_No");
		
		setText(txtNewACCallBackNo, objectValue, callBackNo);
		/*driver.findElement(by.id("advancedSearch")).sendKeys(Keys.CONTROL,"a");

		driver.findElement(by.id("advancedSearch")).sendKeys(Keys.CONTROL,"c");
		driver.findElement(by.id("advancedSearch")).clear();
		driver.findElement(by.id("advancedSearch")).sendKeys(Keys.CONTROL,"v");
		*/
		waitForLoader();

		String email = get("Invalid_Email");
		clickUsingJavaScript(txtEmail, "");
		setText(txtEmail, objectValue, email);

		clickUsingJavaScript(btnNext, objectValue);
		waitForLoader();
		if (isDisplayed(InvalidEmailError, "", 0)) {
		    report.reportPass(strDescription, strExpected, strActual);
		} else {
		    report.reportPass(strDescription, strExpected, strFailed);
		}

		clearText(txtNewACCallingPartyName, objectValue);
		clearText(txtNewACCallBackNo, objectValue);
		clearText(txtEmail, objectValue);

		// waitForLoader();

		// Check for ConnectToCall should be Disabled -- need to be
		// modified
		
		if(get("Application").equalsIgnoreCase("COA")){
		guiValidateInVisibility(ConnectToCall, pageName, "CustomerInfo tab", "ConnectToCall Button is Disabled", "ConnectToCall Button is not Disabled");
		}
		waitForLoader();

	    } catch (Exception exe) {
		exe.printStackTrace();
		throw exe;
	    }

	}

    }

    /**
     * @author V859994
     * @Description:Ui Validation for Address Search Tab
     * @return: No return type
     * @exception Throws
     *                Exception
     * @ModifiedDate:02-15-2017
     * @ModifiedBY:Shilpa Ravula
     * @Comments:
     */

    public void UIValidations_AddressSearchTab() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";

	if (get("CallingFromGUI").equalsIgnoreCase("Yes")) {
	    try {
		String pageName = "New Account Address Search Tab";

		waitForLoader();
		// Check for Account Tab is Active
		guiValidateVisibility(NewAccount, pageName, "Address tab Search", "New Account is active", "New account is not active");

		// Check if Customer Info tab is Disabled
		guiValidateInVisibility(customerInfoTab, pageName, "Address tab Search", "CustomerInfo Tab is not active", "Customer Info tab is active");

		// Check for Address Search Tab is Active

		guiValidateVisibility(AddressSearch, pageName, "Address tab Search", "Address search tab is active", "Addaress search tab is not active");

		// Check for verify Address Tab is Disabled

		guiValidateInVisibility(VerifyAddress, pageName, "Address Search Tab", "Verify Address Tab is Disabled", "Verify Address Tab is NOT Disabled");

		// Check for Available Services Tab is Disabled

		guiValidateInVisibility(AvailableServices, pageName, "Address Search Tab", "Available Services Tab is Disabled", "Available Servicess Tab is NOT Disabled");

		// waitForLoader();

		// Check for Agency Link is Present
		strDescription = "Verifying Agency Links";
		strExpected = "Agency Link Should be Present";
		strActual = "Agency Link is Available";
		strFailed = "Agency Link is Not Present";

		if (isDisplayed(AgencyLink, "", 0)) {
		    report.reportPass(strDescription, strExpected, strActual);
		    clickUsingJavaScript(AgencyLink, objectValue);
		    waitForLoader();
		    report.reportPass("verify to Click on Agency Link", "Click on Agency Link", "Clicked On Agency Link");
		    clickUsingJavaScript(AgencySave, objectValue);
		    report.reportPass("verify to Click on Save Button", "Click on Save Button", "Clicked On Save Button");
		    waitForLoader();

		    guiValidateVisibility(AddressSearch, pageName, "Address tab Search", "Address search tab is active", "Addaress search tab is not active");
		}
		waitForLoader();
		
		 if(get("Application").equalsIgnoreCase("COA")){

		// Capturing Alert Message
		strDescription = "To Capture the Alert message";
		strExpected = "Should Capture the Alert message";
		strActual = "Alert message captured Successfully";
		strFailed = "Alertmessage not captured successfuly";

		if (isDisplayed(AddressSearchAlert, "", 0)) {
		    String ele = getTextFromElement(AddressSearchAlert, objectValue);
		    report.reportPass(strDescription, strExpected, strActual + ele);
		} else {
		    report.reportFail(strDescription, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		 }
		// waitForLoader();

		// Check for Next Button is Enabled

		if (isEnabled(btnNext, "")) {
		    report.reportPass("Verify If Next Button is Enabled", "Next Button Should be Enabled", "Next Button is Enabled");
		} else {
		    report.reportFail("Verify If Next Button is Enabled", "Next Button Should be Enabled", "Next Button is NOT Enabled");
		    report.updateMainReport("ErrorMessage", "Next Button is NOT Enabled");
		}

		// Without entering the Mandatory fields Click on Next Button
		strDescription = "Without entering the Mandatory fields Click on Next Button";
		strExpected = "Should throw an Error";
		strActual = "Error Displayed";
		strFailed = "Error Not Displayed";

		clickUsingJavaScript(btnNext, objectValue);

		if (isDisplayed(NextError, "", 2)) {
		    String nexterror = getTextFromElement(NextError, objectValue);
		    report.reportPass(strDescription, strExpected, "Actual Message is:" + nexterror);
		} else {
		    report.reportFail(strDescription, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// waitForLoader();

		// Verify If Address Field is Disabled Before entering Zip

		guiValidateInVisibility(address, pageName, "Address Search Tab", "Address Field is Disabled Before entering Zip", "Address Field is NOT Disabled Before entering Zip");

		// Verify If Address Field is Enabled After entering ZipCode

		// guiValidateVisibility(address, pageName, "Address Search
		// Tab",
		// "Address Field is Enabled After entering Zip", "Address Field
		// is
		// NOT Enabled After entering Zip");
		String txtZipcode = get("Zipcode");

		if (isDisplayed(zipCode, strFailed, 0)) {
		    setText(zipCode, objectValue, txtZipcode);
		    waitForLoader();
		    guiValidateInVisibility(addressDisabled, pageName, "Address Search Tab", "Address Field is Enabled After entering Zip", "Address Field is NOT Enabled After entering Zip");
		}

		// Check for Advance Search Link Available
		strDescription = "Verify if Advanced Search link is Present";
		strExpected = "Advanced Search link should be available";
		strActual = "Advanced Search link is available";
		strFailed = "Advanced Search link is NOT  available";

		if (isDisplayed(AdvancedSearch, "", 0)) {
		    report.reportPass(strDescription, strExpected, strActual);
		} else {
		    report.reportFail(strDescription, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		clickUsingJavaScript(AdvancedSearch, objectValue);
		waitForLoader();

		// Check ForAddress View Section
		if (isDisplayed(AddressView, "", 0)) {
		    report.reportPass("Address View Section", "Address View Section is Available and the fields displayed are:", "Address View Section is Available");
		} else {
		    report.reportFail("Address View Section", "Address View Section is Available and the fields displayed are:", "Address View Section is Not Available");
		    report.updateMainReport("ErrorMessage", "Address View Section is Not Available");
		}

		// Click Next without giving any Values in Address view Section

		clickUsingJavaScript(btnNext, objectValue);
		waitForLoader();
		if (isDisplayed(NextError, "", 0)) {
		    String nexterror = getTextFromElement(NextError, objectValue);
		    report.reportPass("Without entering the Mandatory fields Click on Next Button", "Should throw an Error", "Actual Message is:" + nexterror);
		} else {
		    report.reportFail("Without entering the Mandatory fields Click on Next Button", "Should throw an Error", "Error Not Displayed");
		    report.updateMainReport("ErrorMessage", "Error Not Displayed");
		}

		// Close the Address View Section
		clickUsingJavaScript(CloseAddressView, objectValue);
		waitForLoader();
		if (isDisplayed(zipCode, "", 0)) {
		    report.reportPass("Closing Advance search view", "Should close the advanced search view and return to Address Search tab", "Advanced Saerch View is Closed Successfully");
		} else {
		    report.reportFail("Closing Advance search view", "Should close the advanced search view and return to Address Search tab", "Advanced Saerch View is NOT Closed");
		    report.updateMainReport("ErrorMessage", "Advanced Search View is NOT Closed");
		}

		// Check for Back Button Validation
		strDescription = "Verify that after clicking on Back Button Customer Info tab is displayed";
		strExpected = "After clicking on Back Button Customer Info tab is displayed";
		strActual = "Customer Info tab is displayed";
		strFailed = "Customer Info tab is NOT displayed";

		if (isDisplayed(backButton, "", 3)) {
		    clickUsingJavaScript(backButton, objectValue);
		    waitForLoader();
		    waitForLoader();
		    if ((guiValidateVisibility(customerInfoTab, pageName, "Address tab Search", "CustomerInfo Tab is not active", "Customer Info tab is active"))) {
			if (isDisplayed(btnNext, "")) {
			    clickUsingJavaScript(btnNext, objectValue);
			    report.reportPass("Verify to Click Next Button", "Able to Click Next Button", "Click on Next Button is Success");
			    waitForLoader();
			    waitForLoader();
			    guiValidateVisibility(AddressSearch, pageName, "Address tab Search", "In Address Search tab", "Not in  Address Search tab");

			} else {
			    report.reportFail("Verify to Click Next Button", "Able to Click Next Button", "Unable to Click on Next Button");
			    report.updateMainReport("ErrorMessage", "Unable to Click on Next Button");
			}
		    }
		} else {
		    report.reportFail("verify to Click on Back Button", "Able to Click on Back Button", "Unable to Click on Back Button");
		    report.updateMainReport("ErrorMessage", "Unable to Click on Back Button");
		}
	    } catch (Exception exe) {
		exe.printStackTrace();
		throw exe;
	    }
	}

    }

    /**
     * @author V859994
     * @Description:Ui Validation for Sales Profile Window
     * @return: No return type
     * @exception Throws
     *                Exception
     * @ModifiedDate:02-15-2017
     * @ModifiedBY:Shilpa Ravula
     * @Comments:
     */

    public void UIValidations_SalesProfile() throws Exception {

	if (get("CallingFromGUI").equalsIgnoreCase("Yes")) {
	    try {
		String pageName = "Sales Profile Window";
		// waitForLoader();

		// Getting Sales Code Information
		if (isDisplayed(Salecode, "", 0)) {
		    // Get Default Sales Code
		    String defaultSalescode = DefaultSalecode.getText();
		    report.reportPass("Verify the Default Sales Code", "Get the Default Sale Code", "Default Selected Sales Codes is " + defaultSalescode);

		} else {
		    report.reportFail("Verify the All Sales Code", "Get the All Sale Code", "Sales Codes are NOT Displayed");
		    report.updateMainReport("ErrorMessage", "Sales Codes are NOT Displayed");

		}

		// Getting Agency Information

		if (isDisplayed(AgencyList, "", 0)) {
		    // Get Default Agency ID
		    String defaultAgencyId = AgencyListDefaultValue.getText();
		    report.reportPass("Verify the Default Agency ID", "Get the Default Agency ID", "Default Selected Agency ID is " + defaultAgencyId);

		} else {
		    report.reportFail("Verify the All Agency IDs", "Get the All Agency IDs", "AgencyIDs are NOT Displayed");
		    report.updateMainReport("ErrorMessage", "AgencyIDs are NOT Displayed");
		}

		// Getting jurisdiction Information

		if (isDisplayed(jurisdiction, "", 0)) {
		    String JurValue = jurisdiction.getText();
		    report.reportPass("Verify Default jurisdiction", "Get the Default jurisdiction", "jurisdiction is " + JurValue);

		} else {
		    report.reportFail("Verify Default jurisdiction", "Get the Default jurisdiction", "jurisdiction is NOT Displayed");
		    report.updateMainReport("ErrorMessage", "jurisdiction is NOT Displayed");
		}
		// Getting Language Information
		if (isDisplayed(Language, "", 0)) {
		    String language = Language.getText();
		    report.reportPass("Verify Language", "Get the Default Language", "Language is " + language);

		} else {
		    report.reportFail("Verify Language", "Get the Default Language", "Language is NOT Displayed");
		    report.updateMainReport("ErrorMessage", "Language is NOT Displayed");
		}

		// Validating AlternateSalesID Section

		if (isDisplayed(AlternateSalesID, "", 0)) {
		    String AlternatesalesIdtext = AlternateSalesID.getText();
		    report.reportPass("Sales Profile Window", "AlternateSalesID Section should  Present and not expanded",
			    "AlternateSalesID Section is Present and not expanded" + AlternatesalesIdtext);
		} else {
		    report.reportFail("Sales Profile Window", "AlternateSalesID Section should  Present and not expanded", "AlternateSalesID Section should  Present and expanded");
		    report.updateMainReport("ErrorMessage", "AlternateSalesID Section should  Present and expanded");
		}
		pageScroll(AlternateSalesID, objectValue, true);
		clickUsingJavaScript(AlternateSalesID, objectValue);
		waitForLoader();
		 report.reportPass("Sales Profile Window", "AlternateSalesID Section should be expanded",
				    "AlternateSalesID Section is expanded");

		// Getting Radio Button Details from Alternate Sales Section
		if (isDisplayed(AlternateSalesSection, "", 1)) {
		    String salesSection = AlternateSalesSection.getText();
		    pageScroll(AlternateSalesSection, salesSection, true);
		    report.reportPass(" Get the Radio Button Details from Alternate Sales Section", "Radio Button Details from Alternate Sales Section", "AlternateSalesSection has : " + salesSection);

		} else {
		    report.reportFail("Get the Radio Button Details from Alternate Sales Section", "Radio Button Details from Alternate Sales Section",
			    "No Information Available in AlternateSalesSection");
		    report.updateMainReport("ErrorMessage", "No Information Available in AlternateSalesSection");
		}

		// Validation Cancel Re-issue Section

		if (isDisplayed(CancelReissue, "", 0)) {
		    String cancelreissuetext = CancelReissue.getText();
		    report.reportPass("Sales Profile Window", "CancelReissue Section should  Present and not expanded", "CancelReissue Section is Present and not expanded" + cancelreissuetext);
		} else {
		    report.reportFail("Sales Profile Window", "CancelReissue Section should  Present and not expanded", "CancelReissue Section should  Present and expanded");
		    report.updateMainReport("ErrorMessage", "CancelReissue Section should  Present and expanded");
		}
		pageScroll(CancelReissue, objectValue, true);
		clickUsingJavaScript(CancelReissue, objectValue);
		// Getting Radio Button Details from CancelReissue Section

		if (isDisplayed(CancelReissueSection, "", 1)) {
		    String CancelReissue = CancelReissueSection.getText();
		    pageScroll(CancelReissueSection, CancelReissue, true);
		    report.reportPass(" Get the Fields from CancelReissue Section", "fields from CancelReissue Section", "CancelReissue has : " + CancelReissue);

		} else {
		    report.reportFail("Get the Fields from CancelReissue Section", "fields from CancelReissue Section", "No Information Available in CancelReissue");
		    report.updateMainReport("ErrorMessage", "No Information Available in CancelReissue");
		}

		clickUsingJavaScript(AlternateSalesID, objectValue);
		clickUsingJavaScript(CancelReissue, objectValue);
		// Save Button Validation

		if (isEnabled(Save, "")) {
		    report.reportPass("Verify If Save Button is Enabled", "Save Button Should be Enabled", "Save Button is Enabled");
		} else {
		    report.reportFail("Verify If Save Button is Enabled", "Save Button Should be Enabled", "Save Button is NOT Enabled");
		    report.updateMainReport("ErrorMessage", "Save Button is NOT Enabled");
		}
	    } catch (Exception exe) {
		exe.printStackTrace();
		report.reportFail("Validate Sales profile GUI Validation", "Validated GUI validations", "Unable to validate GUI Validations" + exe.getCause());
		report.updateMainReport("ErrorMessage", "Unable to validate GUI Validations" + exe.getCause());

	    }

	}

    }

    /**
     * @author v878795
     * @Description:Pre-Ordering Page-New Account Tab—Customer Info Tab
     * @return: No return type
     * @exception Throws
     *                Exception
     * @ModifiedDate:
     * @ModifiedBY:
     * @Comments:
     */
    public void UIValidation_Customer_Info_Tab() throws Exception {

   	if (get("CallingFromGUI").equalsIgnoreCase("Yes")) {

   	    try {

   		String callingPartyName = get("Calling_Party_Name");
   		String callBackNo = get("Call_Back_No");
   		String email = get("Email");
   		String InvalidcallingPartyName = get("Invld_Calling_Party_Name");
   		String InvalidcallBackNo = get("Invld_Call_Back_No");
   		String invalid_Callingptyname_no = get("Invld_Calling_Party_Name_Num");

   		// Customer Info Tab.
   		String pageName = "Customer Info Tab";

   		waitForLoader();

   		guiValidateVisibility(Customer_Info_Tab, pageName, "Customer info Tab", "Customer info Tab should be enable", "Customer info Tab is enable");

   		guiValidateInVisibility(Address_Search, pageName, "Address tab Search", "Address Search Tab should not be enabled", "Addaress search tab is Enabled");

   		guiValidateInVisibility(Verify_Address, pageName, "Verify Address tab", "Verify Address tab should not be enabled", "Verify Address tab is Enabled");

   		guiValidateInVisibility(Available_Services, pageName, "Available Services tab", "Available Services tab should not be enabled", "Available Services tab is Enabled");

   		// Calling Party Name length Validation

   		String strDescription = "Validate wether Calling Party Name should allow only 30 characters";
   		String strExpected = "Calling Party Name should be allowed only 30 characters";
   		String strActual = "Calling Party Name should be allowed only 30 characters";
   		String strFailed = "Calling Party Name is allowing more than 30 characters";
   		getUrl = ", URL Launched --> " + returnURL();

   		clearText(txtNewACCallingPartyName, "");

   		setText(txtNewACCallingPartyName, "", InvalidcallingPartyName);

   		waitForLoader();

   		String Calling_Party_Name_Length = txtNewACCallingPartyName.getAttribute("value");

   		System.out.println(Calling_Party_Name_Length);

   		if (Calling_Party_Name_Length.length() <= 30)

   		{
   		    System.out.println(Calling_Party_Name_Length.length());
   		    report.reportPass(strDescription + getUrl, strExpected, strActual);
   		} else {
   		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
   		    report.updateMainReport("ErrorMessage", strFailed);
   		}

   		// waitForLoader();
   		// Alert Message Validation

   	/*	strDescription = "Validate wether Alert message is Displayed or not";
   		strExpected = "Alert message should be displayed";
   		strActual = "Alert message is Displayed";
   		strFailed = "Alert Message is not Displayed";

   		if (isDisplayed(AlertMsg)) {
   		    System.out.println(AlertMsg.getText());
   		    report.reportPass(strDescription, strExpected, strActual);

   		} else {
   		    report.reportFail(strDescription, strExpected, strFailed);
   		    report.updateMainReport("ErrorMessage", strFailed);
   		}
   		*/

   		// Calling Party Name will not accepts Numeric digits

   		clearText(txtNewACCallingPartyName, "");

   		guiValidateAllowsOnlyAlphapet(txtNewACCallingPartyName, "Verizon_callingParty_Name", pageName, invalid_Callingptyname_no, false);

   		clearText(txtNewACCallingPartyName, "");

   		setText(txtNewACCallingPartyName, "", callingPartyName);

   		// Verizon Wireless or call back number accepts Numeric digits

   		guiValidateAllowsOnlyNumericDigits(txtNewACCallBackNo, "Verizon_CallBack_Number", pageName, callBackNo, true);

   		// Verizon Wireless or call back number not accepts Alphabets
   		clearText(txtNewACCallBackNo, "");

   		guiValidateAllowsOnlyNumericDigits(txtNewACCallBackNo, "Verizon_CallBack_Number", pageName, InvalidcallBackNo, false);

   		// Call back number Validation for 10 Digits

   		strDescription = "Validate that Call back number accepts 10 digits";
   		strExpected = "Call back number should accepts 10 digits";
   		strActual = "Call back number should accepts 10 digits";
   		strFailed = "Call back number is not accepting 10 digits.";
   		getUrl = ", URL Launched --> " + returnURL();

   		clearText(txtNewACCallBackNo, "");

   		setText(txtNewACCallBackNo, "", callBackNo);

   		clickUsingJavaScript(labelNewACCallBackNo, "");

   		String CallBack_Number_Length;

   		CallBack_Number_Length = txtNewACCallBackNo.getAttribute("value").trim();

   		if (CallBack_Number_Length.length() >= 10) {
   		    report.reportPass(strDescription + getUrl, strExpected, strActual);
   		} else {
   		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
   		    report.updateMainReport("ErrorMessage", strFailed);
   		}
   		
   		if(get("Application").equalsIgnoreCase("COA")){
   	
   			// Reason For Call by defaults Sales/Acquisition is Selected.
   	
   			strDescription = "Validate that Reason For Call by defaults Sales/Acquisition is Selected";
   			strExpected = "Reason For Call by defaults Sales/Acquisition should be Selected";
   			strActual = "Reason For Call by defaults Sales/Acquisition should be Selected";
   			strFailed = "Reason For Call by defaults Sales/Acquisition is not Selected";
   			getUrl = ", URL Launched --> " + returnURL();
   	
   			Select select = new Select(dropdwnNewACReasonForCall);
   	
   			select.getFirstSelectedOption().getText();
   	
   			if (select.getFirstSelectedOption().getText().equalsIgnoreCase("Sales/Acquisition")) {
   			    report.reportPass(strDescription + getUrl, strExpected, strActual);
   			} else {
   			    report.reportFail(strDescription + getUrl, strExpected, strFailed);
   			    report.updateMainReport("ErrorMessage", strFailed);
   			}
   		}

   		/*
   		 * // Check for Agency Link is Present
   		 * 
   		 * strDescription = "Validate that AgencyID is Present or not";
   		 * strExpected =
   		 * "AgencyID should be Present in New Install Page"; strActual =
   		 * "AgencyID is Present in New Install Page"; strFailed =
   		 * "AgencyID is not Present in New Install Page";
   		 * 
   		 * if (isDisplayed(AgencyID)) {
   		 * report.reportPass(strDescription, strExpected, strActual); }
   		 * else { report.reportFail(strDescription, strExpected,
   		 * strFailed); }
   		 * 
   		 * clickUsingJavaScript(AgencyID, objectValue);
   		 * 
   		 * waitForLoader();
   		 * 
   		 * clickUsingJavaScript(SaveAgency, objectValue);
   		 */

   		waitForLoader();

   		guiValidateVisibility(NewAccount, pageName, "New Account Tab", "New Acount Section is Displayed", "New Acount Section should be Displayed");

   		// Next Button Enable

   		strDescription = "Validate that Next Button - is in enable mode";
   		strExpected = "Next Button - should be in enable mode";
   		strActual = "Next Button - should be in enable mode";
   		strFailed = "Next Button - should be in enable mode";
   		getUrl = ", URL Launched --> " + returnURL();

   		if (isDisplayed(btnNext)) {
   		    report.reportPass(strDescription + getUrl, strExpected, strActual);
   		} else {
   		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
   		    report.updateMainReport("ErrorMessage", strFailed);
   		}

   		
   		// Line of Business by Default Consumer
   		
   		if(get("Application").equalsIgnoreCase("COA")){

   				strDescription = "Validate that Line Of Business by Default Consumer is selected";
   				strExpected = "Line Of Business by Default Consumer should be selected";
   				strActual = "Line Of Business by Default Consumer should be selected";
   				strFailed = "Line Of Business by Default Consumer is not selected";
   				getUrl = ", URL Launched --> " + returnURL();
   		
   				Select LOB = new Select(Lob);
   		
   			/*	LOB.getFirstSelectedOption().getText();
   		
   				if (LOB.getFirstSelectedOption().getText().equalsIgnoreCase("Consumer")) {
   				    report.reportPass(strDescription + getUrl, strExpected, strActual);
   				} else {
   				    report.reportFail(strDescription + getUrl, strExpected, strFailed);
   				    report.updateMainReport("ErrorMessage", strFailed);
   				}
   				*/
   		
   				// Line of Business Display
   		
   				strDescription = "Validate that Line Of Business has 2 options Consumer and Business";
   				strExpected = "Line Of Business should have 2 options Consumer and Business";
   				strActual = "Line Of Business should have 2 options Consumer and Business";
   				strFailed = "Line Of Business not having 2 options Consumer and Business";
   				getUrl = ", URL Launched --> " + returnURL();
   		
   				// String lob = getTextFromElement(Lob, "");
   		
   				Select lob_dropdown = new Select(Lob);
   		
   				List<WebElement> allOptions = lob_dropdown.getOptions();
   		
   				if (allOptions.size() == 2) {
   				    report.reportPass(strDescription + LOB, strExpected, strActual);
   				} else {
   				    report.reportFail(strDescription + LOB, strExpected, strFailed);
   				    report.updateMainReport("ErrorMessage", strFailed);
   				}
   		
   				// Alternate Telephone Number
   		
   				strDescription = "Validate that Alternate Telephone Number field is Optional";
   				strExpected = "Alternate Telephone Number field should be Optional";
   				strActual = "Alternate Telephone Number field should be Optional";
   				strFailed = "Alternate Telephone Number field is not Optional";
   				getUrl = ", URL Launched --> " + returnURL();
   		
   				String ATN = txtAlternatePhoneNumber.getAttribute("placeholder");
   		
   				if (ATN.contains("Optional")) {
   				    report.reportPass(strDescription + ATN, strExpected, strActual);
   				} else {
   				    report.reportFail(strDescription + ATN, strExpected, strFailed);
   				    report.updateMainReport("ErrorMessage", strFailed);
   				}
   		
   				// Email
   		
   				strDescription = "Validate that Email field is Optional";
   				strExpected = "Email field should be Optional";
   				strActual = "Email field should be Optional";
   				strFailed = "Email field is not Optional";
   				getUrl = ", URL Launched --> " + returnURL();
   		
   				String Email = txtEmail.getAttribute("placeholder");
   		
   				if (Email.contains("Optional")) {
   				    report.reportPass(strDescription + Email, strExpected, strActual);
   				} else {
   				    report.reportFail(strDescription + Email, strExpected, strFailed);
   				    report.updateMainReport("ErrorMessage", strFailed);
   				}
   		
   				// Reason for call DropDown
   		
   				strDescription = "Need to validate all the drop down fields";
   				strExpected = "Should be validated all the drop down fields";
   				strActual = "Should be validated all the drop down fields";
   				strFailed = "Not Anle to Validate all the dropdown fields";
   				getUrl = ", URL Launched --> " + returnURL();
   		
   				Select Reasonforcall_dropdown = new Select(dropdwnNewACReasonForCall);
   		
   				List<WebElement> Reasonforcall_Alloptions = Reasonforcall_dropdown.getOptions();
   		
   				String options = "";
   				for (WebElement i : Reasonforcall_Alloptions) {
   		
   				    options = options + i.getText() + " ;";
   		
   				    // Reporter.log(i.getText());
   				}
   		
   				System.out.println(options);
   		
   				report.reportPass(strDescription + options, strExpected, strActual);
   				// String Reason_For_Call =
   				// getTextFromElement(dropdwnNewACReasonForCall, objectValue);
   		
   				if (Reasonforcall_Alloptions.size() != 0) {
   		
   				    report.reportPass(strDescription + Reasonforcall_Alloptions, strExpected, strActual);
   				} else {
   				    report.reportFail(strDescription + Reasonforcall_Alloptions, strExpected, strFailed);
   				    report.updateMainReport("ErrorMessage", strFailed);
   				}
   		
   		}

   		clearText(txtNewACCallingPartyName, "");
   	    } catch (Exception exe) {
   		exe.printStackTrace();

   	    }

   	}

       }

    /**
     * @author v878795
     * @Description:Pre-Ordering Page-New Account Tab—Customer Info Tab
     * @return: No return type
     * @exception Throws
     *                Exception
     * @ModifiedDate:
     * @ModifiedBY:
     * @Comments:
     */

    public void UIValidation_Verify_Address_Tab() throws Exception {

	if (get("CallingFromGUI").equalsIgnoreCase("Yes")) {

	    String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	    String getUrl = "";
	    String pageName = "Verify_Address_Tab";
	    try {
		// Edit Link

		waitForLoader();

		strDescription = "Validate wether Edit link after Address is present";
		strExpected = "Edit link after Address should be present";
		strActual = "Edit link after Address should be present";
		strFailed = "Edit link after Address should not be present";
		getUrl = ", URL Launched --> " + returnURL();

		if (isDisplayed(Editlink, "")) {
		    report.reportPass(strDescription, strExpected, strActual);
		} else {
		    report.reportFail(strDescription, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// Click on Edit Link.

		clickUsingJavaScript(Editlink, objectValue);

		waitForLoader();

		guiValidateVisibility(Address_Search, pageName, "Address_Search_Tab", "We Should be present in address search Tab", "We are present in address search Tab");

		// Verify Address tab

		clickUsingJavaScript(btnNext, objectValue);

		waitForLoader();

		guiValidateVisibility(Verify_Address, pageName, "Verify_Address_Tab", "We Should be present in Verify Address tab", "We are present in Verify Address tab");

		// Next Button Validation

		// waitForLoader();

		strDescription = "Validate that Next Button Should be Enabled";
		strExpected = "Next Button Should be Enabled in Verify Address tab";
		strActual = "Next Button Should be Enabled in Verify Address tab";
		strFailed = "Next Button is not Enabled in Verify Address tab";
		getUrl = ", URL Launched --> " + returnURL();

		if (isEnabled(btnNext, "")) {
		    report.reportPass(strDescription, strExpected, strActual);
		} else {
		    report.reportFail(strDescription, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// Back Button Check

		// waitForLoader();

		clickUsingJavaScript(Back_Button, objectValue);

		waitForLoader();

		guiValidateVisibility(Address_Search, pageName, "Address_Search_Tab", "Back Button Should be Enabled and working fine", "Back Button is working fine");

		// clicking on Next Button

		// waitForLoader();

		clickUsingJavaScript(btnNext, objectValue);
		waitForLoader();

	    } catch (Exception exe) {
		exe.printStackTrace();
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);

	    }
	}
    }

    /**
     * @author v878795
     * @Description:Pre-Ordering Page-New Account Tab—Available Services Tab
     * @return: No return type
     * @exception Throws
     *                Exception
     * @ModifiedDate:
     * @ModifiedBY:
     * @Comments:
     */

    public void UIValidation_Available_Services_Tab() throws Exception {

	if (get("CallingFromGUI").equalsIgnoreCase("Yes")) {

	    String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	    String getUrl = "";

	    String pageName = "Available_Services_Tab";

	    try {

		// Edit Link

		waitForLoader();

		strDescription = "Validate wether Edit link after Address is present";
		strExpected = "Edit link after Address should be present";
		strActual = "Edit link after Address should be present";
		strFailed = "Edit link after Address should not be present";
		getUrl = ", URL Launched --> " + returnURL();

		// waitForLoader();

		if (isDisplayed(Editlink2, "")) {
		    report.reportPass(strDescription, strExpected, strActual);
		} else {
		    report.reportFail(strDescription, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// Click on Edit Link.

		clickUsingJavaScript(Editlink2, objectValue);

		waitForLoader();

		guiValidateVisibility(Address_Search, pageName, "Address_Search_Tab", "Edit Link Button should be working", "Edit Link Button is working fine");

		// waitForLoader();

		clickUsingJavaScript(btnNext, objectValue);

		waitForLoader();

		guiValidateVisibility(Verify_Address, pageName, "Verify_Address_Tab", "Edit Link Button should be working", "Edit Link Button is working fine");

		// waitForLoader();

		clickUsingJavaScript(btnNext, objectValue);
		waitForLoader();
		
		if(get("Application").equalsIgnoreCase("COA")){


		strDescription = "Validate wether we are at Sales_Profile_Info page";
		strExpected = "We Should be at Sales_Profile_Info page";
		strActual = "We are at Sales_Profile_Info page";
		strFailed = "We are not at Sales_Profile_Info page";

		if (isDisplayed(Sales_Profile_Info, "")) {
		    report.reportPass(strDescription, strExpected, strActual);
		} else {
		    report.reportFail(strDescription, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// waitForLoader();

		clickUsingJavaScript(SaveAgency, objectValue);

		waitForLoader();

		guiValidateVisibility(Available_Services, pageName, "Available_Services_Tab", "We should be at Available_Services Tab", "We are at Available_Services Tab");

		// Available Products & Services Details

		// waitForLoader();

		strDescription = "Available Products & Services:";
		strExpected = "We Should Display Available Products & Services";
		strActual = "We Should Display Available Products & Services:";

		String Product_Details = getTextFromElement(Available_Products_Services, objectValue);

		report.reportPass(strDescription, strExpected, strActual + Product_Details);

		// Address Details

		// waitForLoader();

		strDescription = "Address Details:";
		strExpected = "We Should Display Address Details";
		strActual = "We Should Display Address Details:";

		String address_details = getTextFromElement(Address_Details, objectValue);

		report.reportPass(strDescription, strExpected, strActual + address_details);

		clickUsingJavaScript(Back_Button, "");

		waitForLoader();

		clickUsingJavaScript(btnNext, objectValue);

		waitForLoader();

		clickUsingJavaScript(SaveAgency, objectValue);

		waitForLoader();

		strDescription = "Validate that Back Button is Enable";
		strExpected = "Back Button should be enabled";
		strActual = "Back Button is Enabled";
		strFailed = "Back Button is not Enabled";

		if (isDisplayed(Back_Button, "")) {
		    report.reportPass(strDescription, strExpected, strActual);
		} else {
		    report.reportFail(strDescription, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		strDescription = "Validate that Next Button is Enable";
		strExpected = "Next Button should be enabled";
		strActual = "Next Button is Enabled";
		strFailed = "Next Button is not Enabled";

		if (isDisplayed(btnNext, "")) {
		    report.reportPass(strDescription, strExpected, strActual);
		} else {
		    report.reportFail(strDescription, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// NYDMA Address Validation

		waitForLoader();

		strDescription = "Validate that NYDMA Address is Enable";
		strExpected = "NYDMA Address should be enabled";
		strActual = "NYDMA Address is enabled";
		strFailed = "NYDMA Address is not enabled";
		String nydma_message;

		if (isDisplayed(NYDMA_Capable, "", 0)) {
		    nydma_message = getTextFromElement(NYDMA_Capable, "");

		    if (isDisplayed(NYDMA_Capable)) {
			report.reportPass(strDescription + nydma_message, strExpected, strActual);
		    } else {
			report.reportFail(strDescription + nydma_message, strExpected, strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
		    }
		}

		// Validate that new Account Tab is Active

		guiValidateVisibility(New_Account_Tab, pageName, "NewAccount_Tab", "We should be at New_Account_Tab", "We are at New_Account_Tab");

		// clickUsingJavaScript(btnNext, objectValue);
		}
	    } catch (Exception exe) {
		exe.printStackTrace();
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);

	    }

	}
    }
    
    /**
     * @author v113865
     * @Description: Doing the Stack order for Move scenarios
     * @return: No return type
     * @exception Throws
     *                Exception
     * @ModifiedDate:
     * @ModifiedBY:
     * @Comments:
     */
 
 public void AdvanceSearch() throws Exception {
 	
 	String AdvanceHN = get("AdvanceHN").trim();
 	String AdvanceStr = get("AdvanceStr").trim();
 	try {
 	    waitForLoader();	    
 	    switchToDefaultcontent();
 	
 	  //Door Number clear and set text
 	    clearText(AddressretryHN,objectValue);
 	   System.out.println(AdvanceHN);
 	   setText(AddressretryHN, AdvanceHN, AdvanceHN);
 	  
 	 	 //Directions clear and set text
 	   clearText(AddressretryDirc,objectValue);
 	   
 	  //street name clear and set text
 	  clearText(AddressretryStrnm,objectValue);
 	  System.out.println(AdvanceStr);
 	 setText(AddressretryStrnm, AdvanceStr, AdvanceStr);
 	  
 	//street type clear and set text
 	 clearText(AddressretryStty,objectValue);
 	//street type clear and set text
 	if (isDisplayed(btnNext, "")) {
        clickUsingJavaScript(btnNext, "");
 	   	}
 	
 	waitForLoader();	
 
 	
 	} catch (Exception exe) {
 		exe.printStackTrace();
		report.reportFail("Failed in Negotiating Advance Search in Calling From Page" + getUrl, "Advance search has to be negotiated", "Negotiation of Advance Search in Calling From Page is not successfull");
		report.updateMainReport("ErrorMessage", "Failed in Negotiating Advance Search in Calling From Page");
 		
 		
 		
 	    }
 	
 	}
     


    /**
           * @author v113865
           * @Description: Doing the Stack order for Move scenarios
           * @return: No return type
           * @exception Throws
           *                Exception
           * @ModifiedDate:
           * @ModifiedBY:
           * @Comments:
           */
       
       public void rgmoveStack() throws Exception {

       	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
       	String getUrl = "";
       	try {
       	    waitForLoader();
       	    // Give Customer info
       	    strDescription = "Clicking on Stack Button.";
       	    strExpected = "Should click on Stack and Selected";
       	    strActual = "Clicking on Stack Button and select";
       	    strFailed = "Clicking on Stack Button not Successfull";
       	    getUrl = ", URL Launched --> " + returnURL();
       	    waitForLoader();
       	    switchToDefaultcontent();
       	
       	   try {
       				waitForElementDisplay(snapshot, objectValue, pageTimeoutInSeconds);
       				if (!ordersTab.getAttribute("class").contains("active")) {
       					clickUsingJavaScript(ordersTab, objectValue);
       	    		    waitForPageToLoad(driver);
       	    		}
       				String Stackdisc = get("StackDisconnectOption");
       				String stackoption = getTextFromElement(stackdisconnect1, Stackdisc);
       	    		if (isDisplayed(stackdisconnect, objectValue, 60)) {
       	    		    clickUsingJavaScript(stackdisconnect1, Stackdisc);
       	    		}
       	    			else {
       	    			    report.reportFail("Clicking on Stack Button", "Should click on Stack Button", "Clicking on Stack Button not Successfull");
       	    			}
       	    			report.reportPass(strDescription + getUrl, strExpected+stackoption, strActual+stackoption);
       	   } catch (Exception e) {
                 	
       		    }
       	    waitForLoader();
       		waitForPageToLoad(driver);
       		waitForLoader();
       	} catch (Exception exe) {
       	    if (!isUserDefinedException(exe)) {
       		report.reportFail(strDescription + getUrl, strExpected, strFailed);
       		report.updateMainReport("ErrorMessage", strFailed);
       		captureErrorMsg("Failed in Internet section.");
       	    }
       	    throw exe;
       	}
       	setSearchAndVerifyAddress();
           }
   		
   		

    public void setAccountRetrievedValidation() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	try {
	    // Give Customer info
	    strDescription = "Entering customer info details";
	    strExpected = "Giving customer info in details";
	    strActual = "Giving Customer info in Calling From Page was successful";
	    strFailed = "Giving Customer info in Calling From Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();
	    // **********************************************Header

	    waitForLoader();
	    pause();

	    // ******Customer Details
	    String SearchPage_AccountRetrievalHeader_CustomerName = get("Customer_Name").toString();
	    String AccountRetrieval_StringlabelHeaderCustomerName = labelHeaderCustomerName.getAttribute("textContent");
	    // String StringlabelHeaderTenure =
	    // labelHeaderTenure.getAttribute("textContent");
	    String StringlabelHeaderEmail = labelHeaderEmail.getAttribute("innerText");

	    if (SearchPage_AccountRetrievalHeader_CustomerName.equalsIgnoreCase(AccountRetrieval_StringlabelHeaderCustomerName)) {
		report.reportPass("Verify if customer name is same in Account Retreival page compared to Search Result page",
			"Customer name is same in Account Retreival page compared to Search Result page", strActual);
	    } else {
		report.reportFail("Verify if customer name is same in Account Retreival page compared to Search Result page",
			"Customer Name <br/> Account Retreival page : " + AccountRetrieval_StringlabelHeaderCustomerName + "Search result page : " + SearchPage_AccountRetrievalHeader_CustomerName,
			strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // Customer Address : Search result to Account retrieval
	    try {
		String SearchPage_AccountRetrievalHeader_CustomerAddress = get("Customer_Address").toString();
		String StringlabelHeaderAddressLine = labelHeaderAddressLine1.getAttribute("textContent") + " " + labelHeaderAddressLine2.getAttribute("textContent");
		if (StringlabelHeaderAddressLine.equalsIgnoreCase(SearchPage_AccountRetrievalHeader_CustomerAddress)) {
		    report.reportPass("Verify if customer address is same in Account Retreival page compared to Search Result page",
			    "Customer Address is same in Account Retreival page compared to Search Result page", strActual);
		} else {
		    report.reportFail("Verify if customer address is same in Account Retreival page compared to Search Result page",
			    "Customer Address <br/> Account Retreival page : " + StringlabelHeaderAddressLine + "Search result page : " + SearchPage_AccountRetrievalHeader_CustomerAddress, strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}
	    } catch (Exception e) {
		report.reportFail("Verify if customer address is same in Account Retreival page compared to Search Result page", "Cutomer Address is not displayed", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // *****Calling Party
	    try {
		String StringlabelHeaderCallingParty = labelHeaderCallingParty.getAttribute("innerText").trim();
		String CallingParty = get("Calling_Party_Name");
		if (StringlabelHeaderCallingParty.equalsIgnoreCase(CallingParty)) {
		    report.reportPass("Verify Calling Party Name", "Calling Party Name is same in Account Retreival page compared to Search page", strActual);
		} else {
		    report.reportFail("Verify Calling Party Name", "Calling Party Name <br/> Account Retreival page : " + StringlabelHeaderCallingParty + "<br/>Search page : " + CallingParty,
			    strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}
	    } catch (Exception e) {
		report.reportFail("Verify Calling Party Name", "CallingParty is not displayed", strActual);
	    }

	    // Verify if Calling Party Name is editable
	    try {
		clickUsingJavaScript(labelHeaderCallingParty, objectValue);
		if (isDisplayed(PopupHeaderCallingPartyEdit_NameTextbox)) {
		    report.reportPass("Verify Calling Party Name is editable", "As expected", strActual);
		} else {
		    report.reportFail("Verify Calling Party Name is ediatble", "CallingParty is editable", strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}
		clickUsingJavaScript(CancelButton_EditCallingPartyPopup, objectValue);
	    } catch (Exception exe) {
		report.reportFail("Verify Calling Party Name is editable", "Edit Calling Party popup is not displayed", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // ***** More Options
	    try {
		clickUsingJavaScript(MoreOptions_Header, objectValue);
		report.reportPass("Verify Links Option is loaded", "As expected", strActual);
	    } catch (Exception e) {
		e.printStackTrace();
		report.reportFail("Verify Links Option is loaded", "As expected", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    try {
		// Links
		clickUsingJavaScript(Links_Header, objectValue);
		// Verify for new window content
		if (Header_Links_PopUp.getAttribute("innerText").contains("Links")) {
		    report.reportPass("Verify Links Popup is loaded", "As expected", strActual);
		} else {
		    report.reportFail("Verify Links Popup is loaded", "Not Loaded", strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}
		// Links
		clickUsingJavaScript(CloseX_PopUp_VerticalModal, objectValue);
	    } catch (Exception e) {
		e.printStackTrace();
		report.reportFail("Verify Links Option is loaded", "As expected", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    String ParentWindow = null;

	    // //*****Chat window
	    // ParentWindow = null;
	    // try{
	    // clickUsingJavaScript(OpenChatWindow, objectValue);
	    // pause();
	    // ParentWindow = driver.getWindowHandle();
	    // System.out.println(driver.getWindowHandles().size());
	    // if(driver.getWindowHandles().size()>0){
	    // report.reportPass("Verify Chat Window if Opened", "As expected",
	    // strActual);
	    // for(String w: driver.getWindowHandles()){
	    // driver.switchTo().window(w);
	    // System.out.println(driver.getTitle());
	    // String WindowTitle = driver.getTitle();
	    // if(!WindowTitle.contains(get("Search_Value")) &&
	    // !WindowTitle.contains("Rep Dashboar")){
	    // break;
	    // }
	    // }
	    // }
	    // try{
	    // //Verify for new window content
	    //// driver.switchTo().frame(ChatWindowOuterFrame);
	    // driver.switchTo().frame(0);
	    // switchToFrame("chat-window-1");
	    // if(isDisplayed(Cancel_ChatWindow)){
	    // report.reportPass("Verify Chat Window loaded", "As expected",
	    // strActual);
	    // }else{
	    // report.reportFail("Verify Chat Window loaded", "Chat window is
	    // not loaded", strActual);
	    // }
	    // clickUsingJavaScript(Cancel_ChatWindow,objectValue);
	    // driver.close();
	    // driver.switchTo().window(ParentWindow);
	    // }catch(Exception e){
	    // driver.close();
	    // driver.switchTo().window(ParentWindow);
	    // }
	    // }catch(Exception e){
	    // report.reportFail("Verify Chat Window Opens", "Chat window is not
	    // loaded", strActual);
	    // driver.close();
	    // driver.switchTo().window(ParentWindow);
	    // }

	    // *****How To window
	    ParentWindow = null;
	    try {
		clickUsingJavaScript(MoreOptions_Header, objectValue);
		clickUsingJavaScript(HowTo_Link_Header, objectValue);
		pause();
		ParentWindow = driver.getWindowHandle();
		System.out.println(driver.getWindowHandles().size());
		if (driver.getWindowHandles().size() > 0) {
		    report.reportPass("Verify 'How To' Window if Opened", "As expected", strActual);
		    for (String w : driver.getWindowHandles()) {
			driver.switchTo().window(w);
			System.out.println(driver.getTitle());
			String WindowTitle = driver.getTitle();
			if (!WindowTitle.contains(get("Search_Value")) && !WindowTitle.contains("Rep Dashboar")) {
			    break;
			}
		    }
		}
		try {
		    // Verify for new window content
		    // driver.switchTo().frame(ChatWindowOuterFrame);
		    // driver.switchTo().frame(0);
		    switchToFrame("chat-window-1");
		    if (isDisplayed(HowTo_Window_CoFEEHandout)) {
			report.reportPass("Verify 'How To' Window loaded", "As expected", strActual);
		    } else {
			report.reportFail("Verify 'How To' Window loaded", "'How To' is not loaded", strActual);
			report.updateMainReport("ErrorMessage", strActual);
		    }
		    driver.close();
		    driver.switchTo().window(ParentWindow);
		} catch (Exception e) {
		    driver.close();
		    driver.switchTo().window(ParentWindow);
		}
	    } catch (Exception e) {
		report.reportFail("Verify 'How To' Window Opens", "'How To' window is not loaded", strActual);
		report.updateMainReport("ErrorMessage", strActual);
		driver.close();
		driver.switchTo().window(ParentWindow);
	    }

	    // Verify if Follow Up is opening
	    try {
		clickUsingJavaScript(OpenFollowUpWindow, objectValue);
		// Verify for new window content
		if (isDisplayed(Cancel_FollowUpWindow)) {
		    report.reportPass("Verify FollowUp pop up loaded", "As expected", strActual);
		} else {
		    report.reportFail("Verify FollowUp pop up loaded", "Not Loaded", strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}
		clickUsingJavaScript(Cancel_FollowUpWindow, objectValue);
	    } catch (Exception e) {
		e.printStackTrace();
		report.reportFail("Verify FollowUp pop Opens", "FollowUp pop is not loaded", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // End Header**********************************************

	    // Verify if Bundle Tile is Displayed with non empty content and
	    // able to launch profile details
	    try {
		// Verify for new window content
		if (isDisplayed(BundleTile_LeftPane)) {
		    report.reportPass("Verify Product Tile is loaded", "As expected", strActual);
		} else {
		    report.reportFail("Verify Product Tile is loaded", "Not Loaded", strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		    throw new NoSuchElementException("Left Side Tiles are not loaded in Account Retreival Page");
		}

	    } catch (Exception e) {
		e.printStackTrace();
		report.reportFail("Verify Product Tile", "Unable to Verify - Left Panel is not loaded with Bundles/Packacges Tile", strActual);
		report.updateMainReport("ErrorMessage", strActual);
		throw e;
	    }
	    try {
		clickUsingJavaScript(BundleTile_BundleLink, objectValue);

		String ProfileInfo_AccountNumber = ProfileDetails_PopUp_AccountNumber.getAttribute("innerText");
		ProfileInfo_AccountNumber = ProfileDetails_PopUp_AccountNumber.getAttribute("textContent");
		System.out.println(get("Search_Value").toString());
		if (ProfileInfo_AccountNumber.contains(get("Search_Value"))) {
		    report.reportPass("Verify Profile Information pop up is loaded", "As expected", strActual);
		} else {
		    report.reportFail("Verify Profile Information pop up is loaded", "Not loaded", strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}
		clickUsingJavaScript(ProfileDetails_PopUp_Cancel, objectValue);
	    } catch (Exception e) {
		e.printStackTrace();
		report.reportFail("Verify Profile Information pop up is loaded", "Not Loaded", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }
	    // Verify Tile Present generic
	    try {
		String[] TileName = get("LeftTiles").split(";");
		for (String TileTitle : TileName) {
		    try {
			// System.out.println(isDisplayed(TileDynamic_LeftPane,
			// "Connections"));
			if (isDisplayed(TileDynamic_LeftPane, TileTitle, 2)) {
			    report.reportPass("Verify " + TileTitle + " Tile is loaded", "As expected", strActual);
			} else {
			    report.reportFail("Verify " + TileTitle + " Tile is loaded", "Not Loaded", strActual);
			    report.updateMainReport("ErrorMessage", strActual);
			}
		    } catch (Exception e) {
			report.reportFail("Verify " + TileTitle + " Tile is loaded", "Unable to validate", strActual);
			report.updateMainReport("ErrorMessage", strActual);
		    }
		}
	    } catch (Exception e) {
		report.reportFail("Verify Insights Tile is loaded", "Unable to Validate", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // //Verify Insights Tile
	    // try{
	    // if(isDisplayed(InsightsView_LeftPane)){
	    // report.reportPass("Verify Insights Tile is loaded", "As
	    // expected", strActual);
	    // }else{
	    // report.reportFail("Verify Insights Tile is loaded", "Not Loaded",
	    // strActual);
	    // }
	    // }catch(Exception e){
	    // report.reportFail("Verify Insights Tile is loaded", "Unable to
	    // Validate", strActual);
	    // }
	    //
	    // //Verify Connections Tile
	    // try{
	    // if(isDisplayed(InsightsView_LeftPane)){
	    // report.reportPass("Verify Insights Tile is loaded", "As
	    // expected", strActual);
	    // }else{
	    // report.reportFail("Verify Insights Tile is loaded", "Not Loaded",
	    // strActual);
	    // }
	    // }catch(Exception e){
	    // report.reportFail("Verify Insights Tile is loaded", "Unable to
	    // Validate", strActual);
	    // }

	    // Verify Activity Tile
	    try {
		// Check if Activity is toggled ON by default
		if (Activity_ToggleButton.getAttribute("Class").contains("actve")) {
		    report.reportPass("Verify Activity is toggled ON by default", "As expected", strActual);
		} else {
		    report.reportFail("Verify Activity is toggled ON by default", "Not ON", strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		    clickUsingJavaScript(Activity_ToggleButton, objectValue);
		}

		String TimeLineText = AcitivityTimelineList.getAttribute("textContent");
		if (!TimeLineText.isEmpty()) {
		    report.reportPass("Verify Activity Time Line is loaded", "As expected", strActual);
		} else {
		    report.reportFail("Verify Activity Time Line is loaded", "Not Loaded", strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}
	    } catch (Exception e) {
		report.reportFail("Verify Insights Tile is loaded", "Unable to Validate", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	} catch (Exception e) {
	    e.printStackTrace();
	    report.reportFail(strDescription + getUrl, strExpected, strFailed);
	    report.updateMainReport("ErrorMessage", strActual);
	    throw e;
	}

    }

    public void setAccountRetrievedValidationNewUI() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	try {
	    // Give Customer info
	    strDescription = "Entering customer info details";
	    strExpected = "Giving customer info in details";
	    strActual = "Giving Customer info in Calling From Page was successful";
	    strFailed = "Giving Customer info in Calling From Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();

	    // **********************************************Header

	    waitForLoader();
	    pause();

	    // ******Customer Details
	    String SearchPage_AccountRetrievalHeader_CustomerName = get("Customer_Name").toString();
	    String AccountRetrieval_StringlabelHeaderCustomerName = labelHeaderCustomerNameNew.getAttribute("textContent");
	    // String StringlabelHeaderTenure =
	    // labelHeaderTenure.getAttribute("textContent");
	    String StringlabelHeaderEmail = labelHeaderEmailNew.getAttribute("innerText");

	    if (SearchPage_AccountRetrievalHeader_CustomerName.equalsIgnoreCase(AccountRetrieval_StringlabelHeaderCustomerName)) {
		report.reportPass("Verify if customer name is same in Account Retreival page compared to Search Result page",
			"Customer name is same in Account Retreival page compared to Search Result page", strActual);
	    } else {
		report.reportFail("Verify if customer name is same in Account Retreival page compared to Search Result page",
			"Customer Name <br/> Account Retreival page : " + AccountRetrieval_StringlabelHeaderCustomerName + "Search result page : " + SearchPage_AccountRetrievalHeader_CustomerName,
			strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // Verify if email address of customer is present
	    if (StringlabelHeaderEmail.contains("@") && StringlabelHeaderEmail.contains(".com")) {
		report.reportPass("Verify if Email for Customer is displayed", "As expected : " + StringlabelHeaderEmail, strActual);
	    } else {
		report.reportFail("Verify if Email for Customer is displayed", "Email id should be displayed", "Not As expected");
		report.updateMainReport("ErrorMessage", "Not As expected");
	    }

	    // Customer Address : Search result to Account retrieval
	    try {
		String SearchPage_AccountRetrievalHeader_CustomerAddress = get("Customer_Address").toString();
		String StringlabelHeaderAddressLine = labelHeaderAddressLine1New.getAttribute("textContent") + " " + labelHeaderAddressLine2New.getAttribute("textContent");
		if (StringlabelHeaderAddressLine.equalsIgnoreCase(SearchPage_AccountRetrievalHeader_CustomerAddress)) {
		    report.reportPass("Verify if customer address is same in Account Retreival page compared to Search Result page",
			    "Customer Address is same in Account Retreival page compared to Search Result page", strActual);
		} else {
		    report.reportFail("Verify if customer address is same in Account Retreival page compared to Search Result page",
			    "Customer Address <br/> Account Retreival page : " + StringlabelHeaderAddressLine + "Search result page : " + SearchPage_AccountRetrievalHeader_CustomerAddress, strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}
	    } catch (Exception e) {
		report.reportFail("Verify if customer address is same in Account Retreival page compared to Search Result page", "Cutomer Address is not displayed", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // *****Calling Party
	    try {
		String StringlabelHeaderCallingParty = labelHeaderCallingPartyNew.getAttribute("innerText").trim().split(" - ")[1];
		// String StringlabelHeaderCallingParty =
		// labelHeaderCallingPartyNew.getAttribute("innerText").trim();
		String CallingParty = get("Calling_Party_Name");
		if (StringlabelHeaderCallingParty.equalsIgnoreCase(CallingParty)) {
		    report.reportPass("Verify Calling Party Name", "Calling Party Name is same in Account Retreival page compared to Search page", strActual);
		} else {
		    report.reportFail("Verify Calling Party Name", "Calling Party Name <br/> Account Retreival page : " + StringlabelHeaderCallingParty + "<br/>Search page : " + CallingParty,
			    strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}
	    } catch (Exception e) {
		report.reportFail("Verify Calling Party Name", "CallingParty is not displayed", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // Verify if Calling Party Name is editable
	    try {
		String comparetexttemp = "";
		clickUsingJavaScript(EditCallingPartyNew, objectValue);
		if (isDisplayed(PopupHeaderCallingPartyEdit_NameTextbox)) {
		    report.reportPass("Verify Calling Party Name is editable", "As expected", strActual);
		    clearText(PopupHeaderCallingPartyEdit_NameTextbox, objectValue);
		    PopupHeaderCallingPartyEdit_NameTextbox.clear();
		    setText(PopupHeaderCallingPartyEdit_NameTextbox, objectValue, "TestString");
		    clickUsingJavaScript(SaveButton_PopupHeaderCallingPartyEdit, objectValue);
		    comparetexttemp = labelHeaderCallingPartyNew.getAttribute("innerText").trim().split(" - ")[1];
		    if (comparetexttemp.equals("TestString")) {
			report.reportPass("Verify Calling Party Name is updated to new value", "", "As expected : " + "TestString");
		    } else {
			report.reportFail("Verify Calling Party Name is updated to new value", "", "Not as expected : " + comparetexttemp + " instead of " + "TestString");
			report.updateMainReport("ErrorMessage", "Not as expected : " + comparetexttemp + " instead of " + "TestString");
		    }
		} else {
		    report.reportFail("Verify Calling Party Name is ediatble", "CallingParty is editable", strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}
	    } catch (Exception exe) {
		report.reportFail("Verify Calling Party Name is editable", "Edit Calling Party popup is not displayed", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // *****Callback Number
	    try {
		String StringlabelHeaderCallbackNumber = labelHeaderCallingPartyNew.getAttribute("innerText").trim().split(" - ")[0];
		// String StringlabelHeaderCallingParty =
		// labelHeaderCallingPartyNew.getAttribute("innerText").trim();
		String CallingBackNumber = "#" + get("Call_Back_No").toString();
		if (StringlabelHeaderCallbackNumber.equalsIgnoreCase(CallingBackNumber)) {
		    report.reportPass("Verify Callback Number", "Callback Number is same in Account Retreival page compared to Search page", strActual);
		} else {
		    report.reportFail("Verify Callback Number", "Callback Number <br/> Account Retreival page : " + StringlabelHeaderCallbackNumber + "<br/>Search page : " + CallingBackNumber,
			    strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}
	    } catch (Exception e) {
		e.printStackTrace();
		report.reportFail("Verify Callback Number", "Callback Number is not displayed", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    String ParentWindow = null;

	    // //*****Chat window
	    // ParentWindow = null;
	    // try{
	    // clickUsingJavaScript(OpenChatWindowNew, objectValue);
	    // pause();
	    // ParentWindow = driver.getWindowHandle();
	    // System.out.println(driver.getWindowHandles().size());
	    // if(driver.getWindowHandles().size()>0){
	    // report.reportPass("Verify Chat Window if Opened", "As expected",
	    // strActual);
	    // for(String w: driver.getWindowHandles()){
	    // driver.switchTo().window(w);
	    // System.out.println(driver.getTitle());
	    // String WindowTitle = driver.getTitle();
	    // if(!WindowTitle.contains(get("Search_Value")) &&
	    // !WindowTitle.contains("Rep Dashboar")){
	    // break;
	    // }
	    // }
	    // }
	    // try{
	    // //Verify for new window content
	    //// driver.switchTo().frame(ChatWindowOuterFrame);
	    // driver.switchTo().frame(0);
	    // switchToFrame("chat-window-1");
	    // if(isDisplayed(Cancel_ChatWindow)){
	    // report.reportPass("Verify Chat Window loaded", "As expected",
	    // strActual);
	    // }else{
	    // report.reportFail("Verify Chat Window loaded", "Chat window is
	    // not loaded", strActual);
	    // }
	    // clickUsingJavaScript(Cancel_ChatWindow,objectValue);
	    // driver.close();
	    // driver.switchTo().window(ParentWindow);
	    // }catch(Exception e){
	    // driver.close();
	    // driver.switchTo().window(ParentWindow);
	    // }
	    // }catch(Exception e){
	    // report.reportFail("Verify Chat Window Opens", "Chat window is not
	    // loaded", strActual);
	    // driver.close();
	    // driver.switchTo().window(ParentWindow);
	    // }

	    // ***** Support Info
	    try {
		String HeaderIconString = "SUPPORT";
		clickUsingJavaScript(HeaderIcon_Dynamic, HeaderIconString);
		report.reportPass("Verify 'SUPPORT INFO' icon is available", "", "As expected");
		if (isDisplayed(SearchTextField_SupportInfoPopUp, objectValue, 10)) {
		    report.reportPass("Verify 'SUPPORT INFO' Pop up is available", "", "As expected");
		} else {
		    report.reportFail("Verify 'SUPPORT INFO' Pop up is available", "", "Not as expected");
		    report.updateMainReport("ErrorMessage", "Not as expected");
		}
		clickUsingJavaScript(CloseButton_SupportInfoPopUp, objectValue);
	    } catch (Exception e) {
		e.printStackTrace();
		report.reportFail("Verify 'SUPPORT Options' is loaded", "", "Not as expected");
		report.updateMainReport("ErrorMessage", "Not as expected");
		clickUsingJavaScript(CloseButton_SupportInfoPopUp, objectValue);
	    }

	    // ***** CALL NOTES
	    try {
		String HeaderIconString = "CALL";
		String TestString = "Test";
		clickUsingJavaScript(HeaderIcon_Dynamic, HeaderIconString);
		report.reportPass("Verify 'CALL NOTES' icon is available", "", "As expected");
		setText(TextArea_CallNotesPopUp, objectValue, TestString);
		clickUsingJavaScript(CloseButton_CallNotesPopUp, objectValue);

		// Check if entered text is retained in Call notes
		try {
		    clickUsingJavaScript(HeaderIcon_Dynamic, HeaderIconString);
		    if (TextAreaRead_CallNotesPopUp.getAttribute("innerText").trim().contains(TestString)) {
			report.reportPass("Verify 'CALL NOTES' retains the etered text", "", "As expected");
		    } else {
			report.reportFail("Verify 'CALL NOTES' retains the etered text", "", "Not as expected");
			report.updateMainReport("ErrorMessage", "Not as expected");
		    }
		    clickUsingJavaScript(CloseButton_CallNotesPopUp, objectValue);
		} catch (Exception e) {
		    clickUsingJavaScript(CloseButton_CallNotesPopUp, objectValue);
		    report.reportFail("Verify 'CALL NOTES' retains the etered text", "", "Unable to verify");
		    report.updateMainReport("ErrorMessage", "Unable to verify");
		}

	    } catch (Exception e) {
		e.printStackTrace();
		report.reportFail("Verify 'CALL NOTES' is loaded", "", "Not as expected");
		report.updateMainReport("ErrorMessage", "Not as expected");
		clickUsingJavaScript(CloseButton_SupportInfoPopUp, objectValue);
	    }

	    // Verify if Follow Ups is opening
	    try {
		String HeaderIconString = "FOLLOW";
		String TestString = "Test";
		clickUsingJavaScript(OpenFollowUpWindowNew, objectValue);
		// Verify for new window content
		if (isDisplayed(Cancel_FollowUpWindowNew)) {
		    report.reportPass("Verify 'Follow Ups' pop up loaded", "", "As expected");
		} else {
		    report.reportFail("Verify 'Follow Ups' pop up loaded", "", "Not Loaded");
		    report.updateMainReport("ErrorMessage", "Not Loaded");
		}
		clickUsingJavaScript(Cancel_FollowUpWindowNew, objectValue);
	    } catch (Exception e) {
		e.printStackTrace();
		report.reportFail("Verify 'Follow Ups' pop up Opens", "", "'Follow Ups' pop is not loaded");
		report.updateMainReport("ErrorMessage", "'Follow Ups' pop is not loaded");
	    }

	    // ***** More Options
	    try {
		clickUsingJavaScript(MoreOptions_HeaderNew, objectValue);
		report.reportPass("Verify 'More Options' is loaded", "", "As expected");
	    } catch (Exception e) {
		e.printStackTrace();
		report.reportFail("Verify 'More Options' is loaded", "", "Not as expected");
		report.updateMainReport("ErrorMessage", "Not as expected");
	    }

	    try {
		// Links
		clickUsingJavaScript(Links_HeaderNew, objectValue);
		// Verify for new window content
		if (Header_Links_PopUpNew.getAttribute("innerText").contains("Links")) {
		    report.reportPass("Verify Links Popup is loaded", "As expected", strActual);
		} else {
		    report.reportFail("Verify Links Popup is loaded", "Not Loaded", strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}

		// check if all expandable sections are present in the pop up
		if (Header_Links_PopUpNew.getAttribute("innerText").contains("Links")) {
		    report.reportPass("Verify Links Popup has loaded with all sub sections", "As expected", strActual);
		} else {
		    report.reportFail("Verify Links Popup has loaded with all sub sections", "Not Loaded", strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}

		// Links
		clickUsingJavaScript(CloseX_PopUp_VerticalModal, objectValue);
	    } catch (Exception e) {
		e.printStackTrace();
		report.reportFail("Verify Links Option is loaded", "As expected", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // *****How To window
	    ParentWindow = null;
	    try {
		clickUsingJavaScript(MoreOptions_HeaderNew, objectValue);
		clickUsingJavaScript(HowTo_Link_HeaderNew, objectValue);
		// pause();
		ParentWindow = driver.getWindowHandle();
		System.out.println(driver.getWindowHandles().size());
		if (driver.getWindowHandles().size() > 0) {
		    report.reportPass("Verify 'How To' Window if Opened", "As expected", strActual);
		    for (String w : driver.getWindowHandles()) {
			driver.switchTo().window(w);
			System.out.println(driver.getTitle());
			String WindowTitle = driver.getTitle();
			if (!WindowTitle.contains(get("Search_Value")) && !WindowTitle.contains("Rep Dashboar")) {
			    break;
			}
		    }
		}
		try {
		    // Verify for new window content
		    // driver.switchTo().frame(ChatWindowOuterFrame);
		    // driver.switchTo().frame(0);
		    switchToFrame("chat-window-1");
		    if (isDisplayed(HowTo_Window_CoFEEHandoutNew)) {
			report.reportPass("Verify 'How To' Window loaded", "As expected", strActual);
		    } else {
			report.reportFail("Verify 'How To' Window loaded", "'How To' is not loaded", strActual);
			report.updateMainReport("ErrorMessage", strActual);
		    }
		    driver.close();
		    driver.switchTo().window(ParentWindow);
		} catch (Exception e) {
		    driver.close();
		    driver.switchTo().window(ParentWindow);
		}
	    } catch (Exception e) {
		report.reportFail("Verify 'How To' Window Opens", "'How To' window is not loaded", strActual);
		report.updateMainReport("ErrorMessage", strActual);
		driver.close();
		driver.switchTo().window(ParentWindow);
	    }

	    // Verify if Bundle Section is Displayed with non empty content and
	    // able to launch profile details
	    try {
		// Verify for new window content
		if (isDisplayed(BundleTile_LeftPaneNew)) {
		    report.reportPass("Verify Product Tile is loaded", "As expected", strActual);
		} else {
		    report.reportFail("Verify Product Tile is loaded", "Not Loaded", strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		    throw new NoSuchElementException("Product Tile is not loaded in Account Retreival Page");
		}

	    } catch (Exception e) {
		e.printStackTrace();
		e.printStackTrace();
		report.reportFail("Verify Product Tile", "", "Not Loaded");
		report.updateMainReport("ErrorMessage", "Not Loaded");
	    }
	    try {
		clickUsingJavaScript(BundleTile_BundleLinkNew, objectValue);
		Thread.sleep(5000);
		String ProfileInfo_AccountNumber = ProfileDetails_PopUp_AccountNumber.getAttribute("innerText").trim();
		// ProfileInfo_AccountNumber =
		// ProfileDetails_PopUp_AccountNumber.getAttribute("textContent");
		System.out.println(get("Search_Value").toString());
		if (ProfileInfo_AccountNumber.contains(get("Search_Value"))) {
		    report.reportPass("Verify Profile Information pop up is loaded", "As expected", strActual);
		} else {
		    report.reportFail("Verify Profile Information pop up is loaded", "Not loaded", strActual);
		    report.updateMainReport("ErrorMessage", strActual);
		}
		clickUsingJavaScript(ProfileDetails_PopUp_Cancel, objectValue);
	    } catch (Exception e) {
		e.printStackTrace();
		report.reportFail("Verify Profile Information pop up is loaded", "Not Loaded", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // End Header**********************************************

	    // Verify Tile Present generic
	    try {
		boolean flag = false;
		String[] TileName = get("LeftTiles").split(";");
		for (String TileTitle : TileName) {
		    try {
			// System.out.println(isDisplayed(TileDynamic_LeftPane,
			// "Connections"));
			if (isDisplayed(TileLabelDynamic_LeftPaneNew, TileTitle, 2)) {
			    report.reportPass("Verify " + TileTitle + " Tile is loaded", "As expected", strActual);

			    // check if clicking on icon opens a window
			    int TotalWindowSize = 2;
			    try {
				pageScroll(TileIconDynamic_LeftPaneNew, TileTitle, true);
				clickUsingJavaScript(TileIconDynamic_LeftPaneNew, TileTitle);
				ParentWindow = driver.getWindowHandle();
				System.out.println(driver.getWindowHandles().size());
				TotalWindowSize = driver.getWindowHandles().size();
				if (driver.getWindowHandles().size() > 2) {
				    for (String w : driver.getWindowHandles()) {
					driver.switchTo().window(w);
					System.out.println(driver.getTitle());
					String WindowTitle = driver.getTitle();
					if (!WindowTitle.contains(get("Search_Value")) && !WindowTitle.contains("Rep Dashboar")) {
					    flag = true;
					    break;
					}
				    }
				    if (flag) {
					report.reportPass("Verify clicking'" + TileTitle + "' Icon opens another window", "", "As expected");
					driver.close();
					driver.switchTo().window(ParentWindow);
				    } else {
					report.reportFail("Verify clicking'" + TileTitle + "' Icon opens another window", "", "Not As expected");
					report.updateMainReport("ErrorMessage", "Not As expected");
					driver.switchTo().window(ParentWindow);
				    }
				    flag = false;
				}
			    } catch (Exception e) {
				if (TotalWindowSize > 2) {
				    driver.close();
				}
				driver.switchTo().window(ParentWindow);
			    }

			} else {
			    report.reportFail("Verify '" + TileTitle + "' Card is presnt in left Pane", "", "Not As expected");
			    report.updateMainReport("ErrorMessage", "Not As expected");
			}
		    } catch (Exception e) {

			report.reportFail("Verify '" + TileTitle + "' Card is presnt in left Pane", "", "Unable to validate");
			report.updateMainReport("ErrorMessage", "Unable to validate");
		    }
		}
	    } catch (Exception e) {
		report.reportFail("Verify Insights Tile is loaded", "Unable to Validate", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // //Verify Insights Tile
	    // try{
	    // if(isDisplayed(InsightsView_LeftPane)){
	    // report.reportPass("Verify Insights Tile is loaded", "As
	    // expected", strActual);
	    // }else{
	    // report.reportFail("Verify Insights Tile is loaded", "Not Loaded",
	    // strActual);
	    // }
	    // }catch(Exception e){
	    // report.reportFail("Verify Insights Tile is loaded", "Unable to
	    // Validate", strActual);
	    // }
	    //
	    // //Verify Connections Tile
	    // try{
	    // if(isDisplayed(InsightsView_LeftPane)){
	    // report.reportPass("Verify Insights Tile is loaded", "As
	    // expected", strActual);
	    // }else{
	    // report.reportFail("Verify Insights Tile is loaded", "Not Loaded",
	    // strActual);
	    // }
	    // }catch(Exception e){
	    // report.reportFail("Verify Insights Tile is loaded", "Unable to
	    // Validate", strActual);
	    // }

	    // Verify ACTIVITY switch in header
	    try {
		String SwitchString = "ACTIVITY";
		String HeaderIconString = "ACTIVITY";
		String TestString = "Activity  Timeline";

		// Check if ACTIVITY is not toggled ON by default
		if (getAttribute(ToggleButton_DynamicNew, HeaderIconString, "class").contains("active")) {
		    report.reportPass("Verify " + SwitchString + " is toggled ON by default", "", "As expected");
		} else {
		    report.reportFail("Verify " + SwitchString + " is toggled ON by default", "", "Not As Expected");
		    report.updateMainReport("ErrorMessage", "Not As Expected");
		    clickUsingJavaScript(ToggleButton_DynamicNew, SwitchString);
		}
		Thread.sleep(5000);
		String HeadingLabel = getAttribute(Title_PanelNew, TestString, "textContent").trim();
		if (HeadingLabel.equals(TestString)) {
		    report.reportPass("Verify " + SwitchString + " pane is loaded", "", "As expected");
		} else {
		    report.reportFail("Verify " + SwitchString + " pane is loaded", "", "Not Loaded");
		    report.updateMainReport("ErrorMessage", "Not Loaded");
		}

		String ContentText = getAttribute(Content_PanelNew, TestString, "textContent").trim();
		if (!ContentText.isEmpty()) {
		    report.reportPass("Verify " + SwitchString + " pane is loaded with non-empty content", "", "As expected");
		} else {
		    report.reportFail("Verify " + SwitchString + " Time Line is loaded with non-empty content", "", "Not As Expected");
		    report.updateMainReport("ErrorMessage", "Not As Expected");
		}
		// OFF
		clickUsingJavaScript(ToggleButton_DynamicNew, SwitchString);
	    } catch (Exception e) {
		report.reportFail("Verify Insights Tile is loaded", "Unable to Validate", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // Verify BILLING switch in header
	    try {
		String SwitchString = "BILLING";
		String HeaderIconString = "BILLING";
		String TestString = "Billing & Payment";

		// Check if BILLING is not toggled ON by default
		if (!getAttribute(ToggleButton_DynamicNew, HeaderIconString, "class").contains("active")) {
		    report.reportPass("Verify " + SwitchString + " is toggled not ON by default", "", "As expected");
		    clickUsingJavaScript(ToggleButton_DynamicNew, SwitchString);
		} else {
		    report.reportFail("Verify " + SwitchString + " is toggled not ON by default", "", "Not As Expected");
		    report.updateMainReport("ErrorMessage", "Not As Expected");
		}
		Thread.sleep(5000);
		String HeadingLabel = getAttribute(Title_PanelNew, TestString, "textContent").trim();
		if (HeadingLabel.equals(TestString)) {
		    report.reportPass("Verify " + SwitchString + " pane is loaded", "", "As expected");
		} else {
		    report.reportFail("Verify " + SwitchString + " pane is loaded", "", "Not Loaded");
		    report.updateMainReport("ErrorMessage", "Not Loaded");
		}

		String ContentText = getAttribute(Content_PanelNew, TestString, "textContent").trim();
		if (!ContentText.isEmpty()) {
		    report.reportPass("Verify " + SwitchString + " pane is loaded with non-empty content", "", "As expected");
		} else {
		    report.reportFail("Verify " + SwitchString + " is loaded with non-empty content", "", "Not As Expected");
		    report.updateMainReport("ErrorMessage", "Not As Expected");
		}
		// OFF
		clickUsingJavaScript(ToggleButton_DynamicNew, SwitchString);
	    } catch (Exception e) {
		report.reportFail("Verify BILLING is loaded", "Unable to Validate", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	    // Verify ORDERING switch in header
	    try {
		String SwitchString = "ORDERING";
		String HeaderIconString = "ORDERING";
		String TestString = "Products  & Services";

		// Check if ORDERING is not toggled ON by default
		if (!getAttribute(ToggleButton_DynamicNew, HeaderIconString, "class").contains("active")) {
		    report.reportPass("Verify " + SwitchString + " is toggled not ON by default", "", "As expected");
		    clickUsingJavaScript(ToggleButton_DynamicNew, SwitchString);
		} else {
		    report.reportFail("Verify " + SwitchString + " is toggled not ON by default", "", "Not As Expected");
		    report.updateMainReport("ErrorMessage", "Not As Expected");
		}
		Thread.sleep(5000);
		String HeadingLabel = getAttribute(Title_PanelNew, TestString, "textContent").trim();
		if (HeadingLabel.equals(TestString)) {
		    report.reportPass("Verify " + SwitchString + " pane is loaded", "", "As expected");
		} else {
		    report.reportFail("Verify " + SwitchString + " pane is loaded", "", "Not Loaded");
		    report.updateMainReport("ErrorMessage", "Not Loaded");
		}

		String ContentText = getAttribute(Content_PanelNew, TestString, "textContent").trim();
		if (!ContentText.isEmpty()) {
		    report.reportPass("Verify " + SwitchString + " pane is loaded with non-empty content", "", "As expected");
		} else {
		    report.reportFail("Verify " + SwitchString + " is loaded with non-empty content", "", "Not As Expected");
		    report.updateMainReport("ErrorMessage", "Not As Expected");
		}
		// OFF
		clickUsingJavaScript(ToggleButton_DynamicNew, SwitchString);
	    } catch (Exception e) {
		report.reportFail("Verify ORDERING is loaded", "Unable to Validate", strActual);
		report.updateMainReport("ErrorMessage", strActual);
	    }

	} catch (Exception e) {
	    e.printStackTrace();
	    report.reportFail(strDescription + getUrl, strExpected, strFailed);
	    report.updateMainReport("ErrorMessage", strFailed);
	    throw e;
	}

    }

    public void AdvancedSearch() throws Exception {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		try {
			System.out.println("Calling From Page-->In Account search Tab");
			// Give Customer info
			strDescription = "Negotiating Account Search details";
			strExpected = "Giving Account Search details";
			strActual = "Giving Account Search Details in Calling From Page was successful";
			strFailed = "Giving Account Search Details in Calling From Page was not successful";
			getUrl = ", URL Launched --> " + returnURL();

			// maximizeBrowserWindow();
			waitForLoader();

			String callingPartyName = get("Calling_Party_Name").trim();
			String agencyId = get("AgencyID").trim();
			String Search_Value_Type = get("Search_Value_Type").trim();
			String Search_Value = get("Search_Value").trim();
			String BillType = get("BillType").trim();

			waitForElementDisplay(txtSearchCallingPartyName, objectValue, 30);
			try {

				if (!agencyId.isEmpty()) {
					clickUsingJavaScript(acstSearch_SalesProfile, "");
					waitForLoader();
					if (isDisplayed(salesProfileSave, "", 30)) {
						// setSalesProfileInfo();
						if (!agencyId.trim().isEmpty()) {
							selectDropDownUsingVisibleText(selectAgencyID, "", agencyId);
							report.reportPass("Verify Agency ID in sales Profile",
									"Agency ID " + agencyId + " should be selected",
									"Agency ID " + agencyId + " is selected");
						}

						clickUsingJavaScript(salesProfileSave, "");
						report.reportPass("Verify Save is clicked in sales Profile", "Save should be clicked",
								"Save is clicked");
						waitForLoader();
						waitForLoader();
					}
				}
			} catch (Exception e) {
				strFailed = "Failed in Sales Profile Info, Required Agency ID is not displayed post clicking Agency ID dropdown";
				report.reportFail("Verify in sales Profile Info.",
						"Required Agency ID is not displayed post clicking Agency ID dropdow", strFailed);
				report.updateMainReport("comments", strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				logger.error(strFailed);
				captureErrorMsg(strFailed);
				throw new UserDefinedException(strFailed);
			}

			// Calling Party Name

			if (isDisplayed(txtSearchCallingPartyName, strFailed)) {
				mouseclick(txtSearchCallingPartyName, strFailed);
				waitForLoader();
				setText(txtSearchCallingPartyName, objectValue, callingPartyName);
				report.reportPass("Account search tab -- Enter calling party name.",
						"Calling party name should be entered.",
						"Entered " + callingPartyName + " calling party name.");
			}

			try {
				if (isDisplayed(AdvancedSearchLink)) {
					clickUsingJavaScript(AdvancedSearchLink, strFailed);
					waitForLoader();
					report.reportPass("Account search tab -- Click on AdvancedSearch Option",
							"AdvancedSearch Option option should be clickable",
							"AdvancedSearch Option option is clicked");
				}

			} catch (Exception e) {

				report.reportFail("Account search tab -- Click on AdvancedSearch Option",
						"AdvancedSearch Option option should be clickable",
						"AdvancedSearch Option option is not clicked due to " + e.toString());
				throw new UserDefinedException("AdvancedSearch Option option is not clicked due to " + e.toString());
			}

			if (!Search_Value_Type.isEmpty()) {
				try {
					if (isDisplayed(OptionforAdvanceSearch, Search_Value_Type)) {
						click(OptionforAdvanceSearch, Search_Value_Type);
						waitForLoader();
						report.reportPass("Advanced search tab -- Click " + Search_Value_Type + "Option",
								"Advanced search tab -- " + Search_Value_Type + "Option should be clickable",
								"Advanced search tab -- " + Search_Value_Type + "Option is clicked");
					}

				} catch (Exception e) {

					report.reportPass("Advanced search tab -- Click " + Search_Value_Type + "Option",
							"Advanced search tab -- " + Search_Value_Type + "Option should be clickable",
							"Advanced search tab -- " + Search_Value_Type + "Option is not clicked due to "
									+ e.toString());
					throw new UserDefinedException("Advanced search tab -- " + Search_Value_Type
							+ "Option is not clicked due to " + e.toString());
				}

			}

			if (!BillType.isEmpty() && !Search_Value_Type.equalsIgnoreCase("Alternate TN")
					&& !Search_Value_Type.equalsIgnoreCase("Repair Ticket")
					&& !Search_Value_Type.equalsIgnoreCase("Simple Search")
					&& !Search_Value_Type.equalsIgnoreCase("Service address")
					&& !Search_Value_Type.equalsIgnoreCase("Mobile/Alternate TN")) {
				try {

					String BillSearchkeyTypeforxpath = "";
					String BillAccountTypeforxpath = "";

					if (Search_Value_Type.equalsIgnoreCase("Account Number Details")) {

						BillSearchkeyTypeforxpath = "accountNum";
					} else if (Search_Value_Type.equalsIgnoreCase("TN")) {

						BillSearchkeyTypeforxpath = "acctNum";
					} else if (Search_Value_Type.equalsIgnoreCase("Video/Profile CAN")) {

						BillSearchkeyTypeforxpath = "videoPCAN";
					}

					if (BillType.equalsIgnoreCase("LiveBill")) {
						BillAccountTypeforxpath = "LiveBills";

					} else if (BillType.equalsIgnoreCase("FinalBill")) {
						BillAccountTypeforxpath = "SpecialBill";
					}

					clickUsingJavaScript(BillAccountType, BillSearchkeyTypeforxpath + ";" + BillAccountTypeforxpath);

					waitForLoader();
					report.reportPass("Advanced search tab -- Click " + BillType,
							"Advanced search tab -- " + BillType + "Should be clickable",
							"Advanced search tab -- " + BillType + "is clicked");

				} catch (Exception e) {

					report.reportFail("Advanced search tab -- Click " + BillType,
							"Advanced search tab -- " + BillType + "Should be clickable",
							"Advanced search tab -- " + BillType + "is not clicked due to " + e.toString());
					throw new UserDefinedException(
							"Advanced search tab -- " + BillType + "is not clicked due to " + e.toString());
				}

			}

			if (!Search_Value.isEmpty() && !Search_Value_Type.equalsIgnoreCase("Service address")) {
				try {

					String BillSearchkeyTypeforxpath = "";

					if (Search_Value_Type.equalsIgnoreCase("Account Number Details")) {

						BillSearchkeyTypeforxpath = "AdvAccountSearch()";
					} else if (Search_Value_Type.equalsIgnoreCase("TN")) {

						BillSearchkeyTypeforxpath = "TNSearch()";
					} else if (Search_Value_Type.equalsIgnoreCase("Video/Profile CAN")) {

						BillSearchkeyTypeforxpath = "videoProfileCANSearch()";
					} else if (Search_Value_Type.equalsIgnoreCase("Repair Ticket")) {

						BillSearchkeyTypeforxpath = "TicketSearch()";
					} else if (Search_Value_Type.equalsIgnoreCase("Simple Search")) {

						BillSearchkeyTypeforxpath = "SimpleSearch()";
					} else if (Search_Value_Type.equalsIgnoreCase("Alternate TN")) {

						BillSearchkeyTypeforxpath = "ATNSearch()";
					}
					 else if (Search_Value_Type.equalsIgnoreCase("Mobile/Alternate TN")) {

							BillSearchkeyTypeforxpath = "ATNSearch()";
						}
					else if(Search_Value_Type.equalsIgnoreCase("Legacy PCAN"))
					{
							BillSearchkeyTypeforxpath = "LegacyPCANSearch()";
					}
					
					setText(SearchinputTextfield, BillSearchkeyTypeforxpath, Search_Value);

					click(Searchbutton, BillSearchkeyTypeforxpath);
					waitForLoader();
					report.reportPass("Advanced search tab -- set Search_Value", "set Search_Value as " + Search_Value,
							"Search_Value set as " + Search_Value);

				} catch (Exception e) {

					report.reportFail("Advanced search tab -- set Search_Value", "set Search_Value as " + Search_Value,
							"unable to set search value due to " + e.toString());
					throw new UserDefinedException("unable to set search value due to " + e.toString());
				}

			}

			try {

				if (Search_Value_Type.equalsIgnoreCase("Service address"))

				{

					if (!get("HouseName").isEmpty()) {
						setText(HouseNumber, Search_Value, get("HouseName"));
						report.reportPass("Advanced search-Service address tab -- set HouseNumber",
								"set Search_Value as " + get("HouseName"), " Search_Value set as " + get("HouseName"));

					} else {

						report.reportFail("Advanced search-Service address tab -- set HouseNumber", " ",
								"House number is not provided in run manager sheet");
					}

					if (!get("StreetAddress").isEmpty()) {
						setText(StreetName, Search_Value, get("StreetAddress"));
						report.reportPass("Advanced search-Service address tab -- set StreetAddress",
								"set Search_Value as " +  get("StreetAddress"), " Search_Value set as " +  get("StreetAddress"));

					} else {

						report.reportFail("Advanced search-Service address tab -- set StreetAddress", " ",
								"StreetAddress is not provided in run manager sheet");
					}
					if (!get("City").isEmpty()) {
						setText(City, Search_Value, get("City"));
						report.reportPass("Advanced search-Service address tab -- set City",
								"set Search_Value as " + get("City"), " Search_Value set as " + get("City"));

					} else {

						report.reportFail("Advanced search-Service address tab -- set City", " ",
								"City is not provided in run manager sheet");
					}
					if (!get("State").isEmpty()) {
						selectDropDownUsingVisibleText(State, Search_Value, get("State"));
						report.reportPass("Advanced search-Service address tab -- set State",
								"set Search_Value as " + get("State"), " Search_Value set as " + get("State"));

					} else {

						report.reportFail("Advanced search-Service address tab -- set State", " ",
								"State is not provided in run manager sheet");
					}
					if (!get("Zipcode").isEmpty()) {
						setText(ZipCode, Search_Value, get("Zipcode"));
						report.reportPass("Advanced search-Service address tab -- set Zipcode",
								"set Search_Value as " + get("Zipcode"), " Search_Value set as " + get("Zipcode"));

					} else {

						report.reportFail("Advanced search-Service address tab -- set Zipcode", " ",
								"Zipcode is not provided in run manager sheet");
					}
					try {

						clickUsingJavaScript(Adv_ServiceAddress_Continue, "");
						report.reportPass("Advanced search-Service address tab -- Click on continue button", "",
								" Continue button successfully clicked");
						
						waitForLoader();
						
						if(isDisplayed(Callingfrompage))
						{
							if(isDisplayed(LiveAccountDeatils))
							{
								clickUsingJavaScript(LiveAccount, "");
								report.reportPass("Validate Live Account is clicked or not", "Live Account should be Clicked",
										"Live Account clicked");
							}
						}
						waitForLoader();

					} catch (Exception ex) {

						report.reportFail("Advanced search-Service address tab -- Click on continue button", "",
								" Continue button not loaded");

					}
				}
			} catch (Exception e) {

				report.reportFail("Advanced search-Service address tab -- set Service address",
						"set Search_Value as " + Search_Value, "Service address search page not loaded");
				throw new UserDefinedException("Service address search page not loaded");
			}

			waitForLoader();

			
			
			try{
				
				if(isDisplayed(AccountNotfounderror)){
					report.reportFail("Advanced search-tab -", "Account should be pulled successfully","Account not found error");
					report.updateMainReport("comments", "Account not found error");
					report.updateMainReport("ErrorMessage", "Account not found");
					throw new UserDefinedException("Account not found");
			}
				
			}
			catch(Exception ex){	

			}
			
			
			waitForLoader();
    		try{
    		if(!BillType.equalsIgnoreCase("FinalBill")){
    			//mouseclick(btnOpenSearchResult, "");
			    clickUsingJavaScript(btnOpenSearchResult, "");
			    waitForLoader();
			    waitForLoader();
    		}
    		else{
    			clickUsingJavaScript(SearchResultforFinalAccount, "");
    			clickUsingJavaScript(btnOpenSearchResultforFinalAccount, "");
    		    waitForLoader();
			    waitForLoader();
    			
    		}  
			   
    		}catch(Exception ex){
    			
    		}
			
    		
    		try{
				
				if(isDisplayed(AccountNotfounderror)){
					report.reportFail("Advanced search-tab -", "Account should be pulled successfully","Account not found error");
					report.updateMainReport("comments", "Account not found error");
					report.updateMainReport("ErrorMessage", "Account not found");
					throw new UserDefinedException("Account not found");
			}
				
			}
			catch(Exception ex){	

			}	
			report.reportPass(strDescription + getUrl, strExpected, strActual);

		} catch (Exception exe) {
			exe.printStackTrace();
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				captureErrorMsg("Account search was not successful");
				report.updateMainReport("ErrorMessage", strFailed);
			}

			throw exe;
		}

	}
    
    public void rgmovingdisconnect() throws Exception{


    	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
    	String getUrl = "";
    	try {
    	    waitForLoader();
    	    waitForLoader();
    	    pause();
    	    // Give Customer info
    	    strDescription = "Clicking on Moving/DoccAgreement button in RG Page.";
    	    strExpected = "Click Moving/DoccAgreement button in RG Page";
    	    strActual = "Moving/DoccAgreement button in RG Page was successfully clicked ";
    	    strFailed = "Clicking on Moving/DoccAgreement button in RG Page was not successful";
    	    getUrl = ", URL Launched --> " + returnURL();
    	    waitForLoader();
    	    switchToDefaultcontent();
    	    // DOCC Agreement
    	    if (get("FlowType").contains("Move")  && (get("Application").equalsIgnoreCase("C2G"))) {

    	  	  if(isDisplayed(btnYesDoccAgreement, "", 10)){
      			if (btnYesDoccAgreementList.size() > 0) {
      			    waitForElementDisplay(btnYesDoccAgreement, objectValue, pageTimeoutInSeconds);

      			    if (isDisplayed(btnYesDoccAgreement, objectValue)) {
      				clickUsingJavaScript(btnYesDoccAgreement, objectValue);
      				report.reportPass(strDescription + getUrl, strExpected, strActual);

      			    }
      			}
      		    }
    	    }
    	    if ((get("FlowType").contains("Move") && !get("FlowType").equalsIgnoreCase("SuppMove")) || get("FlowType").equalsIgnoreCase("MoveAsIs")) {
    		waitForLoader();
    		waitForLoader();
    		waitForLoader();
    		waitForLoader();
    		switchToDefaultcontent();
    		 try {
    				waitForElementDisplay(snapshot, objectValue, pageTimeoutInSeconds);
    				 
    			    } catch (Exception e) {
                  
    			    }
    		 
    		if (!ordersTab.getAttribute("class").contains("active")) {

    		    clickUsingJavaScript(ordersTab, objectValue);
    		    waitForPageToLoad(driver);

    		}
    		waitForLoader();
    		waitForPageToLoad(driver);
    		waitForLoader();
    		//waitForElementDisplay(btnMoving, "", pageTimeoutInSeconds);

    		  if (isDisplayed(btnRGMoving, "", 5)) {
    			    clickUsingJavaScript(btnRGMoving, objectValue);
    			}
    			else if(isDisplayed(IWantTolink, objectValue, 5)){
    				 clickUsingJavaScript(IWantTolink, objectValue);
    				 waitForLoader();
    				 if (isDisplayed(btnMoving, "", 5)) {
    					    clickUsingJavaScript(btnMoving, objectValue);
    					    waitForLoader();
    					}
    				}
    			else {
    			    report.reportFail("Click on RG moving", "RG Moving button should be clicked.", "RG moving button is not displayed.");
    			}

    			report.reportPass(strDescription + getUrl, strExpected, strActual);

    		    }
    	    
    	    
    	    // added by Naresh
    	    if(get("ChangeType").toLowerCase().contains("ETFDisconnect")){
    			waitForLoader();
    			waitForLoader();
    			waitForLoader();
    			waitForLoader();
    			switchToDefaultcontent();
    			 try {
    					waitForElementDisplay(snapshot, objectValue, pageTimeoutInSeconds);
    					 
    				    } catch (Exception e) {
    	              
    				    }
    			 
    			if (!ordersTab.getAttribute("class").contains("active")) {

    			    clickUsingJavaScript(ordersTab, objectValue);
    			    waitForPageToLoad(driver);

    			}
    			waitForLoader();
    			waitForPageToLoad(driver);
    			waitForLoader();
    			//waitForElementDisplay(btnMoving, "", pageTimeoutInSeconds);

    			  if (isDisplayed(btn_LoyaltyFlow_Disconnect, "", 5)) {
    				    clickUsingJavaScript(btn_LoyaltyFlow_Disconnect, objectValue);
    				}
    				else if(isDisplayed(IWantTolink, objectValue, 5)){
    					 clickUsingJavaScript(IWantTolink, objectValue);
    					 waitForLoader();
    					 if (isDisplayed(btn_LoyaltyFlow_Disconnect, "", 5)) {
    						    clickUsingJavaScript(btn_LoyaltyFlow_Disconnect, objectValue);
    						    waitForLoader();
    						}
    					}
    				else {
    				    report.reportFail("Click on RG Loyalty Flow /Disconnect", "RG Loyalty Flow /Disconnect button should be clicked.", "RG Loyalty Flow /Disconnect button is not displayed.");
    				}

    				report.reportPass(strDescription + getUrl, strExpected, strActual);

    			    }

    	} catch (Exception exe) {
    	    if (!isUserDefinedException(exe)) {
    		report.reportFail(strDescription + getUrl, strExpected, strFailed);
    		report.updateMainReport("ErrorMessage", strFailed);
    		captureErrorMsg("Failed in Internet section.");
    	    }
    	    throw exe;
    	}
    	
        
    }
}
