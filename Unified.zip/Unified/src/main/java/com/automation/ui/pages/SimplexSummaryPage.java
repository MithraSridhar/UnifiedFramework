package com.automation.ui.pages;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.springframework.core.env.SystemEnvironmentPropertySource;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_Summary_PageObjects;
import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.support.ElementFactory;
import com.automation.test.order.OfferDataExtraction;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * SimplexSummaryPage class represents the Summary Info Page and interact with
 * the Page
 * 
 */
public class SimplexSummaryPage extends Simplex_Summary_PageObjects {

    String objectValue = "";
    static boolean windows = InitiateDriver.windows;
    String description = "", expected = "", actual = "", failure = "", getUrl;
    By by;
    String MON="";

    String testId;
    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

    String EstimatedMonthlyCharges="";
    String EstimatedBillAmt="";
    
    /**
     * SimplexSummaryPage constructor invokes the super class constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     *             	
     *             
     */
    @SuppressWarnings("unchecked")
    public SimplexSummaryPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, windows, report, data);
	this.testId = testId;

    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     */
    public static SimplexSummaryPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexSummaryPage.class, testId, report, data);
    }

    /**
     * Navigation start for Simplex Summary Page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void start() throws Exception {
    	setIterator();
	System.out.println("Summary page.....");

	// To check due date tab is opened or not.. if not click on it
	
	if(get("ChangeType").equalsIgnoreCase("AutoPay")){
		
		//For Setup/Modify Auto Pay By Mounika 16062017
		modifyAutoPay();
		
	}

	else{
	verifySummaryTab();
	
	// Naresh - TechSure
		//verifyTechSure();
		
		//IWMP  Added by Naresh 
				verfiyIWMP();
				
		//Vignesh		
				if(get("SubFlowType").equalsIgnoreCase("TVStbpriceup") || get("SubFlowType").equalsIgnoreCase("HNP")){
				  ValidatinSummary();
				}
	
	            setSummaryInfo();
	    }

    }
/*public void processLofAutoPay() throws Exception { //Anu
    	
       	
    	try{
		// TODO Auto-generated method stub
    	        pageScroll(RbtSocEmail);
        	    clickUsingJavaScript(RbtSocEmail, objectValue);
        	    waitForLoader();
        	    report.reportPass("Click Send email button", "Send email button should be clicked", "Send email button is clicked");
        	    
    		
    	pageScroll(lofautoPaymentYes);  //  Auto Pay
		clickUsingJavaScript(lofautoPaymentYes, "");
		report.reportPass("Select AutoPay", "AutoPay should be selected as Yes.", "Auto pay is selected as Yes");
		waitForLoader();
		waitForPageToLoad(driver);
		
		
		if (get("AutoPayment").equalsIgnoreCase("Yes")){
			if (isDisplayed(lofautoPaymentYes)){
			clickUsingJavaScript(lofautoPaymentYes, "");
		report.reportPass("Select AutoPay Yes", "AutoPay should be selected as Yes.", "AutoPay is selected as Yes");
		}}
		else{
			clickUsingJavaScript(lofautoPaymentNo, "");
			report.reportPass("Select AutoPay No", "AutoPay  should be selected as No.", "AutoPay is selected as No");
		}
		
		if(isDisplayed(paperFreeYes,objectValue,3)){
		
		if (get("PaperfreeBill").equalsIgnoreCase("Yes")){
			clickUsingJavaScript(paperFreeYes, "");
		report.reportPass("Select Paperfree Yes", "Paperfree  should be selected as Yes.", "Paperfree is selected as Yes");
		}
		else{
			clickUsingJavaScript(paperFreeNo, "");
			report.reportPass("Select Paperfree No", "Paperfree  should be selected as No.", "Paperfree is selected as No");
		}
		}
		if(isDisplayed(billNoticeYes,objectValue,3))
		{
		if(get("LOF_Mobile").equalsIgnoreCase("yes")){  //Mobile# add
			clickUsingJavaScript(billNoticeYes, "");
			report.reportPass("Select Mobile No. Option", "Mobile No. Option should be selected as Yes.", "Mobile No. Option is selected as Yes");
		}
			else{
				clickUsingJavaScript(billNoticeNo, "");
			}
		}
		//-- add report
	if(isDisplayed(sendEmail,objectValue,3)){    //--> Preview email
		pageScroll(sendEmail);
		clickUsingJavaScript(sendEmail,objectValue);
				waitForLoader();
		report.reportPass("Click Preview Email Button", "Preview email button should be clicked", "Preview email button is clicked");
	}
    	
	lofAutopayPage();	
	
    	
    	}
    	
    	catch(Exception e)
    	{
    		report.reportFail("Navigate to AutoPay Page URL", "Autopay Page URL should be opened", "Unable to navigate to Autopay Page URL" + e.getCause().getMessage());
			report.updateMainReport("ErrorMessage", "Unable to navigate to Autopay Page URL" + e.getCause().getMessage());
			
			e.printStackTrace();
    		
    	}
	}*/
    
  //Updated by Naresh
  	public void processLofAutoPay() throws Exception { 

  		try {
  			// TODO Auto-generated method stub
  			
  			System.out.println();
  			//get price details from summary page
  			//EstimatedMonthlyCharges=getTextFromElement(EstimatedCharges, objectValue);
  			if(get("Application").equals("C2G"))
  			{
  			EstimatedMonthlyCharges=driver.findElement(By.xpath("//span[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_lblCharges']/../../following-sibling::td[1]/b")).getText();
  			}else {
  			EstimatedMonthlyCharges=getTextFromElement(EstimatedCharges, objectValue);
  			}
  			EstimatedBillAmt=getTextFromElement(EstimatedBill, objectValue);
  			
  			pageScroll(RbtSocEmail);
  			clickUsingJavaScript(RbtSocEmail, objectValue);
  			waitForLoader();
  			report.reportPass("Click Send email button", "Send email button should be clicked",
  					"Send email button is clicked");

  			/*
  			 * pageScroll(lofautoPaymentYes); // Auto Pay
  			 * clickUsingJavaScript(lofautoPaymentYes, "");
  			 * report.reportPass("Select AutoPay", "AutoPay should be selected as Yes.",
  			 * "Auto pay is selected as Yes"); waitForLoader(); waitForPageToLoad(driver);
  			 */

  			if (get("AutoPayment").equalsIgnoreCase("Yes")) {
  				if (isDisplayed(lofautoPaymentYes)) {
  					clickUsingJavaScript(lofautoPaymentYes, "");
  					report.reportPass("Select AutoPay Yes", "AutoPay should be selected as Yes.",
  							"AutoPay is selected as Yes");
  				}
  			} else {
  				clickUsingJavaScript(lofautoPaymentNo, "");
  				report.reportPass("Select AutoPay No", "AutoPay  should be selected as No.",
  						"AutoPay is selected as No");
  			}

  			if (isDisplayed(paperFreeYes, objectValue, 3)) {

  				if (get("PaperfreeBill").equalsIgnoreCase("Yes")) {
  					clickUsingJavaScript(paperFreeYes, "");
  					report.reportPass("Select Paperfree Yes", "Paperfree  should be selected as Yes.",
  							"Paperfree is selected as Yes");
  				} else {
  					clickUsingJavaScript(paperFreeNo, "");
  					report.reportPass("Select Paperfree No", "Paperfree  should be selected as No.",
  							"Paperfree is selected as No");
  				}
  			}
  			if (isDisplayed(billNoticeYes, objectValue, 3)) {
  				if (get("LOF_Mobile").equalsIgnoreCase("yes")) { // Mobile# add
  					clickUsingJavaScript(billNoticeYes, "");
  					report.reportPass("Select Mobile No. Option", "Mobile No. Option should be selected as Yes.",
  							"Mobile No. Option is selected as Yes");
  				} else {
  					clickUsingJavaScript(billNoticeNo, "");
  				}
  			}
  			// -- add report
  			if (isDisplayed(sendEmail, objectValue, 3)) { // --> Preview email
  				pageScroll(sendEmail);
  				click(sendEmail);
  				waitForLoader();
  				report.reportPass("Click Preview Email Button", "Preview email button should be clicked",
  						"Preview email button is clicked");
  			}

  			
  			// Added By Naresh,Madipelly (LOF Flow)
  			lofValidations();

  		}

  		catch (Exception e) {
  			report.reportFail("Navigate to AutoPay Page URL", "Autopay Page URL should be opened",
  					"Unable to navigate to Autopay Page URL" + e.getCause().getMessage());
  			report.updateMainReport("ErrorMessage",
  					"Unable to navigate to Autopay Page URL" + e.getCause().getMessage());

  			e.printStackTrace();

  		}
  	}
    
/*//***********************LOF auto method******************** -- ANu
public void lofAutopayPage() throws Exception {
 	
 	String cardType = get("AutoPaymentCardType").trim();
 	String firstName = get("PayerFirstName").trim();
		String lastName = get("PayerLastName").trim();
		String cardNo = get("Card_Number").trim();
		String payMethod = get("Pay_Method").trim();
		String nickName = get("Nick_Name").trim();
		String cardExpiryMonth = get("CardExpiryMonth").trim();
		String cardExpiryYear = get("CardExpiryYear").trim();
		String cardSecurityCode = get("Card_SecurityCode").trim();
		String zipCode = get("PayerZipCode").trim();
		String Env = get("Environment").trim();
		
		
		
		try{
			
			waitForLoader();
			 switchToDefaultcontent();
			 
			String mon=driver.findElement(By.xpath("//*[@id='monDisplay']")).getText();
			System.out.println("MON is --> "+mon);
			switchToDefaultcontent();
		    switchToFrame("IfProducts");
		
		if(isDisplayed(billingNameAndAddress,objectValue,3)){    
			String billingnameadd = billingNameAndAddress.getText();
			System.out.println("Billing name and address is :"+billingnameadd);	
			String[] list=billingnameadd.split(",");
			
			
				String billAdd=list[1];
				System.out.println(billAdd);
				String[] zipc=billAdd.split(" ");
				for(String Zipcode : zipc ){
				System.out.println(Zipcode);
				}
				System.out.println("Zipcode is: "+zipc[1]);
				
					put("Enter Zipcode", zipc[1]);
				
					waitForLoader();
		}
			
			
//		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\Autopay\\unifiedframework\\src\\test\\resources\\chromedriver.exe");
			Proxy proxy = new Proxy();
			proxy.setAutodetect(false);
			proxy.setProxyType(Proxy.ProxyType.PAC);
			proxy.setProxyAutoconfigUrl("http://autoproxy.verizon.com/cgi-bin/getproxy");
			System.setProperty("webdriver.chrome.driver", new File("src/test/resources/chromedriver.exe").getAbsolutePath());
			DesiredCapabilities ieCapabilities = DesiredCapabilities.chrome();
			ieCapabilities.setCapability(ChromeDriverService.CHROME_DRIVER_EXE_PROPERTY, FilePaths.chromeDriverServer.getAbsolutePath());
			ieCapabilities.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
			ieCapabilities.setCapability(CapabilityType.PROXY,proxy);
			ChromeOptions opts = new ChromeOptions();
			opts.addArguments("start-maximized");
			// To disable developer mode extension in chrome browser
			opts.addArguments("chrome.switches","--disable-extensions");
			/*if(privateBrowsing){
			opts.addArguments("--incognito");
			ieCapabilities.setCapability("chrome.switches", Arrays.asList("-incognito"));
			}
		//ieCapabilities.setCapability(ChromeOptions.CAPABILITY, opts);
		//	driver = new ChromeDriver(ieCapabilities);
		// Initialize browser.
	
		//	InitiateDriver iDriver = new InitiateDriver("Chrome");  //rathna
		//   driver = iDriver.getDriver(); 
		   
		   System.out.println("Opened new browser");
		//	boolean newWindowOpened = switchToWindowWithTitle("Optix Rep Dashboard");
		   Set<String> allWindowsModi = driver.getWindowHandles();
		     System.out.println(allWindowsModi.size());
		     for (String Child_Window : allWindowsModi) {
		     System.out.println(Child_Window);
		     }
			switchToWindowWithTitle("Optix Rep Dashboard");
			if(isDisplayed(srchBtn,objectValue,3))
			{
				System.out.println("switched to main window");
			}
	    	
	    	//if(newWindowOpened){
	    		if(Env.equalsIgnoreCase("NTE1")){
	    			String nte1URL="https://sit-activate.verizon.com/orderinfo/?mon="+mon+"&nf=email&CMP=EMC-CON_2015-Q3_LoFEmail0001&lang=E&lob=01";
	    			
	    		//	String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL,"t");
	    			((JavascriptExecutor)driver).executeScript("window.open('https://sit-activate.verizon.com/orderinfo/?mon="+mon+"&nf=email&CMP=EMC-CON_2015-Q3_LoFEmail0001&lang=E&lob=01');");
	    			//driver.findElement(By.xpath("//div[@ng-if='EnableOptix']")).sendKeys(selectLinkOpeninNewTab);
	    			// ((JavascriptExecutor) driver).executeScript(nte1URL);
	    			
	    			 System.out.println("Opened NTE1 URL");
	    			// driver.switchTo().defaultContent();
	    			 Set<String> allWindowsModi1 = driver.getWindowHandles();
	    		     System.out.println(allWindowsModi1.size());
	    		     for (String Child_Window : allWindowsModi1) {
	    		     System.out.println(Child_Window);
	    		     }
	    			 switchToWindowWithTitle("Verizon Order Details");
	    			 System.out.println("Switched to New Window");
	    			 if(isDisplayed(zip,objectValue,3)){
	    			 System.out.println("Lof Browser is Opened and driver ctrl is moved"); }
	    			 
	    	//switchToWindowWithURL("https://wwwnte1aws.ebiz.verizon.com/orderinfo/?mon="+mon+"&nf");
	    		}
	    		else{
	    			String bauURL="https://sit-activate.verizon.com/orderinfo/?mon="+mon+"&nf=email&CMP=EMC-CON_2015-Q3_LoFEmail0001&lang=E&lob=01";
	    			((JavascriptExecutor)driver).executeScript("window.open('https://sit-activate.verizon.com/orderinfo/?mon="+mon+"&nf=email&CMP=EMC-CON_2015-Q3_LoFEmail0001&lang=E&lob=01');");
	    			
	    			Set<String> allWindowsModi1 = driver.getWindowHandles();
	    		     System.out.println(allWindowsModi1.size());
	    		     for (String Child_Window : allWindowsModi1) {
	    		     System.out.println(Child_Window);
	    		     }
	    			switchToWindowWithURL(bauURL);
	    			//switchToWindowWithURL("https://sit-activate.verizon.com/orderinfo/?mon="+mon+"&nf");
	    		}
	    	//}

	
		
	//System.out.println("Lof Browser is Opened");
	
	
	//zip.sendKeys(get("Zipcode").trim());     
	if(isDisplayed(zip,objectValue,3))//---->Enter Zip Code  
	{
		System.out.println("Zip textbox is available");
	    clearText(zip, "");
	    System.out.println("Zip Code Clear the Text");
	    setText(zip, "", get("Enter Zipcode"));
	}
		waitForLoader();
	if(isDisplayed(zipContinue,objectValue,3)){
	
		clickUsingJavaScript(zipContinue, objectValue);  //-->Continue on Zip Code Page
		System.out.println("Zip Code is entered");
	report.reportPass("Click Conitnue Button", "Continue Button should clicked on Zip Code Page", "Continue Button is clicked");
		  	
	}
	waitForLoader();
	
	waitForLoader();
	waitForLoader();
	
	waitForLoader();
	waitForLoader();
	
	if(isDisplayed(summContinue,objectValue,3)){ 
		pageScroll(summContinue);// ---> Continue on Order Details
 	clickUsingJavaScript(summContinue, objectValue);
 	System.out.println("Continue button is clicked on LOF Summary Page");
    	report.reportPass("Click Conitnue on order Detail", "Continue Button should clicked", "Continue Button is clicked");
  	
   	}
	
	waitForLoader();
	waitForLoader();
	waitForLoader();
	
	waitForLoader();
	if(isDisplayed(IAgreebtn,objectValue,3)){ // --->agree button --Opened Pop up
		pageScroll(IAgreebtn);
		pageScroll(IAgreebtn, mon, true);
	    	clickUsingJavaScript(IAgreebtn, objectValue);
    	report.reportPass("Click Conitnue on order Detail", "Continue Button should clicked", "Continue Button is clicked");
    	waitForLoader();
 	waitForLoader();
 	
 	waitForLoader();
 	
 	waitForLoader(); 
	}
	if(isDisplayed(payMeth, "", 4) || isDisplayed(Selectpay, "",4)){
	if(isDisplayed(payMeth, objectValue,3)){
		clickUsingJavaScript(payMeth, objectValue);
		System.out.println("Selected Use new payment method in LOF page");
    	report.reportPass("Click Use new payment method", "Use new payment method should clicked", "Use new payment method is clicked");
		
	}
	if(isDisplayed(Selectpay, "",5)){
		 selectDropDownUsingVisibleText(Selectpay, "", payMethod);  //--->Select payment Method
		 report.reportPass("Select Payment Method from dropdown", "ayment Method should be selected", "Payment Method is " + payMethod);	
		System.out.println("Payment method is selected");
		 waitForLoader();
	}
	
	if(payMethod.toLowerCase().contains("DEBIT".toLowerCase()) || payMethod.toLowerCase().contains("CREDIT".toLowerCase()))
	{
		
		if (!firstName.isEmpty()) {
			  clearText(LofpayerName, "");   //--->Enter First Name
			  setText(LofpayerName, "", firstName);
			  System.out.println("First Name is entered");
			  report.reportPass("Enter enter First Name", "First Name should be entered.", "Last Name is " + firstName);	
			  waitForLoader();
			}
		

		if (!lastName.isEmpty()) {             //--->Enter Last Name
			  clearText(LofLastName, "");
			  setText(LofLastName, "", lastName);
			  System.out.println("Last Name is entered");
			  report.reportPass("Enter enter Last Name", "Last Name should be entered.", "Last Name is " + lastName);	
			waitForLoader();
		}
			  
			  if (!cardNo.isEmpty()) {			//--->Enter Card Number
			  clearText(LofCrdNum, "");			  
			  setText(LofCrdNum, "", cardNo);
			  System.out.println("Card No. is entered");
			report.reportPass("Enter Card number", "Card no should be entered.", "Card Routing number is " + cardNo);	
			waitForLoader();
			  }
			
	
	if(isDisplayed(selectcard, "", 5))    //--->Select card Type
 {
		selectDropDownUsingVisibleText(selectcard, "", cardType);
      //  clickUsingJavaScript(cardopt, "");
		System.out.println("Card Type is selected");
        report.reportPass("Select Card Type", "Card Type should be selected from dropdown", "Card Type is selecting from dropdown is " +cardType);
        waitForLoader();
 }
	
	if (!nickName.isEmpty()) {	 //--->Enter Nick Name
		pageScroll(Lofnick);
		  clearText(Lofnick, "");
		  setText(Lofnick, "", nickName);
		  System.out.println("Nick name is entered");
		  report.reportPass("Enter Nick Name", "Nick Name should be entered.", "Nick Name is  " + nickName);	
		
	}	
	
	if (!cardExpiryMonth.isEmpty()) {			//--->Enter Expire Month
		  clearText(expMonth, "");
		  setText(expMonth, "", cardExpiryMonth);
		  System.out.println("Expiry month is entered");
		  report.reportPass("Enter Expire Month", "Expire Month should be entered.", "Expire Month is  " + cardExpiryMonth);	
		 
	}
	    
	if (!cardExpiryYear.isEmpty()) {			//--->Enter Expire Year
		  clearText(expYear, "");
		  setText(expYear, "", cardExpiryYear);
		  System.out.println("Expiry Year is entered");
		  report.reportPass("Enter Expire Year", "Expire Year should be entered.", "Expire Year is  " + cardExpiryYear);	
		  
	}
	if (!cardSecurityCode.isEmpty()) {  			//--->Enter CVV
		  clearText(cvv, "");
		  setText(cvv, "", cardSecurityCode);
		  System.out.println("CVV is entered");
		  report.reportPass("Enter CVV", "CVV should be entered.", "CVV is  " + cardSecurityCode);	
		 
	}
	
	if (!get("Enter Zipcode").isEmpty()) {						//--->Enter Zip Code
		  clearText(Lofzip, "");
		  setText(Lofzip, "", get("Enter Zipcode"));
		  System.out.println("Zip Code is entered");
		  report.reportPass("Enter Zip Code", "Zip Code should be entered.", "Zip Code is  " + get("Enter Zipcode"));	
		  waitForLoader();
	}
		  
	}
	
 
	
	else if(payMethod.toLowerCase().contains("SAVINGS".toLowerCase()) || payMethod.toLowerCase().contains("CHECKING".toLowerCase()))
	{
		
		if (!cardSecurityCode.isEmpty()) {			//--->Enter Routing No.
			  clearText(rtnnum, "");
			  setText(rtnnum, "", cardSecurityCode);
			  report.reportPass("Enter Routing number", "Routing no should be entered.", "Routing Routing number is " + cardSecurityCode);	
			waitForLoader();
		}
		
		if (!cardNo.isEmpty()) {         //--->Enter Account Number
			  clearText(bnknum, "");
			  setText(bnknum, "", cardNo);
			  report.reportPass("Enter Account number", "Account no should be entered.", "Account  number is  " + cardNo);	
				waitForLoader();
		}	
		if (!nickName.isEmpty()) {			//--->Enter Nick Name
			  clearText(nickname, "");
			  setText(nickname, "", nickName);
			  report.reportPass("Enter Nick Name", "Nick Name should be entered.", "Nick Name is  " + nickName);	
			 waitForLoader();
		}	
		}
	
		pageScroll(enrollContinue);
		clickUsingJavaScript(enrollContinue, objectValue);  		//--->Continue on enroll page
		report.reportPass("Click Conitnue on AutoPay page", "Continue Button should clicked", "Continue Button is clicked");
      waitForLoader();
		
		waitForLoader();  
		
		
		if(isDisplayed(agreebtn,objectValue,3)){ // --->agree button --Opened Pop up
			
			pageScroll(agreebtn, mon, true);
		    	clickUsingJavaScript(agreebtn, objectValue);
	       	report.reportPass("Click Conitnue on order Detail", "Continue Button should clicked", "Continue Button is clicked");
	    	 
		}
		waitForLoader();
		
		waitForLoader();
     waitForLoader();
		
		waitForLoader();
     waitForLoader();
		
		waitForLoader();
		if(isDisplayed(LOFError, mon, 20)){
			pageScroll(LOFError, mon, true);
			String errormsg2=getTextFromElement(LOFError, objectValue);
 		System.out.println(errormsg2);
 		String strFailed = "Failed in Processing Auto Pay for LOF: "+errormsg2+ "is dispalyed after entering Auto pay details";
 		  report.reportFail("Verify whether LOF AutoPay is processed", "Check whether LOF AutoPay is processed", strFailed);		
 		report.updateMainReport("comments", "Error: "+errormsg2+ " is displayed in LOF section");
 		report.updateMainReport("ErrorMessage", errormsg2);
 		logger.error(errormsg2);
 		captureErrorMsg(errormsg2);
 		throw new UserDefinedException(strFailed);	
			
		}
	
System.out.println("Woohoo page is displayed with Your Order Number: " + mon);
waitForLoader();
	}
	driver.switchTo().defaultContent();
	switchToWindowWithURL("OrderSummary");

		}
		
		catch(Exception e)
		{
			report.reportFail("Process LOF Autopay", "LOF Autopayment should be selected and processed", "Unable to do the LOF autopayment option" + e.getCause().getMessage());
			report.updateMainReport("ErrorMessage", "Unable to do the autopayment option" + e.getCause().getMessage());
			throw e;
		}

}*/
  	
  	
  //***********************LOF validations******************** -- Updated by Naresh
  	public void lofValidations() throws Exception {

  		String Env = get("Environment").trim();

  		try {

  			waitForLoader();
  			switchToDefaultcontent();

  			String mon = driver.findElement(By.xpath("//*[@id='monDisplay']")).getText();
  			System.out.println("MON is --> " + mon);
  			switchToDefaultcontent();
  			switchToFrame("IfProducts");

  			if (isDisplayed(billingNameAndAddress, objectValue, 3)) {
  				String billingnameadd = billingNameAndAddress.getText();
  				System.out.println("Billing name and address is :" + billingnameadd);
  				String[] list = billingnameadd.split(",");

  				String billAdd = list[1];
  				System.out.println(billAdd);
  				String[] zipc = billAdd.split(" ");
  				for (String Zipcode : zipc) {
  					System.out.println(Zipcode);
  				}
  				System.out.println("Zipcode is: " + zipc[1]);

  				put("Enter Zipcode", zipc[1]);

  				waitForLoader();
  			}

  			System.out.println("Opened new browser");
  			Set<String> allWindowsModi = driver.getWindowHandles();
  			System.out.println(allWindowsModi.size());
  			for (String Child_Window : allWindowsModi) {
  				System.out.println(Child_Window);
  			}
  			switchToWindowWithTitle("Optix Rep Dashboard");
  			if (isDisplayed(srchBtn, objectValue, 3)) {
  				System.out.println("switched to main window");
  			}

  			if (Env.equalsIgnoreCase("NTE1")) {
  				String nte1URL = "https://wwwnte1aws.ebiz.verizon.com/orderinfo/?mon=" + mon + "&ecn=y";
  				((JavascriptExecutor) driver).executeScript(
  						"window.open('https://wwwnte1aws.ebiz.verizon.com/orderinfo/?mon=" + mon + "&ecn=y');");
  		
  				Set<String> allWindowsModi1 = driver.getWindowHandles();
  				System.out.println(allWindowsModi1.size());
  				for (String Child_Window : allWindowsModi1) {
  					System.out.println(Child_Window);
  				}
  				switchToWindowWithTitle("Verizon Order Details");
  				System.out.println("Switched to New Window");

  				
  			} else {
  				String bauURL = "https://sit-activate.verizon.com/orderinfo/?mon=" + mon
  						+ "&nf=email&CMP=EMC-CON_2015-Q3_LoFEmail0001&lang=E&lob=01";
  				((JavascriptExecutor) driver)
  						.executeScript("window.open('https://sit-activate.verizon.com/orderinfo/?mon=" + mon
  								+ "&nf=email&CMP=EMC-CON_2015-Q3_LoFEmail0001&lang=E&lob=01');");

  				Set<String> allWindowsModi1 = driver.getWindowHandles();
  				System.out.println(allWindowsModi1.size());
  				for (String Child_Window : allWindowsModi1) {
  					System.out.println(Child_Window);
  				}
  				switchToWindowWithURL(bauURL);
  				
  			}
  			

  			waitForLoader();
  			
  			// validate order details, Added by :Naresh Madipelly (LOF Flow)
  			OrderDetails();
  			
  			
  			if (isDisplayed(summContinue, objectValue, 3)) {
  				pageScroll(summContinue);
  				clickUsingJavaScript(summContinue, objectValue);
  				System.out.println("Continue button is clicked on LOF Summary Page");
  				report.reportPass("Click Conitnue on order Detail", "Continue Button should clicked",
  						"Continue Button is clicked");

  			}
  			waitForLoader();

  			// ==========================================================

  			// added By Naresh,Madipelly (LOF Flow)
  			if (get("AutoPayment").equals("Yes")) {
  				
  				LOFWithAutoPay(mon);
  				driver.switchTo().defaultContent();
  				switchToWindowWithURL("OrderSummary");
  			} else {
  				
  				LOFWithoutAutoPay(mon);
  				driver.switchTo().defaultContent();
  				switchToWindowWithURL("OrderSummary");
  			}

  			// ==========================================================

  		
  		}

  		catch (Exception e) {
  			report.reportFail("Process LOF Autopay", "LOF Autopayment should be selected and processed",
  					"Unable to do the LOF autopayment option" + e.getCause().getMessage());
  			report.updateMainReport("ErrorMessage", "Unable to do the autopayment option" + e.getCause().getMessage());
  			throw e;
  		}

  	}
  	
  	//Naresh
  	
  	public void LOFWithoutAutoPay(String mon) {

		// for LOF without Autopay click on skip

		try {
			report.reportPass("Click on Skip button", "Skip auto pay for registration",
					"Able to see skip auto pay button");
			
			
			String autoPaySelected=getAttribute(eAutoPay, objectValue, "aria-checked");
			if(autoPaySelected.contains("true"))
			{
				clickUsingJavaScript(eAutoPay, objectValue);
			}
			waitForLoader();
			clickUsingJavaScript(SkipAutoPay, objectValue);
			waitForLoader();

			if (isDisplayed(IAgreebtn, objectValue, 3)) {

				report.reportPass("Check Terms and conditions are visible or not", "Verify Terms and condiitions",
						"Able to see terms and conditions");
				pageScroll(IAgreebtn);
				// pageScroll(IAgreebtn, mon, true);
				
				validateTOS();
				
				clickUsingJavaScript(IAgreebtn, objectValue);

				waitForLoader();
				waitForLoader();

				if (isDisplayed(verifyMON, mon, 3)) {
					report.reportPass("Verify MON after accepting Terms", "MON Number should displayed",
							"MON number is displayed");

					// Enter User id
					
					validateUserIDField(mon);

					setText(UserId, objectValue, "v" + mon);
					waitForLoader();

					setText(pwd, objectValue, "vdsi@123!");
					waitForLoader();

					setText(rePwd, objectValue, "vdsi@123!");
					waitForLoader();

					clickUsingJavaScript(submit, objectValue);

					Set<String> allWindowsModi1 = driver.getWindowHandles();
					System.out.println(allWindowsModi1.size());
					for (String Child_Window : allWindowsModi1) {
						System.out.println(Child_Window);
					}

					driver.switchTo().defaultContent();
					switchToWindowWithTitle("Life On Fios");

					waitForLoader();
					waitForLoader();

					String status = getAttribute(registrationStatus, objectValue, "class");
					System.out.println(status);
					if (status.contains("green")) {
						System.out.println("Registration is completed....");
						report.reportPass("Verify Registration completed success message", "Registration Completed",
								"Registration Completed Message is displayed");
					} else {
						System.out.println("Registration Failed.......");
						report.reportFail("Verify Registration completed success message", "Registration Completed",
								"Registration Completed Message is NOT displayed");
					}
					/*
					 * if(isDisplayed(registrationCompleted, objectValue, 3)) { System.out.
					 * println("Registartion Completed Success message is displayed in Life On Fios window"
					 * ); report.reportPass("Verify Registration completed success message",
					 * "Registration Completed", "Registration Completed Message is displayed");
					 * }else { System.out.
					 * println("Registartion Completed Success message is NOT displayed in Life On Fios window"
					 * ); report.reportFail("Verify Registration completed success message",
					 * "Registration Completed", "Registration Completed Message is NOT displayed");
					 * 
					 * }
					 */
				} else {
					System.out.println("LOF Customer Already registered");
					if(isDisplayed(ThankYouOrder, objectValue, 5))
					{
						report.reportPass("LOF Registration", "Verify Customer is registered or not",
								"Customer is already registered..");
					}else {
						report.reportFail("LOF Registration", "Verify Customer is registered or not",
								"Redirecting to invalid page");
					}
					
				}

			}else {
				System.out.println("unable to view terms and conditions");
				report.reportFail("Validate Terms and conditions", "I agree button should be displayed", "I Agree button is not displayed");
			}

		} catch (Exception e) {
			System.out.println("Unable to skip auto pay");
			e.printStackTrace();
		}

	}
  //Naresh	
private void validateTOS() {
		
		try {
			List<WebElement> termsAndCondtions=driver.findElements(By.xpath("//p[@key='Ver_Int_Terms_Serv']"));
			for(WebElement tos : termsAndCondtions)
			{
				try {
					String aggreementSection=tos.getText();
					if(aggreementSection.contains("Verizon Internet") || aggreementSection.contains("Verizon Fios TV") || aggreementSection.contains("Verizon Fios Digital"))
					{
						if(aggreementSection.contains("Internet"))
						{
							/*String areaHidden=driver.findElement(By.xpath("//p[@key='Ver_Int_Terms_Serv']/../following-sibling::li[1]")).getAttribute("aria-hidden");
							if(areaHidden.contains("false"))
							{
								tos.click();
							}*/
							Thread.sleep(1000);
							tos.click();
							report.reportPass("Verify Internet TOS", "Internet TOS should display", "Internet TOS displayed");
							Thread.sleep(1000);
							
							try {
								List<WebElement> I_version=driver.findElements(By.xpath("//center[contains(text(),'Internet TOS v')]"));
								for(WebElement version : I_version )
								{
									((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", version);
										Thread.sleep(500); 
										report.reportPass("Validate Fios Internt Verison", "Verison should be available in TOS", "Fios Internet Verison is available");
									String date=driver.findElement(By.xpath("//center[contains(text(),'Internet TOS v')]//following-sibling::center[contains(text(),'Effe')]")).getText();
									System.out.println("date..."+date);
								}
							} catch (Exception e) {
								report.reportFail("Validate Fios Internt Verison", "Verison should be available in TOS", "Fios Internet Verison is not available");
								e.printStackTrace();
							}
							
						}
						else if(aggreementSection.contains("Verizon Fios TV"))
						{
							/*String areaHidden=driver.findElement(By.xpath("//p[@key='Ver_Int_Terms_Serv']/../following-sibling::li[1]")).getAttribute("aria-hidden");
							if(areaHidden.contains("false"))
							{
								tos.click();
							}*/
							Thread.sleep(1000);
							tos.click();
							Thread.sleep(1000);
							try {
								List<WebElement> I_version=driver.findElements(By.xpath("//center[contains(text(),'Fios TV')]"));
								for(WebElement version : I_version )
								{
									
									((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", version);
										Thread.sleep(500); 
										report.reportPass("Validate Fios TV Verison", "Verison should be available in TOS", "Fios TV Verison is available");
									String date=driver.findElement(By.xpath("//center[contains(text(),'Fios TV')]//following-sibling::center[contains(text(),'Effe')]")).getText();
									System.out.println("date..."+date);
								}
							} catch (Exception e) {
								report.reportFail("Validate Fios TV Verison", "Verison should be available in TOS", "Fios TV Verison is  not available");
								e.printStackTrace();
							}
						}
						else if(aggreementSection.contains("Verizon Fios Digital"))
						{
							/*String areaHidden=driver.findElement(By.xpath("//p[@key='Ver_Int_Terms_Serv']/../following-sibling::li[1]")).getAttribute("aria-hidden");
							if(areaHidden.contains("false"))
							{
								tos.click();
							}*/
							Thread.sleep(1000);
							tos.click();
							Thread.sleep(1000);
							try {
								List<WebElement> I_version=driver.findElements(By.xpath("//center[contains(text(),'Fios Digital')]"));
								for(WebElement version : I_version )
								{
									
									((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", version);
										Thread.sleep(500); 
										report.reportPass("Validate Fios Digital Verison", "Verison should be available in TOS", "Fios Digital Verison is available");
									String date=driver.findElement(By.xpath("//center[contains(text(),'Fios Digital')]//following-sibling::br")).getText();
									System.out.println("date..."+date);
								}
							} catch (Exception e) {
								report.reportFail("Validate Fios Digital Verison", "Verison should be available in TOS", "Fios Digital Verison is available");
								e.printStackTrace();
							}
						}
						
						Thread.sleep(2000);
					}
				} catch (Exception e) {
					
					report.reportFail("Validation of Terms of Services of Verison Products/Services", "Internet, Fios TV, Fios Digital Terms of Services should display", "Inert or TV or FDV TOS are not displayed");
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
  	

public void validateAutoPaytos() throws Exception {
	
	
			try {
				
					if(isDisplayed(autoPaytos, objectValue, 3))
					{
						report.reportPass("Verify Auto Pay TOS", "Autopay tos should display", "Auto pay TOS displayed");
						Thread.sleep(1000);
						autoPaytos.click();
						waitForLoader();
						report.reportPass("Verify Auto Pay TOS", "Autopay tos should display", "Auto pay TOS displayed");
					}else {
						report.reportFail("Verify Auto Pay TOS", "Autopay tos should display", "Auto pay TOS is not displayed");
					}
					
				
			} catch (Exception e) {
				
				report.reportFail("Validation of Terms of Services of Autopay", "Auto pay Terms of Services should display", "Auto pay TOS is not displayed");
				e.printStackTrace();
			}
}

public void LOFWithAutoPay(String mon) throws Exception {
	
	String cardType = get("AutoPaymentCardType").trim();
	String firstName = get("PayerFirstName").trim();
	String lastName = get("PayerLastName").trim();
	String cardNo = get("Card_Number").trim();
	String payMethod = get("Pay_Method").trim();
	String nickName = get("Nick_Name").trim();
	String cardExpiryMonth = get("CardExpiryMonth").trim();
	String cardExpiryYear = get("CardExpiryYear").trim();
	String cardSecurityCode = get("Card_SecurityCode").trim();
	String zipCode = get("PayerZipCode").trim();
	String rnu = get("PayerZipCode").trim();
	
	
	waitForLoader();
	
	
	
	
	try {
		if(isDisplayed(eAutoPay, objectValue, 3))
		{
			report.reportPass("Enter AutoPay details", "Auto pay should be displayed", "Auto pay is displayed LOF page");
			waitForLoader();
			click(eAutoPay);
			waitForLoader();
			click(eAutoPay);
			waitForLoader();
			String attr_val=getAttribute(eAutoPay, objectValue	, "aria-checked");
			System.out.println(attr_val);
			waitForLoader();
			if(attr_val.contains("true"))
			{
				
			}
			if(attr_val.contains("false")){
				clickUsingJavaScript(eAutoPay, objectValue);
				waitForLoader();
			}
			
			
			
			if(isDisplayed(newPaymentMetod, objectValue, 3))
			{
				waitForLoader();
				clickUsingJavaScript(newPaymentMetod, objectValue);
				report.reportPass("Select New Payment method radio button", "Use new payment method should be clicked", "New Payment method radio button is selected");
				waitForLoader();
			}
			
			
			if (isDisplayed(payMeth, "", 4) || isDisplayed(Selectpay, "", 4)) {
				
				if (isDisplayed(payMeth, objectValue, 3)) {
					//clickUsingJavaScript(payMeth, objectValue);
					//System.out.println("Selected Use new payment method in LOF page");
					report.reportPass("Click Use new payment method", "Use new payment method should clicked",
							"Use new payment method is clicked");

				}
				if (isDisplayed(Selectpay, "", 5)) {
					selectDropDownUsingVisibleText(Selectpay, "", payMethod); // --->Select payment Method
					report.reportPass("Select Payment Method from dropdown", "Payment Method should be selected",
							"Payment Method is " + payMethod +" Selected");
					System.out.println("Payment method is selected");
					waitForLoader();
				}

				if (payMethod.toLowerCase().contains("DEBIT".toLowerCase())
						|| payMethod.toLowerCase().contains("CREDIT".toLowerCase())) {

					if (!firstName.isEmpty()) {
						clearText(LofpayerName, ""); // --->Enter First Name
						setText(LofpayerName, "", firstName);
						System.out.println("First Name is entered");
						report.reportPass("Enter enter First Name", "First Name should be entered.",
								"First Name is " + firstName);
						waitForLoader();
					}

					if (!lastName.isEmpty()) { // --->Enter Last Name
						clearText(LofLastName, "");
						setText(LofLastName, "", lastName);
						System.out.println("Last Name is entered");
						report.reportPass("Enter enter Last Name", "Last Name should be entered.",
								"Last Name is " + lastName);
						waitForLoader();
					}

					if (!cardNo.isEmpty()) { // --->Enter Card Number
						clearText(LofCrdNum, "");
						setText(LofCrdNum, "", cardNo);
						System.out.println("Card No. is entered");
						report.reportPass("Enter Card number", "Card no should be entered.",
								"Card Routing number is " + cardNo);
						waitForLoader();
					}

					if (isDisplayed(selectcard, "", 5)) // --->Select card Type
					{
						selectDropDownUsingVisibleText(selectcard, "", cardType);
						// clickUsingJavaScript(cardopt, "");
						System.out.println("Card Type is selected");
						report.reportPass("Select Card Type", "Card Type should be selected from dropdown",
								"Card Type is selecting from dropdown is " + cardType);
						waitForLoader();
					}

					if (!nickName.isEmpty()) { // --->Enter Nick Name
						pageScroll(Lofnick);
						clearText(Lofnick, "");
						setText(Lofnick, "", nickName);
						System.out.println("Nick name is entered");
						report.reportPass("Enter Nick Name", "Nick Name should be entered.",
								"Nick Name is  " + nickName);

					}

					if (!cardExpiryMonth.isEmpty()) { // --->Enter Expire Month
						clearText(expMonth, "");
						setText(expMonth, "", cardExpiryMonth);
						System.out.println("Expiry month is entered");
						report.reportPass("Enter Expire Month", "Expire Month should be entered.",
								"Expire Month is  " + cardExpiryMonth);

					}

					if (!cardExpiryYear.isEmpty()) { // --->Enter Expire Year
						clearText(expYear, "");
						setText(expYear, "", cardExpiryYear);
						System.out.println("Expiry Year is entered");
						report.reportPass("Enter Expire Year", "Expire Year should be entered.",
								"Expire Year is  " + cardExpiryYear);

					}
					if (!cardSecurityCode.isEmpty()) { // --->Enter CVV
						clearText(cvv, "");
						setText(cvv, "", cardSecurityCode);
						System.out.println("CVV is entered");
						report.reportPass("Enter CVV", "CVV should be entered.", "CVV is  " + cardSecurityCode);

					}

					if (!get("Enter Zipcode").isEmpty()) { // --->Enter Zip Code
						clearText(Lofzip, "");
						setText(Lofzip, "", get("Enter Zipcode"));
						System.out.println("Zip Code is entered");
						report.reportPass("Enter Zip Code", "Zip Code should be entered.",
								"Zip Code is  " + get("Enter Zipcode"));
						waitForLoader();
					}
					
					if(isDisplayed(contBtn, objectValue, 3))
					{
						report.reportPass("Verify Continue button after entering Credit/debit details", "Continue button should be enable", "Continue button is enabled");
						clickUsingJavaScript(contBtn, objectValue);
						waitForLoader();
					}
					

					
					
					
					
					if (isDisplayed(IAgreebtn, objectValue, 3)) {

						report.reportPass("Check Terms and conditions are visible or not", "Verify Terms and condiitions",
								"Able to see terms and conditions");
						pageScroll(IAgreebtn);
						// pageScroll(IAgreebtn, mon, true);
						
						validateTOS();
						
						clickUsingJavaScript(IAgreebtn, objectValue);

						waitForLoader();
						waitForLoader();

						if (isDisplayed(verifyMON, mon, 3)) {
							report.reportPass("Verify MON after accepting Terms", "MON Number should displayed",
									"MON number is displayed");

							// Enter User id
							
							validateUserIDField(mon);

							//setText(UserId, objectValue, "v" + mon);
							//waitForLoader();

							valdiatePasswordFields();
							
							//setText(pwd, objectValue, "vdsi@123!");
							//waitForLoader();

							//setText(rePwd, objectValue, "vdsi@123!");
							//waitForLoader();

							clickUsingJavaScript(submit, objectValue);

							Set<String> allWindowsModi1 = driver.getWindowHandles();
							System.out.println(allWindowsModi1.size());
							for (String Child_Window : allWindowsModi1) {
								System.out.println(Child_Window);
							}

							driver.switchTo().defaultContent();
							switchToWindowWithTitle("Life On Fios");

							waitForLoader();
							//waitForLoader();

							String status = getAttribute(registrationStatus, objectValue, "class");
							System.out.println(status);
							if (status.contains("green")) {
								System.out.println("Registration is completed....");
								report.reportPass("Verify Registration completed success message", "Registration Completed",
										"Registration Completed Message is displayed");
							} else {
								System.out.println("Registration Failed.......");
								report.reportFail("Verify Registration completed success message", "Registration Completed",
										"Registration Completed Message is NOT displayed");
							}
							/*
							 * if(isDisplayed(registrationCompleted, objectValue, 3)) { System.out.
							 * println("Registartion Completed Success message is displayed in Life On Fios window"
							 * ); report.reportPass("Verify Registration completed success message",
							 * "Registration Completed", "Registration Completed Message is displayed");
							 * }else { System.out.
							 * println("Registartion Completed Success message is NOT displayed in Life On Fios window"
							 * ); report.reportFail("Verify Registration completed success message",
							 * "Registration Completed", "Registration Completed Message is NOT displayed");
							 * 
							 * }
							 */
						} else {
							System.out.println("LOF Customer Already registered");
							if(isDisplayed(ThankYouOrder, objectValue, 5))
							{
								report.reportPass("LOF Registration", "Verify Customer is registered or not",
										"Customer is already registered..");
							}else {
								report.reportFail("LOF Registration", "Verify Customer is registered or not",
										"Redirecting to invalid page");
							}
							
						}

					}else {
						System.out.println("unable to view terms and conditions");
						report.reportFail("Validate Terms and conditions", "I agree button should be displayed", "I Agree button is not displayed");
					}


					
				}

				else if (payMethod.toLowerCase().contains("SAVINGS".toLowerCase())
						|| payMethod.toLowerCase().contains("CHECKING".toLowerCase())) {
					//using Card_SecurityCode col for routing num
					if (!get("Card_SecurityCode").isEmpty()) { // --->Enter Routing No.
						clearText(rtnnum, "");
						setText(rtnnum, "", get("Card_SecurityCode"));
						report.reportPass("Enter Routing number", "Routing no should be entered.",
								"Routing Routing number is " + get("Card_SecurityCode"));
						waitForLoader();
					}

					if (!cardNo.isEmpty()) { // --->Enter Account Number
						clearText(bnknum, "");
						setText(bnknum, "",cardNo);
						report.reportPass("Enter Account number", "Account no should be entered.",
								"Account  number is  " + cardNo);
						waitForLoader();
					}
					if (!nickName.isEmpty()) { // --->Enter Nick Name
						clearText(nickname, "");
						setText(nickname, "", nickName);
						report.reportPass("Enter Nick Name", "Nick Name should be entered.",
								"Nick Name is  " + nickName);
						waitForLoader();
					}
					
					if(isDisplayed(contBtn, objectValue, 3))
					{
						report.reportPass("Verify Continue button after entering Credit/debit details", "Continue button should be enable", "Continue button is enabled");
						clickUsingJavaScript(contBtn, objectValue);
						waitForLoader();
					}
					
					
					if (isDisplayed(IAgreebtn, objectValue, 3)) {

						report.reportPass("Check Terms and conditions are visible or not", "Verify Terms and condiitions",
								"Able to see terms and conditions");
						pageScroll(IAgreebtn);
						// pageScroll(IAgreebtn, mon, true);
						
						validateTOS();
						
						clickUsingJavaScript(IAgreebtn, objectValue);

						waitForLoader();
						waitForLoader();

						if (isDisplayed(verifyMON, mon, 3)) {
							report.reportPass("Verify MON after accepting Terms", "MON Number should displayed",
									"MON number is displayed");

							// Enter User id
							
							validateUserIDField(mon);

							/*setText(UserId, objectValue, "v" + mon);
							waitForLoader();*/
							
							valdiatePasswordFields();
							
							/*setText(pwd, objectValue, "vdsi@123!");
							waitForLoader();

							setText(rePwd, objectValue, "vdsi@123!");
							waitForLoader();*/

							clickUsingJavaScript(submit, objectValue);

							Set<String> allWindowsModi1 = driver.getWindowHandles();
							System.out.println(allWindowsModi1.size());
							for (String Child_Window : allWindowsModi1) {
								System.out.println(Child_Window);
							}

							driver.switchTo().defaultContent();
							switchToWindowWithTitle("Life On Fios");

							waitForLoader();
							waitForLoader();

							String status = getAttribute(registrationStatus, objectValue, "class");
							System.out.println(status);
							if (status.contains("green")) {
								System.out.println("Registration is completed....");
								report.reportPass("Verify Registration completed success message", "Registration Completed",
										"Registration Completed Message is displayed");
							} else {
								System.out.println("Registration Failed.......");
								report.reportFail("Verify Registration completed success message", "Registration Completed",
										"Registration Completed Message is NOT displayed");
							}
							
						} else {
							System.out.println("LOF Customer Already registered");
							if(isDisplayed(ThankYouOrder, objectValue, 5))
							{
								report.reportPass("LOF Registration", "Verify Customer is registered or not",
										"Customer is already registered..");
							}else {
								report.reportFail("LOF Registration", "Verify Customer is registered or not",
										"Redirecting to invalid page");
							}
							
						}

					}else {
						System.out.println("unable to view terms and conditions");
						report.reportFail("Validate Terms and conditions", "I agree button should be displayed", "I Agree button is not displayed");
					}
					
					
				}
				
				waitForLoader();

				if (isDisplayed(agreebtn, objectValue, 3)) { // --->agree button --Opened Pop up
					
					waitForLoader();
					validateAutoPaytos();
					waitForLoader();
					validateTOS();
					pageScroll(agreebtn, mon, true);
					clickUsingJavaScript(agreebtn, objectValue);
					report.reportPass("Accept TOS", "Agree button should be clicked",
							"clicked on TOS agree button");

				}else {
					report.reportPass("Accept TOS", "Agree button should be clicked",
							"Agree TOS button is not displayed or enabled");
				}
				
				waitForLoader();

			
				if (isDisplayed(LOFError, mon, 20)) {
					pageScroll(LOFError, mon, true);
					String errormsg2 = getTextFromElement(LOFError, objectValue);
					System.out.println(errormsg2);
					String strFailed = "Failed in Processing Auto Pay for LOF: " + errormsg2
							+ "is dispalyed after entering Auto pay details";
					report.reportFail("Verify whether LOF AutoPay is processed",
							"Check whether LOF AutoPay is processed", strFailed);
					report.updateMainReport("comments", "Error: " + errormsg2 + " is displayed in LOF section");
					report.updateMainReport("ErrorMessage", errormsg2);
					logger.error(errormsg2);
					captureErrorMsg(errormsg2);
					throw new UserDefinedException(strFailed);

				}

				
			}
			
			
			
		}else {
			System.out.println("Autopay is not displayed..");
			report.reportFail("Enter AutoPay details", "Auto pay should be displayed", "Auto pay is not displayed");
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}

void validateUserIDField(String mon) throws Exception {
	
	String errmsg = null;
	String strDescription="validate user id mandatory fields";
	String ingstrExpected="Error message should display if User id mandatory field is missing";
	String strActual="Error message is displayed when User id Mandatory field is missing or less than min characters required entered";
	String strFailure="Error Message is not displaying or not matching with expected when Mandatory field is missing or less than min characters entered";
	click(UserId);
	click(pwd);
	
	try {
		if(usernameErrMsg.isDisplayed())
		{
			try
			{
				errmsg=driver.findElement(By.xpath("//p[@id='usenameError']")).getText();
				report.reportPass("Validate User id error msg", "Please enter your User ID.", "Error Message is matching");
				System.out.println(errmsg);
				
			}catch(Exception e)
			{
				report.reportFail("Validate User id error msg", "Please enter your User ID.", "Error Message is NOT matching");
				e.printStackTrace();
			}
			if(errmsg.contains("Please enter your User ID."))
			{
				//highlightElement(usernameErrMsg);
				Thread.sleep(1000);
				//report.reportPass(strDescription, strExpected, strActual);
				Thread.sleep(1000);
				///unHighlightElement(usernameErrMsg);
				
				
				setText(UserId, objectValue, "test");
				click(pwd);
				//highlightElement(usernameErrMsg);
				Thread.sleep(1000);
				//unHighlightElement(usernameErrMsg);
				//errmsg=driver.findElement(By.xpath("//p[@class='error-msg error-userId']")).getText();
				Thread.sleep(1000);
				if(usernameErrMsg.isDisplayed())
				{
					//report.reportPass(strDescription, strExpected, strActual);
					driver.findElement(By.xpath("//input[@id='userName']")).clear();
					setText(UserId, objectValue, "v"+mon);
					Thread.sleep(1000);
					click(pwd);
					Thread.sleep(3000);
					
					
				}else {
					report.reportFail("Validate user id error message", "Please enter valid user id error message should display", strFailure +": user id min characters are not entered failing");
				}
			
			}else {
				report.reportFail(strDescription, "Please enter valid user id error message should display", strFailure +": user id min characters are not entered failing");
			}
				
			
			
		}else {
			report.reportFail(strDescription, "Please enter valid user id error message should display", strFailure);
		}
	} catch (Exception e) {
		report.reportFail("User ID Text field validation", "User ID validation should pass", "User ID field validation failed");
		e.printStackTrace();
	}
}

public void valdiatePasswordFields() {
	
	try {
		String errmsg = null;
		String password=null;
		String strDescription="validate password mandatory fields";
		String strExpected="Error message should display if password mandatory field is missing";
		String strActual="Error message is displayed when password Mandatory field is missing or less than min characters required entered";
		String strFailure="Error Message is not displaying or not matching with expected when Mandatory field is missing or less than min characters entered";
		click(pwd);
		click(rePwd);
		
		if(pwdErrMsg.isDisplayed())
		{
			try
			{
				errmsg=getTextFromElement(pwdErrMsg, objectValue);
				System.out.println(errmsg);
				
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			if(errmsg.contains("Please enter your password."))
			{
				//highlightElement(pwdErrMsg);
				report.reportPass(strDescription, strExpected, strActual);
				Thread.sleep(2000);
				//unHighlightElement(pwdErrMsg);
				
				setText(pwd, objectValue, "test");
				click(rePwd);
				Thread.sleep(2000);
				
				
				errmsg=getTextFromElement(pwdErrMsg,objectValue);
				if(errmsg.contains("Minimum 8 characters"))
				{
					report.reportPass("Password min 8 character error msg", "Min 8 character error message should display", "Min 8 Characters error message is displaying");
					pwd.clear();
					setText(pwd, objectValue, "vdsi@123!");
					Thread.sleep(2000);
					click(rePwd);
					Thread.sleep(2000);
					
					setText(rePwd, objectValue, "test");
					click(submit);
					errmsg=getTextFromElement(rePwdErr, objectValue);
					System.out.println(errmsg);
					if(isDisplayed(rePwdErr))
					{
						//highlightElement(rePwdErr);
						Thread.sleep(2000);
						report.reportPass("Password not matching error", "Password not matching error should display", "Password not matching error is displaying");
						//unHighlightElement(rePwdErr);
						
						//enter actual confirm password
						rePwd.clear();
						Thread.sleep(2000);
						setText(rePwd, objectValue, "vdsi@123!");
						Thread.sleep(5000);
						
					}
					else
					{
						report.reportFail("Password not matching error", "Password not matching error should display", "Password not matching error is not displaying");
					}
				}else {
					report.reportFail("Password min 8 character error msg", "Min 8 character error message should display", "Min 8 Characters error message is not displaying");
				}
			
			}else {
				report.reportFail(strDescription, strExpected, strFailure +": Password min characters are not entered, failing");
			}
		}else {
			report.reportFail(strDescription, strExpected, strFailure);
		}
	} catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (UserDefinedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

}

void OrderDetails()
{
	List<String> bills = new ArrayList<String>();
	try {
		String welcomeMsg=getTextFromElement(welcomeCustomer, objectValue);
		System.out.println(welcomeMsg);
		if(welcomeMsg.contains("Welcome"))
		{
			report.reportPass("Validate Welcome Message", "Welcome with customer name should display", "Welcome message is displaying");
			
			CList<Element> monthlyBills=getElementList(Monthlybills, objectValue);
			for(Element bill : monthlyBills)
			{
				//pageScroll(bill);
				waitForLoader();
				report.reportPass("Verify Bill Amount", "Bill amount should be displayed", "Bill amount is displayed");
				String billAmount=getTextFromElement(bill, objectValue);
				System.out.println(billAmount);
				bills.add(billAmount);
			}
			
			
			if(EstimatedMonthlyCharges.contains(bills.get(0)))
			{
				System.out.println("Monthly charges are matching with LOF Estimated monthly charges");
				report.reportPass("Validate estimated monthly charges", "Estimated Monthly charges should match with LOF estimated monthly charges", "Estimated Monthly charges are matching with LOF estimated charges");
			}else {
				System.out.println("Monthly charges are not matching with LOF Estimated monthly charges...");
				report.reportFail("Validate estimated monthly charges", "Estimated Monthly charges should match with LOF estimated monthly charges", "Estimated Monthly charges are NOT matching with LOF estimated charges");
			}
			
			if(EstimatedBillAmt.contains(bills.get(1)))
			{
				report.reportPass("Validate estimated bill amount", "Estimated bill amount should match with LOF estimated bill amount", "Estimated bill amount is matching with LOF Estimated bill amount");
				System.out.println("Estimated bill amount is matching with LOF Estimated bill amount");
				
			}else {
				report.reportFail("Validate estimated bill amount", "Estimated bill amount should match with LOF estimated bill amount", "Estimated bill amount is  NOT matching with LOF Estimated bill amount");
				System.out.println("Estimated bill amount is NOT matching with LOF Estimated bill amount");
			}
			
			System.out.println("Estimated Monthly Charges are :"+bills.get(0));
			System.out.println("Estimated Monthly Bill is:"+bills.get(1));
		}else {
			System.out.println("Welcome message is not displayed...");
			report.reportFail("Validate Welcome Message", "Welcome with customer name should display", "Welcome message is NOT displaying");
		}
		
	} catch (Exception e) {
		System.out.println("Welcome message is not displayed.....");
		e.printStackTrace();
	}
}

    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void navigateTo() throws Exception {

	// To increment the navigation iteration
	int i = TestIterator.getIterator(testId);
	TestIterator.setIterator(testId, ++i);

	clickUsingJavaScript(summaryTab, objectValue);
    }

    /**
     * @info To compare the order with tax and without tax
     */
    protected void compareOrderPrice() throws Exception {

	try {
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");

	    // To compare the price between product service page and checkout
	    // popup
	    String strOrderSummarySubTotal = txtOrderSummaryMonthlySubTotal.getText();
	    String strOrderSummaryMonthlyCharge = txtOrderSummaryMonthlyCharges.getText();

	    if (totalOrderValueWithoutTax.equals(strOrderSummarySubTotal)) {
		report.reportPass("Order Value Without Tax and Subtotal in summary", "Both Values matched",
			"OPO Page Price without tax:" + totalOrderValueWithoutTax + " Summary Page Subtotal:" + strOrderSummarySubTotal);
	    } else {
		report.reportFail("Order Value Without Tax and Subtotal in summary", "Both Values are different",
			"OPO Page Price without tax:" + totalOrderValueWithoutTax + " Summary Page Subtotal:" + strOrderSummarySubTotal);
		report.updateMainReport("ErrorMessage", "OPO Page Price without tax:" + totalOrderValueWithoutTax + " Summary Page Subtotal:" + strOrderSummarySubTotal);
	    }

	    if (totalOrderValueWithTax.equals(strOrderSummaryMonthlyCharge)) {
		report.reportPass("Order Value With Tax and Monthly charge in summary", "Both Values matched",
			"OPO Page Price with tax:" + totalOrderValueWithTax + " Summary Page Monthly Charges:" + strOrderSummaryMonthlyCharge);
	    } else {
		report.reportFail("Order Value With Tax and Monthly charge in summary", "Both Values are different",
			"OPO Page Price with tax:" + totalOrderValueWithTax + " Summary Page Monthly Charges:" + strOrderSummaryMonthlyCharge);
		report.updateMainReport("ErrorMessage", "OPO Page Price without tax:" + totalOrderValueWithoutTax + " Summary Page Subtotal:" + strOrderSummarySubTotal);
	    }

	    switchToDefaultcontent();
	    waitForLoader();

	} catch (Exception exe) {
	    exe.printStackTrace();
	    throw exe;
	}

    }

    /**
     * setSummaryInfo method for providing the Customer's Summary information in
     * Summary Info Page
     * 
     * @author Shiva Kumar Simharaju
     * @throws Exception
     *             throws exception of type Exception
     */
    protected void setSummaryInfo() throws Exception {

    	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
    	try {
    		System.out.println();
    	    // Give Customer Summary info
    	    strDescription = "Entering customer Summary info details";
    	    strExpected = "Giving customer Summary info in details";
    	    strActual = "Giving Customer Summary details in Summary Info Page was successful";
    	    strFailed = "Giving Customer Summary details in Summary Info Page was not successful";
    	    getUrl = ", URL Launched --> " + returnURL();
    	    int TimeOut = 60;
    	    String autoPay = get("AutoPayment").trim();
    	    String placeAutopayDeenrollement = get("PlaceAutopayDeEnroll").trim();
    	    String paperFreeBill = get("PaperfreeBill").trim();
    	    String notes = get("Notes").trim();
    	    String installationflexibility = get("InstallationFlexibility").trim();
    	    String waiver = get("waiver").trim();


    	    waitForLoader();
    	    waitForLoader();
    	    waitForLoader();
    	    String submitORNosubmit = get("PlaceOrder").trim();

    	   
    	    
    	    // Switch Frame
    	    switchToDefaultcontent();
    	    switchToFrame("IfProducts");
    	    
    	    try {
                //By Shobana
             //To take Screenshot og summary page
		             pageScroll(summaryExpand, objectValue,true);
		             clickUsingJavaScript(summaryExpand,objectValue);
		             report.reportPass("SummaryPage Validations","screens","summary screens");  
		             if(isDisplayed(zeroRated, objectValue, 2)){
		             pageScroll(zeroRated, objectValue,true);  
		             clickUsingJavaScript(zeroRated, objectValue);
		             report.reportPass("SummaryPage Validations","screens","summary screens");   
		             
		             if(!get("ETF").isEmpty()){ 
		             checkETF();
		             }
		             if(get("HLRValidations").equalsIgnoreCase("Yes")){
		             //Prakash -- Validate Zero Rated products for Restore -- Begon
		            if (get("ChangeType").contains("VacationSuspendRestore"))
		     	    {	
		            pageScroll(MasterOrderNumber);
		 	    	clickUsingJavaScript(MasterOrderNumber, objectValue);
		 	    	waitForLoader();
		 	    	waitForLoader();
		 	    	waitForLoader();
		 	    	waitForLoader();
		 	    	WebElement table1=driver.findElement(By.id("ctl00_Panel20"));
		 	    	 java.util.List<WebElement> rows1=table1.findElements(By.tagName("tr"));
		 	    	  String data1=rows1.get(0).getText();
		 	    	 String[] words=data1.split("\\n");
		 	    	 String FdataVD="N",FTVVD="N", FDVVD="N";
		 	    	 String FdataRes="N",FTVRes="N", FDVRes="N";
		 	    	  for(String w:words){  
		 	    	    	    		 System.out.println(w);
		 	    	    	    		 if (w.contains("FiOS TV"))
		 	    	    	    		 {	FTVVD="Y";		 	    	    	    			
		 	    	    	    		 }
		 	    	    	    		if (w.contains("FiOS Internet"))
		 	    	    	    		{	FdataVD="Y";		 	    	    	    			
		 	    	    	    		}
		 	    	    	    		if (w.contains("FiOS Digital Voice"))
		 	    	    	    		{	FDVVD="Y";		 	    	    	    			
		 	    	    	    		}		 	    	    	    		
		 	    	    	    		 waitForLoader();
		 	    						 }
		 	    	  
		 	    	 clickUsingJavaScript(CloseViewDetails, FDVRes);
		 	    	  
		 	    	 for (int i=0; i < RestoreZeroRated.size(); i++)
		 	    	 {
		 	    		 System.out.println(RestoreZeroRated.get(i).getText());
		 	    		 if (RestoreZeroRated.get(i).getText().contains("Fios Internet"))
		 	    		 {
		 	    			FdataRes="Y";
		 	    		 }
		 	    		if (RestoreZeroRated.get(i).getText().contains("Fios TV"))
		 	    		 {
		 	    			FTVRes="Y";
		 	    		 }
		 	    		if (RestoreZeroRated.get(i).getText().contains("FiOS Digital Voice"))
		 	    		 {
		 	    			FDVRes="Y";
		 	    		 }
		 	    	 }
		 	    	 if (FdataVD.contains("Y") && (FdataRes.contains("Y")))
		 	    	 {
		 	    		report.reportPass("Zero Rated products Validation ","Fios Internet Restore  available","Fios Internet Restore available"); 
		 	    	 }
		 	    	 else if (FdataVD.contains("Y") && (FdataRes.contains("N")))
		 	    	 {
		 	    		report.reportFail("Zero Rated products Validation ","Fios Internet Restore Not available","Fios Internet Restore Not available"); 
		 	    	 }
		 	    	if (FTVVD.contains("Y") && (FTVRes.contains("Y")))
		 	    	 {
		 	    		report.reportPass("Zero Rated products Validation ","Fios TV Restore available","Fios TV Restore available"); 
		 	    	 }
		 	    	 else if (FTVVD.contains("Y") && (FTVRes.contains("N")))
		 	    	 {
		 	    		report.reportFail("Zero Rated products Validation ","Fios TV Restore Not available","Fios TV  Restore Not available"); 
		 	    	 }
		 	    	if (FDVVD.contains("Y") && (FDVRes.contains("Y")))
		 	    	 {
		 	    		report.reportPass("Zero Rated products Validation ","Fios Internet Restore available","Fios Internet Restore available"); 
		 	    	 }
		 	    	 else if (FDVVD.contains("Y") && (FDVRes.contains("N")))
		 	    	 {
		 	    		report.reportFail("Zero Rated products Validation ","FFiOS Digital Voice Restore Not available","FiOS Digital Voice  Restore Not available"); 
		 	    	 }
		 	    	 
		     	    }
		           		        	   	            
		 	    	 //Prakash -- Validate Zero Rated products for Restore -- End
		             
		            for (WebElement ele:summaryScreen)
		             {
		             pageScroll(ele);
		             report.reportPass("SummaryPage Validations","screens","summary screens");   
		             }
		             }
		             
		           }
		     }
		catch(Exception e)
		{
		//System.out.println("Unable to take screeshot " );
		}

    	    
    	    
    	    if(get("Application").equalsIgnoreCase("C2G")){
    	    	try{
    	    	String c2gmon=driver.findElement(By.xpath("//div[@id='ctl00_ctl00_ContentPlaceHolder1_dvCustScvcInfo']//td[@id='ctl00_ctl00_ContentPlaceHolder1_custSvcInfo_tdMON']/span[2]")).getText();
    	    	System.out.println("MON:"+ c2gmon);
    		    report.reportPass("To capture Mon Number ", " Mon Number should be captured if availble", " Mon Number " + c2gmon + " is captured");
    		    report.updateMainReport("MON", c2gmon);
    	    	}
    		    catch(Exception e){
    		    	String c2gmon=driver.findElement(By.xpath("//div[@id='monDisplay']")).getText();
        	    	System.out.println("MON:"+ c2gmon);
        		    report.reportPass("To capture Mon Number ", " Mon Number should be captured if availble", " Mon Number " + c2gmon + " is captured");
        		    report.updateMainReport("MON", c2gmon);
        		    
        	    	}

    	    }
    	    else {
    	    	try{
    	    	 String mon = driver.findElement(By.xpath("//div[@id='SimplexMasterView']//td[@id='tdMON']/label")).getText();
    	    	 System.out.println("MON:"+ mon);
    			    report.reportPass("To capture Mon Number ", " Mon Number should be captured if availble", " Mon Number " + mon + " is captured");
    			    report.updateMainReport("MON", mon);
    			    MON=mon;
    	    	}
    	    	catch(Exception e){
    	    		strFailed = "MON Number is not displayed in Summary Page";
         	    	report.reportFail(strDescription + getUrl, strExpected, strFailed);
         			report.updateMainReport("comments", strFailed);
         			report.updateMainReport("ErrorMessage", strFailed);
         			logger.error(strFailed);
         			captureErrorMsg(strFailed);
         			throw new UserDefinedException(strFailed);
    	    	}
    	    }
    	    

    	    // Added for Validating MO validation in Summary Grid
    	    if (!get("MarketingOfferType").isEmpty()) {
    		MOOfferInSummary();
    	    }

    	    // Paper Free bill
    	    if (paperFreeBill.equalsIgnoreCase("No")) {

    		if (isDisplayed(noPaperfreeBilling, "", 1)) {
             try{
    		    clickUsingJavaScript(noPaperfreeBilling, "");
    		    if(isDisplayed(noPaperfreeBillingReason, submitORNosubmit, 2)){
        		    selectDropDownUsingVisibleText(noPaperfreeBillingReason, "", "Other");
        		    }

    		    report.reportPass("Validate Paper free billing", "Paper free billing should be selected as No.", "No paperfree billing is selected");
             }
             catch(Exception e){
     	    	strFailed = "Failed in Clicking No for paper free billing";
     	    	report.reportFail(strDescription + getUrl, strExpected, strFailed);
     			report.updateMainReport("comments", strFailed);
     			report.updateMainReport("ErrorMessage", strFailed);
     			logger.error(strFailed);
     			captureErrorMsg(strFailed);
     			throw new UserDefinedException(strFailed);
     	    	}
             
    		}
    	    } else {

    		if (isDisplayed(yesPaperfreeBilling, "", 1)) {
    			try{

    		    clickUsingJavaScript(yesPaperfreeBilling, "");
    		    waitForLoader();
    		    clickUsingJavaScript(pageFreeBillWindowClose, "");
    		    report.reportPass("Validate Paper free billing", "Paper free billing should be selected as Yes.", "paperfree billing is selected as Yes");
    			}
    			 catch(Exception e){
    	     	    	strFailed = "Failed in Clicking Yes for paper free billing";
    	     	    	report.reportFail(strDescription + getUrl, strExpected, strFailed);
    	     			report.updateMainReport("comments", strFailed);
    	     			report.updateMainReport("ErrorMessage", strFailed);
    	     			logger.error(strFailed);
    	     			captureErrorMsg(strFailed);
    	     			throw new UserDefinedException(strFailed);
    	     	    	}
    		}
    	    }
    	    
			  if(isDisplayed(billNoticeYes,objectValue,3))   //Mobile# add
    		
    	    	{    	
    			clickUsingJavaScript(billNoticeYes, "");
    			report.reportPass("Select Mobile No. Option", "Mobile No. Option should be selected as Yes.", "Mobile No. Option is selected as Yes");
    		}
    			else {
    				clickUsingJavaScript(billNoticeNo, "");
    			}
				
    	    if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
    	    	Net_Bundle_price();
        	    Product_Offer_Description_Summarypage();
        	    Product_Offer_Price_Summarypage();
        	    Compare_MonthlyCharges_RO_OPO();
        	    SOC_Section();
    	    	
    	    	
    	    }
    	    //Update for FCP
    	    if (get("Project_ID").contains("FCP")) {
    	    summaryOfferValidation();
    	    }
    	  //Mounika Polagoni (HLR Validations)
    		
    	 if(get("HLRValidations").equalsIgnoreCase("Yes")){ 	    
    	    switchToDefaultcontent();
     	    switchToFrame("IfProducts");
     	    
     	   //Internet
    	    try{
    	    if(!get("Display Internet").isEmpty()){
        		String IP=get("Display Internet");
        		System.out.println(IP);
        		if(isDisplayed(FiosInternet, "", 1)){
        			pageScroll(FiosInternet, "", true);
    		String BundleComponentsInternet=getTextFromElement(FiosInternet, "");
    		String BCI[]=BundleComponentsInternet.split("Fios Internet");
    		System.out.println(BundleComponentsInternet);
    		String[] IPlan=IP.split("M");
    		System.out.println(BCI[1]);
    		//System.out.println(BCI[2]);
    		if(BCI[1].contains(IPlan[0])){
    			report.reportPass("Internet Plan should be same in OPO and Checkout", "Internet Plan should be same in OPO and Checkout", "Internet is same in OPO and Checkout");
    		}
    		else{
    			report.reportFail("Internet Plan should be same in OPO and Checkout", "Internet Plan should be same in OPO and Checkout", "Internet is not same in OPO and Checkout");
    		}
        		}
        		else if(isDisplayed(FiosInternet2, "", 1)){
        			pageScroll(FiosInternet2, "", true);
        			String BundleComponentsInternet=getTextFromElement(FiosInternet2, "");
            		String BCI[]=BundleComponentsInternet.split("Fios Internet");
            		System.out.println(BundleComponentsInternet);
            		String[] IPlan=IP.split("M");
            		System.out.println(BCI[1]);
            		//System.out.println(BCI[2]);
            		if(BCI[1].contains(IPlan[0])){
            			report.reportPass("Internet Plan should be same in OPO and Checkout", "Internet Plan should be same in OPO and Checkout", "Internet is same in OPO and Checkout");
            		}
            		else{
            			report.reportFail("Internet Plan should be same in OPO and Checkout", "Internet Plan should be same in OPO and Checkout", "Internet is not same in OPO and Checkout");
            		}	
        		}
        		else{
        			report.reportFail("Internet Plan should be same in OPO and Checkout", "Internet Plan should be same in OPO and Checkout", "Selected Internet Plan is not displayed in checkout");
        		}
    		}
    	    }
    	    catch(Exception e){
    	    	System.out.println("");
    	    }
    		
    	    
    	    
    	    
    	  //TV
    	    
    	    try{
    		if(!get("Display Video").isEmpty()){
        		String TP=get("Display Video");
        		System.out.println(TP);
        		
        		if(isDisplayed(FiosTV, "", 1)){
    		pageScroll(FiosTV, "", true);
    		String BundleComponentsTV=getTextFromElement(FiosTV, "");
    		System.out.println(BundleComponentsTV);
    		if(BundleComponentsTV.contains(TP) || TP.contains(BundleComponentsTV)){
    			report.reportPass("TV Plan should be same in OPO and Checkout", "TV Plan should be same in OPO and Checkout", "TV is same in OPO and Checkout");
    		}
    		else{
    			report.reportFail("TV Plan should be same in OPO and Checkout", "TV Plan should be same in OPO and Checkout", "TV is not same in OPO and Checkout");
    		}
    		}
    		
    		else if(isDisplayed(FiosTV2, "", 1)){
    			pageScroll(FiosTV2, "", true);
    			String BundleComponentsTV=getTextFromElement(FiosTV2, "");
        		System.out.println(BundleComponentsTV);
        		if(BundleComponentsTV.contains(TP) || TP.contains(BundleComponentsTV)){
        			report.reportPass("TV Plan should be same in OPO and Checkout", "TV Plan should be same in OPO and Checkout", "TV is same in OPO and Checkout");
        		}
        		else{
        			report.reportFail("TV Plan should be same in OPO and Checkout", "TV Plan should be same in OPO and Checkout", "TV is not same in OPO and Checkout");
        		}
    			
    			
    		}
    		else{
    			report.reportFail("TV Plan should be same in OPO and Checkout", "TV Plan should be same in OPO and Checkout", "Selected TV Plan is not displayed in checkout");
    		}
    		}
    		}
    	    catch(Exception e){
    	    	System.out.println("");
    	    }
    	    
    		
    	    
    	  //voice
    	    
    	    try{
    		if(!get("Display Voice").isEmpty()){
        		String VP=get("Display Voice");
        		System.out.println(VP);
        		if(VP.contains("Fios Digital Voice")){
        			String VP2="Fios Digital Voice";
        		
        		
    		if(isDisplayed(FiosDigitalVoice, "", 1)){
    			pageScroll(FiosDigitalVoice, "", true);
    		String BundleComponentsVoice=getTextFromElement(FiosDigitalVoice, "");
    		System.out.println(BundleComponentsVoice);
    		if(BundleComponentsVoice.contains(VP2)){
    			report.reportPass("Voice Plan should be same in OPO and Checkout", "Voice Plan should be same in OPO and Checkout", "Voice is same in OPO and Checkout");
    		}
    		else{
    			report.reportFail("Voice Plan should be same in OPO and Checkout", "Voice Plan should be same in OPO and Checkout", "Voice is not same in OPO and Checkout");
    		}
    		}
    		else if(isDisplayed(Fiosvoice2, "", 1)){
    			pageScroll(Fiosvoice2, "", true);
    			String BundleComponentsVoice=getTextFromElement(Fiosvoice2, "");
        		System.out.println(BundleComponentsVoice);
        		if(BundleComponentsVoice.contains(VP2)){
        			report.reportPass("Voice Plan should be same in OPO and Checkout", "Voice Plan should be same in OPO and Checkout", "Voice is same in OPO and Checkout");
        		}
        		else{
        			report.reportFail("Voice Plan should be same in OPO and Checkout", "Voice Plan should be same in OPO and Checkout", "Voice is not same in OPO and Checkout");
        		}
    		}
    		else{
    			report.reportFail("Voice Plan should be same in OPO and Checkout", "Voice Plan should be same in OPO and Checkout", "Selected Voice Plan is not displayed in checkout");
    		}
        		}
	         }
    	    }
    	    catch(Exception e){
    	    	
    	    }

    	    
    	    
    	    //Router
    		try{
    		if(!get("Display Router").isEmpty()){
    		String Rtr=get("Display Router");
    		System.out.println(Rtr);
    		if(isDisplayed(RouterOption, "", 1)){
    			pageScroll(RouterOption, Rtr, true);
    		String Router=getTextFromElement(RouterOption, "");
    		if(Router.contains(Rtr)){
    			report.reportPass("Router should be same in OPO and Checkout", "Router should be same in OPO and Checkout", "Router is same in OPO and Checkout");
    		}
    		else{
    			report.reportFail("Router should be same in OPO and Checkout", "Router should be same in OPO and Checkout", "Router is not same in OPO and Checkout");
    		}
    		}
    		else{
    			 report.reportFail("Router should be same in OPO and Checkout", "Router should be same in OPO and Checkout", "Router is not displayed in Checkout");	
    		}
    		}
    		}
            catch(Exception e){
    			
    		}
    		

    		
    		//Recording Option
    		try{
    		if(!get("Display RecordingOption").isEmpty()){
    		String RecOpt=get("Display RecordingOption");
    		System.out.println(RecOpt);
    		if(isDisplayed(getRecordingOption, RecOpt, 1)){
    		String RecordingOption=getTextFromElement(getRecordingOption, "");
    		if(RecordingOption.contains(RecOpt)){
    			report.reportPass("Recording Option should be same in OPO and Checkout", "Recording Option should be same in OPO and Checkout", "Recording Option is same in OPO and Checkout");
    		}
    		else{
    			report.reportFail("Recording Option should be same in OPO and Checkout", "Recording Option should be same in OPO and Checkout", "Recording Option is not same in OPO and Checkout");
    		}
    		}
    		else{
    			report.reportFail("Recording Option should be same in OPO and Checkout", "Recording Option should be same in OPO and Checkout", "Recording Option is not displayed in Checkout");
    		}
    		}
    		}
            catch(Exception e){
    			
    		}
    		
    		
    		
    		//STB
    		try{
        		if(!get("Display NumberOfTv").isEmpty()){
        		String NumOfTvPlan=get("Display NumberOfTv");
        		System.out.println(NumOfTvPlan);
        		if(isDisplayed(TVStb, NumOfTvPlan, 1)){
        		pageScroll(TVStb, NumOfTvPlan, true);
    		String StbTv=getTextFromElement(TVStb, "");
    		String[] StbSplit1=StbTv.split("Set-Top Box");
    		String[] StbSplit2=StbSplit1[0].split("Rent: ");
    		System.out.println(StbSplit2[1]);
    		if(StbSplit2[1].contains(NumOfTvPlan)){
    			report.reportPass("Number Of Tv should be same in OPO and Checkout", "Number Of Tv should be same in OPO and Checkout", "Number Of Tv is same in OPO and Checkout");
    		}
    		else{
    			report.reportFail("Number Of Tv should be same in OPO and Checkout", "Number Of Tv should be same in OPO and Checkout", "Number Of Tv is not same in OPO and Checkout");
    		}
        		}
    		else{
    			report.reportFail("Number Of Tv should be same in OPO and Checkout", "Number Of Tv should be same in OPO and Checkout", "Number Of Tv is not displayed in Checkout");
    		}
        		}
        		}
    		catch(Exception e){
    			
    		}
    		
    	}
    	    
           // Installation Flexibility - Vijay
    	    
    	    
			  if (installationflexibility.contains("setup")&& installationflexibility.contains("fifty")) {
				  				  
				  String setupfee = setupfeewaiver1.getText();
				  System.out.println("SetUpFee" +setupfee);
				  if (setupfee.equalsIgnoreCase(waiver)){
						System.out.println("50% Waiver was added to SOC");
						report.reportPass("Set Up Fee", "50% Waiver should be added to SOC.", "50% Waiver added to SOC");
					}
					else {
						System.out.println("Waiver was not added to SOC");
						strFailed = "Waiver was not added to SOC";
						report.reportFail("Set Up Fee", "50% Waiver should be added to SOC.", "50% Waiver not added to SOC");
						report.updateMainReport("comments", strFailed);
		     			report.updateMainReport("ErrorMessage", strFailed);
		     			logger.error(strFailed);
		     			captureErrorMsg(strFailed);
		     			throw new UserDefinedException(strFailed);
					
					}
			  }
				  else if (installationflexibility.contains("setup")&& installationflexibility.contains("hundred")) {
						String setupfee = setupfeewaiver2.getText();
						System.out.println("SetUpFee" +setupfee);
						  if (setupfee.equalsIgnoreCase(waiver)){
								System.out.println("100% Waiver was added to SOC");
								report.reportPass("Set Up Fee", "100% Waiver should be added to SOC.", "100% Waiver added to SOC");
							}
							else {
								System.out.println("Waiver was not added to SOC");
								report.reportFail("Set Up Fee", "100% Waiver should be added to SOC.", "100% Waiver not added to SOC");
								report.updateMainReport("comments", strFailed);
				     			report.updateMainReport("ErrorMessage", strFailed);
				     			logger.error(strFailed);
				     			captureErrorMsg(strFailed);
				     			throw new UserDefinedException(strFailed);
							}
		}

    	    // for NO Autopay

    	 /*   if (get("GUI_Validations").equalsIgnoreCase("Yes") && get("Application").equalsIgnoreCase("COA")) {

    		boolean isVepsDisplayed = tryForAutoPayVEPS(5);

    		if (isVepsDisplayed) {

    		    UIValidation_No_Autopay();

    		} else {

    		    report.reportFail("Validate Veps NO Autopay Process ", "Veps Autopay Process should work", "Veps Auto pay process failed.");
    		}
    	    }
    	    */

    	    // Auto Payment
    	    //If LOF flow -- Modified by Anu Dhiman
    	    if(get("LOF_Flow").equalsIgnoreCase("Yes")){
    	    	processLofAutoPay();
    	    }
    	    else
    	    {
    	        	    
    	    if (autoPay.equalsIgnoreCase("Yes")) {
    	    	
                if(isDisplayed(manageAutopay, objectValue, 2)){
               	 pageScroll(manageAutopay);	
               	 report.reportPass("Select AutoPay", "AutoPay Should be Selected", "AutoPay is already Enrolled for this if you wish you can Manage Auto Pay");
       	      }
                else if(isDisplayed(autoPaymentYes, objectValue, 2)){
       		pageScroll(autoPaymentYes);
       		clickUsingJavaScript(autoPaymentYes, "");
       		report.reportPass("Select AutoPay", "AutoPay should be selected as Yes.", "Auto pay is selected as Yes");
       		waitForLoader();
       		waitForPageToLoad(driver);
       		if(isDisplayed(PaymentGateway, submitORNosubmit, 3)){
           		pageScroll(PaymentGateway, submitORNosubmit, true);	
           		report.reportPass("Display Payment Gateway", "Display Payment Gateway", "Payment Gateway is displayed");
           		}
       		boolean isPayementDisplayed = tryForAutoPayVEPS(4);
       		if (!isPayementDisplayed && isDisplayed(autoPayUserID)) {
       		    report.reportFail("Validate veps page.", "Veps page should be displayed for autopayment", "Veps page was not displaed for autopayment.");
       		    throw new UserDefinedException("Error: Payment section was not displayed..Couldn't able to complete auto payment");
       		}
       		processAutoPay();
       	    	}
                else if(isDisplayed(LOFautoPaymentYes, objectValue, 2)){
                	report.reportPass("Should display AutoPay", "AutoPay should be diplayed", "LOF Auto pay is displayed");
            		pageScroll(LOFautoPaymentYes);
            		clickUsingJavaScript(LOFautoPaymentYes, "");
            		report.reportPass("Select AutoPay", "AutoPay should be selected as Yes.", "Auto pay is selected as Yes");
            		waitForLoader();
            		waitForPageToLoad(driver);

            		boolean isPayementDisplayed = tryForAutoPayVEPS(4);
            		if (!isPayementDisplayed && isDisplayed(autoPayUserID)) {
            		    report.reportFail("Validate veps page.", "Veps page should be displayed for autopayment", "Veps page was not displaed for autopayment.");
            		    throw new UserDefinedException("Error: Payment section was not displayed..Couldn't able to complete auto payment");
            		}
            		processAutoPay();
            	    	}
                else{
    	    		
    	    		if(isDisplayed(paymentMethod, objectValue, 1)){
    	    			
    	    			pageScroll(paymentMethod, objectValue, true);
    	    			report.reportPass("Select AutoPay", "AutoPay should be selected as Yes.", "Auto Pay cannot be done with this order due to migration order Once the Migration is Completed u can enroll in autopay ");
    	    		}
    	    		report.reportPass("Select AutoPay", "AutoPay should be selected as Yes.", "Auto Pay cannot be done with this order");	
    	    	}

       	    } 
    	    else if(isDisplayed(Autopaydisabled, objectValue, 2) && (autoPay.isEmpty() || autoPay.equalsIgnoreCase("No")) ){
    	    	pageScroll(autoPaymentYes);
           		clickUsingJavaScript(autoPaymentYes, "");
           		report.reportPass("Select AutoPay", "AutoPay should be selected as Yes.", "Auto pay is selected as Yes");
           		waitForLoader();
           		waitForPageToLoad(driver);
           		if(isDisplayed(PaymentGateway, submitORNosubmit, 3)){
               		pageScroll(PaymentGateway, submitORNosubmit, true);	
               		report.reportPass("Display Payment Gateway", "Display Payment Gateway", "Payment Gateway is displayed");
               		}
           		boolean isPayementDisplayed = tryForAutoPayVEPS(4);
           		if (!isPayementDisplayed && isDisplayed(autoPayUserID)) {
           		    report.reportFail("Validate veps page.", "Veps page should be displayed for autopayment", "Veps page was not displaed for autopayment.");
           		    throw new UserDefinedException("Error: Payment section was not displayed..Couldn't able to complete auto payment");
           		}
           		APay();
    	    }
    	    
    	      	    
    	    else if (autoPay.toLowerCase().contains("deenrollment")) {
    	    	pageScroll(manageAutopay);
    		clickUsingJavaScript(manageAutopay, "");
    		report.reportPass("Click on Manage autopay..", "Managae autopay should be clicked.", "Clicked on manage autopay.");
    		waitForLoader();
    		boolean isVepsDisplayed = tryForAutoPayVEPS(5);
    		if (isVepsDisplayed) {
    		    pageScroll(deEnrollAutopay, "", true);
    		    clickUsingJavaScript(deEnrollAutopay, "");
    		    report.reportPass("Click on deenroll button.", "Deenroll button should be clicked.", "Clicked on deenroll button.");
    		    if (placeAutopayDeenrollement.equalsIgnoreCase("Yes")) {

    			clickUsingJavaScript(deEnrollAutopayConfirmYes, "");
    			report.reportPass("Deenroll autopay", "Yes button should be clicked on autopay deenrollment", "Clicked on Yes button of Deenrollment confirmation");
    		    } else {
    			clickUsingJavaScript(deEnrollAutopayConfirmNo, "");
    			report.reportPass("Deenroll autopay", "No button should be clicked on autopay deenrollment", "Clicked on No button of Deenrollment confirmation");

    			switchToDefaultcontent();
    			switchToFrame("IfProducts");
    			pageScroll(autoPayClose, "", true);
    			clickUsingJavaScript(autoPayClose, "");
    		    }

    		} else {
    		    report.reportFail("Validate veps page.", "Veps page should be displayed for auto pay deenrollment", "Veps page was not displaed for autopay deenrollment.");
    		    throw new UserDefinedException("Error: Payment de enroll section was not displayed..Couldn't able to complete auto pay deenrollment");
    		}

    	    } else {
        		if (isDisplayed(autoPaymentNo, "", 1)) {
        		    clickUsingJavaScript(autoPaymentNo, "");
        		    report.reportPass("De Select AutoPay", "AutoPay should be selected as No.", "Auto pay is selected as No");
					if(isDisplayed(autoPayDeclinedReason, submitORNosubmit, 1)){
        		    selectDropDownUsingVisibleText(autoPayDeclinedReason, "", "Other");
					}
        		}
        		else if (isDisplayed(LOFautoPaymentNo, "", 1)) {
        		    clickUsingJavaScript(LOFautoPaymentNo, "");
        		    report.reportPass("De Select AutoPay", "AutoPay should be selected as No.", "Auto pay is selected as No");
        		    selectDropDownUsingVisibleText(LOFautoPayDeclinedReason, "", "Other");
        		}
        	 }
    	    
    	    }
    	    switchToDefaultcontent();
    	    switchToFrame("IfProducts");
    	    //-------------------------Digital Billing Update------------------------------
    	    try{
    	    if(isDisplayed(Digitalbillingrequiredbutton,"",5)){
    	    	pageScroll(Digitalbillingrequiredbutton);
    	    	System.out.println("Digital billing enrollment radio button is auto selected");
    		    report.reportPass("Digital billing enrollment autoselect", "Digital billing enrollment message should be auto selected", "Digital billing enrollment message is auto selected");   	    
    	    }
    	    else
    	    {
    	  
    	    	System.out.println("Digital billing enrollment radio button is not auto selected");
    		    report.reportPass("Digital billing enrollment autoselect", "Digital billing enrollment message should be auto selected", "Digital billing enrollment message is not auto selected"); 
    		    
    	    }
    	    String textMessageUpdate = get("MobileTextMessageUpdate").trim();
    	    if(isDisplayed(DigitalbillingMobileTextMessage,"",2)&&(textMessageUpdate.equals("Yes"))){
    	    	pageScroll(Digitalbillingmobilerediobuttonyes);
    	    	clickUsingJavaScript(Digitalbillingmobilerediobuttonyes, "");
    	    	System.out.println("Digital billing enrollment mobile text message update Yes is clicked");
    		    report.reportPass("Digital billing enrollment Mobile text message update", "Digital billing enrollment Mobile text message update should be clicked yes", "Digital billing enrollment Mobile text message update is clicked yes");     		    
    	    }
    	    else if(isDisplayed(DigitalbillingMobileTextMessage,"",1)){
    	    	pageScroll(DigitalbillingmobilerediobuttonNo);
    	    	clickUsingJavaScript(DigitalbillingmobilerediobuttonNo, "");
    	    	System.out.println("Digital billing enrollment mobile text message update No is clicked");
    		    report.reportPass("Digital billing enrollment Mobile text message update", "Digital billing enrollment Mobile text message update should be clicked No", "Digital billing enrollment Mobile text message update is clicked No");     		    
    	    }
    	    String emailDB= get("Email").trim();
    	    if(emailDB.equals("none")){
    	    	if(isDisplayed(DigitalbillingRadioButtonNo,"",1)){
    	    			
    	    	pageScroll(DigitalbillingRadioButtonNo);
    	    	clickUsingJavaScript(DigitalbillingRadioButtonNo, "");
    	    	selectDropDownUsingVisibleText(DigitalbillingRadioButtonNoDropdownReason,"","Prefer paper copy for record-keeping");
    	    	System.out.println("Digital billing enrollment is selected as No");
    		    report.reportPass("Digital billing is not enrolled", "Digital billing enrollment should be selected as No", "Digital billing enrollment is selected as No");     		    
    	    }}
    	    }
    	    catch(Exception e){
				System.out.println("Digital_billing_enrollment message and radio buttons are not displayed");
				report.reportFail("Digital Billing enrollment message and radio buttons should be  displayed: ", "Digital Billing enrollment message and readio buttons are not displayed: " , "Digital Billing message and radio buttons are not displayed ");
				} 

    	    
    	    // Click On Sent Email Radio Button
    	    if(!get("LOF_Flow").equalsIgnoreCase("Yes")){
   	    try{
   	    pageScroll(RbtSocEmail);
    	    clickUsingJavaScript(RbtSocEmail, objectValue);
   	    waitForLoader();
   	    report.reportPass("Click Send email button", "Send email button should be clicked", "Send email button is clicked");
   	    }
  	    catch(Exception e){
    	    	strFailed = "Failed in Clicking Send Email Radio button";
    	    	report.reportFail(strDescription + getUrl, strExpected, strFailed);
     			report.updateMainReport("comments", strFailed);
     			report.updateMainReport("ErrorMessage", strFailed);
     			logger.error(strFailed);
     			captureErrorMsg(strFailed);
     			throw new UserDefinedException(strFailed);
     	    	}
    	    }
    	    else
    	    {
   	    
   	    }
    	    
    	    /************************HariPrasad Savaravilli***************************/
    	    try{
    	    	if(isDisplayed(btnSOCEmailND2, objectValue, 3)){
    	           pageScroll(btnSOCEmailND2);
    	           clickUsingJavaScript(btnSOCEmailND2, objectValue);
    	           waitForLoader();
    	           report.reportPass("Click Send email button", "Send email button should be clicked", "Send email button is clicked");
    	           }
    	    }
    	           catch(Exception e){
    	              strFailed = "Failed in Clicking Send Email Radio button";
    	              report.reportFail(strDescription + getUrl, strExpected, strFailed);
		              report.updateMainReport("comments", strFailed);
				      report.updateMainReport("ErrorMessage", strFailed);
		              logger.error(strFailed);
				      captureErrorMsg(strFailed);
		              throw new UserDefinedException(strFailed);
    	              }
    	      /********************************************************************/

    	   
    	    String socText="";
    	    for(WebElement ele:SOCText){
    		socText =socText+ele.getText();
    	    }

    	 report.reportPass("Verify SOC", "SOC should be displayed.", "SOC: "+socText);
    	    
    	    // Click On Send Preview Email
    	    try{
    	    	if(isDisplayed(btnSendMailWTC, objectValue, 3)){
    	     clickUsingJavaScript(btnSendMailWTC, objectValue);
    	     report.reportPass("Send preview mail to email", "Preview details should be sent to email", "Preview email is sent.");
    	    	}
     	    // Wait for page navigation
     	    waitForLoader();
    	    }
	        catch(Exception e){
 	    	strFailed = "Send Preview Email is not clicked";
 	    	report.reportFail(strDescription + getUrl, strExpected, strFailed);
 			report.updateMainReport("comments", strFailed);
 			report.updateMainReport("ErrorMessage", strFailed);
 			logger.error(strFailed);
 			captureErrorMsg(strFailed);
 			throw new UserDefinedException(strFailed);
 	    	}

   //-----------------------Digital Billing Update Click On live order radio button-------------------------------------------
    	    
    	    String strLiveOrder = get("LiveOrder");
    	    if(strLiveOrder.equalsIgnoreCase("Yes")){
    	    try{
    	    pageScroll(rdoBtnLiveOrder);
    	    clickUsingJavaScript(rdoBtnLiveOrder, objectValue);
    	    waitForLoader();
    	    report.reportPass("Click on live order radio button", "live order radio button should be clicked", "live order radio button is clicked");
    	    
    	   
    	    if(isDisplayed(chkbxMTN, strLiveOrder, 1)){
    	    clickUsingJavaScript(chkbxMTN, objectValue);
    	    report.reportPass("Click on MTN chk button", "live order radio button should be clicked", "live order radio button is clicked");
    	    waitForLoader();
    	    }
    	    
    	    if(isDisplayed(chkbxEmail, strLiveOrder, 1)){
    	    clickUsingJavaScript(chkbxEmail, objectValue);
    	    report.reportPass("Click on MTN chk button", "live order radio button should be clicked", "live order radio button is clicked");
    	    waitForLoader();   
    	    }
    	    
    	    if(isDisplayed(lnkDBTOS, strLiveOrder, 1)){
    	    clickUsingJavaScript(lnkDBTOS, objectValue);
    	    report.reportPass("Click on MTN chk button", "live order radio button should be clicked", "live order radio button is clicked");
    	    waitForLoader(); 
    	    }
    	    
    	    if(isDisplayed(btnDBReadTOS, strLiveOrder, 1)){
    	   
    	    clickUsingJavaScript(btnDBReadTOS, objectValue);
    	    report.reportPass("Click on MTN chk button", "live order radio button should be clicked", "live order radio button is clicked");
    	    waitForLoader(); 
    	    }
    	    
    	    
    	    		
    	    }
    	    
    	    catch(Exception e){
     	    	strFailed = "Failed in performing live order DB ";
     	    	report.reportFail(strDescription + getUrl, strExpected, strFailed);
     			report.updateMainReport("comments", strFailed);
     			report.updateMainReport("ErrorMessage", strFailed);
     			logger.error(strFailed);
     			captureErrorMsg(strFailed);
     			throw new UserDefinedException(strFailed);
     	    	} 
    	    }
    	   

    	    // Fios Terms and conditions acceptance
    	    if (isDisplayed(fiosBundleAcceptance, "",3)) {
	    	    	try{
	    		pageScroll(fiosBundleAcceptance);
	    		clickUsingJavaScript(fiosBundleAcceptance, "");
	    		waitForLoader();
	    		clickUsingJavaScript(iHaveReadToCustomer, "");
	    		waitForLoader();
	    	    	}
    	    	catch(Exception e){
    	 	    	strFailed = "Failed in clicking fios Bundle Acceptance";
    	 	    	report.reportFail(strDescription + getUrl, strExpected, strFailed);
    	 			report.updateMainReport("comments", strFailed);
    	 			report.updateMainReport("ErrorMessage", strFailed);
    	 			logger.error(strFailed);
    	 			captureErrorMsg(strFailed);
    	 			throw new UserDefinedException(strFailed);
    	 	    	}

    	    }
    	    waitForLoader();
    	    System.out.println();
           if(get("Application").equalsIgnoreCase("COA")){
        	//   if(isDisplayed(certifyChckBox, "")){
        		   try{
        		  
    	    if (!isSelected(certifyChckBox, "")) {
    		pageScroll(certifyChckBox,objectValue,true);
    		clickUsingJavaScript(certifyChckBox, "");
    	    }
    	    report.reportPass("Validate certify TnC", "Certify TnC check box should be selected.", "Certify TnC check box is selected.");
    	    waitForLoader();
    	    // Click On Representative offline Check box
    	  if(isDisplayed(ChkOfflineRep, "", 2)){
    	    clickUsingJavaScript(ChkOfflineRep, objectValue);
    	    report.reportPass("Validate Checkbox Offline", "Certify Checkbox Offline box should be selected.", "Certify Checkbox Offline box is selected.");
    	    }
        	   }catch(Exception e){
   	 	    	strFailed = "Failed in clicking Certify Checkbox";
   	 	    	report.reportFail(strDescription + getUrl, strExpected, strFailed);
   	 			report.updateMainReport("comments", strFailed);
   	 			report.updateMainReport("ErrorMessage", strFailed);
   	 			logger.error(strFailed);
   	 			captureErrorMsg(strFailed);
   	 			throw new UserDefinedException(strFailed);
        	   }      	   
        	   
        	 //  }
           }
           else{
        	   if(isDisplayed(chxAcknowledge, objectValue, 5)){
    	    	 if (!isSelected(chxAcknowledge, "")) {
    	    			pageScroll(chxAcknowledge);
    	    			clickUsingJavaScript(chxAcknowledge, "");
    	    		    }
    	    		    report.reportPass("Validate certify TnC", "Certify TnC check box should be selected.", "Certify TnC check box is selected.");
    	    		    // Click On Representative offline Check box
    	    }
           
    	    waitForLoader();
           }

           if (isDisplayed(btnTOSCATS, "", 1)) {
          try{
       		pageScroll(btnTOSCATS);
       		clickUsingJavaScript(btnTOSCATS, objectValue);
       		report.reportPass("Select Fios Terms of service", "Fios TnS service should be selected. ", "Selected terms of service.");
       		waitForLoader();
       		 if(get("Application").equalsIgnoreCase("COA")){
       			 if (isDisplayed(btnVerbalAcceptance, "", 1)) {
       		clickUsingJavaScript(btnVerbalAcceptance, objectValue);
       			 }
       		waitForLoader();
       		 }
			 
       		 
           }catch(Exception e){
  	 	    	strFailed = "Failed in clicking Fios Terms of Service or Verbal acceptance";
  	 	    	report.reportFail(strDescription + getUrl, strExpected, strFailed);
  	 			report.updateMainReport("comments", strFailed);
  	 			report.updateMainReport("ErrorMessage", strFailed);
  	 			logger.error(strFailed);
  	 			captureErrorMsg(strFailed);
  	 			throw new UserDefinedException(strFailed);
       	   }  
       		       		 
       	    }
                        
              if(isDisplayed(txtOrderSummaryMonthlySubTotal, objectValue, 1)){
           	   String strOrderSummarySubtotalCharge = txtOrderSummaryMonthlySubTotal.getText();  
           	   System.out.println(strOrderSummarySubtotalCharge);
              	report.reportPass("Display order summary Subtotal charges", "Display order summary Subtotal charges", "Order summary Subtotal charges is: "+strOrderSummarySubtotalCharge);
                 }
              if(isDisplayed(txtOrderSummaryMonthlyCharges, objectValue, 1)){
           	   String strOrderSummaryMonthlyCharge = txtOrderSummaryMonthlyCharges.getText();  
           	   System.out.println(strOrderSummaryMonthlyCharge);
           	  
              	report.reportPass("Display order summary monthly charges", "Display order summary monthly charges", "Order summary monthly charges is: "+strOrderSummaryMonthlyCharge);
//              	if(!get("Monthly Estimated Charge in OPO").isEmpty()){
//              	if(get("Monthly Estimated Charge in OPO").equalsIgnoreCase(strOrderSummaryMonthlyCharge)){
//              		report.reportPass("Estimated Monthly Charges in OPO and Summary Page should match", "Estimated Monthly Charges in OPO and Summary Page should be same", "Estimated Monthly Charges in OPO: " +get("Monthly Estimated Charge in OPO")+ " is same as Estimated Monthly Charges in Summary Page: "+strOrderSummaryMonthlyCharge);	
//              	}
//              	else{
//              		report.reportPass("Estimated Monthly Charges in OPO and Summary Page should match", "Estimated Monthly Charges in OPO and Summary Page should be same", "Estimated Monthly Charges in OPO: " +get("Monthly Estimated Charge in OPO")+ " is not same as Estimated Monthly Charges in Summary Page: "+strOrderSummaryMonthlyCharge);
//              	}
//                 }
              }
           // Fios Terms and conditions acceptance
              /*************Mounika***********/
              if(isDisplayed(lnkDBTOS, strLiveOrder, 2)){
          	    clickUsingJavaScript(lnkDBTOS, objectValue);
          	    report.reportPass("Click on MTN chk button", "live order radio button should be clicked", "live order radio button is clicked");
          	    waitForLoader(); 
          	    
          	  clickUsingJavaScript(btnDBReadTOS, objectValue);
          	    }
           // Fios Terms and conditions acceptance
   	    if (isDisplayed(fiosInternetAcceptance, "",3)) {
	    	    	try{
	    		pageScroll(fiosInternetAcceptance);
	    		clickUsingJavaScript(fiosInternetAcceptance, "");
	    		waitForLoader();
	    		waitForLoader();
	    		clickUsingJavaScript(iHaveReadToCustomer, "");
	    		waitForLoader();
	    	    	}
   	    	catch(Exception e){
   	 	    	strFailed = "Failed in clicking fios Bundle Acceptance";
   	 	    	report.reportFail(strDescription + getUrl, strExpected, strFailed);
   	 			report.updateMainReport("comments", strFailed);
   	 			report.updateMainReport("ErrorMessage", strFailed);
   	 			logger.error(strFailed);
   	 			captureErrorMsg(strFailed);
   	 			throw new UserDefinedException(strFailed);
   	 	    	}

   	    }
   	 // Fios Terms and conditions acceptance
	    if (isDisplayed(fiosBundleAcceptance, "",3)) {
    	    	try{
    		pageScroll(fiosBundleAcceptance);
    		clickUsingJavaScript(fiosBundleAcceptance, "");
    		waitForLoader();
    		clickUsingJavaScript(iHaveReadToCustomer, "");
    		waitForLoader();
    	    	}
	    	catch(Exception e){
	 	    	strFailed = "Failed in clicking fios Bundle Acceptance";
	 	    	report.reportFail(strDescription + getUrl, strExpected, strFailed);
	 			report.updateMainReport("comments", strFailed);
	 			report.updateMainReport("ErrorMessage", strFailed);
	 			logger.error(strFailed);
	 			captureErrorMsg(strFailed);
	 			throw new UserDefinedException(strFailed);
	 	    	}

	    }
   	 if(get("Application").equalsIgnoreCase("COA")){
     	//   if(isDisplayed(certifyChckBox, "")){
     		   try{
     		  
 	    if (!isSelected(certifyChckBox, "")) {
 		pageScroll(certifyChckBox,objectValue,true);
 		clickUsingJavaScript(certifyChckBox, "");
 	    }
 	    report.reportPass("Validate certify TnC", "Certify TnC check box should be selected.", "Certify TnC check box is selected.");
 	    waitForLoader();
 	    // Click On Representative offline Check box
     	   }catch(Exception e){
	 	    	strFailed = "Failed in clicking Certify Checkbox";
	 	    	report.reportFail(strDescription + getUrl, strExpected, strFailed);
	 			report.updateMainReport("comments", strFailed);
	 			report.updateMainReport("ErrorMessage", strFailed);
	 			logger.error(strFailed);
	 			captureErrorMsg(strFailed);
	 			throw new UserDefinedException(strFailed);
     	   }      	   
     	   
     	 //  }
        }
   	  if(get("Application").equalsIgnoreCase("C2G")){
 	    	pageScroll(c2gbtnVerbalAcceptance, objectValue, true);
     		clickUsingJavaScript(c2gbtnVerbalAcceptance, objectValue);
     	 report.reportPass("Click Verbal Acceptance", "Verbal Acceptance should be clicked", "Verbal Acceptance is clicked");
     		
     		waitForLoader();
     		pageScroll(getsignature, objectValue, true);
     		clickUsingJavaScript(getsignature, objectValue);
     	 report.reportPass("Click Get Signature", "Get Signature should be clicked", "Get Signature is clicked");
     		waitForLoader();
     		 switchToDefaultcontent();
      	    switchToFrame("IfProducts");
      	    waitForLoader();
      	    waitForLoader();
      	   if(isDisplayed(s1, objectValue, 1)){
      	    String s=driver.findElement(By.xpath("//div[@id='InfoPanel']/table[1]")).getText();
         	 System.out.println(s);
 	    
      	    
 	    report.reportPass("Verify Customer Details", "Display Customer Details", "Customer Details are: "+s);
      	   }
      	   if(isDisplayed(s2, objectValue, 1)){
         	 String s=driver.findElement(By.xpath("//div[@id='InfoPanel']/table[2]")).getText();
         	 System.out.println(s);
         	 report.reportPass("Verify Services & Monthly Charges", "Display Services & Monthly Charges", "Services & Monthly Charges: "+s);
      	   }
      	   if(isDisplayed(c2gsign1, objectValue, 1)){
        		clickUsingJavaScript(c2gsign1, objectValue);
      	   }
      	   if(isDisplayed(c2gsign2, objectValue, 1)){
     		clickUsingJavaScript(c2gsign2, objectValue);
      	   }
      	   if(isDisplayed(c2gsignascustomer, objectValue, 1)){
     		clickUsingJavaScript(c2gsignascustomer, objectValue);
      	   }
      	   if(isDisplayed(c2gVF2F, objectValue, 1)){
     		clickUsingJavaScript(c2gVF2F, objectValue);
      	   
     		Thread.sleep(1000);
      	   }
      	   if(isDisplayed(Signchkvoice, objectValue, 1)){
     		clickUsingJavaScript(Signchkvoice, strFailed);
     		Thread.sleep(1000);
      	   }
      	   if(isDisplayed(SignchkFree, objectValue, 1)){
      	clickUsingJavaScript(SignchkFree, strFailed);
      	Thread.sleep(1000);
      	   }
      	   
      	   
      	   if(isDisplayed(SignchkBdlAgree, objectValue, 1)){
      	clickUsingJavaScript(SignchkBdlAgree, strFailed);
      	Thread.sleep(1000);
      	   }
      	   
      	   if(isDisplayed(SignchkbdlServices, objectValue, 1)){
      	clickUsingJavaScript(SignchkbdlServices, strFailed);
      	Thread.sleep(1000);
      	   }     	   
      	   
      	   
      	   if(isDisplayed(c2gChkDBTOS, objectValue, 1)){
      	clickUsingJavaScript(c2gChkDBTOS, strFailed);
      	Thread.sleep(1000);
      	   }
      	   
      	   if(isDisplayed(c2gChkInternetStandalone, objectValue, 1)){
      	clickUsingJavaScript(c2gChkInternetStandalone, strFailed);
      	Thread.sleep(1000);
      	   }
      	   
      	   
      	   
      	   if(isDisplayed(SignchkAgree, objectValue, 1)){
      	clickUsingJavaScript(SignchkAgree, strFailed);
      	Thread.sleep(1000);
     		report.reportPass("Click VF2F", "VF2F should be clicked", "VF2F is clicked");
      	   }
    	   
     		pause();
     		if(isDisplayed(enterSignature, strLiveOrder, 1)){
     		mouseclick(enterSignature, submitORNosubmit);
     		}
     		
     		//To click on  Proceed Button
     	 if(isDisplayed(Btnprcd, objectValue, 1)){
     		clickUsingJavaScript(Btnprcd, strFailed);
     	 }
     		 }       	    	
       	    	//TO click on Preiew email
       	    if(isDisplayed(Btnsendpreview, objectValue, 30))
	    	{
	    		clickUsingJavaScript(Btnsendpreview, objectValue);
	    	}
       	    
       	 if(isDisplayed(FiosTVappEarlyAccess, objectValue, 60))
    	    {
    	    	clickUsingJavaScript(MTNYes, "");
    	    	waitForLoader();
    	    	waitForLoader();
    	    }
       	    if(!get("FlowType").equalsIgnoreCase("Install")){
       	 String ACHCancel = get("ACHCancel").trim();
         
         if(ACHCancel.equalsIgnoreCase("Resume"))
         {
	           if(isDisplayed(ACHCheckBox, objectValue, 30))
	     {
	            pageScroll(ACHCheckBox);
	     clickUsingJavaScript(ACHCheckBox, objectValue);
	     report.reportPass("Click ACH Order Check Box", "ACH Order Check Box should be Clicked", "Clicked ACH Order Check Box");
	     waitForLoader();
	     }
         }
    	  
       	    }
       	 if (get("PlaceOrder").equalsIgnoreCase("submit")) {
     		if (isDisplayed(validateSubmitOrder, "", 5)) {
                pageScroll(validateSubmitOrder, strLiveOrder, true);
     		    waitForElementDisplay(validateSubmitOrder, objectValue, 5);
     		    clickUsingJavaScript(validateSubmitOrder, objectValue);
     		    waitForLoader();
     		    waitForLoader();
     		    Thread.sleep(10000);
     		    report.reportPass("Validate submit order.", "Validate submit order button should be clicked.", "Clicked on validate submit order button.");
     		}

     		// Click On Release Button(Submit order)
     		if (isDisplayed(btnRelease, "", 5)) {
                pageScroll(btnRelease, strLiveOrder, true);
     		    waitForElementDisplay(btnRelease, objectValue, TimeOut);
     		    clickUsingJavaScript(btnRelease, objectValue);
     		    report.reportPass("submit order.", "submit order button should be clicked.", "Clicked on submit order button.");
     		}
     		Thread.sleep(15000);
     		// Page Sync
     		waitForLoader();
     		waitForLoader();
     		waitForLoader();
     		waitForLoader();
     		 
     		report.reportPass("submit order.", "submit order button should be clicked.", "Clicked on submit order button.");
     		

     		// Switch to default content
     		switchToDefaultcontent();
     		try{
     		waitForElementDisplay(closePopup, "", pageTimeoutInSeconds);
     		}
     		catch(Exception e){
     			
     		}
     		//waitForElement(pleaseWaitLoader, "style", "block");

     		// Click the Closing notes label
     		if(get("Application").equalsIgnoreCase("COA"))
     		{  
     			if(isDisplayed(lblClosingnotesTxt, "", 10)){
     				report.reportPass("check close notes is displayed", "Closing notes should display", "Closing Notes  is successfully displayed");
     			}else
     			{
     				report.reportFail("check close notes is displayed", "Closing notes should display", "Closing Notes  is not successfully displayed");	
     			}     			
     			
	     		if (!getAttribute(lblClosingnotes, objectValue, "class").contains("open")) {
	     		    pageScroll(lblClosingnotes, objectValue, true);
	     		    clickUsingJavaScript(lblClosingnotes, strFailed);
	     		}
	
	     		
	     		
	     		if(isDisplayed(txtClosingnotes, objectValue, 3)){
	     		
	         		report.reportPass("check order is submitted?", "Closing notes page appears", "As closing Notes page appears,Order is sumited");
	
	     			
	     		setText(txtClosingnotes, objectValue, notes);
	
	     		// Click outside on Label to update the value in text box
	     		//clickUsingJavaScript(lblClosingnotessmall, strFailed);
	
	     		report.reportPass("Enter notes", "Notes should be entered.", "Entered notes: " + notes);
	
	     		waitForLoader();
	     		waitForLoader();
	     		waitForLoader();
	     		}
     		}
     		// Click the save and close button
     		report.reportPass("Click on save and close button.", "Save and close button should be clicked", "Clicked on save and close button and the order has been placed successfully");
     		switchToDefaultcontent();
     	    clickUsingJavaScript(btnSaveAndClose, strFailed);
     		}

       	 
       	 //FCP Order submit validation update
       	if (get("PlaceOrder").equalsIgnoreCase("notsubmit")) {
  			 if (isDisplayed(validateSubmitOrder, "", 5)) {
  				 pageScroll(validateSubmitOrder);
  				 waitForElementDisplay(validateSubmitOrder, objectValue, 5);
  				 clickUsingJavaScript(validateSubmitOrder, objectValue);
  				 waitForLoader();
  				 waitForLoader();
  				 Thread.sleep(10000);
  				 report.reportPass("Validate submit order.", "Validate submit order button should be clicked.", "Clicked on validate submit order button.");     		    
  			 }
  			 if (isDisplayed(StatusMessage, "", 5)) {
  				 pageScroll(StatusMessage);
  				 waitForElementDisplay(StatusMessage, objectValue, 5);
  				 clickUsingJavaScript(validateSubmitOrder, objectValue);      			 
  				 Thread.sleep(10000);
  				 report.reportPass("Validate submit order Message.", "Validate submit order button should be clicked.", "Clicked on validate submit order button.");     		    
  			 }
  		 }
        //FCP Order submit validation update
         //vikram script start
       	 if(get("FlowType").equalsIgnoreCase("Install") && get("Application").equalsIgnoreCase("CoA") && get("SubFlowType").equalsIgnoreCase("SLIP")){
       		 if (get("PlaceOrder").equalsIgnoreCase("notsubmit")) {
       			 if (isDisplayed(validateSubmitOrder, "", 5)) {
       				 pageScroll(validateSubmitOrder);
       				 waitForElementDisplay(validateSubmitOrder, objectValue, 5);
       				 clickUsingJavaScript(validateSubmitOrder, objectValue);
       				 waitForLoader();
       				 waitForLoader();
       				 Thread.sleep(10000);
       				 report.reportPass("Validate submit order.", "Validate submit order button should be clicked.", "Clicked on validate submit order button.");     		    
       			 }
       			 if (isDisplayed(StatusMessage, "", 5)) {
       				 pageScroll(StatusMessage);
       				 waitForElementDisplay(StatusMessage, objectValue, 5);
       				 clickUsingJavaScript(validateSubmitOrder, objectValue);      			 
       				 Thread.sleep(10000);
       				 report.reportPass("Validate submit order Message.", "Validate submit order button should be clicked.", "Clicked on validate submit order button.");     		    
       			 }
       		 }
       	 }
       	 //vikram script end	    
     	       
        	    
             //Microservices submitorder validation********************************************************************************
        	    if(get("TSP_LecMSValidation").equalsIgnoreCase("Yes") && get("Application").equalsIgnoreCase("COA")){
        	    	
        	    
        	    verifySubmitOrderXml(); 
        	    
        	    }
       //Microservices submitorder validation********************************************************************************    
       	    

    	} catch (Exception exe) {
    		 if (!isUserDefinedException(exe)) {
    				report.reportFail(strDescription + getUrl, strExpected, strFailed);
    				 report.updateMainReport("comments", strFailed);
    				report.updateMainReport("ErrorMessage", strFailed);
    				captureErrorMsg("Failed in Internet section.");
    			    }

    			    throw exe;   	    
    	    
    	}

        }

    
    
    /**
     * Verifies submit order XML for TSP
     * 
     * @author Suman Pasupula
     * @throws Exception
     */
    public void verifySubmitOrderXml() throws Exception {

    	try {

    		  Thread.sleep(60000);
      	    
    	       	 //Microservices submitorder validation********************************************************************************
    	       	    	    
    	       	    	    String MONNumber = MON;
    	       	    	    String env = get("Environment");
    	       	    	    String Lines = get("TSP_PSAN");
    	       	    	    int linecount;
    	       	    		if(Lines.contains(",")){
    	       					String[] ln = Lines.split(",");
    	       					linecount = ln.length + 1;
    	       				}else{
    	       					linecount = 1;
    	       				}
    	       	    		
    	       	    		String serviceURL =  "http://itotaas.ebiz.verizon.com:8080/ValidationMicroservices-v1.0/gettspstatus";
    	       	        	String REST_SERVICE_URL = serviceURL;
    	       	    		ResteasyClient client = new ResteasyClientBuilder().build();
    	       	    		System.out.println(env);
    	       	    		System.out.println(MONNumber);
    	       	    		System.out.println(String.valueOf(linecount));
    	       	        	
    	       	        	
    	       	        	     String response = client
    	       	        	         .target(REST_SERVICE_URL)
    	       	        	         .queryParam("env", env)
    	       	        	         .queryParam("mon", MONNumber)
    	       	        	         .queryParam("lines", String.valueOf(linecount))
    	       	        	         .request(MediaType.APPLICATION_JSON).get(String.class);
    	       	        	     
    	       	        	     System.out.println(response);
    	       	        	  JSONObject list = new JSONObject(response);  
    	       	       	//JSONObject result = new JSONObject("http://itotaas.ebiz.verizon.com:8080/ValidationMicroservices-v1.0/gettspstatus?mon=MD40001182060&env=BAU&lines=2");
    	       	        	if(response != null && response.contains("SUCCESS")){
    	       	        	System.out.println("TSP validation status Pass");
    	       	        	report.reportPass("Validate TSP validation status", "TSP validation should have the expected values", "TSP validation response : " + list.getString("TSPValidationResponse"));
    	       	    		
    	       	        	}else {
    	       	        	//result.getString("TSPValidationStatus");
    	       	        		System.out.println("TSP validation status Fail");
    	       	        		report.reportFail("Validate TSP validation status", "TSP validation should have the expected values", "TSP validation response : " + list.getString("TSPValidationResponse"));
    	       	        	}
    	       	    	    
    	       	        	//Microservices submitorder validation********************************************************************************
    	       	   	       

    	} catch (Exception e) {
    	    if (!isUserDefinedException(e)) {
    		report.reportFail("Verify SubmitOrderXml", "SubmitOrderXml should be verified.", "SubmitOrderXml verification failed");
    		report.updateMainReport("ErrorMessage", "SubmitOrderXml verification failed");
    	    }

    	    throw e;
    	}

        }
    
    

    /**
     * Verifies summary tab is opened or not, if not clicks on it
     * 
     * @author Shiva Kumar Simharaju
     * @throws Exception
     */
    public void verifySummaryTab() throws Exception {

	try {

	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    String classValue = getAttribute(summaryTab, "", "class");
	    if (classValue != null && !classValue.contains("active")) {
		clickUsingJavaScript(summaryTab, "");
		waitForLoader();
		if (!isDisplayed(activeSummaryTab, "", 3)) {
		    report.reportFail("Verify Summary Tab.", "Summary tab should be displayed.", "Summary tab was not available");
		    report.updateMainReport("ErrorMessage", "Summary tab is not available");
		    report.updateMainReport("comments", "Summary tab was not available");
		    throw new UserDefinedException("Summary tab was not available");
		}
	    }
	} catch (Exception e) {
	    if (!isUserDefinedException(e)) {
		report.reportFail("Verify Summary Tab.", "Summary tab should be displayed.", "Summary tab is not available");
		report.updateMainReport("ErrorMessage", "Summary tab is not available");
	    }

	    throw e;
	}

    }

    // Prakash functions
    public void Net_Bundle_price() throws Exception {

	if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
	    String pageName = "Order Summary";

	    waitForLoader();
	    if (isDisplayed(txtOrderSummaryMonthlyCharges)) {
		report.reportPass("Net Bundle Price ", txtOrderSummaryMonthlyCharges.getText(), " is displayed");
	    } else {
		report.reportFail("Net Bundle Price", " ", "Net Bundle Price not displayed in summary page");
		report.updateMainReport("ErrorMessage", "Net Bundle Price not displayed in summary page");

	    }
	    // guiValidateVisibility(txtOrderSummaryMonthlyCharges, pageName,
	    // "Net bundle price", "Net Bundle price displayed in Summary page",
	    // "Net Bundle price not displayed in Summary page");
	}

    }

    public void Product_Offer_Description_Summarypage() throws Exception {

	if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
	    if (isDisplayed(txtOrderSummaryfirstproduct)) {
		report.reportPass("Product ", txtOrderSummaryfirstproduct.getText(), " is displayed");
	    } else {
		report.reportFail("No Product displayed", " ", "No Product displayed in summary page");
		report.updateMainReport("ErrorMessage", "No Product displayed in summary page");
	    }

	    try {

		if (isDisplayed(txtOrderSummarysecondproduct)) {
		    report.reportPass("Product ", txtOrderSummarysecondproduct.getText(), " is displayed");
		}
	    } catch (Exception e) {
		System.out.println("There is only one product");
	    }

	    try {

		if (isDisplayed(txtOrderSummarythirdproduct)) {
		    report.reportPass("Product ", txtOrderSummarythirdproduct.getText(), " is displayed");
		}
	    } catch (Exception e) {
		System.out.println("There are only two products");
	    }
	}
    }

    public void Product_Offer_Price_Summarypage() throws Exception {

	if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
     /*
	    try {
		clickUsingJavaScript(product_link1, objectValue);

	    } catch (Exception e) {
		System.out.println("Unable to click product link");
	    }

	    try {
		clickUsingJavaScript(product_link2, objectValue);

	    } catch (Exception e) {
		System.out.println("There is only one product");
	    }

	    try {
		clickUsingJavaScript(product_link3, objectValue);

	    } catch (Exception e) {
		System.out.println("There is only two product");
	    }
      */
	    if (isDisplayed(txtOrderSummaryfirstproductprice)) {
		report.reportPass("Product price of " + txtOrderSummaryfirstproduct.getText() + " ", txtOrderSummaryfirstproductprice.getText(), " is displayed");
	    } else {
		report.reportFail("No Product price displayed", " ", "No Product price displayed in summary page");
		report.updateMainReport("ErrorMessage", "No Product price displayed in summary page");

	    }

	    try {

		if (isDisplayed(txtOrderSummarysecondproductprice)) {
		    report.reportPass("Product Price of " + txtOrderSummarysecondproduct.getText() + " ", txtOrderSummarysecondproductprice.getText(), " is displayed");
		}
	    } catch (Exception e) {
		System.out.println("There is only one product");
	    }

	    try {

		if (isDisplayed(txtOrderSummarythirdproductprice)) {
		    report.reportPass("Product price of " + txtOrderSummarythirdproduct.getText() + " ", txtOrderSummarythirdproductprice.getText(), " is displayed");
		}
	    } catch (Exception e) {
		System.out.println("There are only two products");
	    }
	}

    }

    public void Compare_MonthlyCharges_RO_OPO() throws Exception {
    	try{

	if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
	    waitForLoader();
	   // String OPOSubTotal = (String) globalData.get("ROBundleprice");
	    String Summarypage_Total = txtOrderSummaryMonthlySubTotal.getText();
	    String strOrderSummaryMonthlyCharge = txtOrderSummaryMonthlyCharges.getText();
	   
	    String OPOMonthlyTotal= get("Monthly Estimated Charge in OPO");
	    System.out.println(OPOMonthlyTotal);
	    System.out.println(strOrderSummaryMonthlyCharge);
	    if ((OPOMonthlyTotal.equals(strOrderSummaryMonthlyCharge))) {
		report.reportPass("Estimated Monthly Charges in OPO and Summary Page should match", "Estimated Monthly Charges in OPO and Summary Page should be same", "Estimated Monthly Charges in OPO: " +OPOMonthlyTotal+ " is same as Estimated Monthly Charges in Summary Page: "+strOrderSummaryMonthlyCharge);
	    } else {
		report.reportFail("Estimated Monthly Charges in OPO and Summary Page should match", "Estimated Monthly Charges in OPO and Summary Page should be same", "Estimated Monthly Charges in OPO: " +OPOMonthlyTotal+ " is not matching with Estimated Monthly Charges in Summary Page: "+strOrderSummaryMonthlyCharge);
		report.updateMainReport("ErrorMessage", "Estimated Monthly Charges in OPO: " +OPOMonthlyTotal+ " is not matching with Estimated Monthly Charges in Summary Page: "+strOrderSummaryMonthlyCharge);
	    }
	}
    }
    	catch (Exception e) {
    		
    	    }
    }
    
    /**
     * @Description: summaryOfferValidation is used to validate offer summary section of review order
     * @author: Mithra G
     * @return:No Return Type
     * @exception: Throws
     *                 Exception
     * @ModifiedBy:
     * @ModifiedDate:
     * @Comments: Added for new FCP update
     */
public void summaryOfferValidation() throws Exception, UserDefinedException {

	System.out.println("->Summary Offer Validation");

	waitForLoader();
	try {
				
		// Router offer validation
		//Getting router offer validation from validation sheet
		if (get("$12-Router Discounts").equalsIgnoreCase("Yes")) {
			System.out.println(get("$12-Router Discounts"));
			//Getting router offer validation description and price from validation input sheet
			String routerOfferDescription = OfferDataExtraction.offerinfo.get("$12-Router Discounts")
					.get("Summary order Description").toString();

			String routerOfferPrice = OfferDataExtraction.offerinfo.get("$12-Router Discounts")
					.get("Summary order Offer amount").toString();
			System.out.println(routerOfferDescription);
			System.out.println(routerOfferPrice);
			//Validating the presence of router offer in review order page if we have non empty values from input sheet
			try
			{
			if (!routerOfferDescription.isEmpty() || routerOfferPrice.isEmpty()) {
				WebElement routerofferdesc = driver.findElement(
						By.xpath("//a[contains(text(),'"+routerOfferDescription+"')]/parent::td/following-sibling::td[contains(text(),'"+routerOfferPrice+"')]"));
				if (isDisplayed(routerofferdesc)) {
					pageScroll(routerofferdesc);
					System.out.println(routerofferdesc);
					report.reportPass("Router Offer validation",
							"Router offer " + routerOfferDescription + " shoule be present",
							"Router offer " + routerOfferDescription + " is present");
				} else
					report.reportFail("Router Offer validation",
							"Router offer " + routerOfferDescription + " shoule be present",
							"Router offer " + routerOfferDescription + " is not present");
			}
		}
		
		catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
			//throw e;
		}}
		// DVR offer validation
		// $12 DVR discounts
		//Getting DVR offer validation from validation sheet

		if (get("$12 DVR discounts").equalsIgnoreCase("Yes")) {
			System.out.println(get("$12 DVR discounts"));
			//Getting DVR offer validation description and price from validation input sheet
			String dvrOfferDescription = OfferDataExtraction.offerinfo.get("$12 DVR discounts")
					.get("Summary order Description").toString();

			String dvrOfferPrice = OfferDataExtraction.offerinfo.get("$12 DVR discounts")
					.get("Summary order Offer amount").toString();
			System.out.println(dvrOfferDescription);
			System.out.println(dvrOfferPrice);
			//Validating the presence of DVR offer in review order page if we have non empty values from input sheet
try{
			if (!dvrOfferDescription.isEmpty() || dvrOfferPrice.isEmpty()) {
				WebElement DVRofferdesc = driver.findElement(
						By.xpath("//a[contains(text(),'"+dvrOfferDescription+"')]/parent::td/following-sibling::td[contains(text(),'"+dvrOfferPrice+"')]"));
				if (isDisplayed(DVRofferdesc)) {
					pageScroll(DVRofferdesc);
					report.reportPass("DVR Offer validation",
							"DVR offer " + dvrOfferDescription + " shoule be present",
							"DVR offer " + dvrOfferDescription + " is present");
				} else
					report.reportFail("DVR Offer validation",
							"DVR offer " + dvrOfferDescription + " shoule be present",
							"DVR offer " + dvrOfferDescription + " is not present");
			}
		}

		
		catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
			//throw e;
		}}
		// STB offer validation
		//Getting STB offer validation from validation sheet

		if (get("$12 STB discounts").equalsIgnoreCase("Yes")) {
			System.out.println(get("$12 STB discounts"));
			//Getting STB offer validation description and price from validation input sheet
			String stbOfferDescription = OfferDataExtraction.offerinfo.get("$12 STB discounts")
					.get("Summary order Description").toString();

			String stbOfferPrice = OfferDataExtraction.offerinfo.get("$12 STB discounts")
					.get("Summary order Offer amount").toString();
			System.out.println(stbOfferDescription);
			System.out.println(stbOfferPrice);
			//Validating the presence of STB offer in review order page if we have non empty values from input sheet
try
{
			if (!stbOfferDescription.isEmpty() || stbOfferPrice.isEmpty()) {
				WebElement STBofferdesc = driver.findElement(
						By.xpath("//a[contains(text(),'"+stbOfferDescription+"')]/parent::td/following-sibling::td[contains(text(),'"+stbOfferPrice+"')]"));
				if (isDisplayed(STBofferdesc)) {
					pageScroll(STBofferdesc);
					report.reportPass("STB Offer validation",
							"STB offer " + stbOfferDescription + " shoule be present",
							"STB offer " + stbOfferDescription + " is present");
				} else
					report.reportFail("STB Offer validation",
							"STB offer " + stbOfferDescription + " shoule be present",
							"STB offer " + stbOfferDescription + " is not present");
			}
		}
		
		catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
			//throw e;
		}}
		// Auto pay offer validation
		//Getting Auto pay offer validation from validation sheet

		if (get("$10 Auto-Pay Discount").equalsIgnoreCase("Yes")) {
			System.out.println(get("$10 Auto-Pay Discount"));
			//Getting Auto - Pay offer validation description and price from validation input sheet

			String autoPayOfferDescription = OfferDataExtraction.offerinfo.get("$10 Auto-Pay Discount")
					.get("Summary order Description").toString();

			String autoPayOfferPrice = OfferDataExtraction.offerinfo.get("$10 Auto-Pay Discount")
					.get("Summary order Offer amount").toString();
			System.out.println(autoPayOfferDescription);
			System.out.println(autoPayOfferPrice);
			//Validating the presence of Auto pay offer in review order page if we have non empty values from input sheet
try{
	

			if (!autoPayOfferDescription.isEmpty() || autoPayOfferPrice.isEmpty()) {
				WebElement autoPayofferdesc = driver.findElement(
						By.xpath("//a[contains(text(),'"+autoPayOfferDescription+"')]/parent::td/following-sibling::td[contains(text(),'"+autoPayOfferPrice+"')]"));
				if (isDisplayed(autoPayofferdesc)) {
					pageScroll(autoPayofferdesc);
					report.reportPass("Auto-Pay Discount Offer validation",
							"Auto-Pay Discount offer " + autoPayOfferDescription + " shoule be present",
							"Auto-Pay Discount offer " + autoPayOfferDescription + " is present");
				} else
					report.reportFail("Auto-Pay Discount Offer validation",
							"Auto-Pay Discount offer " + autoPayOfferDescription + " shoule be present",
							"Auto-Pay Discount offer " + autoPayOfferDescription + " is not present");
			}
		}
catch (Exception e) {
	e.printStackTrace();
	System.out.println(e);
	//throw e;
}}
	}

	 catch (Exception e) {
		e.printStackTrace();
		System.out.println(e);
		//throw e;
	}

}

    public void SOC_Section() throws Exception {
    	
    	try{

	if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
	    String pageName = "Summary";

	    waitForLoader();
	    if (isDisplayed(SOC_section)) {
		report.reportPass("SOC Section", "SOC section displayed in Summary page", "SOC section displayed in Summary page not displayed");
	    } else {
		report.reportFail("SOC Section", "SOC section displayed in Summary page", "SOC section displayed in Summary page not displayed");
		report.updateMainReport("ErrorMessage", "SOC section displayed in Summary page not displayed");
	    }
	   // guiValidateVisibility(SOC_section, pageName, "SOC Section", "SOC section displayed in Summary page", "SOC section not displayed in Summary page ");
	}
    	}
    	catch (Exception e) {
    		
	    }
    }

    /**
     * Tries for N number of times to get card payment section.
     * 
     * @author Shiva Kumar Simharaju
     * @param noOfTrials
     * @return
     * @throws InterruptedException
     * 
     */
    public boolean tryForAutoPayVEPS(int noOfTrials) throws Exception {
    	System.out.println("In Veps Page");

    	String userID = get("Username");
    	String psw = get("Password");
    	byte[] decryptedPasswordBytes = Base64.getDecoder().decode(psw);
        String decryptedPassword = new String(decryptedPasswordBytes); 

    	for (int i = 1; i <= noOfTrials; i++) {
    	    waitForLoader();
    	    switchToDefaultcontent();
    	    switchToFrame("IfProducts");
    	    switchToFrame("OSPaymentGatewayPopupIFrame");

    	    if (isDisplayed(autoPayUserID, "", 1)) {
             pageScroll(autoPayUserID, decryptedPassword, true);
    		setText(autoPayUserID, "", userID);
    		setText(autoPayPWD, "", decryptedPassword);
    		report.reportPass("Enter Autopay Credentials", "User name and password credentials should be entered.", "Entered credentials");
    		clickUsingJavaScript(autoPaySignOn, "");
    		Thread.sleep(3000);
    		waitForPageToLoad(driver);
    	    }

    	    if (isDisplayed(autoPayAccordion, "", 1) || isDisplayed(deEnrollAutopay, "", 2)) {
    	    	report.reportPass("Should dispaly Auto pay Enrollment or Deenrollment", "Should dispaly Auto pay Enrollment or Deenrollment", "Auto pay Enrollment or Deenrollment is displayed");
    		return true;
    		
    	    } else {
    		switchToDefaultcontent();
    		switchToFrame("IfProducts");
    		clickUsingJavaScript(autoPayClose, "");

    		if (isDisplayed(autoPaymentYes, "", 1)) {
    		    clickUsingJavaScript(autoPaymentYes, "");
    		} else if (isDisplayed(manageAutopay, "", 1)) {
    			report.reportPass("Should dispaly manage Autopay", "Should dispaly manage Autopay", "Manage Autopay is displayed");
    		    clickUsingJavaScript(manageAutopay, "");
    		    
    		}

    	    }
    	}

    	switchToDefaultcontent();
    	switchToFrame("IfProducts");
    	switchToFrame("OSPaymentGatewayPopupIFrame");
    	if (isDisplayed(autoPayAccordion, "", 10) || isDisplayed(deEnrollAutopay, "", 5)) {
    	    return true;
    	} else {
    	    return false;
    	}
        }
    
  //For Setup/Modify Auto Pay By Mounika 16062017
    
    public boolean tryForModifyAutoPayVEPS(int noOfTrials) throws Exception {
try{
    	 String userID =get("Username");
	          String psw = get("Password");
    	
    	byte[] decryptedPasswordBytes = Base64.getDecoder().decode(psw);
        String decryptedPassword = new String(decryptedPasswordBytes); 

    	for (int i = 1; i <= noOfTrials; i++) {
    	    waitForLoader();
    	    switchToFrame("ifAutopay");

    	    if (isDisplayed(autoPayUserID, "", 1)) {

    		setText(autoPayUserID, "", userID);
    		setText(autoPayPWD, "", decryptedPassword);
    		report.reportPass("Enter Autopay Credentials", "User name and password credentials should be entered.", "Entered credentials");
    		clickUsingJavaScript(autoPaySignOn, "");
    		
    		Thread.sleep(3000);
    		waitForLoader();
    		waitForPageToLoad(driver);
    		driver.navigate().refresh();
    		waitForPageToLoad(driver);
    		waitForLoader();
    		Thread.sleep(5000);
    		
    	    }

    	    if (isDisplayed(autoPayAccordion, "", 1) || isDisplayed(deEnrollAutopay, "", 1)) {
    	    	 return true;
    	    }
    	}
    
    	return true;   
}
catch (Exception e) {
    if (!isUserDefinedException(e)) {
	report.reportFail("Verify Summary Tab.", "Summary tab should be displayed.", "Summary tab is not available");
	report.updateMainReport("ErrorMessage", "Summary tab is not available");
    }

    throw e;
}
        	 
    	}
        


    /**
     * Process the auto payment option for credit card or debit card.
     * 
     * @author Shiva Kumar Simharaju
     * @throws Exception
     */
    public void processAutoPay() throws Exception {
    	System.out.println("->Auto Pay Section");
    	String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
    	getUrl = ", URL Launched --> " + returnURL();
			
			String cardType = get("AutoPaymentCardType").trim();
			String cardNo = get("Card_Number").trim();
			String cardSecurityCode = get("Card_SecurityCode").trim();
			String cardExpiryMonth = get("CardExpiryMonth").trim();
			String cardExpiryYear = get("CardExpiryYear").trim();
			String firstName = get("PayerFirstName").trim();
			String lastName = get("PayerLastName").trim();
			String address = get("PayerAddress").trim();
			String city = get("PayerCity").trim();
			String state = get("PayerState").trim();
			String zipCode = get("PayerZipCode").trim();
			
			try {
				
			//waitForLoader();
				
				if(isDisplayed(BtnEnroll, zipCode, 6)){
				pageScroll(BtnEnroll, zipCode, true);
				report.reportPass("Display Enroll button", "Display Enroll button", "Enroll button is displayed");
				
				//driver.findElement(By.xpath("//input[@id='MainContent_btnModify']")).click();
				 clickUsingJavaScript(BtnEnroll, zipCode);
			
				/* JavascriptExecutor js = (JavascriptExecutor)driver;
				WebElement ele = driver.findElement(By.xpath("//input[@id='MainContent_btnModify']"));
				js.executeScript("arguments[0].click();", ele);*/
				
			
			waitForLoader();
			waitForLoader();
			waitForLoader();
			waitForLoader();
			waitForLoader();
				 
					Set<String> allWindows = driver.getWindowHandles();
					System.out.println(allWindows.size());
					for (String Child_Window : allWindows) {
						System.out.println(Child_Window);
					    
						break;
					    }
				//switchToWindowWithTitle("");	
				switchToWindowWithURL("https://phubsit3aws.ebiz.verizon.com/PaymentCloud/PHPmtInstrument/Views/PHPmtInstrument.aspx");
			 if(!cardType.toLowerCase().contains("bank".toLowerCase())){	
			 if(get("ChangeType").equalsIgnoreCase("AutoPay")){
				    switchToFrame("ifAutopay");
				    }
				    else{
				    	switchToDefaultcontent();
				    	
				    	switchToFrame("IfProducts");
				    	switchToFrame("OSPaymentGatewayPopupIFrame");
				    }
			 }
			
			 if(cardType.toLowerCase().contains("bank".toLowerCase())){	
					waitForLoader();
					if(get("ChangeType").equalsIgnoreCase("AutoPay")){
					    switchToFrame("ifAutopay");
					    }
					    else{
					    	switchToDefaultcontent();
					    	switchToFrame("IfProducts");
					    	switchToFrame("OSPaymentGatewayPopupIFrame");
					    }
					if(!isDisplayed(RoutingNum))
					{
					pageScroll(SavingsAccount);
					clickUsingJavaScript(SavingsAccount, "");
					waitForLoader();
					}
					  setText(RoutingNum, "", cardNo);
						report.reportPass("Enter Routing number", "Routing no should be entered.", "Entered Routing number " + cardNo);				
						setText(AccountNum, "", cardSecurityCode);
						report.reportPass("Enter Account Number", "Account Number should be entered.", "Entered Account Number " + cardSecurityCode);
						waitForLoader();
						if(get("ChangeType").equalsIgnoreCase("AutoPay")){
						    switchToFrame("ifAutopay");
						    }
						    else{
						    	switchToDefaultcontent();
						    	switchToFrame("IfProducts");
						    	switchToFrame("OSPaymentGatewayPopupIFrame");
						    }
					
						
						 clickUsingJavaScript(SubmitButton, "");
						 waitForLoader();
						 waitForLoader();
					
				}
				else{
					//Madhu
					switchToDefaultcontent();
			    	switchToFrame("IfProducts");
			    	switchToFrame("OSPaymentGatewayPopupIFrame");
					waitForElementDisplay(autoPayAccordion, "", 30);
					if (!autoPayAccordion.getAttribute("class").contains("open")) {
					  pageScroll(autoPayAccordion);
					  clickUsingJavaScript(autoPayAccordion, "");
					}
					
				
			/*	if (cardType.toLowerCase().contains("debit".toLowerCase())) {
				  clickUsingJavaScript(debitCardRdBtn, "");
				  report.reportPass("Select payment card type", "Debit card radio button should be selected.", "Selected debit card radio button.");
				} else {
				  clickUsingJavaScript(creditCardRdBtn, "");
				  report.reportPass("Select payment card type", "Credit card radio button should be selected.", "Selected credit card radio button.");
				}
                */
				waitForLoader();
				Thread.sleep(500);
				if(get("ChangeType").equalsIgnoreCase("AutoPay")){
				    switchToFrame("ifAutopay");
				    }
				    else{
				    	switchToDefaultcontent();
				    	switchToFrame("IfProducts");
				    	switchToFrame("OSPaymentGatewayPopupIFrame");
				    }
			

				setText(cardNumber, "", cardNo);
				report.reportPass("Enter card number", "Card no should be entered.", "Entered card number " + cardNo);
				
				setText(securityCode, "", cardSecurityCode);
				report.reportPass("Enter card card security code", "Security code should be entered.", "Entered security code no " + cardSecurityCode);
				
				WebElement webElement = driver.findElement(By.xpath("//input[@id='txtSecurityCode']"));
				  webElement.sendKeys(Keys.TAB);
				  webElement.sendKeys(Keys.ENTER);
				
				
						 WebElement e = driver.findElement(By.xpath("//select[@id='ddlCardExpMonth' or @id='ddlCardMonth']"));
						  e.sendKeys(Keys.ENTER);
						  e.sendKeys(Keys.TAB);
					selectDropDownUsingVisibleText(selectExpiryMonth, "", cardExpiryMonth);
					
					 WebElement e3 = driver.findElement(By.xpath("//select[@id='ddlCardExpYear' or @id='ddlCardYear']"));
					  e3.sendKeys(Keys.ENTER);
					  e3.sendKeys(Keys.TAB);
					selectDropDownUsingVisibleText(selectExpiryYear, "", cardExpiryYear);

				report.reportPass("Select card expiry year", "Card expiry year should be selected.", "Selected card expiry year " + cardExpiryYear);
				
				if (!firstName.isEmpty()) {
				  clearText(payerName, "");
				  setText(payerName, "", firstName);
				}
			/*	if (!lastName.isEmpty()) {
				  clearText(payerLastName, "");
				  setText(payerLastName, "", lastName);
				}*/
				if (!address.isEmpty()) {
				  clearText(payerAddress, "");
				  setText(payerAddress, "", address);
				}
				if (!city.isEmpty()) {
				  clearText(payerCity, "");
				  setText(payerCity, "", city);
				}
				if (!state.isEmpty()) {
				  clearText(payerState, "");
				  setText(payerState, "", state);
				}
				if (!zipCode.isEmpty()) {
					  clearText(payerZipCode, "");
					  setText(payerZipCode, "", zipCode);
					}
					report.reportPass("Enter payer details", "Payer details should be entered", "Entered payer details.");
					
					
					}
				 if(!get("ChangeType").equalsIgnoreCase("AutoPay")){
				 clickUsingJavaScript(autoPaySubmit, "");
					report.reportPass("Click on submit button.", "Auto pay submit button should be clicked.", "Clicked on submit button.");
					clickUsingJavaScript(autopayConfirmationClose, "");
					
					
					
					//waitForLoader();
					//waitForPageToLoad(driver);
					//Madhu
				
					
				
				switchToWindowWithTitle("Customer Sensitive Information CoA: New Install - Passlow Customer");	
				waitForLoader();
				waitForLoader();
				switchToDefaultcontent();
				if(get("ChangeType").equalsIgnoreCase("AutoPay")){
				    switchToFrame("ifAutopay");
				    }
				else
				{
				     switchToFrame("IfProducts");
				     switchToFrame("OSPaymentGatewayPopupIFrame");
				}
				report.reportPass("Click on Btnclose button.", "Auto pay Btnclose button should be clicked.", "Clicked on Btnclose button.");
				if(isDisplayed(Btnclose, zipCode, 1)){
				clickUsingJavaScript(Btnclose, zipCode);
				}
				 }
				 }
				 else{
					 report.reportPass("Click on Enroll for Autopay Enrollment", "Click on Enroll for Autopay Enrollment", "There is already a Autopay enrollment for this customer");
					 if(isDisplayed(Btnclose, zipCode, 1)){
							clickUsingJavaScript(Btnclose, zipCode);
							}
				 }
					}  catch (Exception exe) {

				    if (!isUserDefinedException(exe)) {
					report.reportFail("Auto Pay should be processed" + getUrl, "Auto Payment should be successfull", "Auto Pay is not successfull");
					report.updateMainReport("ErrorMessage", "Failed in Processing Auto Pay");
					report.updateMainReport("comments", "Failed in Processing Auto Pay");
					captureErrorMsg("Failed in Processing Auto Pay");
				    }
				    throw exe;
				}
				}

    /**
     * @Description: Validating the services and their prices, promo offers in Summary Page against OPO Page 
     * @Author: Sravya
     * @throws Exception
     * @Date: 03/27/17
     */

    public void MOOfferInSummary() throws Exception {
        
        double SummaryPageVoiceprice = 0.00;
        double SummaryPageInternetprice = 0.00;
        double SummaryPageTvprice = 0.00;
        double SummaryPageLecprice=0.00;
        
        double Summary_ExpectdMonthlyWoPromos = 0.00;
        double Summary_Expectdpromoffers = 0.00;
        double SummaryPageAdditionaldetails=0.00;
        double SummaryPageExpectedMonthlyWoTax=0.00;
        DecimalFormat df = new DecimalFormat("#,###,##0.00");
        String[] promos;
        HashMap<String, String> summary_map = new HashMap<String, String>();
        ArrayList<String> promoffers = new ArrayList<String>();
        String keyvalue = new String();
        String Keyproduct = new String();
        double opo_Internet = Double.parseDouble(get("ProductServicePageInternetPrice"));
        double opo_TV = Double.parseDouble(get("ProductServicePageTVPrice"));
        double opo_Voice = Double.parseDouble(get("ProductServicePageVoicePrice"));
        //double opo_promooffers = Double.parseDouble(get("str_agreement_offer_Price"));         
     double opo_BundlePrice = Double.parseDouble(get("ProductServicePageBundlePrice").replace("$", "").trim());
     opo_BundlePrice=Double.parseDouble(df.format(opo_BundlePrice));
     double opo_MonthlyCharge_WOTax = Double.parseDouble(get("ProductServicePageMonthlyCharge_WOTax").replace("$", "").trim());
     opo_MonthlyCharge_WOTax=Double.parseDouble(df.format(opo_MonthlyCharge_WOTax));
     double opo_MonthlyCharge_WithTax = Double.parseDouble(get("ProductServicePageMonthlyCharge").replace("$", "").trim());
     opo_MonthlyCharge_WithTax=Double.parseDouble(df.format(opo_MonthlyCharge_WithTax));
        // Switch Frame
        switchToDefaultcontent();
        switchToFrame("IfProducts");
        waitForLoader();
        System.out.println("OPO Prices" + opo_Internet + opo_TV + opo_Voice );
        try {
               clickUsingJavaScript(summaryExpand,objectValue);
               double SummaryPage_MC=Double.parseDouble(getTextFromElement(MonthlyAmount,objectValue).replace("$","").trim());
               double SummaryPage_MWP=Double.parseDouble(getTextFromElement(MonthlyWOPromos,objectValue).replace("$","").trim());
               System.out.println("From Summary Page MC"+SummaryPage_MC+"MWP"+SummaryPage_MWP);
               double Summary_BundlePrice = Double.parseDouble(getTextFromElement(summary_BundlePrice, objectValue).replace("$", "").trim());
            double summary_withouttax=Double.parseDouble(getTextFromElement(MonthlyWOTax, objectValue).replace("$","").trim());
            double summary_withtax;
               //Added tp get summaryTax for C2G as well
            if(get("Application").equalsIgnoreCase("C2G"))
         {
                     //shob
         String summary_WTax=getTextFromElement(summary_WTaxEle, objectValue);
         summary_withtax=Double.parseDouble(summary_WTax.replace("$", "").trim());
         }
         else {
         summary_withtax=Double.parseDouble(getTextFromElement(MonthlywithTax, objectValue).replace("$","").trim());
         System.out.println(summary_withtax);
     }


            
             
            for(WebElement ele:EquipDetails){
                   SummaryPageAdditionaldetails+=Double.parseDouble(ele.getText().replace("$","").trim());
            }
               // summary_map contains information on all services and their
               // corresponding rates
               for (int i = 2; i < 5; i++) {

                     List<WebElement> products_list = driver
                                   .findElements(By.xpath("//*[@id='BillSummaryGrid']/tbody[@class='togard'][" + i + "]/tr"));
                     int rows = driver
                                   .findElements(By.xpath("//*[@id='BillSummaryGrid']/tbody[@class='togard'][" + i + "]/tr"))
                                   .size();
                     for (int j = 1; j <= rows; j++) {
                            int columns = driver
                                          .findElements(By.xpath(
                                                        "//*[@id='BillSummaryGrid']/tbody[@class='togard'][" + i + "]/tr[" + j + "]/td"))
                                          .size();
                            List<WebElement> cols_data = driver.findElements(
                                          By.xpath("//*[@id='BillSummaryGrid']/tbody[@class='togard'][" + i + "]/tr[" + j + "]/td"));

                            for (WebElement ele : cols_data) {
                                   if (!ele.getText().isEmpty() && ele.getText().contains("$")
                                                 && !ele.getAttribute("id").contains("PMC"))
                                          keyvalue = ele.getText().replace("$", "").trim();
                                   else if (!ele.getText().isEmpty() && !ele.getText().contains("$"))
                                          Keyproduct = ele.getText().trim();
                            }
                            summary_map.put(Keyproduct, keyvalue);
                     }
               }
               // summary_promoffers contains promo offer details
               
               for (WebElement ele : PromoOffersList) {
                     // System.out.println(ele.getText());
                     promoffers.add(ele.getText().trim());
               }
               // Service Level Prices are captured from SummaryPage
               for (Map.Entry summary_ofr : summary_map.entrySet()) {
                     String val = (String) summary_ofr.getValue();
               //Changed the Value contentEquals method
                     if (!val.contentEquals("0.00") && !val.isEmpty()) {
                            String key = (String) summary_ofr.getKey();
                            
                            if (key.contains("Voice")) {
                                   SummaryPageVoiceprice += Double.parseDouble(val);
                            } else if (key.contains("Internet")) {
                                   SummaryPageInternetprice += Double.parseDouble(val);
                            } else if (key.contains("TV")) {
                                   SummaryPageTvprice += Double.parseDouble(val);

                            } else if (key.contains("Lec")) {
                   SummaryPageLecprice+=Double.parseDouble(val);
                            }
                     }
               }
               Summary_ExpectdMonthlyWoPromos = SummaryPageVoiceprice+SummaryPageInternetprice+SummaryPageTvprice;
               
               java.util.Iterator<String> it = promoffers.iterator();
               while (it.hasNext()) {
                     promos = it.next().split(" ");
                     Summary_Expectdpromoffers += Double.parseDouble(promos[0].replace("$","").trim());
               }
               
        String SummaryPageExpectdMonthlyAmount = df.format(Summary_ExpectdMonthlyWoPromos - Summary_Expectdpromoffers);
        SummaryPageExpectedMonthlyWoTax=Double.parseDouble(SummaryPageExpectdMonthlyAmount)+SummaryPageAdditionaldetails;
               
               // OPO Prices and Summary Prices are verified 
               if(opo_Internet==SummaryPageInternetprice)
               {
                     report.reportPass("SummaryPage Validations","Internet price in SummaryPage is evaluated against OPO Page","Internet Price in Summary Page and OPO Page are equal");
               }
               else{
                     report.reportFail("SummaryPage Validations","Internet price in SummaryPage is evaluated against OPO Page","Internet Price in Summary Page and OPO Page are not equal :Summary Page Internet Price"+SummaryPageInternetprice+" :OPO InternetPrice"+opo_Internet+"");
               }
               if(opo_TV==SummaryPageTvprice)
               {
                     report.reportPass("SummaryPage Validations","TV price in SummaryPage is evaluated against OPO Page","TV Price in Summary Page and OPO Page are equal");
               }
               else{
                     report.reportFail("SummaryPage Validations","TV price in SummaryPage is evaluated against OPO Page","TV Price in Summary Page and OPO Page are not equal :Summary PageTvPrice "+SummaryPageTvprice+" :OPO PageTVprice"+opo_TV+"");
               }
               if(opo_Voice==SummaryPageVoiceprice)
               {
                     report.reportPass("SummaryPage Validations","Voice price in SummaryPage is evaluated against OPO Page","Voice Price in Summary Page and OPO Page are equal");
               }
               else{
                     report.reportFail("SummaryPage Validations","Voice price in SummaryPage is evaluated against OPO Page","Voice Price in Summary Page and OPO Page are not equal :SummaryPageVoicePrice"+SummaryPageVoiceprice+": OPO PageVoicePrice"+opo_Voice+"");
               }
               if(opo_BundlePrice==Summary_BundlePrice)
               {
                     report.reportPass("SummaryPage Validations","Bundle Price price in SummaryPage is evaluated against OPO Page","Bundle Price in Summary Page and OPO Page are equal");
               }
               else{
                     report.reportFail("SummaryPage Validations","Bundle price in SummaryPage is evaluated against OPO Page","Bundle Price in Summary Page and OPO Page are not equal :SummaryPAgeBundlePrice"+Summary_BundlePrice+"  OPOPageBundlePrice:"+opo_BundlePrice+"");
               }
               if(opo_MonthlyCharge_WOTax==summary_withouttax)
               {
                     report.reportPass("SummaryPage Validations","MonthlyChargeWithouTax price in SummaryPage is evaluated against OPO Page","MonthlyChargeWithouTax Price in Summary Page and OPO Page are equal");
               }
               else{
                     report.reportFail("SummaryPage Validations","MonthlyChargeWithouTax price in SummaryPage is evaluated against OPO Page","MonthlyChargeWithouTax Price in Summary Page and OPO Page are not equal :SummaryPageWithOutTax"+summary_withouttax+"  OPOPageWithoutTax:"+opo_MonthlyCharge_WOTax+"");
               }
               if(opo_MonthlyCharge_WithTax==summary_withtax)
               {
                     report.reportPass("SummaryPage Validations","MonthlyChargeWithTax price in SummaryPage is evaluated against OPO Page","MonthlyChargeWithTax Price in Summary Page and OPO Page are equal");
               }
               else{
                     report.reportFail("SummaryPage Validations","MonthlyChargeWithTax price in SummaryPage is evaluated against OPO Page","MonthlyChargeWithTax Price in Summary Page and OPO Page are not equal :SummaryPageWithTax"+summary_withtax+"OPO PageWithTax:"+opo_MonthlyCharge_WithTax+"");
               }
               //Summary prices are verified based on calculation done on services that appear in summary
      if(Summary_ExpectdMonthlyWoPromos==SummaryPage_MWP)
      {
        report.reportPass("SummaryPage Validations","Verify Monthly WithoutPromos in summaryPage","Monthly WithoutPromos price appearing in the application is correct as per calculation made based on summary details");
      }
      else{
        report.reportFail("SummaryPage Validations","Verify Monthly WithoutPromos in summaryPage","Monthly WithoutPromos price appearing in the application is not correct as per calculation made based on summary details");
      }
      if(Double.parseDouble(SummaryPageExpectdMonthlyAmount)==SummaryPage_MC)
      {
        report.reportPass("SummaryPage Validations","Verify Monthly Amount in summaryPage","Monthly Amount price appearing in the application is correct as per calculation made based on summary details");
      }
      else{
        report.reportFail("SummaryPage Validations","Verify Monthly Amount in summaryPage","Monthly Amount price appearing in the application is not correct as per calculation made based on summary details");
      }
      if(SummaryPageExpectedMonthlyWoTax==summary_withouttax){
        report.reportPass("SummaryPage Validations","Verify Estimated Monthly Subtotal in summaryPage","Estimated Monthly Subtotal appearing in the application is correct as per calculation made based on summary details");
      }
      else{
        report.reportFail("SummaryPage Validations","Verify Estimated Monthly Subtotal in summaryPage","Estimated Monthly Subtotal appearing in the application is not correct as per calculation made based on summary details");
      }
      
      //By Shobana
      //To Expand ZeroRated products and Expand All section and take Screenshot 
      try
      {
      clickUsingJavaScript(zeroRated, objectValue);
      report.reportPass("SummaryPage Validations","Verify ZeroRated Products are displayed","Zero Rated Product option is clicked and able to see the products of zero rated");
      }
      catch(Exception e)
      {
      report.reportFail("SummaryPage Validations","Verify ZeroRated Products are displayed","Zero Rated Product option is clicked but not able to see the products of zero rated");
      }


      
        } catch (Exception exe) {
               exe.printStackTrace();
               report.reportFail("SummaryPage Validations" + returnURL(),"Verify SummaryPage Validations","Failed to execute Summary Page Validations");
               throw exe;
        }

}



    // For Autopay Window closing by Gopal 03/22/17

    protected void UIValidation_No_Autopay() throws Exception {

	if (get("GUI_Validations").equalsIgnoreCase("Yes")) {

	    String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	    strDescription = "Validating that Autopay window is closing or not";
	    strExpected = "Autopay window should be closed";
	    strActual = "Autopay window is closed";
	    strFailed = "Autopay window is not closed";
	    getUrl = ", URL Launched --> " + returnURL();

	    try {
		waitForLoader();
		switchToDefaultcontent();
		switchToFrame("IfProducts");

		if (isDisplayed(autoPayClose)) {
		    clickUsingJavaScript(autoPayClose, "");
		}

		waitForPageToLoad(driver);

		if (isSelected(autoPaymentNo)) {
		    report.reportPass("De Select AutoPay", "AutoPay should be selected as No.", "Auto pay is selected as No");
		    selectDropDownUsingVisibleText(autoPayDeclinedReason, "", "Other");
		}

	    } catch (Exception e) {

		e.printStackTrace();

	    }

	}
    }

    // For Close Account window By Gopal 03/22/17

    protected void UIValidation_Close_Account_window_Save_and_Close() throws Exception {

	if (get("GUI_Validations").equalsIgnoreCase("Yes")) {

	    String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	    strDescription = "Validating that Close Account Window is Diaplyed or not";
	    strExpected = "Close Account Window should be Diaplyed";
	    strActual = "Close Account Window is Diaplyed";
	    strFailed = "Close Account Window is not Diaplyed";
	    getUrl = ", URL Launched --> " + returnURL();

	    try {
		waitForPageToLoad(driver);

		if (isDisplayed(CloseAccount_Window)) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		} else {
		    report.reportFail(strDescription, strExpected, strFailed);
		}

		waitForLoader();

		if (isDisplayed(Duedate_userid)) {

		    report.reportPass("Validate wether Duedate and Userid is present or not", "Duedate and Userid should be present in close account window",
			    "Duedate and Userid is present in close account window");
		    getTextFromElement(Duedate_userid, "");
		} else {
		    report.reportFail("Validate wether Duedate and Userid is present or not", "Duedate and Userid should be present in close account window",
			    "Duedate and Userid is not present in close account window");
		}

	    } catch (Exception e) {

		e.printStackTrace();

	    }

	}
    }
    
    
    //For Setup/Modify Auto Pay By Mounika 16062017
    protected void modifyAutoPay() throws Exception {

	
	waitForLoader();
	switchToWindowWithURL("AutopayFrame");

	boolean isPayementDisplayed = tryForModifyAutoPayVEPS(4);
	if (!isPayementDisplayed) {
	    report.reportFail("Validate veps page.", "Veps page should be displayed for autopayment", "Veps page was not displaed for autopayment.");
	    throw new UserDefinedException("Error: Payment section was not displayed..Couldn't able to complete auto payment");
	}
	
	if(get("AutoPayment").equalsIgnoreCase("Yes")){
	processAutoPay();
	}

    
	else if (get("AutoPayment").toLowerCase().contains("deenrollment")) {

//	clickUsingJavaScript(manageAutopay, "");
//	report.reportPass("Click on Manage autopay..", "Managae autopay should be clicked.", "Clicked on manage autopay.");
//	waitForLoader();
	boolean isVepsDisplayed = tryForModifyAutoPayVEPS(4);
	if (isVepsDisplayed) {
		 switchToFrame("ifAutopay");
	    pageScroll(deEnrollAutopay2, "", true);
	    clickUsingJavaScript(deEnrollAutopay2, "");
	    waitForLoader();
	    waitForLoader();
	    Thread.sleep(2000);
	    report.reportPass("Click on deenroll button.", "Deenroll button should be clicked.", "Clicked on deenroll button.");
	    switchToFrame("ifAutopay");
	    if (get("PlaceAutopayDeEnroll").equalsIgnoreCase("Yes")) {

		clickUsingJavaScript(deEnrollAutopayConfirmYes, "");
		report.reportPass("Deenroll autopay", "Yes button should be clicked on autopay deenrollment", "Clicked on Yes button of Deenrollment confirmation");
	    } else {
		clickUsingJavaScript(deEnrollAutopayConfirmNo, "");
		report.reportPass("Deenroll autopay", "No button should be clicked on autopay deenrollment", "Clicked on No button of Deenrollment confirmation");

		
		pageScroll(Btnclose, "", true);
		clickUsingJavaScript(Btnclose, "");
	    }

	} else {
	    report.reportFail("Validate veps page.", "Veps page should be displayed for auto pay deenrollment", "Veps page was not displaed for autopay deenrollment.");
	    throw new UserDefinedException("Error: Payment de enroll section was not displayed..Couldn't able to complete auto pay deenrollment");
	}

    }
	

    
    
    
    
    
    }
    
    /**
     * @Created by: Naresh
     * @Date Created : 06 March , 2018
     * @throws Exception
     */
     public void checkETF() throws Exception{
 		if( get("Contract").equalsIgnoreCase("M2M") && get("FlowType").equalsIgnoreCase("Change") || get("Contract").equalsIgnoreCase("M2M") && get("FlowType").equalsIgnoreCase("Move") || get("Contract").equalsIgnoreCase("M2M") && get("FlowType").equalsIgnoreCase("disconnect") || get("Contract").equalsIgnoreCase("M2M") && get("FlowType").equalsIgnoreCase("disconnect")){
 		
     		pageScroll(etfText);
     		String oneTimeCharges_ETF=etfText.getText();
     		if(oneTimeCharges_ETF.equals("24 Month Bundle Early Termination Fee")){
         	    report.reportPass("Check whether ETF content is displayed or not for term break", "ETF content must be displayed", "ETF content is displayed as "+oneTimeCharges_ETF);

     		}
     		else{
     			report.reportFail("Check whether ETF content is displayed or not for term break", "ETF content must be displayed", "ETF content is not displayed");
     		}
     		
     		
     	}
     }
     
     public void verifyRSNBC() throws Exception{
     	
     	/**
 	     * @Description: if TV plan is selected ,verify RSN & BC charges
 	     * @author: Naresh,Madipelly
 	     * @return:No Return Type
 	     * @exception: No exception
 	     
 	     */
 		if(!get("TvPlan").isEmpty() && get("TvPlan")!="Local"){
 			try
 			{
 				pageScroll(estimatedMonthlyBill);
 				waitForLoader();
 				String regionalSportsFee=getTextFromElement(RegionalSportsNetworkFees, "");
 				System.out.println("========================= Summary Page : Regional SPorts Fees is ::" +regionalSportsFee +"===========================");
 				String fiosTVBroadCastFee=getTextFromElement(FiosBroadCastFees, "");
 				System.out.println("========================= Summary Page : Fios TV BroadCast Fees is ::" +fiosTVBroadCastFee +"===========================");
 				report.reportPass("Summary Page Regional Network Fees", regionalSportsFee, regionalSportsFee);
 			}
 			catch (Exception e) {
 				    String strFailed = "Failed in getting RSN and BC fees from Summary page";
 				    logger.error(strFailed, e);
 				    report.reportFail("Get RSN and BC fees from summary page", "Getting RSN and BC values", strFailed);
 				    report.updateMainReport("comments", strFailed);
 				    report.updateMainReport("ErrorMessage", strFailed);
 				    captureErrorMsg(strFailed);
 				    throw new UserDefinedException(strFailed);
 				}

 			try{
 				
 			switchToDefaultcontent();
 			 
 			//click on Mon display to view detials
 			clickUsingJavaScript(MONDisplay,objectValue);
 			waitForLoader();
 			pageScroll(ViewDetailsBCFee);
 			//String ViewDetailsRSNFEE=getTextFromElement(getViewDetailsRSNAddedValue, "");
 			String ViewDetailsRSNFEE=getViewDetailsRSNAddedValue.getText();
 			String ViewDetailsBCFEE=getViewDetailsBCAddedValue.getText();
 			//String ViewDetailsBCFEE=getTextFromElement(getViewDetailsBCAddedValue, "");
 			System.out.println("=======View Details : RSN Fee " +ViewDetailsRSNFEE);
 			System.out.println("=======View Details : BC Fee " +ViewDetailsBCFEE);
 			report.reportPass("View Details Page Regional Network Fees", ViewDetailsRSNFEE, ViewDetailsRSNFEE);// change expected and actual values
 		
 			waitForLoader();
 			clickUsingJavaScript(closeViewDetailsPopup,objectValue);
 			}
 			catch (Exception e) {
 			    String strFailed = "Failed in getting RSN and BC fees from View Details";
 			    logger.error(strFailed, e);
 			    report.reportFail("Get RSN and BC fees from View Details", "Getting RSN and BC values", strFailed);
 			    report.updateMainReport("comments", strFailed);
 			    report.updateMainReport("ErrorMessage", strFailed);
 			    captureErrorMsg(strFailed);
 			    throw new UserDefinedException(strFailed);
 			}
 		}
     	
     }
     
     //Naresh
     public void verifyTechSure() throws Exception{
      	
      	/**
     	     * @Description: TechSure plus and Premium Verification
     	     * @author: Naresh,Madipelly
     	     * @return:No Return Type
     	     * @exception: No exception
     	   */
     		if(!get("VASProduct").isEmpty() && (!get("FlowType").equalsIgnoreCase("Install"))){
     			try
     			{
     				
     				pageScroll(BBEProducts, objectValue, true);
     				
     				
     				List<WebElement> BBEListRemovedProducts = driver.findElements(By.xpath("//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_Pnl2']//tbody//tr//td[contains(text(),'Remove')]/following-sibling::td/a[contains(@href,'Vasip')]"));			    	 		  			      	 				  
 	 				  for (int i=0;i<BBEListRemovedProducts.size();i++)
 	 				  {
 	 					 
 	 					
 	 					 String x=BBEListRemovedProducts.get(i).getText();
 	 					
 	 					String[] listChannels = get("VASProduct").split(";");
 	 					
 	 					
 	 					for (int y=0;y<listChannels.length;y++) {
 	 					    
 	 						 if(listChannels[y].toUpperCase().contains(":X") ){
 	 							 
 	 							String BBEProduct = listChannels[y].split(":X")[0];
 	 							
 	 							
 	 							if(x.contains(BBEProduct)){
 	 								
 	 							
 	 								System.out.println("Removed Products are: "+listChannels[y]);
 	 								report.reportPass("Display Removed Products", "Display Removed Products", "Removed Products are: "+listChannels[y]);
 	 								
 	 						 }
 	 						 
 	 					 }
 	 					}
 	 					
 	 					
 	 					
 	 					
 	 				  }  
 	 				 List<WebElement> BBEListNewProducts = driver.findElements(By.xpath("//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_Pnl2']//tbody//tr//td[contains(text(),'NEW')]/following-sibling::td/a[contains(@href,'Vasip')]"));			    	 		  			      	 				  
 	 				  for (int i=0;i<BBEListNewProducts.size();i++)
 	 				  {
 	 					  
 	 					  String x=BBEListNewProducts.get(i).getText();
 	 					 
 	 					 String[] listChannels = get("VASProduct").split(";");	 
 	 					 
 	 					for (int y = 0; y < listChannels.length; y++) {
 	 						
 	 						 if(!listChannels[y].toUpperCase().contains(":X") ){
 	 							 
 	 							
 	 							
 	 							if(x.equalsIgnoreCase(listChannels[y])){
 	 							
 	 								System.out.println("Newly added Products  are: "+listChannels[y]);
 	 								report.reportPass("Newly added Products", "Newly added Products", "Newly added Products are: "+listChannels[y]);
 	 						 }
 	 						 
 	 					 }
 	 					}
 	 				  }
 	 				   
 	 				
 	 				  
 	 				  /*
     				pageScroll(scrollTillTechSure);
     				waitForLoader();
     				
     				String VasProduct=getTextFromElement(scrollTillTechSure, "");
     				if(VasProduct.equalsIgnoreCase(get("VAS_TechSure_Product"))){
     					report.reportPass("Vas Product details found in summary page", VasProduct, get("VASProduct"));
     				}else{
     					report.reportFail("Vas Product details not found in summary page", VasProduct, get("VASProduct"));
     				}
     				
     				if(get("TechSure_LifeLock_Adult").equalsIgnoreCase("Yes")){
     						
     					String lifelockAdultText=getTextFromElement(lifelockAdult, "");
     					if(lifelockAdultText.contains("LifeLock Select Adult")){
     						report.reportPass("Lifelock select Adult", "Lifelock select Adult", lifelockAdultText);
     					}else{
     						report.reportFail("Lifelock select Adult is not found", "Lifelock select Adult", lifelockAdultText);
     					}
     				}
     				
     				if(get("TechSure_LifeLock_Junior").equalsIgnoreCase("Yes")){
     					
     					String lifelockJuniorText=getTextFromElement(lifelockJunior, "");
     					if(lifelockJuniorText.contains("LifeLock Select Junior")){
     						report.reportPass("Lifelock select Junior", "Lifelock select Junior", lifelockJuniorText);
     					}else{
     						report.reportFail("Lifelock select Junior is not found", "Lifelock select Junior", lifelockJuniorText);
     					}
     				}
     				*/
     				
     				
     			}
     			catch (Exception e) {
     				    String strFailed = "Failed in getting Vasproduct details from Summary page";
     				    logger.error(strFailed, e);
     				    report.reportFail("Get Vasproduct details from summary page", "Getting vasproduct details in summary page", strFailed);
     				    report.updateMainReport("comments", strFailed);
     				    report.updateMainReport("ErrorMessage", strFailed);
     				    captureErrorMsg(strFailed);
     				    throw new UserDefinedException(strFailed);
     				}

     			if(get("FlowType").equalsIgnoreCase("Install")){
     			try{
     			switchToDefaultcontent();
     			 
     			//click on Mon display to view detials
     			clickUsingJavaScript(MONDisplay,objectValue);
     			waitForLoader();
     			pageScroll(ViewTechSureFees, objectValue, true);
     			report.reportPass("Techsure Product details in view details page", "Techsure products", "Techsure products");

     			waitForLoader();
     			if(get("TechSure_LifeLock_Adult").equalsIgnoreCase("Yes")){
     				if(isDisplayed(getTechsureAdult))	{
     					report.reportPass("Techsure Product Adult details in view details page", "Techsure Select Adult", "Techsure Select Adult");
     				}
     			}
     			
     			if(get("TechSure_LifeLock_Junior").equalsIgnoreCase("Yes")){
     				if(isDisplayed(getTechsureJunior))	{
     					report.reportPass("Techsure Product Junior details in view details page", "Techsure Select Junior", "Techsure Select Junior");
     				}
     			}
     			}
     			catch (Exception e) {
     			    String strFailed = "Failed in getting Techsure fees from View Details";
     			    logger.error(strFailed, e);
     			    report.reportFail("Get Techsure fees from View Details", "Getting Techsure values", strFailed);
     			    report.updateMainReport("comments", strFailed);
     			    report.updateMainReport("ErrorMessage", strFailed);
     			    captureErrorMsg(strFailed);
     			    throw new UserDefinedException(strFailed);
     			}
     			
     			}
     		}
      	
      }
     
     /**
      * Process the auto payment option for credit card or debit card.
      * 
      * @author Shiva Kumar Simharaju
      * @throws Exception
      */
     public void APay() throws Exception {
     	System.out.println("->Auto Pay Section");
     	String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
     	getUrl = ", URL Launched --> " + returnURL();
 			
 			String cardType = get("AutoPaymentCardType").trim();
 			String cardNo = get("Card_Number").trim();
 			String cardSecurityCode = get("Card_SecurityCode").trim();
 			String cardExpiryMonth = get("CardExpiryMonth").trim();
 			String cardExpiryYear = get("CardExpiryYear").trim();
 			String firstName = get("PayerFirstName").trim();
 			String lastName = get("PayerLastName").trim();
 			String address = get("PayerAddress").trim();
 			String city = get("PayerCity").trim();
 			String state = get("PayerState").trim();
 			String zipCode = get("PayerZipCode").trim();
 			
 			try {
 				if(isDisplayed(BtnEnroll, zipCode, 6)){
 			//waitForLoader();
 				pageScroll(BtnEnroll, zipCode, true);
				report.reportPass("Display Enroll button", "Display Enroll button", "Enroll button is displayed");
				
 				
 				//driver.findElement(By.xpath("//input[@id='MainContent_btnModify']")).click();
 				 clickUsingJavaScript(BtnEnroll, zipCode);
 			
 				/* JavascriptExecutor js = (JavascriptExecutor)driver;
 				WebElement ele = driver.findElement(By.xpath("//input[@id='MainContent_btnModify']"));
 				js.executeScript("arguments[0].click();", ele);*/
 				
 			
 			waitForLoader();
 			waitForLoader();
 			waitForLoader();
 			waitForLoader();
 			waitForLoader();
 				 
 					Set<String> allWindows = driver.getWindowHandles();
 					System.out.println(allWindows.size());
 					for (String Child_Window : allWindows) {
 						System.out.println(Child_Window);
 					    
 						break;
 					    }
 				//switchToWindowWithTitle("");	
 				switchToWindowWithURL("https://phubsit3aws.ebiz.verizon.com/PaymentCloud/PHPmtInstrument/Views/PHPmtInstrument.aspx");
 				 if(get("ChangeType").equalsIgnoreCase("AutoPay")){
  				    switchToFrame("ifAutopay");
  				    }
  				    else{
  				    	switchToDefaultcontent();
  				    	
  				    	switchToFrame("IfProducts");
  				    	switchToFrame("OSPaymentGatewayPopupIFrame");
  				    }
  			 
  			
  			switchToDefaultcontent();
 	    	switchToFrame("IfProducts");
 	    	switchToFrame("OSPaymentGatewayPopupIFrame");
 			waitForElementDisplay(autoPayAccordion, "", 30);
 			if (!autoPayAccordion.getAttribute("class").contains("open")) {
 			  pageScroll(autoPayAccordion);
 			  clickUsingJavaScript(autoPayAccordion, "");
 			}
  				
  				
 				 // clickUsingJavaScript(debitCardRdBtn, "");
 				  report.reportPass("Select payment card type", "Debit card radio button should be selected.", "Selected debit card radio button.");
 				
 				waitForLoader();
 				Thread.sleep(500);
 				if(get("ChangeType").equalsIgnoreCase("AutoPay")){
 				    switchToFrame("ifAutopay");
 				    }
 				    else{
 				    	switchToDefaultcontent();
 				    	switchToFrame("IfProducts");
 				    	switchToFrame("OSPaymentGatewayPopupIFrame");
 				    }
 			

 				setText(cardNumber, "", "5111005111051128");
 				report.reportPass("Enter card number", "Card no should be entered.", "Entered card number " + cardNo);
 				
 				setText(securityCode, "", "123");
 				report.reportPass("Enter card card security code", "Security code should be entered.", "Entered security code no " + cardSecurityCode);
 				
 				WebElement webElement = driver.findElement(By.xpath("//input[@id='txtSecurityCode']"));
 				  webElement.sendKeys(Keys.TAB);
 				  webElement.sendKeys(Keys.ENTER);
 				
 				
 						 WebElement e = driver.findElement(By.xpath("//select[@id='ddlCardExpMonth' or @id='ddlCardMonth']"));
 						  e.sendKeys(Keys.ENTER);
 						  e.sendKeys(Keys.TAB);
 					selectDropDownUsingVisibleText(selectExpiryMonth, "", "03");
 					
 					 WebElement e3 = driver.findElement(By.xpath("//select[@id='ddlCardExpYear' or @id='ddlCardYear']"));
 					  e3.sendKeys(Keys.ENTER);
 					  e3.sendKeys(Keys.TAB);
 					selectDropDownUsingVisibleText(selectExpiryYear, "", "2020");

 				report.reportPass("Select card expiry year", "Card expiry year should be selected.", "Selected card expiry year " + cardExpiryYear);
 				
 				if (!firstName.isEmpty()) {
 				  clearText(payerName, "");
 				  setText(payerName, "", firstName);
 				}
 			/*	if (!lastName.isEmpty()) {
 				  clearText(payerLastName, "");
 				  setText(payerLastName, "", lastName);
 				}*/
 				if (!address.isEmpty()) {
 				  clearText(payerAddress, "");
 				  setText(payerAddress, "", address);
 				}
 				if (!city.isEmpty()) {
 				  clearText(payerCity, "");
 				  setText(payerCity, "", city);
 				}
 				if (!state.isEmpty()) {
 				  clearText(payerState, "");
 				  setText(payerState, "", state);
 				}
 				if (!zipCode.isEmpty()) {
 				  clearText(payerZipCode, "");
 				  setText(payerZipCode, "", zipCode);
 				}
 				report.reportPass("Enter payer details", "Payer details should be entered", "Entered payer details.");
 				
 				clickUsingJavaScript(autoPaySubmit, "");
 				
 				
 				report.reportPass("Click on submit button.", "Auto pay submit button should be clicked.", "Clicked on submit button.");
 				clickUsingJavaScript(autopayConfirmationClose, "");
 				
 				
 				
 				//waitForLoader();
 				//waitForPageToLoad(driver);
 				//Madhu
 				
 			
 			switchToWindowWithTitle("Customer Sensitive Information CoA: New Install - Passlow Customer");	
 			waitForLoader();
 			waitForLoader();
 			switchToDefaultcontent();
 			if(get("ChangeType").equalsIgnoreCase("AutoPay")){
 			    switchToFrame("ifAutopay");
 			    }
 			else
 			{
 			     switchToFrame("IfProducts");
 			     switchToFrame("OSPaymentGatewayPopupIFrame");
 			}
 			report.reportPass("Click on Btnclose button.", "Auto pay Btnclose button should be clicked.", "Clicked on Btnclose button.");
 			if(isDisplayed(Btnclose, zipCode, 1)){
 			clickUsingJavaScript(Btnclose, zipCode);
 			}
 				}
				 else{
					 report.reportPass("Click on Enroll for Autopay Enrollment", "Click on Enroll for Autopay Enrollment", "There is already a Autopay enrollment for this customer");
					 if(isDisplayed(Btnclose, zipCode, 1)){
							clickUsingJavaScript(Btnclose, zipCode);
							}
				 }
 				
 				} catch (Exception exe) {

 				    if (!isUserDefinedException(exe)) {
 					report.reportFail("Auto Pay should be processed" + getUrl, "Auto Payment should be successfull", "Auto Pay is not successfull");
 					report.updateMainReport("ErrorMessage", "Failed in Processing Auto Pay");
 					report.updateMainReport("comments", "Failed in Processing Auto Pay");
 					captureErrorMsg("Failed in Processing Auto Pay");
 				    }
 				    throw exe;
 				}
 				}
     
     /**
      * Verifies IWMP is added or not in summary page
      * 
      * @author Naresh,Madipelly
      * @throws Exception
      */
     public void verfiyIWMP()throws Exception{

     	if(get("VASProduct").equals("Inside Wire Maintenance"))
     	{    	
     		try {
     		switchToDefaultcontent();
     	    switchToFrame("IfProducts");
     	    
     		if (isDisplayed(IWMPInSummaryPage, "", 3)) {
     			report.reportPass("Verify Inside Wire Maintenance in Summary Tab", "IWMP should display in Summary Tab", "IWMP displayed in summary tab");
     		}else{
     			report.reportFail("Verify Inside Wire Maintenance in Summary Tab", "IWMP should display in Summary Tab", "IWMP is not displayed in summary tab");
     		}
     	    
 	    	} catch (Exception e) {
 	    	    if (!isUserDefinedException(e)) {
 	    		report.reportFail("Verify IWMP in Summary Tab.", "Summary tab should be displayed.", "Summary tab is not available");
 	    		}
 	    	    throw e;
 	    	}
     	}
    }
     
     
     //////////Vignesh//////////////////////////
     
     public void ValidatinSummary() throws Exception {

 		if (!get("NoOfTV_Price").isEmpty()) {

 			String newTVcount = get("NoOfTv").trim();
 			String New_NoOfTV_Price = "";
 			String PreExistingTVcount = get("PreExistingTVCount").trim();
 			WebElement TVdetail = null;
 			String desc_in_summary = "";
 			if (Integer.valueOf(newTVcount) == 1) {

 				New_NoOfTV_Price = "$12";
 			} else if (Integer.valueOf(newTVcount) == 2) {

 				New_NoOfTV_Price = "$24";
 			} else if (Integer.valueOf(newTVcount) == 3) {

 				New_NoOfTV_Price = "$30";
 			} else if (Integer.valueOf(newTVcount) == 4) {

 				New_NoOfTV_Price = "$36";
 			} else if (Integer.valueOf(newTVcount) >= 5) {

 				New_NoOfTV_Price = "$42";
 			}

 			if (!PreExistingTVcount.isEmpty()) {
 				

 				if (PreExistingTVcount.equalsIgnoreCase(newTVcount)) {
 					
 					if (!get("NoOfTV_Price").trim().contains("New")) {
 						desc_in_summary = "Rent: " + PreExistingTVcount
 								+ " Set-Top Box";
 						try {
 							TVdetail = driver
 									.findElement(By
 											.xpath("//td[contains(text(),'Existing')]/following-sibling::td[1][contains(.,'Set-Top Box') and contains(.,'"
 													+ PreExistingTVcount
 													+ "')]"));
 							if (TVdetail.isDisplayed()) {

 								report.reportPass(
 										"Verify Summary page",
 										desc_in_summary																							
 												+ " should be displayed in Summary page",
 										desc_in_summary
 												+ " is displayed in review page");
 							} else {
 								report.reportFail(
 										"Verify Summary page",
 										desc_in_summary
 												+ " should be displayed in Summary page",
 										desc_in_summary
 												+ " is not displayed in review page");
 							}
 						} catch (Exception ex) {
 							report.reportFail(
 									"Verify Summary page",
 									desc_in_summary
 											+ " should be displayed in Summary page",
 									desc_in_summary
 											+ " is not displayed in review page");
 							throw new UserDefinedException(desc_in_summary
 									+ " is not displayed in review page");

 						}
 					} else {
 						desc_in_summary = "Rent: " + PreExistingTVcount
 								+ " Set-Top Box";
 						try {
 							TVdetail = driver
 									.findElement(By
 											.xpath("//td[contains(text(),'Existing')]/following-sibling::td[1][contains(.,'Set-Top Box') and contains(.,'"
 													+ PreExistingTVcount
 													+ "')]/following-sibling::td[1][contains(.,'"
 													+ New_NoOfTV_Price + "')]"));
 							if (TVdetail.isDisplayed()) {

 								report.reportPass(
 										"Verify Summary page",
 										desc_in_summary
 												+ " "
 												+ New_NoOfTV_Price
 												+ " should be displayed in Summary page",
 										desc_in_summary
 												+ " "
 												+ New_NoOfTV_Price
 												+ " is displayed in review page");
 							} else {
 								report.reportFail(
 										"Verify Summary page",
 										desc_in_summary
 												+ " "
 												+ New_NoOfTV_Price
 												+ " should be displayed in Summary page",
 										desc_in_summary
 												+ " "
 												+ New_NoOfTV_Price
 												+ " is not displayed in review page");
 							}
 						} catch (Exception ex) {
 							report.reportFail(
 									"Verify Summary page",
 									desc_in_summary
 											+ " "
 											+ New_NoOfTV_Price
 											+ " should be displayed in Summary page",
 									desc_in_summary
 											+ " "
 											+ New_NoOfTV_Price
 											+ " is not displayed in review page");
 							throw new UserDefinedException(desc_in_summary
 									+ " " + New_NoOfTV_Price
 									+ " is not displayed in review page");

 						}

 					}
 				}

 			}

 			else {
 				desc_in_summary = "Rent: " + newTVcount + " Set-Top Boxes";
 				try {
 					TVdetail = driver
 							.findElement(By
 									.xpath("//td[contains(text(),'New')]/following-sibling::td[1][contains(.,'Set-Top Box') and contains(.,'"
 											+ newTVcount
 											+ "')]/following-sibling::td[1][contains(.,'"
 											+ New_NoOfTV_Price + "')]"));
 					if (TVdetail.isDisplayed()) {

 						report.reportPass(
 								"Verify Summary page",
 								desc_in_summary
 										+ " "
 										+ New_NoOfTV_Price
 										+ " should be displayed in Summary page",
 								desc_in_summary + " " + New_NoOfTV_Price
 										+ " is displayed in review page");
 					} else {
 						report.reportFail(
 								"Verify Summary page",
 								desc_in_summary
 										+ " "
 										+ New_NoOfTV_Price
 										+ " should be displayed in Summary page",
 								desc_in_summary + " " + New_NoOfTV_Price
 										+ " is not displayed in review page");
 					}
 				} catch (Exception ex) {
 					report.reportFail("Verify Summary page", desc_in_summary
 							+ " " + New_NoOfTV_Price
 							+ " should be displayed in Summary page",
 							desc_in_summary + " " + New_NoOfTV_Price
 									+ " is not displayed in review page");
 					throw new UserDefinedException(desc_in_summary + " "
 							+ New_NoOfTV_Price
 							+ " is not displayed in review page");

 				}

 			}

 		}

 		if (!get("HNP").isEmpty()) {
 			String strFailed = "";
 			try {
 				clickUsingJavaScript(zeroRated, objectValue);
 				report.reportPass(
 						"SummaryPage Validations",
 						"Verify ZeroRated Products are displayed",
 						"Zero Rated Product option is clicked and able to see the products of zero rated");
 			} catch (Exception e) {
 				report.reportFail(
 						"SummaryPage Validations",
 						"Verify ZeroRated Products are displayed",
 						"Zero Rated Product option is clicked but not able to see the products of zero rated");
 			}

 			String HNP = get("HNP").trim();
 			WebElement HNPinSummary = null;
 			if (HNP.equalsIgnoreCase("AutoAdded")) {
 				
 				try{
 				HNPinSummary = driver
 						.findElement(By
 								.xpath("//td[contains(text(),'New')]/following-sibling::td[1][contains(.,'Home Network Protection') and contains(.,'$0')]"));
 				if (isDisplayed(HNPinSummary)) {

 					report.reportPass(
 							"validate Home Network Protection in Summary Page",
 							"Home Network Protection should be added in Summary Page",
 							"Home Network Protection is added in Summary Page");

 				} else {

 					report.reportFail(
 							"validate Home Network Protection",
 							"Home Network Protection should be in added Summary Page",
 							"Home Network Protection is not added in Summary Page");
 					strFailed = "Home Network Protection is not added in Summary Page";
 					throw new UserDefinedException(strFailed);
 				}
 				}
 				catch(Exception ex){
 					report.reportFail(
 							"validate Home Network Protection",
 							"Home Network Protection should be in added Summary Page",
 							"Home Network Protection is not added in Summary Page");
 					strFailed = "Home Network Protection is not added in Summary Page";
 					throw new UserDefinedException(strFailed);
 					
 				}
 			}

 			else if (HNP.equalsIgnoreCase("NotAutoAdded")) {

 				try{
 				HNPinSummary = driver
 						.findElement(By
 								.xpath("//td[contains(text(),'New')]/following-sibling::td[1][contains(.,'Home Network Protection') and contains(.,'$0')]"));

 				if (!isDisplayed(HNPinSummary)) {

 					report.reportPass(
 							"validate Home Network Protection  in Summary Page",
 							"Home Network Protection should not be added  in Summary Page",
 							"Home Network Protection is not added  in Summary Page");

 				} else {

 					report.reportFail(
 							"validate Home Network Protection  in Summary Page",
 							"Home Network Protection should not be added  in Summary Page",
 							"Home Network Protection is added  in Summary Page");
 					strFailed = "Home Network Protection is added  in Summary Page";
 					throw new UserDefinedException(strFailed);
 				}
 				}
 				catch(Exception ex){
 					report.reportPass(
 							"validate Home Network Protection  in Summary Page",
 							"Home Network Protection should not be added  in Summary Page",
 							"Home Network Protection is not added  in Summary Page");
 				}
 			} else if (HNP.equalsIgnoreCase("blockdeletion")) {
 				try{
 				HNPinSummary = driver
 						.findElement(By
 								.xpath("//td[contains(text(),'Existing')]/following-sibling::td[1][contains(.,'Home Network Protection') and contains(.,'$0')]"));
 				if (isDisplayed(HNPinSummary)) {

 					report.reportPass(
 							"validate Home Network Protection in Summary Page",
 							"Existing Home Network Protection should present in Summary Page",
 							"Existing Home Network Protection is present in Summary Page");

 				} else {

 					report.reportFail(
 							"validate Home Network Protection",
 							"Existing Home Network Protection should present in Summary Page",
 							" Existing Home Network Protection is not present in Summary Page");
 					strFailed = "Existing Home Network Protection is not present in Summary Page";
 					throw new UserDefinedException(strFailed);
 				}}
 				catch(Exception ex){
 					report.reportFail(
 							"validate Home Network Protection",
 							"Existing Home Network Protection should present in Summary Page",
 							" Existing Home Network Protection is not present in Summary Page");
 					strFailed = "Existing Home Network Protection is not present in Summary Page";
 					throw new UserDefinedException(strFailed);
 				}

 			}

 		}

 	}


}
