package com.automation.ui.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.exec.util.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_ProductAndServices_PageObjects;
import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.support.ElementFactory;
import com.automation.test.order.OfferDataExtraction;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;
//import com.thoughtworks.selenium.webdriven.JavascriptLibrary;

/**
 * SimplexProductAndServicesPage class represents the Product & Services and
 * interact with the Page.
 * 
 */
public class SimplexProductAndServicesPage extends Simplex_ProductAndServices_PageObjects {

	String objectValue = "";
	static boolean windows = InitiateDriver.windows;
	String testId;
	Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(), testId);

	String description = "", expected = "", actual = "", failure = "", getUrl = "";
	By by;

	/**
	 * SimplexProductServicesPage constructor invokes the super class
	 * constructor.
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            represents the test case id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @throws Exception
	 *             throws exception of type Exception
	 * 
	 * 
	 */
	public SimplexProductAndServicesPage(WebDriver driver, String testId, ReportStatus report,
			HashMap<String, String> data) throws Exception {
		super(driver, windows, report, data);
		this.testId = testId;
	}

	/**
	 * initialize method used to initialize the page elements for this page and
	 * returns current Page
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            repesents the testcase id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @return returns current page class
	 */
	public static SimplexProductAndServicesPage initialize(WebDriver driver, String testId, ReportStatus report,
			HashMap<String, String> data) {

		return ElementFactory.initElements(driver, SimplexProductAndServicesPage.class, testId, report, data);
	}

	public void start() throws Exception {
		System.out.println("Products & Services Page...");
		waitForLoader();

		if (isDisplayed(Smartcartpopup, "", 3)) {
			clickUsingJavaScript(Smartcartpopup, "");
		}
		setIterator();
		if (get("FlowType").contains("SuppMove")) {

			moveSuppOrder();
		} else if (get("FlowType").contains("OwnerShip") && !get("Checkout").isEmpty()) {
			waitForLoader();
			selectEquipmentOptions();
			waitForLoader();
			goToCheckout();
		}
		/************ Change PIN****SAC **********/
		else if (get("ChangeType").contains("ChangePIN")) {
			editPIN();
		}
		/************ Change Password****SAC **********/
		else if (get("ChangeType").contains("ChangePassword")) {
			changePassword();

		} else if (get("ChangeType").equalsIgnoreCase("Disconnect")
				|| get("ChangeType").equalsIgnoreCase("PartialDisconnect")
				|| get("ChangeType").equalsIgnoreCase("StackDisconnect")) {
			Disconnect();
		}

		// To Negotiate Only review Order and Checkout Button in Products Page
		// call this function
		else if (!get("Checkout").isEmpty()) {

			waitForLoader();
			waitForLoader();
			goToCheckout();
		}

		else {

			try {
				if (get("FlowType").equalsIgnoreCase("Change") && get("FCPChangeMigrate").equalsIgnoreCase("Yes")) {
					System.out.println("FCP Change Migratge FLow");
					waitForLoader();
					waitForLoader();
					switchToDefaultcontent();
					switchToFrame("IfProducts");
					clickUsingJavaScript(opoGetFCPButton, objectValue);
					waitForLoader();
					waitForLoader();
					if (isDisplayed(opoFCPETFMessage)) {
						String FCTETFMessage = opoFCPETFMessage.getText();
						System.out.println(FCTETFMessage);
						report.reportPass("Get Classic To FCP ETF message", "ETF Message should be displayed",
								"ETF Message is displayed " + FCTETFMessage + "");
					}
					report.reportPass("Clicking Get FCP Plan button", "Get FCP Plans button should be clicked",
							"Get FCP plans button is clicked");
				}

			} catch (Exception ex) {

				report.reportFail("click GetFCPButton ", "'GetFCPButton' button should be clicked",
						"'GetFCPButton' button is clicked");
			}

			selectPackage();

			report.reportPass("The flow is Classic Flow", "The flow should be classic flow as per customer input",
					"The flow is classic flow");

		}

	}

	public void navigateTo() throws Exception, UserDefinedException {

		// To increment the navigation iteration
		int i = TestIterator.getIterator(testId);
		TestIterator.setIterator(testId, ++i);

		if (get("Switch-Over").equalsIgnoreCase("MakeChanges")) {
			try {

				switchToDefaultcontent();
				switchToFrame("IfProducts");

				if (isDisplayed(btnMakeChanges, objectValue)) {
					clickUsingJavaScript(btnMakeChanges, objectValue);
				}

			} catch (Exception e) {
				e.printStackTrace();
				throw new UserDefinedException("Make_Changes Button didn't clicked");
			}
		} else if (!get("Switch-Over").equalsIgnoreCase("No")) {

			try {

				switchToDefaultcontent();
				switchToFrame("IfProducts");

				if (isDisplayed(productTab, objectValue)) {
					System.out.println("Test1");
					clickUsingJavaScript(productTab, objectValue);
				} else if (isDisplayed(productTab1, objectValue)) {
					System.out.println("Test2");
					clickUsingJavaScript(productTab1, objectValue);
				}
				// make changes pop up
				if (isDisplayed(btnOkMakeChanges, objectValue)) {
					clickUsingJavaScript(btnOkMakeChanges, objectValue);
				}
				waitForLoader();

			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}

	}

	/**
	 * @Description: moveSuppOrder is used for Supp ordere in Move Flow
	 * @author: Mounika, Padmini
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */

	public void moveSuppOrder() throws Exception, UserDefinedException {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl = "";

		try {
			strDescription = "Selecting Update/Due date change for Move";
			strActual = "Update/Due date change link was successfully clicked";
			strFailed = "Update/Due date change click was not successful";
			getUrl = ", URL Launched --> " + returnURL();
			waitForLoader();

			// waitForElementDisplay(expandMovePending, objectValue,
			// pageTimeoutInSeconds);
			try {

				if (isDisplayed(expandMovePending, objectValue)) {

					clickUsingJavaScript(expandMovePending, objectValue);
					pause();
				}
			} catch (Exception exe) {
				System.out.println("Move pending is already expanded");

			}

			if (get("Supp_Order_Type").equalsIgnoreCase("Update")) {

				// waitForElementDisplay(BtnupdateMove, objectValue, 30);

				clickUsingJavaScript(BtnupdateMoves, objectValue);
				System.out.println("Update Button is clicked");

				if ((isDisplayed(salesProfileSave, "", 2))) {
					clickUsingJavaScript(salesProfileSave, objectValue);
					report.reportPass("Click Save on saled profile", "Save button is clicked.",
							" Save button should be clicked ");
					System.out.println("Sales profile Button is clicked");
					waitForLoader();

				}

			}
			if (get("Supp_Order_Type").equalsIgnoreCase("DueDate")) {

				waitForElementDisplay(ChangeDueDateMoves, objectValue, 30);

				clickUsingJavaScript(ChangeDueDateMoves, objectValue);
				report.reportPass("Click Save on Change DueDate Button", "Change DueDate Button should be clicked ",
						" Change DueDate Button is clicked ");

				waitForLoader();
				waitForLoader();
				waitForLoader();
				waitForLoader();
				waitForLoader();
				waitForLoader();

				if ((isDisplayed(salesProfileSave, "", 2))) {
					clickUsingJavaScript(salesProfileSave, objectValue);
					report.reportPass("Click Save on saled profile", "Save button should be clicked.",
							" Save button is clicked ");
					System.out.println("Sales profile Button is clicked");
					waitForLoader();
					waitForLoader();

				}

			}

			waitForLoader();

		} catch (Exception exe) {
			exe.printStackTrace();
			report.reportFail(strDescription + getUrl, strExpected, strFailed + exe.getCause());
			report.updateMainReport("ErrorMessage", strFailed);
			throw new UserDefinedException("Failed in Move Supp Order ");
		}

		if (!get("Supp_Order_Type").equalsIgnoreCase("DueDate")) {
			selectPackage();
		}
	}

	/**
	 * @Description: SelectPackage is used to select the Recommended Section
	 * @author: Mounika, Padmini
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */

	public void selectPackage() throws Exception, UserDefinedException {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "Validate Recommended section.";
		strExpected = "Recommended section should be validated";
		strActual = "Selected Recommeded section.";
		strFailed = "Failed to validate recommended section due to object unavailability.";
		getUrl = ", URL Launched --> " + returnURL();

		String selectPackage = get("SelectPackage").trim();
		waitForLoader();
		waitForLoader();
		waitForLoader();
		waitForLoader();
		waitForLoader();

		switchToDefaultcontent();

		try {
			waitForElementDisplay(enableProducts, objectValue, 120);
		} catch (Exception e) {

		}

		// waitForElementDisplay(IfProducts, selectPackage, 120);

		if (get("GUI_Validations").equalsIgnoreCase("Yes")) {

			GUIValidation_OPO();
		}

		String flowtype = get("FlowType").trim();
		if (selectPackage.contains("Tile") && flowtype.equalsIgnoreCase("Change")) {
			pegaRecommendations();
		} else {
			try {

				switchToDefaultcontent();
				switchToFrame("IfProducts");
				if (selectPackage.equalsIgnoreCase("Get Prepaid Plans")
						|| selectPackage.equalsIgnoreCase("View fios IPTV")
						|| selectPackage.equalsIgnoreCase("View IPTV Products")
						|| selectPackage.equalsIgnoreCase("Classic Products")) {
					String ReasonForMigration = get("ReasonForMigration");
					/*
					 * if (getPrepaidPlan.getText().contains("Get Prepaid Plans"
					 * )) { clickUsingJavaScript(getPrepaidPlan, objectValue);
					 * report.reportPass("Get Prepaid Plan header",
					 * "Get Prepaid Plan header should be selected in Product and service page."
					 * ,
					 * "Get Prepaid Plan header is displayed and selected in Product and service page."
					 * );
					 * 
					 * } else { report.reportFail("Get Prepaid Plan header",
					 * "Get Prepaid Plan header should be displayed in Product and service page."
					 * ,
					 * "Get Prepaid Plan header is not displayed in Product and service page."
					 * ); report.updateMainReport("ErrorMessage",
					 * "Get Prepaid Plan header is not displayed."); throw new
					 * UserDefinedException(
					 * "Get Prepaid Plan header is not displayed in Product and service page."
					 * ); }
					 */

					waitForElementDisplay(getPrepaidPlan, objectValue, pageTimeoutInSeconds);
					if (getPrepaidPlan.getText().contains("Get Prepaid Plans")
							|| getPrepaidPlan.getText().contains("View fios IPTV")
							|| getPrepaidPlan.getText().contains("View IPTV Products")
							|| getPrepaidPlan.getText().contains("Classic Products")) {
						clickUsingJavaScript(getPrepaidPlan, objectValue);
						report.reportPass(selectPackage + " header",
								selectPackage + " header should be selected in Product and service page.",
								selectPackage + " header is displayed and selected in Product and service page.");
						waitForLoader();
						if (selectPackage.equalsIgnoreCase("Classic Products")) {
							switchToDefaultcontent();
							switchToFrame("IfProducts");
							clickUsingJavaScript(reasonForMigration, ReasonForMigration);
							report.reportPass("To Select Reason for Migration",
									"Verify Whether Reason for Migration is selected",
									"Reason for Migration" + ReasonForMigration + "is Selected");
							waitForLoader();
							clickUsingJavaScript(continuebtn, objectValue);
							waitForLoader();
						}

					} else {
						report.reportFail(selectPackage + " header",
								selectPackage + " header should be displayed in Product and service page.",
								selectPackage + " header is not displayed in Product and service page.");
						report.updateMainReport("ErrorMessage", selectPackage + " header is not displayed.");
						throw new UserDefinedException(
								selectPackage + " header is not displayed in Product and service page.");
					}

				} else if (isDisplayed(tabRecommendation, objectValue, 20)) {

					if ((!selectPackage.isEmpty()) && (!selectPackage.equalsIgnoreCase("No"))) {

						// Switch to frame to select the needed plan
						switchToDefaultcontent();
						switchToFrame("IfProducts");

						// Expand recommendation tab in product and services
						// page
						if (!getAttribute(tabRecommendation, objectValue, "class").contains("open")) {
							pageScroll(tabRecommendation, objectValue, true);
							clickUsingJavaScript(tabRecommendation, objectValue);
						}
						// clicking on more recommendations section

						if (isDisplayed(moreRecommendation, "", 3)) {
							clickUsingJavaScript(moreRecommendation, objectValue);
						}

						// selecting recommended section platinum offer
						if (get("SelectPackage").equalsIgnoreCase("HeroTile")
								|| (get("SelectPackage").equalsIgnoreCase("Deselect"))) {
							System.out.println("Platinum offers tiles available is :" + platinumOffers.size());

							for (int i = 0; i < platinumOffers.size(); i++) {

								try {

									String sValue = platinumOffers.get(i).getAttribute("data-hero-tile").toString();

									if (!sValue.equalsIgnoreCase("active")
											&& (get("SelectPackage").equalsIgnoreCase("HeroTile"))) {

										report.reportPass(strDescription + platinumOffers.get(i).getText(), strExpected,
												strActual);
										platinumOffers.get(i).click();
										// Actions action = new Actions(driver);
										// action.click(platinumOffers.get(i)).build().perform();

										// collapse select package

										if (getAttribute(tabRecommendation, objectValue, "class").contains("open")) {
											pageScroll(tabRecommendation, objectValue, true);
											clickUsingJavaScript(tabRecommendation, objectValue);
										}

										break;
									}

									report.reportPass(strDescription + platinumOffers.get(i).getText(), strExpected,
											strActual);

									if (sValue.equalsIgnoreCase("active")
											&& get("SelectPackage").equalsIgnoreCase("Deselect")) {

										report.reportPass(strDescription + platinumOffers.get(i).getText(), strExpected,
												strActual);
										// platinumOffers.get(i).click();
										Actions action = new Actions(driver);
										action.click(platinumOffers.get(i)).build().perform();
										break;
									}

									waitForLoader();
									waitForLoader();

								} catch (Exception e) {
									System.out.print(e.getMessage());
								}
							}
							report.reportPass(strDescription + getUrl, strExpected, strActual);
						}
					}

				}
				// ********* Added Prepaid Plans*******************

				// To select the Get Prepaid Plans And Fios IPTV section in
				// product
				// & services
				// page.

				// *************** Prepaid Plans********

				waitForLoader();
				waitForLoader();

				// Switching to Default Content
				switchToDefaultcontent();

			}

			catch (Exception exe)

			{
				exe.printStackTrace();
				if (!isUserDefinedException(exe)) {
					report.reportFail(strDescription + getUrl, strExpected, strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					captureErrorMsg("Recommend section was not loaded.");
				}

				throw exe;
			}
		}
		// Moving to SelectInternetPlan
		if (get("Project_ID").contains("FCP")) {
			selectInternetPlan_FCP();
		} else {
			selectInternetPlan();

		}
	}

	/**
	 * @Description: changeInternetPlan is used to change the Internet Plan,
	 *               Upgrade, Downgrade for C2G and COA Change
	 * @param: internetPlanDetails
	 *             is used to represent the Internet Plan to choose
	 * @param: Standalone
	 *             is used to choose if Data is Standalone
	 * @param: Contract
	 *             is used to Choose between 2Year and Month to Month Terms
	 * @author: Mounika, Padmini
	 * @LastUpdatedBy -- Shiva 4/3/2017
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */

	public void selectInternetPlan_FCP() throws Exception, UserDefinedException

	{

		System.out.println("->selectInternetPlanFCP");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		getUrl = ", URL Launched --> " + returnURL();

		String internetPlan = get("InternetPlan").trim();
		String contract = get("Contract").trim();

		try {

			waitForLoader();
			// Switching to Default Content
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			String FiosData = "";
			if (isDisplayed(simplex_SelectedData, "", 3)) {
				FiosData = getTextFromElement(simplex_SelectedData, objectValue);

			}
			report.reportPass("To View Whether OPO is Loaded", "Verify Whether OPO is Loaded", "OPO Should be Loaded");

			waitForLoader();
			waitForLoader();
			waitForLoader();
			// Switching to Default Content
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			if (get("HLRValidations").equalsIgnoreCase("Yes") && get("FlowType").equalsIgnoreCase("MoveAsIs")) // Gopal
																												// for
																												// Move
																												// AS
																												// IS
																												// Validation
																												// 11/13
			{

				System.out.println(Existingdataproduct.getText().trim());
				String ExistingDataspeed = Existingdataproduct.getText().trim();

				if (Existingdataproduct.isDisplayed() && !ExistingDataspeed.isEmpty()) {
					try {

						System.out.println(ExistingDataspeed);
						String[] ExistingDataSpeed = ExistingDataspeed.split("\\(");
						System.out.println(ExistingDataSpeed[0]);

						String CureentDataspeed = Currentdataspeed.getText();
						System.out.println(CureentDataspeed);
						String[] CureentDataSpeed = CureentDataspeed.split("\\(");
						System.out.println(CureentDataSpeed[0]);

						if (ExistingDataSpeed[0].contains(CureentDataSpeed[0])) {

							report.reportPass(
									"To verify if Existing and Current Data Speed's both are same for moveAsIs",
									"Existing and Current Data Speed's both Sould be Same",
									"Existing and Current Data Speed's both are same");
						} else {

							report.reportFail(
									"To verify if Existing and Current Data Speed's both are same for moveAsIs",
									"Existing and Current Data Speed's both Sould be Same",
									"Existing and Current Data Speed's both are not same");
						}

					} catch (Exception e) {

						throw new UserDefinedException("Existing and Current Data Speed's both are not same");
					}

				}

			}

			if (!internetPlan.isEmpty() ||(!FiosData.isEmpty())) {

				// Expand Internet
				if (!getAttribute(expandInternet, objectValue, "class").contains("open")) {
					pageScroll(expandInternet, objectValue, true);
					clickUsingJavaScript(expandInternet, objectValue);
				}
				waitForLoader();

				// Checking Internet Section loaded or not.

				try {
					if (isDisplayed(allInternetSpeeds)) {
						waitForElementDisplay(allInternetSpeeds, "", pageTimeoutInSeconds);
					}
				} catch (Exception e) {

					strFailed = "Failed in internet plan, Internet section was not loaded even after "
							+ pageTimeoutInSeconds + " seconds.";
					report.reportFail("Select Internet plan", "Internet  plan should be selected.", strFailed);
					report.updateMainReport("comments", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					logger.error(strFailed);
					captureErrorMsg(strFailed);
					throw new UserDefinedException(strFailed);

				}
				waitForLoader();
				// update for FCP
				// To Click View Standalone Prices
				/*
				 * if (standalone.toLowerCase().contains("Data".toLowerCase()))
				 * {
				 * 
				 * String S = getTextFromElement(viewStandaloneText, "");
				 * System.out.println(S); if (S.contains("Standalone")) { try {
				 * clickUsingJavaScript(lnkDataViewStandaone, objectValue);
				 * report.reportPass("Click on standalone prices",
				 * "Standalone prices should be clicked.",
				 * "Clicked on View Standalone Prices in Internet Plan"); }
				 * catch (Exception e) {
				 * 
				 * strFailed =
				 * "Failed in internet plan, View standalone prices not available."
				 * ; logger.error(strFailed, e); report.reportFail(
				 * "Select standalone plan",
				 * "Internet standalone prices should be selected.", strFailed);
				 * report.updateMainReport("comments", strFailed);
				 * report.updateMainReport("ErrorMessage", strFailed);
				 * captureErrorMsg(strFailed); throw new
				 * UserDefinedException(strFailed); }
				 * 
				 * }
				 * 
				 * // To Click Month to Month Plans if
				 * (contract.equalsIgnoreCase("M2M")) { try {
				 * clickUsingJavaScript(contractM2M, objectValue);
				 * report.reportPass("Select Month to Month",
				 * "Month to Month plan should be selected.",
				 * "Selected INternet Month to Month plan"); waitForLoader(); }
				 * catch (Exception e) {
				 * 
				 * strFailed =
				 * "Failed in internet plan, Month to Month plan not available."
				 * ; logger.error(strFailed, e); report.reportFail(
				 * "Select Month to month plan",
				 * "Internet Monthly plan should be selected.", strFailed);
				 * report.updateMainReport("comments", strFailed);
				 * report.updateMainReport("ErrorMessage", strFailed);
				 * captureErrorMsg(strFailed); throw new
				 * UserDefinedException(strFailed); }
				 * 
				 * }
				 * 
				 * // To Click 2 Year Agreement Plans else if
				 * (contract.equalsIgnoreCase("2Year")) {
				 * 
				 * if (isDisplayed(contract2Year, objectValue, 0)) { try {
				 * 
				 * clickUsingJavaScript(contract2Year, objectValue);
				 * report.reportPass("Select 2Year",
				 * "2Year plan should be selected.",
				 * "Selected Internet Month to Month2Year plan");
				 * waitForLoader();
				 * 
				 * } catch (Exception e) {
				 * 
				 * strFailed =
				 * "Failed in internet plan, 2Year plan not available.";
				 * logger.error(strFailed, e); report.reportFail(
				 * "Select 2Year plan",
				 * "Internet 2Year plan should be selected.", strFailed);
				 * report.updateMainReport("comments", strFailed);
				 * report.updateMainReport("ErrorMessage", strFailed);
				 * captureErrorMsg(strFailed); throw new
				 * UserDefinedException(strFailed); }
				 * 
				 * }
				 * 
				 * }
				 * 
				 * } else { // Click View Bundle Prices String S =
				 * getTextFromElement(viewStandaloneText, objectValue);
				 * System.out.println(S); if (S.contains("Bundle")) {
				 * 
				 * try { clickUsingJavaScript(lnkDataViewBundle, objectValue);
				 * report.reportPass(
				 * "Simplex Page  ordering - Verify able to click View Bundle Prices in Internet Plan"
				 * ,
				 * "Should be able to click View Bundle Prices in Internet Plan"
				 * , "Able to click View Bundle Prices in Internet Plan"); }
				 * catch (Exception e) { strFailed =
				 * "Failed in Internet Plan, Bundle prices not available.";
				 * logger.error(strFailed, e); report.reportFail(
				 * "Select Bundle Internet plan",
				 * "Internet bundle prices should be selected.", strFailed);
				 * report.updateMainReport("comments", strFailed);
				 * report.updateMainReport("ErrorMessage", strFailed);
				 * captureErrorMsg(strFailed); throw new
				 * UserDefinedException(strFailed); }
				 * 
				 * } }
				 */
				// update for FCP
				waitForLoader();
				waitForLoader();
				// Getting the Text of Selected Data
				String SelectedData = getTextFromElement(simplex_SelectedData, objectValue);
				SelectedData = SelectedData.split("[(][a-zA-Z]*[)]", 2)[0].trim();
				System.out.println(SelectedData);

				// To Upgrade or Downgrade Internet
				if ((internetPlan.contains("Upgrade")) || (internetPlan.contains("Downgrade"))) {

					internetUpgradeDowngrade();

				} else if (internetPlan.equalsIgnoreCase("Deselect")) {

					Deselectservice("internet");
					report.reportPass("Simplex Page  ordering - Verify able to Deselect Internet Plan",
							"Should be able to Deselect Internet Plan", "Able to Deselect Internet Plan");

				}

				// To Click the Internet Plan Given in the Run Manager Sheet
				else if ((!internetPlan.isEmpty()) && (!SelectedData.equalsIgnoreCase(internetPlan))) {

					try {
						waitForLoader();
						if (isDisplayed(lnkInternetPlans, internetPlan, 5)) {
							pageScroll(lnkInternetPlans, internetPlan, true);
							clickUsingJavaScript(lnkInternetPlans, internetPlan);
							report.reportPass("Select Internet Plan: " + internetPlan,
									"Internet plan should be selected.", "Selected internet plan: " + internetPlan);

							// ----------------------Digital Billing Update
							// ---------------------------------------
							try {
								String DB = null;

								if (isDisplayed(Digital_billing_enrollment, "", 3)) {
									pageScroll(Digital_billing_enrollment);
									DB = getTextFromElement(Digital_billing_enrollment_Message, objectValue);
									System.out.println("Digital_billing_enrollment message is displayed");
									report.reportPass("Digital Billing enrollment message should be  displayed: " + DB,
											"Digital Billing enrollment message is  displayed: " + DB,
											"Digital Billing message is " + DB);
								}
								// Digital billing NJ check box
								if (isDisplayed(Digital_billing_enrollment_NJCheckbox, "", 3)) {
									pageScroll(Digital_billing_enrollment_NJCheckbox);
									clickUsingJavaScript(Digital_billing_enrollment_NJCheckbox, objectValue);
									System.out.println(
											"Digital billing Check box is displayed and selected for NJ address");
									report.reportPass(
											"Digital Billing enrollment Checkbox should be displayed for NJ address",
											"Digital Billing enrollment Checkbox is displayed for NJ address",
											"Digital Billing enrollment Checkbox is displayed for NJ address and it is selected");
								} else {
									System.out.println(
											"Digital billing Check box is not displayed and not selected for NJ address");
									report.reportPass(
											"Digital Billing enrollment Checkbox should be displayed for NJ address",
											"Digital Billing enrollment Checkbox is not displayed for NJ address",
											"Digital Billing enrollment Checkbox is not displayed for NJ address and it is not selected");
								}

								// Digital_billing_enrollment_review
								if (isDisplayed(Digital_billing_enrollment_review, "", 3)) {
									pageScroll(Digital_billing_enrollment_review);
									Thread.sleep(3000);
									clickUsingJavaScript(Digital_billing_enrollment_review, objectValue);
									Thread.sleep(3000);
									System.out.println("Digital billing please review is displayed and clicked");
									report.reportPass("Digital Billing enrollment please review should be displayed",
											"Digital Billing enrollment please review is displayed",
											"Digital Billing enrollment please review is displayed and it is clicked");
								} else {
									System.out
											.println("Digital billing please review is not displayed and not clicked");
									report.reportPass("Digital Billing enrollment please review should be displayed",
											"Digital Billing enrollment please review is displayed",
											"Digital Billing enrollment please review is displayed and it is clicked");
								}

							} catch (Exception e) {
								System.out.println("Digital_billing_enrollment message is not displayed");
								report.reportFail("Digital Billing enrollment message should be  displayed: ",
										"Digital Billing enrollment message is not displayed: ",
										"Digital Billing message is not displayed ");
							}
						} else {
							String x = getTextFromElement(firstHighSpeedInternet, SelectedData);
							System.out.println(x);
							if (!x.equals(SelectedData)) {

								clickUsingJavaScript(firstHighSpeedInternet, objectValue);
								report.reportPass("Internet Plan is " + internetPlan + " not available",
										"Internet plan " + internetPlan
												+ " not available so selected First Avaialble Highest Speed",
										"Internet plan " + internetPlan
												+ " not available so selected First Avaialble Highest Speed: " + x);

							} else {
								report.reportPass("Internet Plan is " + internetPlan + " not available",
										"Internet plan " + internetPlan
												+ " not available so selected First Avaialble Highest Speed",
										"Internet plan " + internetPlan
												+ " not available so selected First Avaialble Highest Speed: " + x);
							}

						}
					} catch (Exception e) {
						e.printStackTrace();
						strFailed = "Failed in internet plan, Required speed " + internetPlan + "  not available.";
						logger.error(strFailed, e);
						report.reportFail("Select Internet plan", "Internet plan should be selected.", strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						captureErrorMsg(strFailed);
						throw new UserDefinedException(strFailed);
					}

				} else if (SelectedData.equalsIgnoreCase(internetPlan)) {
					report.reportPass("Select Internet Plan: " + internetPlan,
							internetPlan + " Internet plan should be selected",
							"Already selected " + internetPlan + " internet plan, no need to select again.");
				}

				waitForLoader();

				// Mounika Polagoni (HLR Validations)

				if (get("HLRValidations").equalsIgnoreCase("Yes")) {

					if (isDisplayed(simplex_SelectedData, "", 3)) {
						if (getTextFromElement(simplex_SelectedData, "").contains("Gigabit")) {
							put("Display Internet", "Fios Gigabit Connection");

						} else if (getTextFromElement(simplex_SelectedData, "").contains("Cons")) {

							String FiData = getTextFromElement(simplex_SelectedData, objectValue);
							String FiosData2[] = FiData.split("SFU");
							System.out.println(FiosData2[0]);
							String FSD[] = FiosData2[0].split("Cons");
							System.out.println(FSD[1]);
							put("Display Internet", FSD[1]);
						} else if (getTextFromElement(simplex_SelectedData, "").contains("Standalone")) {
							String FiData = getTextFromElement(simplex_SelectedData, objectValue);
							String FiosData2[] = FiData.split("\\(");
							System.out.println(FiosData2[0]);
							if (FiosData2[0].contains("/")) {
								String FDt[] = FiosData2[0].split("/");
								System.out.println(FDt[0]);
								put("Display Internet", FDt[0]);
							} else {
								put("Display Internet", FiosData2[0]);
							}
						} else if (getTextFromElement(simplex_SelectedData, "").contains("Bundle")) {
							String FiData = getTextFromElement(simplex_SelectedData, objectValue);
							String FiosData2[] = FiData.split("\\(");
							System.out.println(FiosData2[0]);
							put("Display Internet", FiosData2[0]);
						} else {
							String FiosData2 = getTextFromElement(simplex_SelectedData, objectValue);
							System.out.println(FiosData2);
							put("Display Internet", FiosData2);
						}

					}
				}

				// Collapse Internet

				if (getAttribute(expandInternet, objectValue, "class").contains("open")) {
					pageScroll(expandInternet, objectValue, true);
					clickUsingJavaScript(expandInternet, objectValue);
				}

			}

			// Switching to Default Content
			switchToDefaultcontent();

		}

		catch (Exception exe) {

			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in Internet section.");
			}
			throw exe;
		}

		// Moving to TV Plan
		if (fd.isEmpty()) {
			
				selectTvPlan_FCP();
			
		}

	}

	/**
	 * @Description: selectTvPlan is used to change the TV Plan, Upgrade,
	 *               Downgrade for C2G and COA Change
	 * @param: tvPlanDetails
	 *             is used to choose the TV Plan
	 * @param: Standalone
	 *             is used to choose if TV is Standalone
	 * @author: Mounika, Padmini
	 * @LastUpdatedBy -- Shiva 03/04/2017
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */

	protected void selectTvPlan_FCP() throws Exception, UserDefinedException {

		System.out.println("->selectTvPlanFCP");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		getUrl = ", URL Launched --> " + returnURL();

		try {

			waitForLoader();
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			String tvPlan = get("TvPlan").trim();
			String standalone = get("Standalone").trim();
			String fiosFiveChannels = get("FiosFiveChannels").trim();


			
			String FiosTV = "";
			if (isDisplayed(simplex_SelectedTV, "", 1)) {
				FiosTV = simplex_SelectedTV.getText();

			}

			waitForLoader();
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			if (get("HLRValidations").equalsIgnoreCase("Yes") && get("FlowType").equalsIgnoreCase("MoveAsIs")) // Gopal
																												// for
																												// Move
																												// AS
																												// IS
																												// Validation
																												// 11/13
			{

				String ExistingTVProduct = Existingtvproduct.getText().trim();

				if (Existingtvproduct.isDisplayed() && !ExistingTVProduct.isEmpty()) {
					try {

						String CurrentTVProduct = Currenttvproduct.getText().trim();

						System.out.println(ExistingTVProduct);

						System.out.println(CurrentTVProduct);

						if (CurrentTVProduct.contains("(")) {

							String[] CurrentTVproduct = CurrentTVProduct.split("");
							System.out.println(CurrentTVproduct[0]);

							if (ExistingTVProduct.contains(CurrentTVproduct[0])) {

								report.reportPass(
										"To verify if Existing and Current TV Product both are same for moveAsIs",
										"Existing and Current TV Product both Sould be Same",
										"Existing and Current TV Product both are same");
							} else {

								report.reportFail(
										"To verify if Existing and Current TV Product both are same for moveAsIs",
										"Existing and Current TV Product both Sould be Same",
										"Existing and Current TV Product both are not same");
							}

						} else {
							if (ExistingTVProduct.equals(CurrentTVProduct)) {

								report.reportPass(
										"To verify if Existing and Current TV Product both are same for moveAsIs",
										"Existing and Current TV Product both Sould be Same",
										"Existing and Current TV Product both are same");
							} else {

								report.reportFail(
										"To verify if Existing and Current TV Product both are same for moveAsIs",
										"Existing and Current TV Product both Sould be Same",
										"Existing and Current TV Product both are not same");
							}

						}

					} catch (Exception e) {

						throw new UserDefinedException("Existing and Current TV Product both are not same");
					}
				}
			}

			if (!tvPlan.isEmpty() || (!FiosTV.isEmpty())) {
				// Expanding TV
				if (!getAttribute(expandTv, objectValue, "class").contains("open")) {
					pageScroll(expandTv, objectValue, true);
					clickUsingJavaScript(expandTv, objectValue);

				}

				try {
					waitForElementDisplay(allTvs, "", pageTimeoutInSeconds);
				} catch (Exception e) {

					strFailed = "Failed in TV plan, TV section was not loaded even after " + pageTimeoutInSeconds
							+ " seconds..";
					report.reportFail("Select TV plan", "TV plan should be selected.", strFailed);
					report.updateMainReport("comments", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					logger.error(strFailed);
					captureErrorMsg(strFailed);
					throw new UserDefinedException(strFailed);

				}
				/*
				 * //update for FCP if
				 * (standalone.toLowerCase().contains("TV".toLowerCase())) { //
				 * Click View Standalone prices
				 * 
				 * String S = getTextFromElement(viewStandaloneTVText,
				 * objectValue); System.out.println(S); if
				 * (S.contains("Standalone")) { try {
				 * clickUsingJavaScript(C2GTVStandalonePrice, objectValue);
				 * report.reportPass("Select standalone tv plan",
				 * "Standalone tv plan should be selected.",
				 * "Clicked on View standalone prices of Tv plan."); } catch
				 * (Exception e) { strFailed =
				 * "Failed in Tv Plan, View standalone prices not available.";
				 * logger.error(strFailed, e); report.reportFail(
				 * "Select standalone tv plan",
				 * "TV standalone prices should be selected.", strFailed);
				 * report.updateMainReport("comments", strFailed);
				 * report.updateMainReport("ErrorMessage", strFailed);
				 * captureErrorMsg(strFailed); throw new
				 * UserDefinedException(strFailed); }
				 * 
				 * }
				 * 
				 * } else { // Click View Bundle Prices String S =
				 * getTextFromElement(viewStandaloneTVText, objectValue);
				 * System.out.println(S); if (S.contains("Bundle")) {
				 * 
				 * try { clickUsingJavaScript(C2GTVBundlePrice, objectValue);
				 * report.reportPass("Click View Bundle Prices in Tv Plan",
				 * "View Bundle Prices should be clicked in Tv Plan",
				 * "Clicked on View Bundle Prices in Tv Plan"); } catch
				 * (Exception e) { strFailed =
				 * "Failed in Tv Plan, Bundle price not available.";
				 * logger.error(strFailed, e); report.reportFail(
				 * "Select Bundle tv plan",
				 * "TV bundle prices should be selected.", strFailed);
				 * report.updateMainReport("comments", strFailed);
				 * report.updateMainReport("ErrorMessage", strFailed);
				 * captureErrorMsg(strFailed); throw new
				 * UserDefinedException(strFailed); }
				 * 
				 * }
				 * 
				 * }
				 */
				// update for FCP

				// Getting Text of Selected TV
				String SelectedTV = getTextFromElement(simplex_SelectedTV, objectValue);
				System.out.println(SelectedTV);

				// To Upgrade or Downgrade TV
				if (tvPlan.toUpperCase().contains("UPGRADE") || tvPlan.toUpperCase().contains("DOWNGRADE")) {

					tvUpgradeDowngrade();

				} else if (tvPlan.equalsIgnoreCase("Deselect")) {

					Deselectservice("video");
					report.reportPass("Simplex Page  ordering - Verify able to Deselect Tv Plan",
							"Should be able to Deselect Tv Plan", "Able to Deselect Tv Plan");

				} else if (tvPlan.contains("Custom")) {

					pageScroll(showCustomTvLink, objectValue, true);
					clickUsingJavaScript(showCustomTvLink, objectValue);
					report.reportPass("Simplex Page  ordering - Verify able to Click Show Custom Tv",
							"Should be able to Click Show Custom Tv", "Able to Click Show Custom Tv");
					waitForLoader();
					if (!SelectedTV.toLowerCase().contains(tvPlan.toLowerCase())) {

						if (isDisplayed(lnkTVPlansCustomTv, tvPlan, 1)) {
							pageScroll(lnkTVPlansCustomTv, tvPlan, true);
							clickUsingJavaScript(lnkTVPlansCustomTv, tvPlan);
							report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.",
									"Clicked on " + tvPlan + " tv plan");

						} else if (isDisplayed(selectCustomTv, tvPlan, 1)) {
							pageScroll(selectCustomTv, tvPlan, true);
							clickUsingJavaScript(selectCustomTv, tvPlan);
							report.reportPass("Simplex Page  ordering - Verify able to Select Custom Tv",
									"Should be able to Select Custom Tv", "Able to Select Custom Tv");

						} else {
							pageScroll(clickCustomTv, objectValue, true);
							clickUsingJavaScript(clickCustomTv, objectValue);
							report.reportPass("Simplex Page  ordering - Verify able to Select Custom Tv",
									"Should be able to Select Custom Tv", "Able to Select Custom Tv");
						}
					}
				}

				else if (!SelectedTV.toLowerCase().contains(tvPlan.toLowerCase())) {

					try {
						if (isDisplayed(lnkTVPlans, tvPlan, 5)) {
							pageScroll(lnkTVPlans, tvPlan, true);
							clickUsingJavaScript(lnkTVPlans, tvPlan);
							//vikram scrtip start FCP
							
							waitForElementDisplay(fiosFivePopUp, objectValue, 10);
							if (!fiosFiveChannels.isEmpty() && tvPlan.contains("Fios Five")) {	
								
								String[] channelsList = fiosFiveChannels.split(",");
								
								int channelCount = channelsList.length;
								System.out.println("Channels arry count: " + channelCount);
								if(channelCount != 5){
									System.out.println("Needs to be total 5 channels for selection, check RM sheet");
									report.reportFail("Need to be total 5 channels for selection", "total 5 channels needs to be present", "total channels is not 5, count is: "+ channelCount);
								}
								
								for(int i=0; i<channelCount; i++){
									System.out.println("Channel :" + channelsList[i]);
								}
								
								for(String f5Channel : channelsList){
									System.out.println("Channel :" + f5Channel);
									
									try {
										f5Channel = f5Channel.trim();
										System.out.println("f5Channel: " + f5Channel);
										//switchToDefaultcontent();
										//WebElement channel = driver.findElement(By.xpath("//img[@ng-src='http://optixsit2.ebiz.verizon.com/CoFEE/Content/Simplex/Products/ProductsUI/Static/Images/FiosFive/"+f5Channel+".png']"));
										WebElement channel = driver.findElement(By.xpath("//img[@ng-src='http://optixsit2.ebiz.verizon.com/CoFEE/Content/Simplex/Products/ProductsUI/Static/Images/FiosFive/"+f5Channel+".png' or @ng-src='http://optixnte12.ebiz.verizon.com/CoFEE/Content/Simplex/Products/ProductsUI/Static/Images/FiosFive/"+f5Channel+".png']"));
										if (isDisplayed(channel)) {
											
											pageScroll(channel);
											channel.click();							
											report.reportPass("Clicks on the fios five channel tile", "Need to click fios five channel tile", "Clicked fios five channel tile");
										}
										

									}

									catch (Exception e) {
										System.out.println("Exception is :" + e.getMessage());						
										strFailed = "Failed in Fios Five channels section, Required Fios five channel "	+ f5Channel + " is not available.";
										report.reportFail("Select fios five channels", "fios five channels should be selected.", strFailed);

									}
								}
								Thread.sleep(2000);
								//wait(2);
								try{
								if(isDisplayed(f5PopUpText))
								{
									pageScroll(f5PopUpText);
									report.reportPass("Fios Five channels are included", "5 fios five channels must be selected", "Fios Five Channels are selected");									
								}
								if(isDisplayed(SaveFiosFiveProducts)){
									//SaveFiosFiveProducts.click();
									clickUsingJavaScript(SaveFiosFiveProducts, objectValue);
								}
								}
								catch(Exception e)
								{
									System.out.println("Exception message got at Fios 5 popUp is: " + e.getMessage());
								}
							}	
						
				
						
					
								else
							
							// update for FCP
							/*
							 * if(get("FlowType").equalsIgnoreCase("Install") &&
							 * tvPlan.contains("Ultimate")) { report.reportPass(
							 * "Click on tv plan" + tvPlan,
							 * "Tv plan should be clicked.", "Clicked on " +
							 * tvPlan + " tv plan");
							 * 
							 * if(isDisplayed(deselectTestDrive)) {
							 * pageScroll(deselectTestDrive);
							 * clickUsingJavaScript(deselectTestDrive, "");
							 * report.reportPass("Click on tv plan" + tvPlan,
							 * "Tv plan should be clicked.", "Clicked on " +
							 * tvPlan + " tv plan"); } } else {
							 * clickUsingJavaScript(lnkTVPlans, tvPlan);
							 * report.reportPass("Click on tv plan" + tvPlan,
							 * "Tv plan should be clicked.", "Clicked on " +
							 * tvPlan + " tv plan"); }
							 */
							// update for FCP
							report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.",
									"Clicked on " + tvPlan + " tv plan");
						} else {
							String x = getTextFromElement(firstHighestVideo, SelectedTV);
							System.out.println(x);
							if (!x.equals(SelectedTV)) {
								clickUsingJavaScript(firstHighestVideo, objectValue);
								report.reportPass("TV Plan is " + tvPlan + " not available",
										"TV plan " + tvPlan
												+ " not available so selected First Avaialble Highest Video",
										"TV plan " + tvPlan
												+ " not available so selected First Avaialble Highest Video:" + x);

							} else {
								report.reportPass("TV Plan is " + tvPlan + " not available",
										"TV plan " + tvPlan
												+ " not available so selected First Avaialble Highest Video",
										"TV plan " + tvPlan
												+ " not available so selected First Avaialble Highest Video: " + x);
							}

						}
					} catch (Exception e) {
						strFailed = "Failed in Tv plan, Required TV " + tvPlan + "  not available.";
						logger.error(strFailed, e);
						report.reportFail("Select TV plan", "TV plan should be selected.", strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						captureErrorMsg(strFailed);
						throw e;
					}

				} else if (SelectedTV.toLowerCase().contains(tvPlan.toLowerCase())
						&& get("FlowType").equalsIgnoreCase("Install")) {
					if (isDisplayed(lnkTVPlans, tvPlan, 5)) {
						pageScroll(lnkTVPlans, tvPlan, true);
						report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.",
								"Clicked on " + tvPlan + " tv plan");
						if (get("FlowType").equalsIgnoreCase("Install") && tvPlan.contains("Fios TV Test Drive")) {
							if (isDisplayed(ChkFiosTVTestDrive)) {
								pageScroll(ChkFiosTVTestDrive);
								clickUsingJavaScript(ChkFiosTVTestDrive, "");
								report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.",
										"Clicked on " + tvPlan + " tv plan");
							}
						}
					}
				} else if (SelectedTV.toLowerCase().contains(tvPlan.toLowerCase())) {
					report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.",
							"By default selected " + tvPlan + " tv plan, no need to select again.");
				}

			}

			// Mounika Polagoni (HLR Validations)

			if (get("HLRValidations").equalsIgnoreCase("Yes")) {
				String FiosTV2 = "";
				if (isDisplayed(simplex_SelectedTV, "", 3)) {

					if (getTextFromElement(simplex_SelectedTV, "").contains("Custom TV")) {
						String FiosTv = getTextFromElement(simplex_SelectedTV, objectValue);
						System.out.println(FiosTv);
						String FiTv[] = FiosTv.split("TV");
						System.out.println(FiTv[0]);
						put("Display Video", FiTv[0]);

					} else if (getTextFromElement(simplex_SelectedTV, "").contains("Standalone")) {
						String FiosTv = getTextFromElement(simplex_SelectedTV, objectValue);
						String FiTv[] = FiosTv.split("\\(");
						System.out.println(FiTv[0]);
						put("Display Video", FiTv[0]);
					} else if (getTextFromElement(simplex_SelectedTV, "").contains("Bundle")) {
						String FiosTv = getTextFromElement(simplex_SelectedTV, objectValue);
						String FiTv[] = FiosTv.split("\\(");
						System.out.println(FiTv[0]);
						put("Display Video", FiTv[0]);
					} else {
						FiosTV2 = simplex_SelectedTV.getText();
						put("Display Video", FiosTV2);
						System.out.println(FiosTV2);

						report.reportPass("Check Existing data on Profile", "Check Existing data on Profile",
								"Existing data on Profile is: " + FiosTV2);

					}

				}
			}

			// Collapsing TV
			if (getAttribute(expandTv, objectValue, "class").contains("open")) {
				pageScroll(expandTv, objectValue, true);
				clickUsingJavaScript(expandTv, objectValue);
			}

			// Switching to Default Content
			switchToDefaultcontent();

		} catch (Exception exe) {

			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in TV section.");
			}
			throw exe;
		}

		// Moving to Streaming services
		// selectVoicePlan();
		selectStreamingServices();
	}

	// Update For FCP
	// Select Streaming services @Meena
	/**
	 * @Description: selectStreamingServices is used to select the Streaming
	 *               Services for C2G and COA Change
	 * @author: Meena
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments: Added for new FCP update
	 */
	public void selectStreamingServices() throws Exception, UserDefinedException {

		System.out.println("->Select Streaming Services FCP");
		String streamserv = get("StreamingServices").trim();
		waitForLoader();
		switchToDefaultcontent();
		switchToFrame("IfProducts");
		if (!streamserv.isEmpty()) {
			// Expanding streaming services
			if (!getAttribute(expandstreamingServ, objectValue, "class").contains("open")) {
				pageScroll(expandstreamingServ, objectValue, true);
				clickUsingJavaScript(expandstreamingServ, objectValue);
				waitForLoader();
			}

			if (isDisplayed(clickYoutubeTv, streamserv, 5)) {
				pageScroll(clickYoutubeTv, streamserv, true);
				clickUsingJavaScript(clickYoutubeTv, streamserv);
				report.reportPass("streaming Services to be selected", "Streaming services selected",
						"Streaming services is selected");
			} else
				report.reportFail("streaming Services to be selected", "Streaming services not selected",
						"Streaming services is not selected");
		}

		// Moving to Voice Plan
		if (get("Project_ID").contains("FCP")) {

			selectVoicePlan_FCP();
		} else {
			selectVoicePlan();

		}
	}

	/**
	 * @Description: selectVoicePlan is used to change the Voice Plan for C2G
	 *               and COA Change
	 * @param: voicePlanDetails
	 *             is used to choose the Voice Plan
	 * @param: Standalone
	 *             is used to choose if Voice is Standalone
	 * @author: Mounika, Padmini
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */
	public void selectVoicePlan_FCP() throws Exception, UserDefinedException {

		System.out.println("->selectVoicePlanFCP");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		// select Voice type
		strDescription = "Validation of Voice plan";
		strExpected = "Voice plan should be selected.";
		strActual = "Selected voice plan";
		strFailed = "Failed to select voice plan due to page objects unavailability.";
		getUrl = ", URL Launched --> " + returnURL();

		try {

			String voicePlan = get("VoicePlan").trim();
			String standalone = get("Standalone").trim();
			String migrate = get("Migrate").trim();

			waitForLoader();

			// Switching to Products & Services Frame
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			if (get("HLRValidations").equalsIgnoreCase("Yes") && get("FlowType").equalsIgnoreCase("MoveAsIs")) // Gopal
																												// for
																												// Move
																												// AS
																												// IS
																												// Validation
																												// 11/13
			{

				String ExistingVoiceProduct = Existingvoiceproduct.getText().trim();

				if (Existingvoiceproduct.isDisplayed() && !ExistingVoiceProduct.isEmpty()) {
					try {

						String CurrentVoiceProduct = Currentvoiceproduct.getText().trim();

						System.out.println(ExistingVoiceProduct);

						System.out.println(CurrentVoiceProduct);

						if (ExistingVoiceProduct.equals(CurrentVoiceProduct)) {

							report.reportPass(
									"To verify if Existing and Current  Voice Product both are same for moveAsIs",
									"Existing and Current Voice Product both Sould be Same",
									"Existing and Current Voice Product both are same");
						} else {

							report.reportFail(
									"To verify if Existing and Current Voice Product both are same for moveAsIs",
									"Existing and Current Voice Product both Sould be Same",
									"Existing and Current Voice Product both are not same");
						}

					} catch (Exception e) {

						throw new UserDefinedException("Existing and Current Voice Product both are not same.");
					}
				}
			}

			if (!voicePlan.isEmpty()) {

				if (voicePlan.equalsIgnoreCase("FDV")) {
					// update for FCP
					// voicePlan = "Fios Digital Voice Unlimited";
					voicePlan = "Fios Digital Voice";
					// update for FCP
				}

				// Expand Voice
				if (!getAttribute(expandVoice, objectValue, "class").contains("open")) {
					pageScroll(expandVoice, objectValue, true);
					clickUsingJavaScript(expandVoice, objectValue);
					waitForLoader();
				}

				// Click view stand alone prices
				// update for FCP
				/*
				 * if (standalone.toLowerCase().contains("Voice".toLowerCase()))
				 * {
				 * 
				 * String S = getTextFromElement(viewStandaloneVoiceText,
				 * objectValue); System.out.println(S); if
				 * (S.contains("Standalone")) { try {
				 * clickUsingJavaScript(C2GVoiceStandalonePrice, objectValue);
				 * report.reportPass("Select Standalone Prices in Voice Plan",
				 * "View Standalone Prices should be clicked in Voice Plan",
				 * "Clicked on View Standalone Prices in Voice Plan"); } catch
				 * (Exception e) {
				 * 
				 * strFailed =
				 * "Failed in Voice plan, View standalone prices not available."
				 * ; logger.error(strFailed, e); report.reportFail(
				 * "Select standalone voice plan",
				 * "Voice standalone prices should be selected.", strFailed);
				 * report.updateMainReport("comments", strFailed);
				 * report.updateMainReport("ErrorMessage", strFailed);
				 * captureErrorMsg(strFailed); throw new
				 * UserDefinedException(strFailed); }
				 * 
				 * } waitForLoader(); } else { // Click View Bundle Prices
				 * String S = getTextFromElement(viewStandaloneVoiceText,
				 * objectValue); System.out.println(S); if
				 * (S.contains("Bundle")) { try {
				 * clickUsingJavaScript(C2GVoiceBundlePrice, objectValue);
				 * waitForLoader(); report.reportPass(
				 * "Select View Bundle Prices in Voice Plan",
				 * "View Bundle Prices clicked in Voice Plan",
				 * "clicked on View Bundle Prices in Voice Plan"); } catch
				 * (Exception e) {
				 * 
				 * strFailed =
				 * "Failed in Voice Plan, Bundle prices not available.";
				 * logger.error(strFailed, e); report.reportFail(
				 * "Select Bundle Voice plan",
				 * "Voice Bundle Plan should be selected.", strFailed);
				 * report.updateMainReport("comments", strFailed);
				 * report.updateMainReport("ErrorMessage", strFailed);
				 * captureErrorMsg(strFailed); throw new
				 * UserDefinedException(strFailed); }
				 * 
				 * } }
				 */

				// Deselect Voice Plan
				if (voicePlan.equalsIgnoreCase("Deselect")) {

					Deselectservice("voice");
					waitForLoader();
					report.reportPass("Deselect voice plan", "Voice plan should be deselected.",
							"Deselected voice plan");
					// Select the Voice Plan
				} else if (!voicePlan.isEmpty()) {

					String selectedVoice = getTextFromElement(simplex_SelectedVoice, objectValue);

					if (!selectedVoice.toLowerCase().contains(voicePlan.trim().toLowerCase())
							|| selectedVoice.trim().isEmpty()) {

						try {
							pageScroll(lnkVoicePlans, (voicePlan).trim(), true);
							clickUsingJavaScript(lnkVoicePlans, (voicePlan).trim());
							waitForLoader();
							switchToDefaultcontent();
							switchToFrame("IfProducts");
							// if(isDisplayed(MigrationtoFiosButton))
							// {
							// pageScroll(SelectFDVMigrateButton);
							// clickUsingJavaScript(SelectFDVMigrateButton, "");
							// waitForLoader();
							// }
							report.reportPass("Select voice plan" + voicePlan, "Voice plan should be selected.",
									"Selected voice plan" + voicePlan);
						} catch (Exception e) {
							strFailed = "Failed in Voice plan, Required Voice " + voicePlan + "  not available.";
							logger.error(strFailed, e);
							report.reportFail("Select Voice plan", "Voice plan should be selected.", strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							captureErrorMsg(strFailed);
							throw e;
						}

					} else if (selectedVoice.toLowerCase().contains(voicePlan.trim().toLowerCase())) {
						report.reportPass("Select voice plan" + voicePlan, "Voice plan should be selected.",
								"By default selected " + voicePlan + " voice plan, no need to select again.");
					}

				}

				waitForLoader();
				// Changing from FTTP to FDV
				if (migrate.equals("Y")) {
					report.reportPass("Select Migrate option", "Migrate option should be selected..",
							"Migrate Option should be selected");
					clickUsingJavaScript(selectMigrate, "");
					report.reportPass("Select Migrate option", "Migrate option should be selected..",
							"Selected voice migration option");

					if (!isDisplayed(expandVoice, migrate, 10)) {
						strFailed = "Failed in Voice Plan, Products Page grayed out on clicking Migrating to FDV";
						logger.error(strFailed);
						report.reportFail("Select Bundle Voice plan", "Voice Bundle Plan should be selected.",
								strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						captureErrorMsg(strFailed);
						throw new UserDefinedException(strFailed);
					}
				}

				waitForLoader();
				waitForLoader();

			}

			// Mounika Polagoni (HLR Validations)

			if (get("HLRValidations").equalsIgnoreCase("Yes")) {

				if (isDisplayed(simplex_SelectedVoice, "", 3)) {
					if (getTextFromElement(simplex_SelectedVoice, "").contains("Standalone")) {
						String FiVoice = getTextFromElement(simplex_SelectedVoice, objectValue);
						String FiosVoice[] = FiVoice.split("\\(");
						System.out.println(FiosVoice[0]);
						put("Display Voice", FiosVoice[0]);
					} else if (getTextFromElement(simplex_SelectedVoice, "").contains("Bundle")) {
						String FiVoice = getTextFromElement(simplex_SelectedVoice, objectValue);
						String FiosVoice[] = FiVoice.split("\\(");
						System.out.println(FiosVoice[0]);
						put("Display Voice", FiosVoice[0]);
					} else {
						String voicePlan2 = simplex_SelectedVoice.getText();
						put("Display Voice", voicePlan2);
						System.out.println(voicePlan2);
						report.reportPass("Check Existing data on Profile", "Check Existing data on Profile",
								"Existing data on Profile is: " + voicePlan2);

					}

				}
			}

			// Collapse Voice
			if (getAttribute(expandVoice, objectValue, "class").contains("open")) {
				pageScroll(expandVoice, objectValue, true);
				clickUsingJavaScript(expandVoice, objectValue);
				waitForLoader();
			}

			// Switching to Default Content
			switchToDefaultcontent();

		} catch (Exception exe) {
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				logger.error(strFailed, exe);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in Voice section.");
			}
			throw exe;
		}
		if (get("SelectPackage").contains("Get Prepaid Plans")) {
			selectEquipmentOptions();
		} else {

				selectContract_FCP();
			
		}
	}

	/**
	 * @Description: changeContract is used to change the Contract Term for C2G
	 *               and COA Change
	 * @param: Contract
	 *             is used to choose the Agreement and Offers Plan
	 * @param: Standalone
	 *             is used to choose if Voice is Standalone
	 * @author: Mounika, Padmini
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy: Rashmi
	 * @ModifiedDate: 13/01/2017
	 * @Comments: Added code for MoveASIS to validate contract
	 * @ModifiedBy: Jeevitha S
	 * @ModifiedDate: 17/02/2017
	 * @Comments: Added code Marketting Offer Validation
	 */
	public void selectContract_FCP() throws Exception, UserDefinedException {

		System.out.println("->selectContractFCP");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "Validation of Contract plan";
		strExpected = "Contract plan should be selected.";
		strActual = "Selected contract plan ";
		strFailed = "Failed to select contract plan due to page unavailability";
		getUrl = ", URL Launched --> " + returnURL();

		try {
			String contract = get("Contract").trim();
			String standalone = get("Standalone").trim();
			String coupon = get("Coupon").trim();
			String affinityCoupon = get("AffinityCoupon").trim();
			String DigitalCoupon = get("DigitalCoupon").trim();

			switchToDefaultcontent();
			switchToFrame("IfProducts");

			// Expand Contract
			if (!getAttribute(expandContract, objectValue, "class").contains("open")) {
				pageScroll(expandContract, objectValue, true);
				clickUsingJavaScript(expandContract, objectValue);

				waitForLoader();
				waitForLoader();
				waitForLoader();
				waitForLoader();
				report.reportPass("To View Agreement & Offers Section", "Display Agreement & Offers Section",
						"Agreement & Offers Section should be displayed");
			}
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			if (get("HLRValidations").equalsIgnoreCase("Yes") && get("FlowType").equalsIgnoreCase("MoveAsIs")) // Gopal
																												// for
																												// Move
																												// AS
																												// IS
																												// Validation
																												// 11/13
			{
				try {

					if (isDisplayed(contract2YearTerm_Selected)) {

						String selected_contract = contract2YearTerm_Selected.getText();
						System.out.println(selected_contract);

						if (selected_contract.contains("Move As Is")) {

							report.reportPass("To verify if 2 year contract is preselected for moveAsIs",
									"2 year contract moveAsIs should be preselected ",
									"2 year contract moveAsIs is PreSelected");
						} else {

							report.reportFail("To verify if 2 year contract is preselected for moveAsIs",
									"2 year contract moveAsIs should be preselected",
									"2 year contract moveAsIs is not PreSelected");
						}
					}

				} catch (Exception e) {

					throw new UserDefinedException("Element_validation - failed as 2 year contract is not PreSelected");
				}
			}
			if (isDisplayed(selectedContarct, DigitalCoupon, 3)) {
				String S = getTextFromElement(selectedContarct, objectValue);
				System.out.println(S);
				report.reportPass("Selected Contact", "Selected Contact", "Selected Contract is :" + S);
				if (S.contains("$10 Auto Pay") || (S.contains("$5 Auto Pay"))) {
					report.reportPass("Check Whether the customer is enrolled for Auto pay",
							"Verify Whether the customer is enrolled for Auto pay",
							"The customer is already enrolled for Auto pay" + S);
				} else if (S.contains("Declined")) {
					report.reportPass("Check Whether the Status of Auto pay", "Verify the status of Auto pay",
							"The customer has already declined for for Auto pay" + S);
				}
			}

			if (!contract.isEmpty() || !coupon.isEmpty() || !DigitalCoupon.isEmpty() || !affinityCoupon.isEmpty()) {
				// if (standalone.isEmpty()) {
				// Vikram , removed condition for SA data is empty, since it was
				// blocking SA auto pay decline scenario

				/*
				 * if(isDisplayed(Offers, DigitalCoupon, 3)){ //
				 * if(allAgreements.size()>0){ report.reportPass(
				 * "To View Agreement & Offers Section",
				 * "Display Agreement & Offers Section",
				 * "Agreement & Offers Section should be displayed"); } else{
				 * strFailed =
				 * "Failed in Agreement and offer section, Agreement offer section was not loaded."
				 * ; report.reportFail("Select Agreement",
				 * "Agreement and offer section should be selected.",
				 * strFailed); report.updateMainReport("comments", strFailed);
				 * report.updateMainReport("ErrorMessage", strFailed);
				 * logger.error(strFailed); captureErrorMsg(strFailed); throw
				 * new UserDefinedException(strFailed);
				 * 
				 * }
				 */

				if (!DigitalCoupon.isEmpty()) {
					if (isDisplayed(btnCoupon, objectValue, 1)) {
						clickUsingJavaScript(btnCoupon, objectValue);
						report.reportPass("Click on coupon link.", "Coupon link should be clicked.",
								"Clicked on coupon link");
					} else {
						strFailed = "Failed in Agreement and offer section, Coupon link is not available.";
						report.reportFail("Click on coupon link.", "Coupon link should be clicked.", strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						logger.error(strFailed);
						captureErrorMsg(strFailed);
						throw new UserDefinedException(strFailed);
					}
					waitForLoader();
					waitForLoader();
					try {
						setText(Digitalcoupon, objectValue, DigitalCoupon);
						report.reportPass("Enter coupon.", "Coupon should be entered.",
								"Entered coupon " + DigitalCoupon);
						clickUsingJavaScript(verifyDigitalCoupon, objectValue);
						waitForLoader();
						waitForLoader();
						waitForLoader();
						if (isDisplayed(ValidDigitalCoupon)) {
							report.reportPass("Click on verify button.", "Verify button should be clicked.",
									"Clicked on verify coupon button.");
							waitForLoader();
							// clickUsingJavaScript(selectCoupon,
							// objectValue);
							report.reportPass("Selecte coupon", "Coupon should be selected.", "Selected coupon");
							clickUsingJavaScript(applyCoupon, objectValue);
							report.reportPass("Negotiate Coupon", "Coupon should be validated.",
									"Validated " + DigitalCoupon + " Coupon.");
							waitForLoader();
							waitForLoader();
							waitForLoader();

						}

						else {
							if (isDisplayed(invalidDigitalCoupon, "", 3)) {
								strFailed = "Failed in Agreement and offer section, Failed to validate Digital coupon.";
								report.reportFail("Vlidate coupon", "Coupon section should be validated.", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								logger.error(strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							}

							else {
								report.reportPass("Click on verify button.", "Verify button should be clicked.",
										"Clicked on verify coupon button.");
							}
							waitForLoader();
							clickUsingJavaScript(selectCoupon, objectValue);
							report.reportPass("Selecte coupon", "Coupon should be selected.", "Selected coupon");
							clickUsingJavaScript(applyCoupon, objectValue);
							report.reportPass("Negotiate Coupon", "Coupon should be validated.",
									"Validated " + DigitalCoupon + " Coupon.");
							waitForLoader();
							waitForLoader();

						}
					}

					catch (Exception e) {
						strFailed = "Failed in Agreement and offer section, Coupon validation failed." + DigitalCoupon;
						report.reportFail("Validate coupon", "Failed to validate coupon.", strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						logger.error(strFailed);
						captureErrorMsg(strFailed);
						throw new UserDefinedException(strFailed);
					}
				}
				/*
				 * if (contract.contains("M2M") && contract.contains("Decline"))
				 * { if (isDisplayed(contractViewOnlyM2MTerm, "", 3)) {
				 * pageScroll(contractViewOnlyM2MTerm, objectValue, true);
				 * clickUsingJavaScript(contractViewOnlyM2MTerm, objectValue);
				 * report.reportPass( "Select View Only M2M term",
				 * "View Only M2M term should be clicked.",
				 * "Clicked View Only M2M term"); waitForLoader(); }
				 * if(isDisplayed(autoPayM2MDecline, "", 2)){
				 * clickUsingJavaScript(autoPayM2MDecline, objectValue);
				 * report.reportPass("Select Auto Pay decline",
				 * "Auto Pay decline", "Selected Auto Pay decline");
				 * waitForLoader(); }
				 * 
				 * } else if (contract.contains("2Year") &&
				 * contract.contains("Decline")) { if
				 * (isDisplayed(contractViewOnlyM2MTerm, "", 3)) {
				 * pageScroll(contractViewOnlyM2MTerm, objectValue, true);
				 * clickUsingJavaScript(contractViewOnlyM2MTerm, objectValue);
				 * report.reportPass( "Select View Only M2M term",
				 * "View Only M2M term should be clicked.",
				 * "Clicked View Only M2M term"); waitForLoader(); }
				 * 
				 * if(isDisplayed(autoPay2YearDecline, "", 1)){
				 * clickUsingJavaScript(autoPayM2MDecline, objectValue);
				 * report.reportPass("Select Auto Pay decline",
				 * "Auto Pay decline should be selected.",
				 * "Selected Auto Pay decline"); waitForLoader(); } }
				 */
				try {
					if (contract.contains("AutoPayAccept")) {

						if (isDisplayed(rdAutoPayYes, DigitalCoupon, 2)) {
							clickUsingJavaScript(rdAutoPayYes, objectValue);
							// clickUsingJavaScript(rdAutoPayYes, objectValue);
							report.reportPass("select Auto pay and paper free billing discount",
									"Auto pay and paper free billing discount should be selected",
									"Auto pay and paper free billing discount is selected");
							waitForLoader();
							waitForLoader();
							waitForLoader();

						}

						else if (!isSelected(AutoPaychkDeclineorAccept)) {

							try {

								clickUsingJavaScript(AutoPaychkDeclineorAccept, objectValue);
								report.reportPass("select Auto pay and paper free billing discount",
										"Auto pay and paper free billing discount should be selected",
										"Auto pay and paper free billing discount is selected");

							} catch (Exception ex) {
								strFailed = "Auto pay and paper free billing discount is selected";
								report.reportPass("select Auto pay and paper free billing discount",
										"Auto pay and paper free billing discount should be selected",
										"Auto pay and paper free billing discount is not selected");
								/*
								 * report.updateMainReport("comments",
								 * strFailed);
								 * report.updateMainReport("ErrorMessage",
								 * strFailed); captureErrorMsg(strFailed); throw
								 * new UserDefinedException(strFailed);
								 */

							}
						} else {

						}

					} else if (contract.contains("AutoPayDecline")) {

						if (isDisplayed(rdAutoPayNo, DigitalCoupon, 2)) {

							clickUsingJavaScript(rdAutoPayNo, objectValue);
							report.reportPass("Deselect Auto pay and paper free billing discount",
									"Auto pay and paper free billing discount should be Deselected",
									"Auto pay and paper free billing discount is Deselected");
							waitForLoader();
							waitForLoader();
							waitForLoader();

						}

						else if (isSelected(AutoPaychkDeclineorAccept)) {

							try {

								clickUsingJavaScript(AutoPaychkDeclineorAccept, objectValue);
								report.reportPass("Deselect Auto pay and paper free billing discount",
										"Auto pay and paper free billing discount should be Deselected",
										"Auto pay and paper free billing discount is Deselected");

							} catch (Exception ex) {
								strFailed = "Auto pay and paper free billing discount is not Deselected";
								report.reportPass("Deselect Auto pay and paper free billing discount",
										"Auto pay and paper free billing discount should be Deselected",
										"Auto pay and paper free billing discount is not Deselected");
								/*
								 * report.updateMainReport("comments",
								 * strFailed);
								 * report.updateMainReport("ErrorMessage",
								 * strFailed); captureErrorMsg(strFailed); throw
								 * new UserDefinedException(strFailed);
								 */

							}
						} else {

						}

					}

					else if (isDisplayed(rdAutoPayNo, DigitalCoupon, 2)) {

						clickUsingJavaScript(rdAutoPayNo, objectValue);
						report.reportPass("Deselect Auto pay and paper free billing discount",
								"Auto pay and paper free billing discount should be Deselected",
								"Auto pay and paper free billing discount is Deselected");
						waitForLoader();
						waitForLoader();
						waitForLoader();

					}
				} catch (Exception ex) {

				}

				// To Select Month to Month or 2 Year Contract
				if (contract.contains("M2M") || contract.contains("2Year")) {

					if (contract.contains("M2M")) {
						if (isDisplayed(contractViewOnlyM2MTerm, "", 3)) {
							// pageScroll(contractViewOnlyM2MTerm, objectValue,
							// true);
							clickUsingJavaScript(contractViewOnlyM2MTerm, objectValue);
							report.reportPass("Select View Only M2M term", "View Only M2M term should be clicked.",
									"Clicked View Only M2M term");
							waitForLoader();
							clickUsingJavaScript(contractM2MTerm, objectValue);
							report.reportPass("Select Month to Month Agreement",
									"Month to month agreement should be selected.",
									"Selected Month to Month agreement.");
							waitForLoader();
						}

						else if (isDisplayed(contractM2MTerm, "", 3)) {

							clickUsingJavaScript(contractM2MTerm, objectValue);
							report.reportPass("Select Month to Month Agreement",
									"Month to month agreement should be selected.",
									"Selected Month to Month agreement.");
							waitForLoader();
						}
						// Vikram Gomez script start
						else if (isDisplayed(contractSAM2M, "", 3)) {

							clickUsingJavaScript(contractSAM2M, objectValue);
							report.reportPass("Select Month to Month Agreement",
									"Month to month agreement should be selected.",
									"Selected Month to Month agreement.");
							waitForLoader();
						}
						// Vikram Gomez script end
						else if (isDisplayed(contractNoContract, "", 1)) {
							clickUsingJavaScript(contractNoContract, objectValue);
							report.reportPass("Select Month to Month Agreement",
									"Month to month agreement should be selected.",
									"Selected Month to Month agreement.");
							waitForLoader();
						}

						else {
							strFailed = "Failed in Agreement and offers section, Month to Month plan not available.";
							logger.error(strFailed);
							report.reportFail("Select Month to month plan in agreement section",
									"Month to month agreement should be selected.", strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}

					} else if (contract.contains("2Year")) {

						boolean twoyearofferselected = false;

						if (isDisplayed(contractViewOnly2YrTerm, "", 3)) {
							pageScroll(contractViewOnly2YrTerm, objectValue, true);
							clickUsingJavaScript(contractViewOnly2YrTerm, objectValue);
							waitForLoader();
							report.reportPass("Select 2Year Agreement", "2Year agreement should be selected.",
									"Selected 2Year agreement.");
							if (get("OfferValidation").equalsIgnoreCase("Yes")) {
								if (isDisplayed(viewOfferDetails, objectValue, 2)) {
									clickUsingJavaScript(viewOfferDetails, objectValue);
									waitForLoader();
									String x = getTextFromElement(availableOffersDetails, objectValue);
									System.out.println(x);
									report.reportPass("Available Offer Details in Contract",
											"View Available Offer Details in Contract", "Available Offers are: " + x);
									clickUsingJavaScript(closeButton, objectValue);
									waitForLoader();
								}
							}
						}
						if (isDisplayed(NoAgreementOffers, "", 3)) {
							clickUsingJavaScript(NoAgreementOffers, objectValue);
							waitForLoader();
						}

						for (Element contractelement : contract2YearTerm) {
							if (isDisplayed(contractelement, "", 3)) {

								clickUsingJavaScript(contractelement, objectValue);
								twoyearofferselected = true;
								waitForLoader();
								report.reportPass("Select 2Year Agreement", "2Year agreement should be selected.",
										"Selected 2Year agreement.");
								if (get("OfferValidation").equalsIgnoreCase("Yes")) {
									if (isDisplayed(viewOfferDetails, objectValue, 2)) {
										clickUsingJavaScript(viewOfferDetails, objectValue);
										waitForLoader();
										String x = getTextFromElement(availableOffersDetails, objectValue);
										System.out.println(x);
										report.reportPass("Available Offer Details in Contract",
												"View Available Offer Details in Contract",
												"Available Offers are: " + x);
										clickUsingJavaScript(closeButton, objectValue);
										waitForLoader();
									}
								}

								break;
							}
						}

						if (isDisplayed(contractTryMe2year, "", 3) && !twoyearofferselected) {

							clickUsingJavaScript(contractTryMe2year, objectValue);
							waitForLoader();
							report.reportPass("Select 2Year Agreement", "2Year agreement should be selected.",
									"Selected 2Year agreement.");
							if (get("OfferValidation").equalsIgnoreCase("Yes")) {
								if (isDisplayed(viewOfferDetails, objectValue, 2)) {
									clickUsingJavaScript(viewOfferDetails, objectValue);
									waitForLoader();
									String x = getTextFromElement(availableOffersDetails, objectValue);
									System.out.println(x);
									report.reportPass("Available Offer Details in Contract",
											"View Available Offer Details in Contract", "Available Offers are: " + x);
									clickUsingJavaScript(closeButton, objectValue);
									waitForLoader();
								}
							}
						} else if (!twoyearofferselected) {
							strFailed = "Failed in Agreement and offers section, 2Year plan not available.";
							logger.error(strFailed);
							report.reportFail("Select 2Year plan in agreement section",
									"2Year agreement should be selected.", strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}

					}

				}
				// To Select Renew If Data or TV or Voice is Standalone
				else if (contract.contains("Renew") && (!standalone.isEmpty())) {

					if (isDisplayed(contractRenewM2MStandalone, "")) {
						clickUsingJavaScript(contractRenewM2MStandalone, "");
						report.reportPass("Renew standalone Month to Month plan",
								"Month to month plan should be selected.",
								"Clicked on Standalone month to month renew plan");

					}

					else if (isDisplayed(contractRenew2YearStandalone, "")) {
						clickUsingJavaScript(contractRenew2YearStandalone, "");
						report.reportPass("Renew standalone 2Year plan", "2Year plan should be selected.",
								"Clicked on Standalone 2Year renew plan");

					}

				}

				// To Renew Contract for Bundle
				else if (contract.contains("Renew")) {
					try {
						if (isDisplayed(contractRenewM2MBundle, objectValue)) {
							clickUsingJavaScript(contractRenewM2MBundle, objectValue);
							report.reportPass("Renew Bundle Month to Month plan",
									"Month to month plan should be selected.",
									"Clicked on Bundle month to month renew plan");

						} else if (isDisplayed(contractRenew2YearBundle, objectValue)) {
							pageScroll(contractRenew2YearBundle, objectValue, true);
							clickUsingJavaScript(contractRenew2YearBundle, objectValue);
							report.reportPass("Renew Bundle 2Year plan", "2Year plan should be selected.",
									"Clicked on Bundle 2Year renew plan");
							if (isDisplayed(okbtn, objectValue, 3)) {
								clickUsingJavaScript(okbtn, objectValue);
							}

							waitForLoader();
							waitForLoader();

							if (isDisplayed(SelectedcontractRenew2Year, DigitalCoupon, 3)) {
								report.reportPass("Renew Bundle 2Year plan", "2Year plan should be selected.",
										"Clicked on Bundle 2Year renew plan");
							} else {
								pageScroll(RenewContract, objectValue, true);
								clickUsingJavaScript(RenewContract, objectValue);
								report.reportPass("Renew Bundle 2Year plan", "2Year plan should be selected.",
										"Clicked on Bundle 2Year renew plan");

								// Anu added
								if (isDisplayed(okbtn, objectValue, 3)) {
									clickUsingJavaScript(okbtn, objectValue);
								}
								waitForLoader();
								waitForLoader();
								pause();
							}

						}

						else if (isDisplayed(contractRenew2YearBundleFuture, objectValue)
								&& isDisplayed(contractRenew2YearBundle, objectValue)) {
							clickUsingJavaScript(contractRenew2YearBundleFuture, objectValue);
							report.reportPass("Renew Bundle 2Year plan", "2Year plan should be selected.",
									"Clicked on Bundle 2Year renew plan");

						} else if (!isDisplayed(contractRenew2YearBundle, objectValue)
								&& isDisplayed(contractRenew2YearBundle, objectValue)) {
							clickUsingJavaScript(contractRenew2YearBundle, objectValue);

							if (contract.contains(",")) {
								String[] arrOfStr = contract.split(",");
								clickUsingJavaScript(contractRenew2YearBundleOffer, arrOfStr[1]);
							}

							report.reportPass("Renew Bundle 2Year plan", "2Year plan should be selected.",
									"Clicked on Bundle 2Year renew plan");
						}
					} catch (Exception e) {
					}
				}

				else if (contract.contains("MoveASIS")) {
					try {

						contract2YearTerm_Selected.isDisplayed();

						String selected_contract = contract2YearTerm_Selected.getText();
						System.out.println(selected_contract);

						report.reportPass("To verify if 2 year contract is preselected for moveAsIs",
								"2 year contract should be preselected ", "2 year contract is PreSelected");

					} catch (Exception e) {
						report.reportFail("To verify if 2 year contract is preselected for moveAsIs",
								"2 year contract should be preselected", "2 year contract is not PreSelected");
						throw new UserDefinedException(
								"Element_validation - failed as 2 year contract is not PreSelected");
					}
				} else if (contract.contains("KeepCurrentTerm")) {
					clickUsingJavaScript(contractRenew2YearBundle, objectValue);
					waitForLoader();
					waitForLoader();
					report.reportPass("Negotiate Contract", "Select Contract Term if available",
							"Selected Contract: " + contract);
				}

				report.reportPass("Negotiate Contract", "Select Contract Term if available",
						"Selected Contract: " + contract);
				if (!DigitalCoupon.isEmpty()) {
					List<WebElement> lst = driver.findElements(By.xpath(
							"//div[@class='ng-scope']/div[contains(@class,'w_tiles') and (not(contains(@class,'tiny')))]/div"));
					for (int i = 0; i < lst.size(); i++) {
						System.out.println(lst.size());
						String list1 = lst.get(i).getText();
						System.out.println(list1);
						if (list1.contains("$15 HD Set-Top Box")) {

							report.reportPass("Coupon Validations", "Coupon section details", lst.get(i).getText());
							System.out.println(list1);
							if (isDisplayed(notselectedcontract, list1)) {
								lst.get(i).click();
								report.reportPass("Select Term", "Select Term", "Required Term is Selected");
								break;

							}
						}
					}
				}

				if (!coupon.isEmpty() || !affinityCoupon.isEmpty()) {

					waitForLoader();
					if (isDisplayed(btnCoupon, objectValue, 1)) {
						clickUsingJavaScript(btnCoupon, objectValue);
						report.reportPass("Click on coupon link.", "Coupon link should be clicked.",
								"Clicked on coupon link");
					} else {
						strFailed = "Failed in Agreement and offer section, Coupon link is not available.";
						report.reportFail("Click on coupon link.", "Coupon link should be clicked.", strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						logger.error(strFailed);
						captureErrorMsg(strFailed);
						throw new UserDefinedException(strFailed);
					}

					waitForLoader();
					waitForLoader();
					if (!coupon.isEmpty()) {
						try {
							setText(enterCoupon, objectValue, coupon);
							report.reportPass("Enter coupon.", "Coupon should be entered.", "Entered coupon " + coupon);
							clickUsingJavaScript(verifyCoupon, objectValue);
							if (isDisplayed(invalidCoupon, "", 3)) {
								strFailed = "Failed in Agreement and offer section, Failed to validate coupon.";
								report.reportFail("Vlidate coupon", "Coupon section should be validated.", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								logger.error(strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							} else {
								report.reportPass("Click on verify button.", "Verify button should be clicked.",
										"Clicked on verify coupon button.");
							}
							waitForLoader();
							clickUsingJavaScript(selectCoupon, objectValue);
							report.reportPass("Selecte coupon", "Coupon should be selected.", "Selected coupon");
							clickUsingJavaScript(applyCoupon, objectValue);
							report.reportPass("Negotiate Coupon", "Coupon should be validated.",
									"Validated " + coupon + " Coupon.");
							waitForLoader();
							waitForLoader();
							waitForLoader();
							switchToDefaultcontent();
							switchToFrame("IfProducts");

						} catch (Exception e) {
							strFailed = "Failed in Agreement and offer section, Coupon validation failed." + coupon;
							report.reportFail("Validate coupon", "Failed to validate coupon.", strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							logger.error(strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}
					}
					if (!affinityCoupon.isEmpty()) {
						setText(affinitycoupon, objectValue, affinityCoupon);
						report.reportPass("Enter coupon.", "Coupon should be entered.",
								"Entered coupon " + affinityCoupon);
						clickUsingJavaScript(verifyoffercode, objectValue);
						if (isDisplayed(invalidCoupon, "", 3)) {
							strFailed = "Failed in Agreement and offer section, Failed to validate coupon.";
							report.reportFail("Vlidate coupon", "Coupon section should be validated.", strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							logger.error(strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						} else {
							report.reportPass("Click on verify button.", "Verify button should be clicked.",
									"Clicked on verify coupon button.");
						}

					}

				}
				// }

			}
			// Added for Marketing Offer Validation
			if (!get("MarketingOfferType").isEmpty()) {
				System.out.println("->Validating Marketing Offer");
				MarketingOffValidation();
			}

			if (isDisplayed(rdAutoPayNo, DigitalCoupon, 2)) {
				if (!isSelected(rdAutoPayNo, DigitalCoupon)) {

					clickUsingJavaScript(rdAutoPayNo, objectValue);
					report.reportPass("Deselect Auto pay and paper free billing discount",
							"Auto pay and paper free billing discount should be Deselected",
							"Auto pay and paper free billing discount is Deselected");
					waitForLoader();
					waitForLoader();
					waitForLoader();
					if (isDisplayed(contractViewOnlyM2MTerm, "", 3)) {
						// pageScroll(contractViewOnlyM2MTerm, objectValue,
						// true);
						clickUsingJavaScript(contractViewOnlyM2MTerm, objectValue);
						report.reportPass("Select View Only M2M term", "View Only M2M term should be clicked.",
								"Clicked View Only M2M term");
						waitForLoader();
						clickUsingJavaScript(contractM2MTerm, objectValue);
						report.reportPass("Select Month to Month Agreement",
								"Month to month agreement should be selected.", "Selected Month to Month agreement.");
						waitForLoader();
					}

					else if (isDisplayed(contractM2MTerm, "", 3)) {

						clickUsingJavaScript(contractM2MTerm, objectValue);
						report.reportPass("Select Month to Month Agreement",
								"Month to month agreement should be selected.", "Selected Month to Month agreement.");
						waitForLoader();
					} else if (isDisplayed(contractNoContract, "", 1)) {
						clickUsingJavaScript(contractNoContract, objectValue);
						report.reportPass("Select Month to Month Agreement",
								"Month to month agreement should be selected.", "Selected Month to Month agreement.");
						waitForLoader();
					}
				}

			}
			if (isDisplayed(selectedContarct, DigitalCoupon, 3)) {
				String S = getTextFromElement(selectedContarct, objectValue);
				System.out.println(S);
				report.reportPass("Selected Contact", "Selected Contact", "Selected Contract is :" + S);
				if (S.contains("$10 Auto Pay") || (S.contains("$5 Auto Pay"))) {
					report.reportPass("Selected Contact", "Selected Contact",
							"Selected Contract Contains Auto pay Discount:" + S);
				}

			}

			// Expand Contract
			if (isDisplayed(expandContract, "", 1)) {
				// Expand Contract
				if (getAttribute(expandContract, objectValue, "class").contains("open")) {
					pageScroll(expandContract, objectValue, true);
					clickUsingJavaScript(expandContract, objectValue);
					waitForLoader();
				}
			}

			// Switching to Default Content
			switchToDefaultcontent();

		} catch (Exception exe) {
			if (!isUserDefinedException(exe)) {

				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in Agreements section.");
			}
			throw exe;
		}
		// FCP update
		if (get("Project_ID").contains("FCP")) {
		offerTileValidation();
		}
		if (get("FlowType").toLowerCase().contains("move") && get("Application").equalsIgnoreCase("COA")
				&& !get("ProfileTypeSelection").equals("")
				|| get("FlowType").toLowerCase().contains("Change") && get("Application").equalsIgnoreCase("COA")
						&& get("OPOCheck").equalsIgnoreCase("Yes") && !get("ProfileTypeSelection").equals("")) {

			OPOMoveProdCheck();
		} else {

			selectvoiceOptions();

		}
	}

	public void selectInternetPlan() throws Exception, UserDefinedException

    {

	System.out.println("->selectInternetPlan");
	String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
	getUrl = ", URL Launched --> " + returnURL();

	String internetPlan = get("InternetPlan").trim();
	String standalone = get("Standalone").trim();
	String contract = get("Contract").trim();

	try {

	    waitForLoader();
	    // Switching to Default Content
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	   

	    String FiosData = "";
	    if (isDisplayed(simplex_SelectedData, "", 3)) {
		FiosData = getTextFromElement(simplex_SelectedData, objectValue);

	    }
	    report.reportPass("To View Whether OPO is Loaded","Verify Whether OPO is Loaded", "OPO Should be Loaded");
	    
	    waitForLoader();
	    // Switching to Default Content
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    
	    if (get("HLRValidations").equalsIgnoreCase("Yes") && get("FlowType").equalsIgnoreCase("MoveAsIs"))   //Gopal for Move AS IS Validation 11/13
		{
	
	 		  System.out.println(Existingdataproduct.getText().trim());
	 		  String ExistingDataspeed  = Existingdataproduct.getText().trim();
	 		
	 		if(Existingdataproduct.isDisplayed() && !ExistingDataspeed.isEmpty())
			{
	 			try {

					
	 				System.out.println(ExistingDataspeed);
	 				String[] ExistingDataSpeed=ExistingDataspeed.split("\\(");
	 				System.out.println(ExistingDataSpeed[0]);
	 				
	 				String CureentDataspeed = Currentdataspeed.getText();
	 				System.out.println(CureentDataspeed);
	 				String[] CureentDataSpeed=CureentDataspeed.split("\\(");
	 				System.out.println(CureentDataSpeed[0]);
	 			
	 				 
	 				if(ExistingDataSpeed[0].contains(CureentDataSpeed[0]))
	 				{

	 				report.reportPass("To verify if Existing and Current Data Speed's both are same for moveAsIs",
	 						"Existing and Current Data Speed's both Sould be Same", "Existing and Current Data Speed's both are same");
	 				}
	 				else{
	 					

	 					report.reportFail("To verify if Existing and Current Data Speed's both are same for moveAsIs",
	 							"Existing and Current Data Speed's both Sould be Same", "Existing and Current Data Speed's both are not same");
	 				} 

	 			} catch (Exception e) {
	 				
	 				throw new UserDefinedException(
	 						"Existing and Current Data Speed's both are not same");
	 			}
	 		
	 		
			}
	 		
	  }
	    
	    if (!internetPlan.isEmpty() || (standalone.contains("Data")) || (!FiosData.isEmpty())) {

		// Expand Internet
		if (!getAttribute(expandInternet, objectValue, "class").contains("open")) {
		    pageScroll(expandInternet, objectValue, true);
		    clickUsingJavaScript(expandInternet, objectValue);
		}
	    waitForLoader();

		// Checking Internet Section loaded or not.

		try {
			if(isDisplayed(allInternetSpeeds))
			{     
			waitForElementDisplay(allInternetSpeeds, "", pageTimeoutInSeconds);
			}
		} catch (Exception e) {

		    strFailed = "Failed in internet plan, Internet section was not loaded even after " + pageTimeoutInSeconds + " seconds.";
		    report.reportFail("Select Internet plan", "Internet  plan should be selected.", strFailed);
		    report.updateMainReport("comments", strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		    logger.error(strFailed);
		    captureErrorMsg(strFailed);
		    throw new UserDefinedException(strFailed);

		}
	    waitForLoader();

		// To Click View Standalone Prices
		if (standalone.toLowerCase().contains("Data".toLowerCase())) {

		    String S = getTextFromElement(viewStandaloneText, "");
		    System.out.println(S);
		    if (S.contains("Standalone")) {
			try {
			    clickUsingJavaScript(lnkDataViewStandaone, objectValue);
			    report.reportPass("Click on standalone prices", "Standalone prices should be clicked.", "Clicked on View Standalone Prices in Internet Plan");
			} catch (Exception e) {

			    strFailed = "Failed in internet plan, View standalone prices not available.";
			    logger.error(strFailed, e);
			    report.reportFail("Select standalone plan", "Internet standalone prices should be selected.", strFailed);
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);
			}

		    }

		    // To Click Month to Month Plans
		   /* if (contract.equalsIgnoreCase("M2M")) {
			try {
			    clickUsingJavaScript(contractM2M, objectValue);
			    report.reportPass("Select Month to Month", "Month to Month plan should be selected.", "Selected INternet Month to Month plan");
			    waitForLoader();
			} catch (Exception e) {

			    strFailed = "Failed in internet plan, Month to Month plan not available.";
			    logger.error(strFailed, e);
			    report.reportFail("Select Month to month plan", "Internet Monthly plan should be selected.", strFailed);
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);
			}

		    }*/

		    // To Click 2 Year Agreement Plans
		    /*else if (contract.equalsIgnoreCase("2Year")) {

			if (isDisplayed(contract2Year, objectValue, 0)) {
			    try {

				clickUsingJavaScript(contract2Year, objectValue);
				report.reportPass("Select 2Year", "2Year plan should be selected.", "Selected Internet Month to Month2Year plan");
				waitForLoader();

			    } catch (Exception e) {

				strFailed = "Failed in internet plan, 2Year plan not available.";
				logger.error(strFailed, e);
				report.reportFail("Select 2Year plan", "Internet 2Year plan should be selected.", strFailed);
				report.updateMainReport("comments", strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg(strFailed);
				throw new UserDefinedException(strFailed);
			    }

			}

		    } */

		} else {
		    // Click View Bundle Prices
		    String S = getTextFromElement(viewStandaloneText, objectValue);
		    System.out.println(S);
		    if (S.contains("Bundle")) {

			try {
			    clickUsingJavaScript(lnkDataViewBundle, objectValue);
			    report.reportPass("Simplex Page  ordering - Verify able to click View Bundle Prices in Internet Plan", "Should be able to click View Bundle Prices in Internet Plan",
				    "Able to click View Bundle Prices in Internet Plan");
			} catch (Exception e) {
			    strFailed = "Failed in Internet Plan, Bundle prices not available.";
			    logger.error(strFailed, e);
			    report.reportFail("Select Bundle Internet plan", "Internet bundle prices should be selected.", strFailed);
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);
			}

		    }
		}
	    waitForLoader();

		// Getting the Text of Selected Data
		String SelectedData = getTextFromElement(simplex_SelectedData, objectValue);
		SelectedData = SelectedData.split("[(][a-zA-Z]*[)]", 2)[0].trim();
		System.out.println(SelectedData);

		// To Upgrade or Downgrade Internet
		if ((internetPlan.contains("Upgrade")) || (internetPlan.contains("Downgrade"))) {

		    internetUpgradeDowngrade();

		} else if (internetPlan.equalsIgnoreCase("Deselect")) {

		    Deselectservice("internet");
		    report.reportPass("Simplex Page  ordering - Verify able to Deselect Internet Plan", "Should be able to Deselect Internet Plan", "Able to Deselect Internet Plan");

		}

		// To Click the Internet Plan Given in the Run Manager Sheet
		else if ((!internetPlan.isEmpty()) && (!SelectedData.equalsIgnoreCase(internetPlan))) {

		    try {
		    	if(isDisplayed(lnkInternetPlans, internetPlan, 5)){
					pageScroll(lnkInternetPlans, internetPlan, true);
					clickUsingJavaScript(lnkInternetPlans, internetPlan);
					report.reportPass("Select Internet Plan: " + internetPlan, "Internet plan should be selected.", "Selected internet plan: " + internetPlan);

					//----------------------Digital Billing Update ---------------------------------------
					try{
						String DB = null;
						
						if(isDisplayed(Digital_billing_enrollment,"",3)){
						pageScroll(Digital_billing_enrollment);
						 DB=  getTextFromElement(Digital_billing_enrollment_Message, objectValue);
						System.out.println("Digital_billing_enrollment message is displayed");
						report.reportPass("Digital Billing enrollment message should be  displayed: " + DB, "Digital Billing enrollment message is  displayed: " + DB, "Digital Billing message is " + DB); 
						}
						//Digital billing NJ check box
						if(isDisplayed(Digital_billing_enrollment_NJCheckbox,"",3)){
							pageScroll(Digital_billing_enrollment_NJCheckbox);
							clickUsingJavaScript(Digital_billing_enrollment_NJCheckbox, objectValue);														
							System.out.println("Digital billing Check box is displayed and selected for NJ address");
							report.reportPass("Digital Billing enrollment Checkbox should be displayed for NJ address", "Digital Billing enrollment Checkbox is displayed for NJ address", "Digital Billing enrollment Checkbox is displayed for NJ address and it is selected"); 
						 }
					     else {
						    System.out.println("Digital billing Check box is not displayed and not selected for NJ address");
						    report.reportPass("Digital Billing enrollment Checkbox should be displayed for NJ address", "Digital Billing enrollment Checkbox is not displayed for NJ address", "Digital Billing enrollment Checkbox is not displayed for NJ address and it is not selected"); 
						     }
					
						//Digital_billing_enrollment_review
						if(isDisplayed(Digital_billing_enrollment_review,"",3)){
							pageScroll(Digital_billing_enrollment_review);
							Thread.sleep(3000);
							clickUsingJavaScript(Digital_billing_enrollment_review, objectValue);														
							Thread.sleep(3000);
							System.out.println("Digital billing please review is displayed and clicked");
							report.reportPass("Digital Billing enrollment please review should be displayed", "Digital Billing enrollment please review is displayed", "Digital Billing enrollment please review is displayed and it is clicked"); 
						 }
					     else {
						    System.out.println("Digital billing please review is not displayed and not clicked");
						    report.reportPass("Digital Billing enrollment please review should be displayed", "Digital Billing enrollment please review is displayed", "Digital Billing enrollment please review is displayed and it is clicked"); 
						     }
						
						   
					    }
					catch(Exception e){
						System.out.println("Digital_billing_enrollment message is not displayed");
						report.reportFail("Digital Billing enrollment message should be  displayed: ", "Digital Billing enrollment message is not displayed: " , "Digital Billing message is not displayed ");
						} 
				    	}
		    	else {
				    	String x=getTextFromElement(firstHighSpeedInternet, SelectedData);
		    			System.out.println(x);
		    			if(!x.equals(SelectedData)){
		    		
		    		clickUsingJavaScript(firstHighSpeedInternet, objectValue);
		    		report.reportPass("Internet Plan is "+ internetPlan +" not available", "Internet plan "+ internetPlan +" not available so selected First Avaialble Highest Speed", "Internet plan "+ internetPlan +" not available so selected First Avaialble Highest Speed: " +x);
		    		
		    			}
		    			else{
		    				report.reportPass("Internet Plan is "+ internetPlan +" not available", "Internet plan "+ internetPlan +" not available so selected First Avaialble Highest Speed", "Internet plan "+ internetPlan +" not available so selected First Avaialble Highest Speed: "+x);
		    			}
		    		
				    	}
		    } catch (Exception e) {
			e.printStackTrace();
			strFailed = "Failed in internet plan, Required speed " + internetPlan + "  not available.";
			logger.error(strFailed, e);
			report.reportFail("Select Internet plan", "Internet plan should be selected.", strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);
		    }

		}else if (SelectedData.equalsIgnoreCase(internetPlan)) {
		    report.reportPass("Select Internet Plan: " + internetPlan, internetPlan + " Internet plan should be selected",
			    "Already selected " + internetPlan + " internet plan, no need to select again.");
		}

		waitForLoader();
		
		//Mounika Polagoni (HLR Validations)
		
if(get("HLRValidations").equalsIgnoreCase("Yes")){
	
	 if (isDisplayed(simplex_SelectedData, "", 3)) {
		 if(getTextFromElement(simplex_SelectedData, "").contains("Gigabit")){
			 put("Display Internet","Fios Gigabit Connection"); 
			 
		 }
		 else if(getTextFromElement(simplex_SelectedData, "").contains("Cons")){
			
			 String FiData=getTextFromElement(simplex_SelectedData, objectValue);
	    		String FiosData2[]=FiData.split("SFU");
	    		System.out.println(FiosData2[0]);
	    		String FSD[]=FiosData2[0].split("Cons");
	    		System.out.println(FSD[1]);
	    		put("Display Internet",FSD[1]);
		 }
		 else if(getTextFromElement(simplex_SelectedData, "").contains("Standalone")){
    		String FiData=getTextFromElement(simplex_SelectedData, objectValue);
    		String FiosData2[]=FiData.split("\\(");
    		System.out.println(FiosData2[0]);
    		if(FiosData2[0].contains("/")){
    		   String FDt[]=FiosData2[0].split("/");
    		   System.out.println(FDt[0]);
    		   put("Display Internet",FDt[0]);
    		}
    		else{    		
    		   put("Display Internet",FiosData2[0]);
    		}
    		        }
    	else if(getTextFromElement(simplex_SelectedData, "").contains("Bundle")){
    			String FiData=getTextFromElement(simplex_SelectedData, objectValue);
	    		String FiosData2[]=FiData.split("\\(");
	    		System.out.println(FiosData2[0]);
	    		put("Display Internet",FiosData2[0]);
    		}
    	else{
			String FiosData2 = getTextFromElement(simplex_SelectedData, objectValue);
			System.out.println(FiosData2);
			put("Display Internet",FiosData2);
    		}
	    		
    	}
		}

		// Collapse Internet

		if (getAttribute(expandInternet, objectValue, "class").contains("open")) {
		    pageScroll(expandInternet, objectValue, true);
		    clickUsingJavaScript(expandInternet, objectValue);
		}

	    }

	    // Switching to Default Content
	    switchToDefaultcontent();

	}

	catch (Exception exe) {

	    if (!isUserDefinedException(exe)) {
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		captureErrorMsg("Failed in Internet section.");
	    }
	    throw exe;
	}

	// Moving to TV Plan
	if(fd.isEmpty()){
		selectTvPlan();
	}
	
    }

   
	/**
     * @Description: selectTvPlan is used to change the TV Plan, Upgrade,
     *               Downgrade for C2G and COA Change
     * @param: tvPlanDetails
     *             is used to choose the TV Plan
     * @param: Standalone
     *             is used to choose if TV is Standalone
     * @author: Mounika, Padmini
     * @LastUpdatedBy -- Shiva 03/04/2017
     * @return:No Return Type
     * @exception: Throws
     *                 Exception
     * @ModifiedBy:
     * @ModifiedDate:
     * @Comments:
     */

    protected void selectTvPlan() throws Exception, UserDefinedException {

	System.out.println("->selectTvPlan");
	String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
	getUrl = ", URL Launched --> " + returnURL();

	try {

	    waitForLoader();
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");

	    String tvPlan = get("TvPlan").trim();
	    String standalone = get("Standalone").trim();

	    String FiosTV = "";
	    if (isDisplayed(simplex_SelectedTV, "", 1)) {
		FiosTV = simplex_SelectedTV.getText();

	    }

	    waitForLoader();
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    
	    if (get("HLRValidations").equalsIgnoreCase("Yes") && get("FlowType").equalsIgnoreCase("MoveAsIs"))  //Gopal for Move AS IS Validation 11/13
		{
	    	
	    	String ExistingTVProduct = Existingtvproduct.getText().trim();
	    	
	    	if(Existingtvproduct.isDisplayed() && !ExistingTVProduct.isEmpty())
	    	{
			try {
	
				String CurrentTVProduct = Currenttvproduct.getText().trim();
				
				System.out.println(ExistingTVProduct);
				
				System.out.println(CurrentTVProduct);
				
				if(CurrentTVProduct.contains("("))
				{
					
					String[] CurrentTVproduct=CurrentTVProduct.split("");
					System.out.println(CurrentTVproduct[0]);
					
					if(ExistingTVProduct.contains(CurrentTVproduct[0]))
					{
	
					report.reportPass("To verify if Existing and Current TV Product both are same for moveAsIs",
							"Existing and Current TV Product both Sould be Same", "Existing and Current TV Product both are same");
					}
					else{
						
	
						report.reportFail("To verify if Existing and Current TV Product both are same for moveAsIs",
								"Existing and Current TV Product both Sould be Same", "Existing and Current TV Product both are not same");
					}
				
				}	
			else
			{
				if(ExistingTVProduct.equals(CurrentTVProduct))
				{
	
				report.reportPass("To verify if Existing and Current TV Product both are same for moveAsIs",
						"Existing and Current TV Product both Sould be Same", "Existing and Current TV Product both are same");
				}
				else{
					
	
					report.reportFail("To verify if Existing and Current TV Product both are same for moveAsIs",
							"Existing and Current TV Product both Sould be Same", "Existing and Current TV Product both are not same");
				}
				
			}
				
	
			} catch (Exception e) {
				
				throw new UserDefinedException(
						"Existing and Current TV Product both are not same");
			}
	    }
	  }
	    
	    if (!tvPlan.isEmpty() || (!FiosTV.isEmpty())) {
			// Expanding TV
			if (!getAttribute(expandTv, objectValue, "class").contains("open")) {
			    pageScroll(expandTv, objectValue, true);
			    clickUsingJavaScript(expandTv, objectValue);
			    
			}

			try {
			    waitForElementDisplay(allTvs, "", pageTimeoutInSeconds);
			} catch (Exception e) {

			    strFailed = "Failed in TV plan, TV section was not loaded even after " + pageTimeoutInSeconds + " seconds..";
			    report.reportFail("Select TV plan", "TV plan should be selected.", strFailed);
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    logger.error(strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);

			}

			if (standalone.toLowerCase().contains("TV".toLowerCase())) {
			    // Click View Standalone prices

			    String S = getTextFromElement(viewStandaloneTVText, objectValue);
			    System.out.println(S);
			    if (S.contains("Standalone")) {
				try {
				    clickUsingJavaScript(C2GTVStandalonePrice, objectValue);
				    report.reportPass("Select standalone tv plan", "Standalone tv plan should be selected.", "Clicked on View standalone prices of Tv plan.");
				} catch (Exception e) {
				    strFailed = "Failed in Tv Plan, View standalone prices not available.";
				    logger.error(strFailed, e);
				    report.reportFail("Select standalone tv plan", "TV standalone prices should be selected.", strFailed);
				    report.updateMainReport("comments", strFailed);
				    report.updateMainReport("ErrorMessage", strFailed);
				    captureErrorMsg(strFailed);
				    throw new UserDefinedException(strFailed);
				}

			    }

			} else {
			    // Click View Bundle Prices
			    String S = getTextFromElement(viewStandaloneTVText, objectValue);
			    System.out.println(S);
			    if (S.contains("Bundle")) {

				try {
				    clickUsingJavaScript(C2GTVBundlePrice, objectValue);
				    report.reportPass("Click View Bundle Prices in Tv Plan", "View Bundle Prices should be clicked in Tv Plan", "Clicked on View Bundle Prices in Tv Plan");
				} catch (Exception e) {
				    strFailed = "Failed in Tv Plan, Bundle price not available.";
				    logger.error(strFailed, e);
				    report.reportFail("Select Bundle tv plan", "TV bundle prices should be selected.", strFailed);
				    report.updateMainReport("comments", strFailed);
				    report.updateMainReport("ErrorMessage", strFailed);
				    captureErrorMsg(strFailed);
				    throw new UserDefinedException(strFailed);
				}

			    }

			}

			// Getting Text of Selected TV
			String SelectedTV = getTextFromElement(simplex_SelectedTV, objectValue);
			System.out.println(SelectedTV);

			// To Upgrade or Downgrade TV
			if (tvPlan.toUpperCase().contains("UPGRADE") || tvPlan.toUpperCase().contains("DOWNGRADE")) {

			    tvUpgradeDowngrade();

			} else if (tvPlan.equalsIgnoreCase("Deselect")) {

			    Deselectservice("video");
			    report.reportPass("Simplex Page  ordering - Verify able to Deselect Tv Plan", "Should be able to Deselect Tv Plan", "Able to Deselect Tv Plan");

			} 
			else if (tvPlan.contains("Custom")) {

				pageScroll(showCustomTvLink, objectValue, true);
				clickUsingJavaScript(showCustomTvLink, objectValue);
				    report.reportPass("Simplex Page  ordering - Verify able to Click Show Custom Tv", "Should be able to Click Show Custom Tv", "Able to Click Show Custom Tv");
			            waitForLoader();
			            if (!SelectedTV.toLowerCase().contains(tvPlan.toLowerCase()))
			            {
			            	
			            	if(isDisplayed(lnkTVPlansCustomTv, tvPlan, 1)){
			            		pageScroll(lnkTVPlansCustomTv, tvPlan, true);
								clickUsingJavaScript(lnkTVPlansCustomTv, tvPlan);
								report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.", "Clicked on " + tvPlan + " tv plan");
							    
			            	}
			            	else if(isDisplayed(selectCustomTv, tvPlan, 1)){
			             pageScroll(selectCustomTv, tvPlan, true);
			                clickUsingJavaScript(selectCustomTv, tvPlan);
			                report.reportPass("Simplex Page  ordering - Verify able to Select Custom Tv", "Should be able to Select Custom Tv", "Able to Select Custom Tv");
			              
			            }
			            else{
			            pageScroll(clickCustomTv, objectValue, true);
			            clickUsingJavaScript(clickCustomTv, objectValue);
			            report.reportPass("Simplex Page  ordering - Verify able to Select Custom Tv", "Should be able to Select Custom Tv", "Able to Select Custom Tv");
			            }
			            }
				}
			
			else if (!SelectedTV.toLowerCase().contains(tvPlan.toLowerCase())) {

			    try {
			    	if(isDisplayed(lnkTVPlans, tvPlan, 5)){
						pageScroll(lnkTVPlans, tvPlan, true);
					
						if(get("FlowType").equalsIgnoreCase("Install") &&  tvPlan.contains("Ultimate"))
						{
							report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.", "Clicked on " + tvPlan + " tv plan");
							
							if(isDisplayed(deselectTestDrive))
							{
								pageScroll(deselectTestDrive);
								clickUsingJavaScript(deselectTestDrive, "");
								report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.", "Clicked on " + tvPlan + " tv plan");
							}
						}
						else
						{
						clickUsingJavaScript(lnkTVPlans, tvPlan);
						report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.", "Clicked on " + tvPlan + " tv plan");
						}
						report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.", "Clicked on " + tvPlan + " tv plan");
					    	}
			    	     else {
						    	String x=getTextFromElement(firstHighestVideo, SelectedTV);
				    			System.out.println(x);
				    			if(!x.equals(SelectedTV)){
					    		clickUsingJavaScript(firstHighestVideo, objectValue);
					    		report.reportPass("TV Plan is "+ tvPlan +" not available", "TV plan "+ tvPlan +" not available so selected First Avaialble Highest Video", "TV plan "+ tvPlan +" not available so selected First Avaialble Highest Video:" +x);
					    		
				    			}
				    			else{
				    				report.reportPass("TV Plan is "+ tvPlan +" not available", "TV plan "+ tvPlan +" not available so selected First Avaialble Highest Video", "TV plan "+ tvPlan +" not available so selected First Avaialble Highest Video: "+x);
				    			}
				    		
						    	}
			    } catch (Exception e) {
				strFailed = "Failed in Tv plan, Required TV " + tvPlan + "  not available.";
				logger.error(strFailed, e);
				report.reportFail("Select TV plan", "TV plan should be selected.", strFailed);
				report.updateMainReport("comments", strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg(strFailed);
				throw e;
			    }

			}
			else if (SelectedTV.toLowerCase().contains(tvPlan.toLowerCase()) && get("FlowType").equalsIgnoreCase("Install"))
			{
				if(isDisplayed(lnkTVPlans, tvPlan, 5)){
					pageScroll(lnkTVPlans, tvPlan, true);
					report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.", "Clicked on " + tvPlan + " tv plan");
					if(get("FlowType").equalsIgnoreCase("Install") &&  tvPlan.contains("Fios TV Test Drive"))
					{
						if(isDisplayed(ChkFiosTVTestDrive))
							{
								pageScroll(ChkFiosTVTestDrive);
								clickUsingJavaScript(ChkFiosTVTestDrive, "");
								report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.", "Clicked on " + tvPlan + " tv plan");
							}
					}
			      }
			}
			else if (SelectedTV.toLowerCase().contains(tvPlan.toLowerCase())) {
			    report.reportPass("Click on tv plan" + tvPlan, "Tv plan should be clicked.", "By default selected " + tvPlan + " tv plan, no need to select again.");
			}

		    }
           
    //Mounika Polagoni (HLR Validations)
		
  if(get("HLRValidations").equalsIgnoreCase("Yes")){
      String FiosTV2="";
      if (isDisplayed(simplex_SelectedTV, "", 3)) {
    	  
    	  if(getTextFromElement(simplex_SelectedTV, "").contains("Custom TV")){
    		  String FiosTv=getTextFromElement(simplex_SelectedTV, objectValue);
    		  System.out.println(FiosTv);
      		String FiTv[]=FiosTv.split("TV");
      		System.out.println(FiTv[0]);
      		put("Display Video", FiTv[0]);  
    		  
    	  }
    	  else if(getTextFromElement(simplex_SelectedTV, "").contains("Standalone")){
    		String FiosTv=getTextFromElement(simplex_SelectedTV, objectValue);
    		String FiTv[]=FiosTv.split("\\(");
    		System.out.println(FiTv[0]);
    		put("Display Video", FiTv[0]);
    		}
    		else if(getTextFromElement(simplex_SelectedTV, "").contains("Bundle")){
    			String FiosTv=getTextFromElement(simplex_SelectedTV, objectValue);
    	  		String FiTv[]=FiosTv.split("\\(");
    	  		System.out.println(FiTv[0]);
    	  		put("Display Video", FiTv[0]);
    		}
    		else{
    			FiosTV2 = simplex_SelectedTV.getText();
    	  		put("Display Video", FiosTV2);
    			System.out.println(FiosTV2);
    			
    			 report.reportPass("Check Existing data on Profile","Check Existing data on Profile", "Existing data on Profile is: "+FiosTV2);
    		    
    		}
  	    		
    	}
  }

	    // Collapsing TV
	    if (getAttribute(expandTv, objectValue, "class").contains("open")) {
		pageScroll(expandTv, objectValue, true);
		clickUsingJavaScript(expandTv, objectValue);
	    }

	    // Switching to Default Content
	    switchToDefaultcontent();

	} catch (Exception exe) {

	    if (!isUserDefinedException(exe)) {
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		captureErrorMsg("Failed in TV section.");
	    }
	    throw exe;
	}

	// Moving to Voice Plan
	selectVoicePlan();
    }

    /**
     * @Description: selectVoicePlan is used to change the Voice Plan for C2G
     *               and COA Change
     * @param: voicePlanDetails
     *             is used to choose the Voice Plan
     * @param: Standalone
     *             is used to choose if Voice is Standalone
     * @author: Mounika, Padmini
     * @return:No Return Type
     * @exception: Throws
     *                 Exception
     * @ModifiedBy:
     * @ModifiedDate:
     * @Comments:
     */
    public void selectVoicePlan() throws Exception, UserDefinedException {

	System.out.println("->selectVoicePlan");
	String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
	// select Voice type
	strDescription = "Validation of Voice plan";
	strExpected = "Voice plan should be selected.";
	strActual = "Selected voice plan";
	strFailed = "Failed to select voice plan due to page objects unavailability.";
	getUrl = ", URL Launched --> " + returnURL();

	try {

	    String voicePlan = get("VoicePlan").trim();
	    String standalone = get("Standalone").trim();
	    String migrate = get("Migrate").trim();

	    waitForLoader();
	    
		 // Switching to Products & Services Frame
		    switchToDefaultcontent();
		    switchToFrame("IfProducts");
			
			if (get("HLRValidations").equalsIgnoreCase("Yes") && get("FlowType").equalsIgnoreCase("MoveAsIs"))   //Gopal for Move AS IS Validation 11/13
			{
				
				String ExistingVoiceProduct = Existingvoiceproduct.getText().trim();
				
				if(Existingvoiceproduct.isDisplayed() && !ExistingVoiceProduct.isEmpty())
				{
				   try {
			
						
						String CurrentVoiceProduct = Currentvoiceproduct.getText().trim();
			
						
						System.out.println(ExistingVoiceProduct);
						
						System.out.println(CurrentVoiceProduct);
						 
						if(ExistingVoiceProduct.equals(CurrentVoiceProduct))
						{
			
						report.reportPass("To verify if Existing and Current  Voice Product both are same for moveAsIs",
								"Existing and Current Voice Product both Sould be Same", "Existing and Current Voice Product both are same");
						}
						else{
							
			
							report.reportFail("To verify if Existing and Current Voice Product both are same for moveAsIs",
									"Existing and Current Voice Product both Sould be Same", "Existing and Current Voice Product both are not same");
						}
			
					} catch (Exception e) {
						
						throw new UserDefinedException(
								"Existing and Current Voice Product both are not same.");
					}
				}
		  }


	    if (!voicePlan.isEmpty()) {

		if (voicePlan.equalsIgnoreCase("FDV")) {
		    voicePlan = "Fios Digital Voice Unlimited";
		}

		// Expand Voice
		if (!getAttribute(expandVoice, objectValue, "class").contains("open")) {
		    pageScroll(expandVoice, objectValue, true);
		    clickUsingJavaScript(expandVoice, objectValue);
		    waitForLoader();
		}

		// Click view stand alone prices

		if (standalone.toLowerCase().contains("Voice".toLowerCase())) {

		    String S = getTextFromElement(viewStandaloneVoiceText, objectValue);
		    System.out.println(S);
		    if (S.contains("Standalone")) {
			try {
			    clickUsingJavaScript(C2GVoiceStandalonePrice, objectValue);
			    report.reportPass("Select Standalone Prices in Voice Plan", "View Standalone Prices should be clicked in Voice Plan", "Clicked on View Standalone Prices in Voice Plan");
			} catch (Exception e) {

			    strFailed = "Failed in Voice plan, View standalone prices not available.";
			    logger.error(strFailed, e);
			    report.reportFail("Select standalone voice plan", "Voice standalone prices should be selected.", strFailed);
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);
			}

		    }
		    waitForLoader();
		} else {
		    // Click View Bundle Prices
		    String S = getTextFromElement(viewStandaloneVoiceText, objectValue);
		    System.out.println(S);
		    if (S.contains("Bundle")) {
			try {
			    clickUsingJavaScript(C2GVoiceBundlePrice, objectValue);
			    waitForLoader();
			    report.reportPass("Select View Bundle Prices in Voice Plan", "View Bundle Prices clicked in Voice Plan", "clicked on View Bundle Prices in Voice Plan");
			} catch (Exception e) {

			    strFailed = "Failed in Voice Plan, Bundle prices not available.";
			    logger.error(strFailed, e);
			    report.reportFail("Select Bundle Voice plan", "Voice Bundle Plan should be selected.", strFailed);
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);
			}

		    }
		}
		// Deselect Voice Plan
		if (voicePlan.equalsIgnoreCase("Deselect")) {

		    Deselectservice("voice");
		    waitForLoader();
		    report.reportPass("Deselect voice plan", "Voice plan should be deselected.", "Deselected voice plan");
		    // Select the Voice Plan
		} else if (!voicePlan.isEmpty()) {

		    String selectedVoice = getTextFromElement(simplex_SelectedVoice, objectValue);

		    if (!selectedVoice.toLowerCase().contains(voicePlan.trim().toLowerCase()) || selectedVoice.trim().isEmpty()) {

			try {
			    pageScroll(lnkVoicePlans, (voicePlan).trim(), true);
			    clickUsingJavaScript(lnkVoicePlans, (voicePlan).trim());
			    waitForLoader();
			    switchToDefaultcontent();
			    switchToFrame("IfProducts");
			  //  if(isDisplayed(MigrationtoFiosButton))
			  //  {
			  //  	pageScroll(SelectFDVMigrateButton);
			  //  	clickUsingJavaScript(SelectFDVMigrateButton, "");
			  //  	waitForLoader();
			  //  }
			    report.reportPass("Select voice plan" + voicePlan, "Voice plan should be selected.", "Selected voice plan" + voicePlan);
			} catch (Exception e) {
			    strFailed = "Failed in Voice plan, Required Voice " + voicePlan + "  not available.";
			    logger.error(strFailed, e);
			    report.reportFail("Select Voice plan", "Voice plan should be selected.", strFailed);
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    captureErrorMsg(strFailed);
			    throw e;
			}

		    } else if (selectedVoice.toLowerCase().contains(voicePlan.trim().toLowerCase())) {
			report.reportPass("Select voice plan" + voicePlan, "Voice plan should be selected.", "By default selected " + voicePlan + " voice plan, no need to select again.");
		    }

		}

		waitForLoader();
		// Changing from FTTP to FDV
		if (migrate.equals("Y")) {
			report.reportPass("Select Migrate option", "Migrate option should be selected..", "Migrate Option should be selected");
		    clickUsingJavaScript(selectMigrate, "");
		    report.reportPass("Select Migrate option", "Migrate option should be selected..", "Selected voice migration option");

		    if(!isDisplayed(expandVoice, migrate, 10)){
		    	strFailed = "Failed in Voice Plan, Products Page grayed out on clicking Migrating to FDV";
			    logger.error(strFailed);
			    report.reportFail("Select Bundle Voice plan", "Voice Bundle Plan should be selected.", strFailed);
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);	
		    }
		}

		waitForLoader();
		waitForLoader();
		
	    }
	    
	  //Mounika Polagoni (HLR Validations)
		
 if(get("HLRValidations").equalsIgnoreCase("Yes")){
	    
	    if (isDisplayed(simplex_SelectedVoice, "", 3)) {
    		if(getTextFromElement(simplex_SelectedVoice, "").contains("Standalone")){
    		String FiVoice=getTextFromElement(simplex_SelectedVoice, objectValue);
    		String FiosVoice[]=FiVoice.split("\\(");
    		System.out.println(FiosVoice[0]);
    		put("Display Voice",FiosVoice[0]);
    		}
    		else if(getTextFromElement(simplex_SelectedVoice, "").contains("Bundle")){
    			String FiVoice=getTextFromElement(simplex_SelectedVoice, objectValue);
        		String FiosVoice[]=FiVoice.split("\\(");
        		System.out.println(FiosVoice[0]);
        		put("Display Voice",FiosVoice[0]);
    		}
    		else{
    			String voicePlan2 = simplex_SelectedVoice.getText();
    	  		put("Display Voice", voicePlan2);
    			System.out.println(voicePlan2);
    			report.reportPass("Check Existing data on Profile","Check Existing data on Profile", "Existing data on Profile is: "+voicePlan2);
    		    

    		}
	    		
    	}
	}

	    // Collapse Voice
	    if (getAttribute(expandVoice, objectValue, "class").contains("open")) {
		pageScroll(expandVoice, objectValue, true);
		clickUsingJavaScript(expandVoice, objectValue);
		waitForLoader();
	    }

	    // Switching to Default Content
	    switchToDefaultcontent();

	} catch (Exception exe) {
	    if (!isUserDefinedException(exe)) {
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		logger.error(strFailed, exe);
		report.updateMainReport("ErrorMessage", strFailed);
		captureErrorMsg("Failed in Voice section.");
	    }
	    throw exe;
	}
	if (get("SelectPackage").contains("Get Prepaid Plans"))
	{
		selectEquipmentOptions();
	}
	else
	{	
	selectContract();
	}
    }

    /**
     * @Description: changeContract is used to change the Contract Term for C2G
     *               and COA Change
     * @param: Contract
     *             is used to choose the Agreement and Offers Plan
     * @param: Standalone
     *             is used to choose if Voice is Standalone
     * @author: Mounika, Padmini
     * @return:No Return Type
     * @exception: Throws
     *                 Exception
     * @ModifiedBy: Rashmi
     * @ModifiedDate: 13/01/2017
     * @Comments: Added code for MoveASIS to validate contract
     * @ModifiedBy: Jeevitha S
     * @ModifiedDate: 17/02/2017
     * @Comments: Added code Marketting Offer Validation
     */
    public void selectContract() throws Exception, UserDefinedException {

		System.out.println("->selectContract");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "Validation of Contract plan";
		strExpected = "Contract plan should be selected.";
		strActual = "Selected contract plan ";
		strFailed = "Failed to select contract plan due to page unavailability";
		getUrl = ", URL Launched --> " + returnURL();

		try {
			String contract = get("Contract").trim();
			String standalone = get("Standalone").trim();
			String coupon = get("Coupon").trim();
			String affinityCoupon = get("AffinityCoupon").trim();
			String DigitalCoupon = get("DigitalCoupon").trim();

			switchToDefaultcontent();
			switchToFrame("IfProducts");
			

			// Expand Contract
			if (!getAttribute(expandContract, objectValue, "class").contains("open")) {
				pageScroll(expandContract, objectValue, true);
				clickUsingJavaScript(expandContract, objectValue);

                waitForLoader();
				waitForLoader();
				waitForLoader();
				waitForLoader();
				report.reportPass("To View Agreement & Offers Section", "Display Agreement & Offers Section",
						"Agreement & Offers Section should be displayed");
			}
			switchToDefaultcontent();
			switchToFrame("IfProducts");
			
			if (get("HLRValidations").equalsIgnoreCase("Yes") && get("FlowType").equalsIgnoreCase("MoveAsIs")) //Gopal for Move AS IS Validation 11/13
			{
				try {
	
					if(isDisplayed(contract2YearTerm_Selected))
						{
		
						String selected_contract = contract2YearTerm_Selected.getText();
						System.out.println(selected_contract);
						 
						if(selected_contract.contains("Move As Is"))
						{
		
						report.reportPass("To verify if 2 year contract is preselected for moveAsIs",
								"2 year contract moveAsIs should be preselected ", "2 year contract moveAsIs is PreSelected");
						}
						else{
							
		
							report.reportFail("To verify if 2 year contract is preselected for moveAsIs",
									"2 year contract moveAsIs should be preselected", "2 year contract moveAsIs is not PreSelected");
							}
						}
	
				} catch (Exception e) {
					
					throw new UserDefinedException(
							"Element_validation - failed as 2 year contract is not PreSelected");
				 }
		   } 
			if (isDisplayed(selectedContarct, DigitalCoupon, 3)) {
				String S = getTextFromElement(selectedContarct, objectValue);
				System.out.println(S);
				report.reportPass("Selected Contact", "Selected Contact", "Selected Contract is :" + S);
				if (S.contains("$10 Auto Pay") || (S.contains("$5 Auto Pay"))) {
					report.reportPass("Check Whether the customer is enrolled for Auto pay",
							"Verify Whether the customer is enrolled for Auto pay",
							"The customer is already enrolled for Auto pay" + S);
				} else if (S.contains("Declined")) {
					report.reportPass("Check Whether the Status of Auto pay", "Verify the status of Auto pay",
							"The customer has already declined for for Auto pay" + S);
				}
			}

			if (!contract.isEmpty() || !coupon.isEmpty() || !DigitalCoupon.isEmpty() || !affinityCoupon.isEmpty()) {
				//if (standalone.isEmpty()) {
				//Vikram , removed condition for SA data is empty, since it was blocking SA auto pay decline scenario

					/*
					 * if(isDisplayed(Offers, DigitalCoupon, 3)){ //
					 * if(allAgreements.size()>0){ report.reportPass(
					 * "To View Agreement & Offers Section",
					 * "Display Agreement & Offers Section",
					 * "Agreement & Offers Section should be displayed"); }
					 * else{ strFailed =
					 * "Failed in Agreement and offer section, Agreement offer section was not loaded."
					 * ; report.reportFail("Select Agreement",
					 * "Agreement and offer section should be selected.",
					 * strFailed); report.updateMainReport("comments",
					 * strFailed); report.updateMainReport("ErrorMessage",
					 * strFailed); logger.error(strFailed);
					 * captureErrorMsg(strFailed); throw new
					 * UserDefinedException(strFailed);
					 * 
					 * }
					 */

					if (!DigitalCoupon.isEmpty()) {
						if (isDisplayed(btnCoupon, objectValue, 1)) {
							clickUsingJavaScript(btnCoupon, objectValue);
							report.reportPass("Click on coupon link.", "Coupon link should be clicked.",
									"Clicked on coupon link");
						} else {
							strFailed = "Failed in Agreement and offer section, Coupon link is not available.";
							report.reportFail("Click on coupon link.", "Coupon link should be clicked.", strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							logger.error(strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}
						waitForLoader();
						waitForLoader();
						try {
							setText(Digitalcoupon, objectValue, DigitalCoupon);
							report.reportPass("Enter coupon.", "Coupon should be entered.",
									"Entered coupon " + DigitalCoupon);
							clickUsingJavaScript(verifyDigitalCoupon, objectValue);
							waitForLoader();
							waitForLoader();
							waitForLoader();
							if (isDisplayed(ValidDigitalCoupon)) {
								report.reportPass("Click on verify button.", "Verify button should be clicked.",
										"Clicked on verify coupon button.");
								waitForLoader();
								// clickUsingJavaScript(selectCoupon,
								// objectValue);
								report.reportPass("Selecte coupon", "Coupon should be selected.", "Selected coupon");
								clickUsingJavaScript(applyCoupon, objectValue);
								report.reportPass("Negotiate Coupon", "Coupon should be validated.",
										"Validated " + DigitalCoupon + " Coupon.");
								waitForLoader();
								waitForLoader();
								waitForLoader();

							}

							else {
								if (isDisplayed(invalidDigitalCoupon, "", 3)) {
									strFailed = "Failed in Agreement and offer section, Failed to validate Digital coupon.";
									report.reportFail("Vlidate coupon", "Coupon section should be validated.",
											strFailed);
									report.updateMainReport("comments", strFailed);
									report.updateMainReport("ErrorMessage", strFailed);
									logger.error(strFailed);
									captureErrorMsg(strFailed);
									throw new UserDefinedException(strFailed);
								}

								else {
									report.reportPass("Click on verify button.", "Verify button should be clicked.",
											"Clicked on verify coupon button.");
								}
								waitForLoader();
								clickUsingJavaScript(selectCoupon, objectValue);
								report.reportPass("Selecte coupon", "Coupon should be selected.", "Selected coupon");
								clickUsingJavaScript(applyCoupon, objectValue);
								report.reportPass("Negotiate Coupon", "Coupon should be validated.",
										"Validated " + DigitalCoupon + " Coupon.");
								waitForLoader();
								waitForLoader();

							}
						}

						catch (Exception e) {
							strFailed = "Failed in Agreement and offer section, Coupon validation failed."
									+ DigitalCoupon;
							report.reportFail("Validate coupon", "Failed to validate coupon.", strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							logger.error(strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}
					}
					/*
					 * if (contract.contains("M2M") &&
					 * contract.contains("Decline")) { if
					 * (isDisplayed(contractViewOnlyM2MTerm, "", 3)) {
					 * pageScroll(contractViewOnlyM2MTerm, objectValue, true);
					 * clickUsingJavaScript(contractViewOnlyM2MTerm,
					 * objectValue); report.reportPass(
					 * "Select View Only M2M term",
					 * "View Only M2M term should be clicked.",
					 * "Clicked View Only M2M term"); waitForLoader(); }
					 * if(isDisplayed(autoPayM2MDecline, "", 2)){
					 * clickUsingJavaScript(autoPayM2MDecline, objectValue);
					 * report.reportPass("Select Auto Pay decline",
					 * "Auto Pay decline", "Selected Auto Pay decline");
					 * waitForLoader(); }
					 * 
					 * } else if (contract.contains("2Year") &&
					 * contract.contains("Decline")) { if
					 * (isDisplayed(contractViewOnlyM2MTerm, "", 3)) {
					 * pageScroll(contractViewOnlyM2MTerm, objectValue, true);
					 * clickUsingJavaScript(contractViewOnlyM2MTerm,
					 * objectValue); report.reportPass(
					 * "Select View Only M2M term",
					 * "View Only M2M term should be clicked.",
					 * "Clicked View Only M2M term"); waitForLoader(); }
					 * 
					 * if(isDisplayed(autoPay2YearDecline, "", 1)){
					 * clickUsingJavaScript(autoPayM2MDecline, objectValue);
					 * report.reportPass("Select Auto Pay decline",
					 * "Auto Pay decline should be selected.",
					 * "Selected Auto Pay decline"); waitForLoader(); } }
					 */
					try{
					if (contract.contains("AutoPayAccept")) {
						
						if(isDisplayed(rdAutoPayYes, DigitalCoupon, 2)){
							clickUsingJavaScript(rdAutoPayYes, objectValue);
                           // clickUsingJavaScript(rdAutoPayYes, objectValue);
							report.reportPass("select Auto pay and paper free billing discount",
									"Auto pay and paper free billing discount should be selected",
									"Auto pay and paper free billing discount is selected");
							waitForLoader();
							waitForLoader();
							waitForLoader();

						}

						else if (!isSelected(AutoPaychkDeclineorAccept)) {

							try {

								clickUsingJavaScript(AutoPaychkDeclineorAccept, objectValue);
								report.reportPass("select Auto pay and paper free billing discount",
										"Auto pay and paper free billing discount should be selected",
										"Auto pay and paper free billing discount is selected");

							} catch (Exception ex) {
								strFailed = "Auto pay and paper free billing discount is selected";
								report.reportPass("select Auto pay and paper free billing discount",
										"Auto pay and paper free billing discount should be selected",
										"Auto pay and paper free billing discount is not selected");
								/*report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);*/

							}
						} else {
							

						}

					} else if (contract.contains("AutoPayDecline")) {
						
						if(isDisplayed(rdAutoPayNo, DigitalCoupon, 2)){
							
							
							clickUsingJavaScript(rdAutoPayNo, objectValue);
							report.reportPass("Deselect Auto pay and paper free billing discount",
									"Auto pay and paper free billing discount should be Deselected",
									"Auto pay and paper free billing discount is Deselected");
							waitForLoader();
							waitForLoader();
							waitForLoader();
							
						}

						else if (isSelected(AutoPaychkDeclineorAccept)) {

							try {

								clickUsingJavaScript(AutoPaychkDeclineorAccept, objectValue);
								report.reportPass("Deselect Auto pay and paper free billing discount",
										"Auto pay and paper free billing discount should be Deselected",
										"Auto pay and paper free billing discount is Deselected");

							} catch (Exception ex) {
								strFailed = "Auto pay and paper free billing discount is not Deselected";
								report.reportPass("Deselect Auto pay and paper free billing discount",
										"Auto pay and paper free billing discount should be Deselected",
										"Auto pay and paper free billing discount is not Deselected");
								/*report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);*/

							}
						}else {
							

						}

					}
					
					else if(isDisplayed(rdAutoPayNo, DigitalCoupon, 2)){
						
						
						clickUsingJavaScript(rdAutoPayNo, objectValue);
						report.reportPass("Deselect Auto pay and paper free billing discount",
								"Auto pay and paper free billing discount should be Deselected",
								"Auto pay and paper free billing discount is Deselected");
						waitForLoader();
						waitForLoader();
						waitForLoader();
						
					}
					}catch(Exception ex){
						
					}
                  
					// To Select Month to Month or 2 Year Contract
					if (contract.contains("M2M") || contract.contains("2Year")) {

						if (contract.contains("M2M")) {
							if (isDisplayed(contractViewOnlyM2MTerm, "", 3)) {
								//pageScroll(contractViewOnlyM2MTerm, objectValue, true);
								clickUsingJavaScript(contractViewOnlyM2MTerm, objectValue);
								report.reportPass("Select View Only M2M term", "View Only M2M term should be clicked.",
										"Clicked View Only M2M term");
								waitForLoader();
								clickUsingJavaScript(contractM2MTerm, objectValue);
								report.reportPass("Select Month to Month Agreement",
										"Month to month agreement should be selected.",
										"Selected Month to Month agreement.");
								waitForLoader();
							}

							else if (isDisplayed(contractM2MTerm, "", 3)) {

								clickUsingJavaScript(contractM2MTerm, objectValue);
								report.reportPass("Select Month to Month Agreement",
										"Month to month agreement should be selected.",
										"Selected Month to Month agreement.");
								waitForLoader();
							}
							//Vikram Gomez script start
							else if (isDisplayed(contractSAM2M, "", 3)) {

								clickUsingJavaScript(contractSAM2M, objectValue);
								report.reportPass("Select Month to Month Agreement",
										"Month to month agreement should be selected.",
										"Selected Month to Month agreement.");
								waitForLoader();
							}
							//Vikram Gomez script end
							else if (isDisplayed(contractNoContract, "", 1)) {
								clickUsingJavaScript(contractNoContract, objectValue);
								report.reportPass("Select Month to Month Agreement",
										"Month to month agreement should be selected.",
										"Selected Month to Month agreement.");
								waitForLoader();
							}

							else {
								strFailed = "Failed in Agreement and offers section, Month to Month plan not available.";
								logger.error(strFailed);
								report.reportFail("Select Month to month plan in agreement section",
										"Month to month agreement should be selected.", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							}

						} else if (contract.contains("2Year")) {

							boolean twoyearofferselected = false;

							if (isDisplayed(contractViewOnly2YrTerm, "", 3)) {
								pageScroll(contractViewOnly2YrTerm, objectValue, true);
								clickUsingJavaScript(contractViewOnly2YrTerm, objectValue);
								waitForLoader();
								report.reportPass("Select 2Year Agreement", "2Year agreement should be selected.",
										"Selected 2Year agreement.");
								if (get("OfferValidation").equalsIgnoreCase("Yes")) {
									if (isDisplayed(viewOfferDetails, objectValue, 2)) {
										clickUsingJavaScript(viewOfferDetails, objectValue);
										waitForLoader();
										String x = getTextFromElement(availableOffersDetails, objectValue);
										System.out.println(x);
										report.reportPass("Available Offer Details in Contract",
												"View Available Offer Details in Contract",
												"Available Offers are: " + x);
										clickUsingJavaScript(closeButton, objectValue);
										waitForLoader();
									}
								}
							}
							if (isDisplayed(NoAgreementOffers, "", 3)) {
								clickUsingJavaScript(NoAgreementOffers, objectValue);
								waitForLoader();
							}

							for (Element contractelement : contract2YearTerm) {
								if (isDisplayed(contractelement, "", 3)) {

									clickUsingJavaScript(contractelement, objectValue);
									twoyearofferselected = true;
									waitForLoader();
									report.reportPass("Select 2Year Agreement", "2Year agreement should be selected.",
											"Selected 2Year agreement.");
									if (get("OfferValidation").equalsIgnoreCase("Yes")) {
										if (isDisplayed(viewOfferDetails, objectValue, 2)) {
											clickUsingJavaScript(viewOfferDetails, objectValue);
											waitForLoader();
											String x = getTextFromElement(availableOffersDetails, objectValue);
											System.out.println(x);
											report.reportPass("Available Offer Details in Contract",
													"View Available Offer Details in Contract",
													"Available Offers are: " + x);
											clickUsingJavaScript(closeButton, objectValue);
											waitForLoader();
										}
									}

									break;
								}
							}

							if (isDisplayed(contractTryMe2year, "", 3) && !twoyearofferselected) {

								clickUsingJavaScript(contractTryMe2year, objectValue);
								waitForLoader();
								report.reportPass("Select 2Year Agreement", "2Year agreement should be selected.",
										"Selected 2Year agreement.");
								if (get("OfferValidation").equalsIgnoreCase("Yes")) {
									if (isDisplayed(viewOfferDetails, objectValue, 2)) {
										clickUsingJavaScript(viewOfferDetails, objectValue);
										waitForLoader();
										String x = getTextFromElement(availableOffersDetails, objectValue);
										System.out.println(x);
										report.reportPass("Available Offer Details in Contract",
												"View Available Offer Details in Contract",
												"Available Offers are: " + x);
										clickUsingJavaScript(closeButton, objectValue);
										waitForLoader();
									}
								}
							} else if (!twoyearofferselected) {
								strFailed = "Failed in Agreement and offers section, 2Year plan not available.";
								logger.error(strFailed);
								report.reportFail("Select 2Year plan in agreement section",
										"2Year agreement should be selected.", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							}

						}

					}
					// To Select Renew If Data or TV or Voice is Standalone
					else if (contract.contains("Renew") && (!standalone.isEmpty())) {

						if (isDisplayed(contractRenewM2MStandalone, "")) {
							clickUsingJavaScript(contractRenewM2MStandalone, "");
							report.reportPass("Renew standalone Month to Month plan",
									"Month to month plan should be selected.",
									"Clicked on Standalone month to month renew plan");

						}

						else if (isDisplayed(contractRenew2YearStandalone, "")) {
							clickUsingJavaScript(contractRenew2YearStandalone, "");
							report.reportPass("Renew standalone 2Year plan", "2Year plan should be selected.",
									"Clicked on Standalone 2Year renew plan");

						}

					}

					// To Renew Contract for Bundle
					else if (contract.contains("Renew")) {
						try {
							if (isDisplayed(contractRenewM2MBundle, objectValue)) {
								clickUsingJavaScript(contractRenewM2MBundle, objectValue);
								report.reportPass("Renew Bundle Month to Month plan",
										"Month to month plan should be selected.",
										"Clicked on Bundle month to month renew plan");

							} else if (isDisplayed(contractRenew2YearBundle, objectValue)) {
								pageScroll(contractRenew2YearBundle, objectValue, true);
								clickUsingJavaScript(contractRenew2YearBundle, objectValue);
								report.reportPass("Renew Bundle 2Year plan", "2Year plan should be selected.",
										"Clicked on Bundle 2Year renew plan");
											if(isDisplayed(okbtn,objectValue,3)){
            				clickUsingJavaScript(okbtn, objectValue);	
            					}

								waitForLoader();
								waitForLoader();

								if (isDisplayed(SelectedcontractRenew2Year, DigitalCoupon, 3)) {
									report.reportPass("Renew Bundle 2Year plan", "2Year plan should be selected.",
											"Clicked on Bundle 2Year renew plan");
								} else {
									pageScroll(RenewContract, objectValue, true);
									clickUsingJavaScript(RenewContract, objectValue);
									report.reportPass("Renew Bundle 2Year plan", "2Year plan should be selected.",
											"Clicked on Bundle 2Year renew plan");
										
        					      			
        					//Anu added		
        			  if(isDisplayed(okbtn,objectValue,3)){
        				clickUsingJavaScript(okbtn, objectValue);	
        					}
									waitForLoader();
									waitForLoader();
									pause();
								}

							}

							else if (isDisplayed(contractRenew2YearBundleFuture, objectValue)
									&& isDisplayed(contractRenew2YearBundle, objectValue)) {
								clickUsingJavaScript(contractRenew2YearBundleFuture, objectValue);
								report.reportPass("Renew Bundle 2Year plan", "2Year plan should be selected.",
										"Clicked on Bundle 2Year renew plan");

							} else if (!isDisplayed(contractRenew2YearBundle, objectValue)
									&& isDisplayed(contractRenew2YearBundle, objectValue)) {
								clickUsingJavaScript(contractRenew2YearBundle, objectValue);

								if (contract.contains(",")) {
									String[] arrOfStr = contract.split(",");
									clickUsingJavaScript(contractRenew2YearBundleOffer, arrOfStr[1]);
								}

								report.reportPass("Renew Bundle 2Year plan", "2Year plan should be selected.",
										"Clicked on Bundle 2Year renew plan");
							}
						} catch (Exception e) {
						}
					}

					else if (contract.contains("MoveASIS")) {
						try {

							contract2YearTerm_Selected.isDisplayed();

							String selected_contract = contract2YearTerm_Selected.getText();
							System.out.println(selected_contract);

							report.reportPass("To verify if 2 year contract is preselected for moveAsIs",
									"2 year contract should be preselected ", "2 year contract is PreSelected");

						} catch (Exception e) {
							report.reportFail("To verify if 2 year contract is preselected for moveAsIs",
									"2 year contract should be preselected", "2 year contract is not PreSelected");
							throw new UserDefinedException(
									"Element_validation - failed as 2 year contract is not PreSelected");
						}
					} else if (contract.contains("KeepCurrentTerm")) {
						clickUsingJavaScript(contractRenew2YearBundle, objectValue);
						waitForLoader();
						waitForLoader();
						report.reportPass("Negotiate Contract", "Select Contract Term if available",
								"Selected Contract: " + contract);
					}

					report.reportPass("Negotiate Contract", "Select Contract Term if available",
							"Selected Contract: " + contract);
					if (!DigitalCoupon.isEmpty()) {
						List<WebElement> lst = driver.findElements(By.xpath(
								"//div[@class='ng-scope']/div[contains(@class,'w_tiles') and (not(contains(@class,'tiny')))]/div"));
						for (int i = 0; i < lst.size(); i++) {
							System.out.println(lst.size());
							String list1 = lst.get(i).getText();
							System.out.println(list1);
							if (list1.contains("$15 HD Set-Top Box")) {

								report.reportPass("Coupon Validations", "Coupon section details", lst.get(i).getText());
								System.out.println(list1);
								if (isDisplayed(notselectedcontract, list1)) {
									lst.get(i).click();
									report.reportPass("Select Term", "Select Term", "Required Term is Selected");
									break;

								}
							}
						}
					}

					if (!coupon.isEmpty() || !affinityCoupon.isEmpty()) {

						waitForLoader();
						if (isDisplayed(btnCoupon, objectValue, 1)) {
							clickUsingJavaScript(btnCoupon, objectValue);
							report.reportPass("Click on coupon link.", "Coupon link should be clicked.",
									"Clicked on coupon link");
						} else {
							strFailed = "Failed in Agreement and offer section, Coupon link is not available.";
							report.reportFail("Click on coupon link.", "Coupon link should be clicked.", strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							logger.error(strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}

						waitForLoader();
						waitForLoader();
						if (!coupon.isEmpty()) {
							try {
								setText(enterCoupon, objectValue, coupon);
								report.reportPass("Enter coupon.", "Coupon should be entered.",
										"Entered coupon " + coupon);
								clickUsingJavaScript(verifyCoupon, objectValue);
								if (isDisplayed(invalidCoupon, "", 3)) {
									strFailed = "Failed in Agreement and offer section, Failed to validate coupon.";
									report.reportFail("Vlidate coupon", "Coupon section should be validated.",
											strFailed);
									report.updateMainReport("comments", strFailed);
									report.updateMainReport("ErrorMessage", strFailed);
									logger.error(strFailed);
									captureErrorMsg(strFailed);
									throw new UserDefinedException(strFailed);
								} else {
									report.reportPass("Click on verify button.", "Verify button should be clicked.",
											"Clicked on verify coupon button.");
								}
								waitForLoader();
								clickUsingJavaScript(selectCoupon, objectValue);
								report.reportPass("Selecte coupon", "Coupon should be selected.", "Selected coupon");
								clickUsingJavaScript(applyCoupon, objectValue);
								report.reportPass("Negotiate Coupon", "Coupon should be validated.",
										"Validated " + coupon + " Coupon.");
								waitForLoader();
								waitForLoader();
								waitForLoader();
								switchToDefaultcontent();
								switchToFrame("IfProducts");

							} catch (Exception e) {
								strFailed = "Failed in Agreement and offer section, Coupon validation failed." + coupon;
								report.reportFail("Validate coupon", "Failed to validate coupon.", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								logger.error(strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							}
						}
						if (!affinityCoupon.isEmpty()) {
							setText(affinitycoupon, objectValue, affinityCoupon);
							report.reportPass("Enter coupon.", "Coupon should be entered.",
									"Entered coupon " + affinityCoupon);
							clickUsingJavaScript(verifyoffercode, objectValue);
							if (isDisplayed(invalidCoupon, "", 3)) {
								strFailed = "Failed in Agreement and offer section, Failed to validate coupon.";
								report.reportFail("Vlidate coupon", "Coupon section should be validated.", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								logger.error(strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							} else {
								report.reportPass("Click on verify button.", "Verify button should be clicked.",
										"Clicked on verify coupon button.");
							}

						}

					}
				//}

			}
			// Added for Marketing Offer Validation
			if (!get("MarketingOfferType").isEmpty()) {
				System.out.println("->Validating Marketing Offer");
				MarketingOffValidation();
			}
          
          if(isDisplayed(rdAutoPayNo, DigitalCoupon, 2)){
				if(!isSelected(rdAutoPayNo, DigitalCoupon)){
				
				
				clickUsingJavaScript(rdAutoPayNo, objectValue);
				report.reportPass("Deselect Auto pay and paper free billing discount",
						"Auto pay and paper free billing discount should be Deselected",
						"Auto pay and paper free billing discount is Deselected");
				waitForLoader();
				waitForLoader();
				waitForLoader();
				if (isDisplayed(contractViewOnlyM2MTerm, "", 3)) {
					//pageScroll(contractViewOnlyM2MTerm, objectValue, true);
					clickUsingJavaScript(contractViewOnlyM2MTerm, objectValue);
					report.reportPass("Select View Only M2M term", "View Only M2M term should be clicked.",
							"Clicked View Only M2M term");
					waitForLoader();
					clickUsingJavaScript(contractM2MTerm, objectValue);
					report.reportPass("Select Month to Month Agreement",
							"Month to month agreement should be selected.",
							"Selected Month to Month agreement.");
					waitForLoader();
				}

				else if (isDisplayed(contractM2MTerm, "", 3)) {

					clickUsingJavaScript(contractM2MTerm, objectValue);
					report.reportPass("Select Month to Month Agreement",
							"Month to month agreement should be selected.",
							"Selected Month to Month agreement.");
					waitForLoader();
				}
				else if (isDisplayed(contractNoContract, "", 1)) {
					clickUsingJavaScript(contractNoContract, objectValue);
					report.reportPass("Select Month to Month Agreement",
							"Month to month agreement should be selected.",
							"Selected Month to Month agreement.");
					waitForLoader();
				}
				}
				
			}
			if (isDisplayed(selectedContarct, DigitalCoupon, 3)) {
				String S = getTextFromElement(selectedContarct, objectValue);
				System.out.println(S);
				report.reportPass("Selected Contact", "Selected Contact", "Selected Contract is :" + S);
				if (S.contains("$10 Auto Pay") || (S.contains("$5 Auto Pay"))) {
					report.reportPass("Selected Contact", "Selected Contact",
							"Selected Contract Contains Auto pay Discount:" + S);
				}

			}

			// Expand Contract
			if (isDisplayed(expandContract, "", 1)) {
				// Expand Contract
				if (getAttribute(expandContract, objectValue, "class").contains("open")) {
					pageScroll(expandContract, objectValue, true);
					clickUsingJavaScript(expandContract, objectValue);
					waitForLoader();
				}
			}

			// Switching to Default Content
			switchToDefaultcontent();

		} catch (Exception exe) {
			if (!isUserDefinedException(exe)) {

				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in Agreements section.");
			}
			throw exe;
		}

		if (get("FlowType").toLowerCase().contains("move") && get("Application").equalsIgnoreCase("COA")
				&& !get("ProfileTypeSelection").equals("")
				|| get("FlowType").toLowerCase().contains("Change") && get("Application").equalsIgnoreCase("COA")
						&& get("OPOCheck").equalsIgnoreCase("Yes") && !get("ProfileTypeSelection").equals("")) {

			OPOMoveProdCheck();
		} else {

			selectvoiceOptions();

		}
	}



		   
	/**
	 * @Info To validate the product selection based on the Account search
	 * @throws Exception
	 * @ConvertedBy Rashmi
	 * @LastUpdated 06/02/2017 - Rashmi
	 */
	public void OPOMoveProdCheck() throws Exception {

		System.out.println("->OPOMoveProdCheck");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		String FiosTV = null;
		String FiosData = null;
		String HomePhone = null;

		// Give Customer info
		strDescription = "Verify products selection";
		strExpected = "Product selection is verified as expected";
		strActual = "Verify products selected in products selection page successfully";
		strFailed = "Products selection verification in products selection page was not successful";
		getUrl = ", URL Launched --> " + returnURL();

		try {

			waitForLoader();

			driver.switchTo().defaultContent();
			switchToFrame("IfProducts");
			FiosData = getTextFromElement(simplex_SelectedData, objectValue);

			System.out.println(FiosData);
			FiosTV = simplex_SelectedTV.getText();
			System.out.println(FiosTV);
			HomePhone = simplex_SelectedVoice.getText();
			System.out.println(HomePhone);
			// partial disconnect
			if (get("RG_Selection").equalsIgnoreCase("PartialDisconnect")) {

				if (get("Internet_PartialDisconnect").equalsIgnoreCase("Yes")) {

					if (!FiosData.isEmpty()) {

						if (FiosData.toLowerCase().contains("removed")) {
							report.reportPass("Disconnected internet data", "Internet should be removed",
									"Internet is removed: " + FiosData);
						} else {
							report.reportFail("Disconnected internet data", "Internet should be removed",
									"Internet value is either not removed or selected:" + FiosData);
							report.updateMainReport("ErrorMessage",
									"Internet value is either not removed or selected: " + FiosData);
							throw new UserDefinedException(
									"Element_validation - failed as Internet value is either not removed or selected");

						}

					}
				}
				if (get("TV_PartialDisconnect").equalsIgnoreCase("Yes")) {

					if (!FiosTV.isEmpty()) {

						if (FiosTV.toLowerCase().contains("removed")) {
							report.reportPass("Disconnected TV data", "TV should be removed",
									"TV is removed: " + FiosTV);
						} else {
							report.reportFail("Disconnected TV data", "Internet should be removed",
									"TV value is either not removed or selected:" + FiosTV);
							report.updateMainReport("ErrorMessage",
									"Internet value is either not removed or selected: " + FiosTV);
							throw new UserDefinedException(
									"Element_validation - failed as Internet value is either not removed or selected");

						}

					}
				}
			}
			// validate profile required
			// Internet
			if (get("ProfileTypeSelection").equalsIgnoreCase("Data")
					|| get("ProfileTypeSelection").equalsIgnoreCase("FDVData")
					|| get("ProfileTypeSelection").equalsIgnoreCase("double flex")
					|| get("ProfileTypeSelection").equalsIgnoreCase("DataVideo")
					|| get("ProfileTypeSelection").equalsIgnoreCase("TP FDV")) {
				if (!FiosData.isEmpty()) {

					report.reportPass("simplex Selected internet data", "Internet should be selected",
							"Internet is selected: " + FiosData);
				} else {
					report.reportFail("simplex Selected internet data", "Internet Data value must be displayed",
							"Internet value is not selected for account profile with Data");
					report.updateMainReport("ErrorMessage",
							"Internet value is not selected for account profile with Data");
					throw new UserDefinedException(
							"Element_validation - failed as Internet is not selected for account profile with Data ");
				}
			}
			// Video
			if (get("ProfileTypeSelection").equalsIgnoreCase("Video")
					|| get("ProfileTypeSelection").equalsIgnoreCase("FDVVideo")
					|| get("ProfileTypeSelection").equalsIgnoreCase("double flex")
					|| get("ProfileTypeSelection").equalsIgnoreCase("DataVideo")
					|| get("ProfileTypeSelection").equalsIgnoreCase("TP FDV")) {
				if (!FiosTV.isEmpty()) {

					report.reportPass("simplex Selected TV data", "TV should be selected", "TV is selected: " + FiosTV);
				} else {
					report.reportFail("simplex Selected TV data", "TV Data value must be displayed",
							"TV value is not selected for account profile with Video");
					report.updateMainReport("ErrorMessage", "TV value is not selected for account profile with Video");
					throw new UserDefinedException(
							"Element_validation - failed as TV is not selected for account profile with Vedio");
				}

			}
			// Voice
			if (get("ProfileTypeSelection").equalsIgnoreCase("FDVVideo")
					|| get("ProfileTypeSelection").equalsIgnoreCase("FDVData")
					|| get("ProfileTypeSelection").equalsIgnoreCase("TP FDV")
					|| get("ProfileTypeSelection").equalsIgnoreCase("FDV")) {
				if (!HomePhone.isEmpty()) {

					report.reportPass("simplex Selected Voice data", "Voice should be selected",
							"Voice is selected: " + HomePhone);
				} else {
					report.reportFail("simplex Selected Voice data", "Voice Data value must be displayed",
							"Voice value is not selected for account profile with Voice");
					report.updateMainReport("ErrorMessage",
							"Voice value is not selected for account profile with Voice");
					throw new UserDefinedException(
							"Element_validation - failed as voice is not selected for account profile with Voice");
				}

			}
			// verify profile not required
			// Internet
			if (get("ProfileTypenotrequired").equalsIgnoreCase("Data")
					|| get("ProfileTypenotrequired").equalsIgnoreCase("FDVData")
					|| get("ProfileTypenotrequired").equalsIgnoreCase("double flex")
					|| get("ProfileTypenotrequired").equalsIgnoreCase("DataVideo")
					|| get("ProfileTypenotrequired").equalsIgnoreCase("TP FDV")) {
				if (!FiosData.isEmpty()) {
					report.reportFail("simplex Selected internet data", "Internet Data value must not be selected",
							"Internet value is selected though not required");
					report.updateMainReport("ErrorMessage", "Internet value is selected though not required");
					throw new UserDefinedException("Element_validation - failed as Internet is selected");

				} else {
					report.reportPass("simplex Selected internet data", "Internet should not be selected",
							"Internet is not selected");
				}
			}
			// Video
			if (get("ProfileTypenotrequired").equalsIgnoreCase("Video")
					|| get("ProfileTypenotrequired").equalsIgnoreCase("FDVVideo")
					|| get("ProfileTypenotrequired").equalsIgnoreCase("double flex")
					|| get("ProfileTypenotrequired").equalsIgnoreCase("DataVideo")
					|| get("ProfileTypenotrequired").equalsIgnoreCase("TP FDV")) {
				if (!FiosTV.isEmpty()) {
					report.reportFail("simplex Selected TV data", "TV Data value must not be selected",
							"Video is selected though not required");
					report.updateMainReport("ErrorMessage", "Video is selected though not required");
					throw new UserDefinedException("Element_validation - failed as Video is selected");

				} else {
					report.reportPass("simplex Selected TV data", "Video should not be selected",
							"Video is not selected");
				}

			}
			// Voice
			if (get("ProfileTypenotrequired").equalsIgnoreCase("FDVVideo")
					|| get("ProfileTypenotrequired").equalsIgnoreCase("FDVData")
					|| get("ProfileTypenotrequired").equalsIgnoreCase("TP FDV")
					|| get("ProfileTypenotrequired").equalsIgnoreCase("FDV")) {
				if (!HomePhone.isEmpty()) {
					report.reportFail("simplex Selected Voice data", "Voice Data value must not be selected",
							"Voice value is selected though not required");
					report.updateMainReport("ErrorMessage", "Voice value is selected though not required");
					throw new UserDefinedException("Element_validation - failed as voice is selected");

				} else {
					report.reportPass("simplex Selected Voice data", "Voice should not be selected",
							"Voice is not selected");
				}

			}

			report.reportPass(strDescription + getUrl, strExpected, strActual);

		} catch (Exception exe) {
			exe.printStackTrace();
			report.reportFail(strDescription + getUrl, strExpected, strFailed + exe.getCause());
			report.updateMainReport("ErrorMessage", strFailed);
			throw new UserDefinedException("Failed in Product verification at Product page");

		}

		// Moving to Contract Plan
		selectvoiceOptions();

	}

	/**
	 * @Description: selectvoiceOptions is used to change the Voice Options
	 * @param: InternationalPlan,
	 *             Wiremaintanance, FirstName, LastName are used to update the
	 *             Main Line in Voice Options
	 * @author: Mounika, Padmini
	 * @LastUpdatedBy Shiva Kumar Simharaju 06/04/2017
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */
	public void selectvoiceOptions() throws Exception, UserDefinedException {

		System.out.println("->selectvoiceOptions");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "Selet voice options.";
		strExpected = "Voice options should be selected.";
		strActual = "Selected voice options.";
		getUrl = ", URL Launched --> " + returnURL();
		try {

			// Switch Frame
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			String HomePhone = "";
			String SelectedPremiums = "";
			String AssignedTN = "";
			String selectedVoicePlan = "";

			String internationalPlan = get("InternationalPlan").trim();
			String wiremaintanance = get("Wiremaintanance");
			String firstName = get("FirstName").trim();
			String lastName = get("LastName").trim();
			// String voicePlanDetails=get("voicePlanDetails");
			String addFdvLine = get("AddFdvLine").trim();
			String voicePlan = get("VoicePlan").trim();
			String application = get("Application").trim();
			String subFlowType = get("SubFlowType").trim();

			String PortOutTN = get("PortOutTN").trim();

			if (!voicePlan.isEmpty() && get("GUI_Validations").equalsIgnoreCase("Yes")
					|| (get("ChangeType").contains("PartialDisconnect") && get("RG_Selection").contains("Phone"))) {

				if (voicePlan.equalsIgnoreCase("FDV") && get("GUI_Validations").equalsIgnoreCase("Yes")) {
					UIValidations_Voiceoptions();
				}
			}

			// get the selected voice plan
			if (isDisplayed(simplex_SelectedVoice, "")) {
				HomePhone = getTextFromElement(simplex_SelectedVoice, objectValue);

			}

			// get the selected voice plan
			if (!HomePhone.isEmpty()) {

				// Expand voice options if is not opened
				if (!getAttribute(Phone_Product_section, objectValue, "class").contains("open")) {
					pageScroll(Phone_Product_section, objectValue, true);
					clickUsingJavaScript(Phone_Product_section, objectValue);
					waitForLoader();
					report.reportPass("Expand Voice Options", "Voice Options should be expanded.",
							"Voice Options is expanded.");
				}

				// get the selected voice plan

				if (isDisplayed(Selected_phone_product, "")) {
					selectedVoicePlan = getTextFromElement(Selected_phone_product, objectValue);
				}
				// fdv & Lec
				if ((HomePhone.toLowerCase().contains("fios digital voice"))) {

					try {
						waitForElementDisplay(voiceDetails, objectValue, pageTimeoutInSeconds);

					} catch (Exception e) {

						strFailed = "Failed in voice options, voice options was not loaded even after "
								+ pageTimeoutInSeconds + " seconds";
						report.reportFail("Select voice options", "Voice optoins should be selected.", strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						logger.error(strFailed);
						captureErrorMsg(strFailed);
						throw new UserDefinedException(strFailed);

					}

					if (!addFdvLine.isEmpty()) {

						try {
							// Selecting no of lines.
							if (getAttribute(selectNoOfTNs, addFdvLine, "data-phone-select").contains("active")) {

								report.reportPass("Select no of TNs", "No of TN numbers should be clicked.",
										"By default selected number of TN as " + addFdvLine
												+ " line, no need to click again.");

							} else {
								pageScroll(selectNoOfTNs, addFdvLine, true);
								clickUsingJavaScript(selectNoOfTNs, addFdvLine);
								report.reportPass("Select no of TNs", "No of TN numbers should be clicked.",
										"Clicked on  " + addFdvLine + " line.");
							}
							if (Integer.parseInt(addFdvLine) == 1) {
								if (isDisplayed(mainLine, "", 1)) {
									report.reportPass("Check whether main line was assigned or not.",
											"Main should be assigned by default.",
											"By default main line was assigned.");
								} else {
									strFailed = "Failed in voice options, Main line was not assigned by default.";
									report.reportFail("Select voice options",
											"Main line should be assigned by default.", strFailed);
									report.updateMainReport("comments", strFailed);
									report.updateMainReport("ErrorMessage", strFailed);
									logger.error(strFailed);
									captureErrorMsg(strFailed);
									throw new UserDefinedException(strFailed);
								}
							}

							// Checking if any unassigned line numbers present
							// or not.

							if (noOfUnAssignedLines.size() > 0) {
								// Checking lines assigned or not.
								pageScroll(MoreOptions, objectValue, true);
								clickUsingJavaScript(MoreOptions, objectValue);
								report.reportPass("Click on more options",
										"More options should be clicked on voice options", "Clicked on more options");
								waitForLoader();

								for (WebElement element : unAssignedLinesNumbers) {
									String unAssignedLines = element.getText().trim();
									selectDropDownUsingVisibleText(selectNumber, "", unAssignedLines);
									report.reportPass("Select un assigned line", "Unassigned line should be selected ",
											"Selected " + unAssignedLines);
									clickUsingJavaScript(PleaseSelectnumber, objectValue);

									pageScroll(TNNumberAssign);
									clickUsingJavaScript(TNNumberAssign, objectValue);
									report.reportPass("Click on telephone number section.",
											"Telehone number assignment section should be clicked and expanded.",
											"Clicked on telephone number assignment section");
									pageScroll(DynamicAssignment);
									clickUsingJavaScript(DynamicAssignment, objectValue);
									report.reportPass("Click on Dynamic assignment",
											"Dynamic assignment radio button should be clicked.",
											"Clicked on dynamic assignment radio button.");
									pageScroll(getNumbers);
									clickUsingJavaScript(getNumbers, objectValue);
									report.reportPass("Click on Getnumbers button.",
											"Get numbers button should be clicked.", "Clicked on Get numbers button.");
									pageScroll(assignNumber);
									clickUsingJavaScript(assignNumber, objectValue);
									report.reportPass("Click on assign number link.",
											"Assign number link should be clicked.", "Clicked on assign number link.");
									pageScroll(DirectorylistingOptions);
									clickUsingJavaScript(DirectorylistingOptions, objectValue);
									report.reportPass("Click on Directory listing options.",
											"Directory listing options should be clicked.",
											"Clicked on Directory listing options.");
									pageScroll(addDirectory);
									clickUsingJavaScript(addDirectory, objectValue);
									report.reportPass("Click on Add directory", "Add directory link should be clicked.",
											"Clicked on add directory link.");
									waitForLoader();

									// FDV Listing First name
									pageScroll(txtFirstName);
									clearText(txtFirstName, objectValue);
									setText(txtFirstName, "", firstName);
									report.reportPass("Enter first name", "First name should be entered.",
											"Entered first name " + firstName);

									// FDV Listing Last name
									pageScroll(txtLastName);
									clearText(txtLastName, objectValue);
									setText(txtLastName, voicePlan, lastName);
									report.reportPass("Enter last name", "Last name should be entered.",
											"Entered last name " + firstName);

									pageScroll(publicationStatus);
									selectDropDownUsingVisibleText(publicationStatus, objectValue,
											("Published").trim());
									report.reportPass("Select publication status",
											"Publication status should be selected.",
											"Selected publication status as Published.");
									waitForLoader();

									clickUsingJavaScript(listingStyle, objectValue);
									report.reportPass("Click on individual lifestyle",
											"Individual life style should be clicked.",
											"Clicked on individual life style");

									clearText(fdvListingAddress, objectValue);
									setText(fdvListingAddress, voicePlan, "3230, LAKE AV, BALTIMORE, MD, 21213");
									report.reportPass("Enter FDV listing address",
											"FDV listing address should be entered",
											"Entered Address: 3230, LAKE AV, BALTIMORE, MD, 21213");

									pageScroll(applyDirectoryInfo);
									clickUsingJavaScript(applyDirectoryInfo, objectValue);
									report.reportPass("Click on directory save button.",
											"Directory save button should be clicked.",
											"Clicked on directory save button.");
								}

								waitForLoader();
								pageScroll(saveChanges);
								clickUsingJavaScript(saveChanges, objectValue);
								report.reportPass("Click on Save changes button.",
										"Save changes button should be clicked.", "Clicked on save changes button.");
								waitForLoader();
							}

						} catch (Exception e) {

							if (!isUserDefinedException(e)) {
								strFailed = "Failed in voice options, Unable to assign no of lines " + addFdvLine;
								report.reportFail("Select no of lines", addFdvLine + " lines should be selected.",
										strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								logger.error(strFailed);
								captureErrorMsg(strFailed);
							}

							throw e;
						}

					}
					// Select International Plans
					if (!(internationalPlan.isEmpty())) {
						try {
							pageScroll(internationalPlanSection, "", true);
							String[] IPs = internationalPlan.split(",");
							for (String InternationalPln : IPs) {
								if (InternationalPln.toUpperCase().contains(":X")) {
									InternationalPln = InternationalPln.split(":X")[0];
									if (selectedVoicePlan.toLowerCase()
											.contains(InternationalPln.toLowerCase().trim())) {
										pageScroll(IP_WM_Tile, InternationalPln.trim(), true);
										clickUsingJavaScript(IP_WM_Tile, InternationalPln.trim());
										report.reportPass(
												"Simplex Page ordering - Verify able to deselect International Plan:"
														+ InternationalPln,
												"Should be able to deselect International Plan",
												"Able to deselect International Plan:" + InternationalPln);
									}

								} else {
									if (!selectedVoicePlan.toLowerCase()
											.contains(InternationalPln.toLowerCase().trim())) {
										pageScroll(IP_WM_Tile, InternationalPln.trim(), true);
										clickUsingJavaScript(IP_WM_Tile, InternationalPln.trim());
										report.reportPass(
												"Simplex Page ordering - Verify able to select International Plan:"
														+ InternationalPln,
												"Should be able to select International Plan",
												"Able to select International Plan:" + InternationalPln);
									}
								}
							}
						} catch (Exception e) {
							strFailed = "Failed in voice options, Required international plan is not available "
									+ internationalPlan;
							report.reportFail("Select international plan", "International plan should be selected.",
									strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							logger.error(strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}

					}

					// wiremaintanance

					if (!(wiremaintanance.isEmpty())) {

						try {

							pageScroll(wireMaintainanceSection, "", true);
							String[] WMs = wiremaintanance.split(",");
							for (String WM : WMs) {
								if (WM.toUpperCase().contains(":X")) {
									WM = WM.split(":X")[0];
									if (selectedVoicePlan.toLowerCase().contains(WM.toLowerCase().trim())) {
										clickUsingJavaScript(IP_WM_Tile, WM.trim());
										report.reportPass(
												"Simplex Page ordering - Verify able to deselect Wiremaintanance Plan:"
														+ WM,
												"Should be able to deselect Wiremaintanance Plan",
												"Able to deselect Wiremaintanance Plan:" + WM);
									}

								} else {
									if (!selectedVoicePlan.toLowerCase().contains(WM.toLowerCase().trim())) {
										clickUsingJavaScript(IP_WM_Tile, WM.trim());
										report.reportPass(
												"Simplex Page ordering - Verify able to select Wiremaintanance Plan:"
														+ WM,
												"Should be able to select Wiremaintanance Plan",
												"Able to select Wiremaintanance Plan:" + WM);
									}
								}
							}
						} catch (Exception e) {
							strFailed = "Failed in voice options, Required wire maintaince plan is not available "
									+ wiremaintanance;
							report.reportFail("Select wire maintaince plan", "Wire maintaince plan should be selected.",
									strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							logger.error(strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}

					}

					if (HomePhone.toLowerCase().contains("fios digital voice")
							&& (get("FlowType").toLowerCase().contains("move")
									|| (!firstName.isEmpty() && (!lastName.isEmpty())))) {

						clickUsingJavaScript(MoreOptions, objectValue);
						waitForLoader();

						if (!isDisplayed(directoryListingOptions, objectValue)) {

							clickUsingJavaScript(directoryListing, objectValue);

							waitForLoader();
							waitForLoader();
						}
						if (isDisplayed(UpdatelistingOptions, objectValue, 3)) {

							// Update Listing
							clickUsingJavaScript(UpdatelistingOptions, objectValue);
							waitForLoader();

							// FDV Listing First name
							waitForElementDisplay(txtFirstName, "", 5);
							clearText(txtFirstName, objectValue);
							setText(txtFirstName, objectValue, firstName);

							// FDV Listing Last name
							clearText(txtLastName, objectValue);
							setText(txtLastName, objectValue, lastName);
							waitForLoader();

							waitForElementDisplay(ListingsaveChanges, objectValue, 20);
							clickUsingJavaScript(ListingsaveChanges, objectValue);
							waitForLoader();

							waitForElementDisplay(saveChanges, objectValue, 60);
							clickUsingJavaScript(saveChanges, objectValue);
							waitForLoader();
						} else {
							pageScroll(addDirectory);
							clickUsingJavaScript(addDirectory, objectValue);
							report.reportPass("Click on Add directory", "Add directory link should be clicked.",
									"Clicked on add directory link.");
							waitForLoader();

							// FDV Listing First name
							pageScroll(txtFirstName);
							clearText(txtFirstName, objectValue);
							setText(txtFirstName, "", firstName);
							report.reportPass("Enter first name", "First name should be entered.",
									"Entered first name " + firstName);

							// FDV Listing Last name
							pageScroll(txtLastName);
							clearText(txtLastName, objectValue);
							setText(txtLastName, voicePlan, lastName);
							report.reportPass("Enter last name", "Last name should be entered.",
									"Entered last name " + firstName);

							pageScroll(publicationStatus);
							selectDropDownUsingVisibleText(publicationStatus, objectValue, ("Published").trim());
							report.reportPass("Select publication status", "Publication status should be selected.",
									"Selected publication status as Published.");
							waitForLoader();

							clickUsingJavaScript(listingStyle, objectValue);
							report.reportPass("Click on individual lifestyle",
									"Individual life style should be clicked.", "Clicked on individual life style");
							pageScroll(fdvListingAddress, objectValue, true);
							clearText(fdvListingAddress, objectValue);
							setText(fdvListingAddress, voicePlan, "3230, LAKE AV, BALTIMORE, MD, 21213");
							report.reportPass("Enter FDV listing address", "FDV listing address should be entered",
									"Entered Address: 3230, LAKE AV, BALTIMORE, MD, 21213");

							pageScroll(applyDirectoryInfo);
							clickUsingJavaScript(applyDirectoryInfo, objectValue);
							report.reportPass("Click on directory save button.",
									"Directory save button should be clicked.", "Clicked on directory save button.");

							waitForLoader();
							pageScroll(saveChanges);
							clickUsingJavaScript(saveChanges, objectValue);
							report.reportPass("Click on Save changes button.", "Save changes button should be clicked.",
									"Clicked on save changes button.");
							waitForLoader();
						}

					}

				} else if (get("RG_Selection").contains("Phone") && get("ChangeType").contains("PartialDisconnect")) {
					switchToDefaultcontent();
					switchToFrame("IfProducts");

					// Updated by poovaraj on 07-Mar-2017
					String baseWindow = driver.getWindowHandle();

					// clickUsingJavaScript(VoiceOptionsBar, objectValue);
					clickUsingJavaScript(VoiceMoreOptions, objectValue);

					if (get("FlowType").equalsIgnoreCase("Install")) {
						switchToWindowWithURL("LineAndTN");
					} else {
						switchToWindowWithURL("LCW");
					}
					// maximizeBrowserWindow();

					waitForLoader();
					waitForLoader();

					clickUsingJavaScript(SelectIntercept, baseWindow);
					waitForLoader();

					clickUsingJavaScript(OkIntercept, baseWindow);
					waitForLoader();
					waitForLoader();
					Thread.sleep(2000);
					LECClickSaveAndContinue();

					driver.switchTo().window(baseWindow);
					waitForLoader();
					waitForLoader();
					Thread.sleep(3000);

				} else if (get("Application").equalsIgnoreCase("COA")
						&& ((HomePhone.toLowerCase().contains("freedom") && (voicePlan.equalsIgnoreCase("FREEDOM")))
								|| HomePhone.toLowerCase().contains("standalone"))) {

					if (get("RG_Selection").contains("Migrate to FDV") && get("FlowType").contains("Move")) {
						switchToDefaultcontent();
						switchToFrame("IfProducts");

						// Updated by poovaraj on 07-Mar-2017
						String baseWindow = driver.getWindowHandle();

						// clickUsingJavaScript(VoiceOptionsBar, objectValue);
						clickUsingJavaScript(VoiceMoreOptions, objectValue);

						if (get("FlowType").equalsIgnoreCase("Install")) {
							switchToWindowWithURL("LineAndTN");
						} else {
							switchToWindowWithURL("LCW");
						}
						// maximizeBrowserWindow();

						waitForLoader();
						waitForLoader();

						clickUsingJavaScript(SelectIntercept, baseWindow);
						waitForLoader();

						clickUsingJavaScript(OkIntercept, baseWindow);
						waitForLoader();
						waitForLoader();
						Thread.sleep(2000);
						LECClickSaveAndContinue();

						driver.switchTo().window(baseWindow);
						waitForLoader();
						waitForLoader();
						waitForLoader();
						waitForLoader();
						Thread.sleep(3000);

					} else {
						LECPageNavigation();
						pause();
					}

				}

				else if (get("Application").equalsIgnoreCase("C2G") && ((HomePhone.toLowerCase().contains("freedom"))
						|| HomePhone.toLowerCase().contains("standalone"))) {
					String additionalLine = get("AddLecLine");
					if (!additionalLine.isEmpty()) {
						int addlineCount = Integer.parseInt(additionalLine);

						System.out.println("addlineCount value:" + addlineCount);

						if (isDisplayed(MoreOptions, objectValue)) {
							clickUsingJavaScript(MoreOptions, objectValue);
							waitForLoader();
							waitForLoader();
							waitForLoader();

							selectLecVoice();
						}

					}
				}

			}
			// Winback flow for Portout TN by Gopal 07/12/2017
			if (!PortOutTN.isEmpty()) {
				try {
					if (isDisplayed(MoreOptions, objectValue)) {
						mouseOver(MoreOptions, objectValue);
						clickUsingJavaScript(MoreOptions, objectValue);

					}

					waitForLoader();

					if (isDisplayed(BringYourOwnNumber, objectValue)) {
						mouseOver(BringYourOwnNumber, objectValue);
						clickUsingJavaScript(BringYourOwnNumber, objectValue);

					}
					waitForLoader();

					if (isDisplayed(PortTN, objectValue)) {
						clearText(PortTN, "");
						setText(PortTN, "", PortOutTN);

						waitForLoader();

						clickUsingJavaScript(btnchkavailability, objectValue);

						waitForLoader();

						if (isSelected(Slammed)) {

							selectDropDownUsingVisibleText(Reasonforverizon, subFlowType, "Winback");

						}

						waitForLoader();

						clearText(billingname, "");
						setText(billingname, "", "Passlow Customer");

						clearText(accNum, "");
						setText(accNum, "", get("Search_Value").trim());

						clearText(pswPin, "");
						setText(pswPin, "", "a1b2");

						clickUsingJavaScript(rbtnyes, "");

						waitForLoader();

						clickUsingJavaScript(btnSaveWinbackDetails, "");

						waitForLoader();

						clickUsingJavaScript(AssignNumber, " ");

						waitForLoader();

						clickUsingJavaScript(FDVsavechanges, " ");

					}
					waitForLoader();

				} catch (Exception exe) {

					throw exe;
				}

			}

			switchToDefaultcontent();
			switchToFrame("IfProducts");

			// collapsing voice options if is opened
			if (getAttribute(Phone_Product_section, objectValue, "class").contains("open")) {

				pageScroll(Phone_Product_section, objectValue, true);
				clickUsingJavaScript(Phone_Product_section, objectValue);
				waitForLoader();
			}

			// Switching to Default Content
			switchToDefaultcontent();

		} catch (Exception exe) {
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in Voice options section.");
			}
			throw exe;
		}

		Thread.sleep(3000);
		// Moving to Contract Plan
		selectEquipmentOptions();
	}

	/**
	 * @Description: selectEquipmentOptions is used to change the Number of
	 *               Tv's, Recording Options, TV Equipment, Router Option,
	 *               Select Battery Backup and Equipment Return Option for C2G
	 *               and COA Change
	 * @param: noOfTVs
	 *             is used to Select or Change the Number of Tv's
	 * @param: strRecordingOptions
	 *             is used to choose the Recording Optiom
	 * @param: strRouterOptions
	 *             is used to choose the Router Option
	 * @param: strBatteryBackup
	 *             is used to select the Battery Backup option
	 * @param: EquipReturnOption
	 *             is used to select the Equipment Return Option
	 * @author: Mounika, Padmini
	 * @LastUpdatedBy -- Shiva Kumar Simharaju -- 07/04/2018
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */
	public void selectEquipmentOptions() throws Exception, UserDefinedException {

		System.out.println("->selectEquipmentOptions");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", SelectedTVCount = "",
				SelectedRecordingOptions = "", SelectedRouter = "", SelectedBatteryBackup = "", getUrl;
		strDescription = "Negotiate Equipment section.";
		strExpected = "Equipment section should be negotiated";
		strActual = "Eqiupment section is negotiated";
		strFailed = "Failed in Equipment section due to objects unavailability.";
		getUrl = ", URL Launched --> " + returnURL();

		try {
			waitForLoader();
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			String FiosTV = "";
			String FiosData = "";
			String HomePhone = "";
			String SelectedEquip = "";

			String noOfTVs = get("NoOfTv").trim();
			String strRecordingOptions = get("RecordingOptions").trim();
			String strRouterOptions = get("RouterOptions").trim();
			String strBatteryBackup = get("BatteryBackup").trim();
			// update for FCP
			String strBatteryBackupDeclineReason = get("BatteryBackupDeclineReason").trim();
			String TVEquipment = get("TVEquipment").trim();
			String voicePlan = get("VoicePlan").trim();
			String equipReturnOpt = get("EquipReturnOpt").trim();
			String extender = get("Extender").trim();

			if (get("GUI_Validations").equalsIgnoreCase("Yes")) {

				UIValidations_Equipment_And_Accessories();

			}

			if (isDisplayed(simplex_SelectedTV, "", 1)) {
				FiosTV = getTextFromElement(simplex_SelectedTV, objectValue);
			}
			// get selected Data plan
			if (isDisplayed(simplex_SelectedData, "", 1)) {
				FiosData = getTextFromElement(simplex_SelectedData, objectValue);
			}

			// get selected voice
			if (isDisplayed(simplex_SelectedVoice, "", 1)) {
				HomePhone = getTextFromElement(simplex_SelectedVoice, objectValue);
			}

			Thread.sleep(5000);
			// Equipment Section
			if (!FiosTV.isEmpty() || !strRouterOptions.isEmpty() || !noOfTVs.isEmpty() || !strRecordingOptions.isEmpty()
					|| !TVEquipment.isEmpty() || (!strBatteryBackup.isEmpty()) || !FiosData.isEmpty()) {

				// Expand Equipments and Accessories section
				if (!getAttribute(expandEquipmentsAccessoriesRibbon, objectValue, "class").contains("open")) {
					pageScroll(expandEquipmentsAccessoriesRibbon, objectValue, true);
					clickUsingJavaScript(expandEquipmentsAccessoriesRibbon, objectValue);
				}
				waitForLoader();
				waitForLoader();

				// Change sync handle
				if (get("FlowType").trim().equals("Change")) {
					// waitForEquipmentsLoad();
				}

				try {
					waitForElementDisplay(equipmentDetails, "", pageTimeoutInSeconds);
				} catch (Exception e) {

					strFailed = "Failed in Equipment section, Equipment section was not loaded even after "
							+ pageTimeoutInSeconds + " seconds.";
					report.reportFail("Select equipment options", "Equipment options should be selected.", strFailed);
					report.updateMainReport("comments", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					logger.error(strFailed);
					captureErrorMsg(strFailed);
					throw new UserDefinedException(strFailed);

				}

				if (isDisplayed(selectedEqpText, "", 3)) {
					SelectedEquip = getTextFromElement(selectedEqpText, objectValue);
					System.out.println(SelectedEquip);
				}
				// Select the no of TVs in Product and Services page

				if (!noOfTVs.isEmpty() && !FiosTV.isEmpty()) {
					// PageSync
					waitForLoader();

					/*
					 * if (get("IPTV").toString().equalsIgnoreCase("yes")) {
					 * 
					 * SelectedTVCount = lnkNoOfIPTvs_Selected.getText();
					 * System.out.println(SelectedTVCount); if
					 * (!SelectedTVCount.toLowerCase().contains(noOfTVs.trim().
					 * toLowerCase())) { pageScroll(lnkNoOfIPTvs_ToSelect,
					 * noOfTVs); clickUsingJavaScript(lnkNoOfIPTvs_ToSelect,
					 * noOfTVs); report.reportPass("To select No of TVs",
					 * noOfTVs + " is Selected as No of TVs if available",
					 * "No of TVs  " + noOfTVs + " is Selected"); } else {
					 * report.reportPass("To select No of TVs ", SelectedTVCount
					 * + "is preselected as No of TVs",
					 * "No change in No of TVs proceeding with Existing TV count "
					 * + SelectedTVCount); }
					 * 
					 * }
					 */

					////////////////////////////////////////////////////////////////////////////

					if (get("SubFlowType").equalsIgnoreCase("TVStbpriceup")
							|| get("SubFlowType").equalsIgnoreCase("HNP")) {
						String NoOfTV_Price = get("NoOfTV_Price").trim();

						// Expand Total Number of Tv's
						put("PreExistingTVCount", "");
						if (isDisplayed(lnkNoOfTvs_Selected, "", 2)) {
							SelectedTVCount = lnkNoOfTvs_Selected.getText().replaceAll("[^0-9]", "").trim();
							System.out.println(SelectedTVCount);
							put("PreExistingTVCount", SelectedTVCount);

						}

						// Check if TV Count is already selected

						if (!SelectedTVCount.trim().toLowerCase().equalsIgnoreCase(noOfTVs.trim().toLowerCase())) {

							// expand addditional tv option

							try {

								for (Element ExpandadditionalTVopt : ExpandadditionalTVoption) {
									if (isDisplayed(ExpandadditionalTVopt, objectValue, 5)) {
										pageScroll(ExpandadditionalTVopt, "", true);
										report.reportPass("Expand additional Tv opion",
												" additional Tv opion should be Expanded",
												" additional Tv opion is Expanded ");
										clickUsingJavaScript(ExpandadditionalTVopt, objectValue);
										waitForLoader();
									}
								}
								// pageScroll(lnkNoOfTvs, noOfTVs);
								clickUsingJavaScript(lnkNoOfTvs, noOfTVs);
								pageScroll(lnkNoOfTvs, "", true);

								report.reportPass("To select No of TVs ",
										noOfTVs + " is Selected as No of TVs if available",
										"No of TVs  " + noOfTVs + " is Selected");
								waitForLoader();

							} catch (Exception e) {

								strFailed = "Failed in Equipment section, Unable to select required no of equipments "
										+ noOfTVs;
								report.reportFail("Select no of TVs", "No of Tvs should be selected.", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								logger.error(strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							}

						} else {
							report.reportPass("To select No of TVs ", SelectedTVCount + "is preselected as No of TVs",
									"No change in No of TVs proceeding with Existing TV count " + SelectedTVCount);
						}

						// Mounika Polagoni (HLR Validations)

						if (get("HLRValidations").equalsIgnoreCase("Yes")) {
							if (isDisplayed(lnkNoOfTvs_Selected, "", 2)) {
								SelectedTVCount = lnkNoOfTvs_Selected.getText().replaceAll("[^0-9]", "").trim();
								System.out.println(SelectedTVCount);
								put("Display NumberOfTv", SelectedTVCount);

							}
						}

						// Click Number of Tv's

						if (NoOfTV_Price.contains("New")) {

							String New_NoOfTV_Price = "";

							if (Integer.valueOf(noOfTVs) == 1) {

								New_NoOfTV_Price = "$12";
							} else if (Integer.valueOf(noOfTVs) == 2) {

								New_NoOfTV_Price = "$24";
							} else if (Integer.valueOf(noOfTVs) == 3) {

								New_NoOfTV_Price = "$30";
							} else if (Integer.valueOf(noOfTVs) == 4) {

								New_NoOfTV_Price = "$36";
							} else if (Integer.valueOf(noOfTVs) >= 5) {

								New_NoOfTV_Price = "$42";
							}

							String expectedTvprice = noOfTVs + "-TV Equipment Package: " + New_NoOfTV_Price;

							if (isDisplayed(selectedEqpText, "", 3)) {
								SelectedEquip = getTextFromElement(selectedEqpText, objectValue);
							}

							if (SelectedEquip.contains(expectedTvprice)) {

								report.reportPass("check price of " + noOfTVs + " TV",
										" price of " + noOfTVs + " TV should be " + New_NoOfTV_Price,
										" price of " + noOfTVs + " TV is " + New_NoOfTV_Price);

							} else {
								report.reportFail("check price of " + noOfTVs + " TV",
										" price of " + noOfTVs + " TV should be " + New_NoOfTV_Price,
										" price of " + noOfTVs + " TV is not " + New_NoOfTV_Price);

							}

						}

					}

					///////////////////////////////////////////////////////////////////////
					else {

						// Expand Total Number of Tv's

						if (isDisplayed(lnkNoOfTvs_Selected, "", 2)) {
							SelectedTVCount = lnkNoOfTvs_Selected.getText();
							System.out.println(SelectedTVCount);
						}

						// Check if TV Count is already selected

						if (!SelectedTVCount.toLowerCase().contains(noOfTVs.trim().toLowerCase())) {

							try {
								// pageScroll(TotalNoOfTvs, objectValue);
								if (isDisplayed(TotalNoOfTvs, objectValue, 5)) {
									clickUsingJavaScript(TotalNoOfTvs, objectValue);
									waitForLoader();
								}
								// pageScroll(lnkNoOfTvs, noOfTVs);
								clickUsingJavaScript(lnkNoOfTvs, noOfTVs);
								report.reportPass("To select No of TVs ",
										noOfTVs + " is Selected as No of TVs if available",
										"No of TVs  " + noOfTVs + " is Selected");
								waitForLoader();

							} catch (Exception e) {

								strFailed = "Failed in Equipment section, Unable to select required no of equipments "
										+ noOfTVs;
								report.reportFail("Select no of TVs", "No of Tvs should be selected.", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								logger.error(strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							}

						} else {
							report.reportPass("To select No of TVs ", SelectedTVCount + "is preselected as No of TVs",
									"No change in No of TVs proceeding with Existing TV count " + SelectedTVCount);
						}
						// Click Number of Tv's

					}
				}

				// To select the TV Equipment
				if (!TVEquipment.isEmpty() && !FiosTV.isEmpty()) {

					try {

						// prepaid plans. Make sure to select Get Prepaid plan
						// in 'selectPackage' function
						if (getPrepaidPlan.getText().contains("Get Traditional Plans")) {

							clickUsingJavaScript(setTopFiosPrepaidTV, objectValue);
							report.reportPass("Select Set-Top Fios Prepaid TV",
									"Set-Top Fios Prepaid TV should be selected in TV section",
									"Set-Top Fios Prepaid TV is selected in TV Section");
							waitForLoader();

						} else {

							clickUsingJavaScript(tvEquipmentMoreOption, objectValue);
							waitForLoader();

							// by Ramesh N

							try {
								String[] TVEquip = TVEquipment.split(",");

								for (String Cnt : TVEquip) {
									String SelectedTVEquip = TVEquip[0].trim();
									if (Cnt.toUpperCase().contains(":X")) {
										int size = noOfEquipmentsDeselect.size();
										for (int i = 0; i < size; i++) {

											clickUsingJavaScript(deselectTvEquipm, objectValue);
										}
									} else if (!SelectedTVEquip.toLowerCase().contains(Cnt.toLowerCase().trim())) {
										clickUsingJavaScript(selectTvEquip, Cnt.trim());
									}
								}
							}
							// end of code by Ramesh N

							catch (Exception exe) {
								exe.printStackTrace();

							}
							clickUsingJavaScript(tvEquipmentSaveOption, objectValue);
							waitForLoader();

						}

					} catch (Exception exe) {
						exe.printStackTrace();
					}
				}

				// To select Recording Options
				if (!strRecordingOptions.isEmpty() && !FiosTV.isEmpty()) {

					// pageScroll(recordingSection, "");

					if (strRecordingOptions.equalsIgnoreCase("VmsToLegacy")) {
						String encryptpwd = get("Password").toString();
						byte[] decryptedPasswordBytes = Base64.getDecoder().decode(encryptpwd);
						String decryptedPassword = new String(decryptedPasswordBytes);

						pageScroll(clickExchangeOptions, "", true);
						clickUsingJavaScript(clickExchangeOptions, "");
						report.reportPass("Select Exchange option", "Exchange option should be selected.",
								"Selected Exchange option");
						waitForLoader();

						waitForLoader();

						clickUsingJavaScript(chxboxVmsToLegacy, strRecordingOptions);
						report.reportPass("Select Checkbox VMS to Legacy", "Checkbox VMS to Legacy should be selected.",
								"Selected Checkbox VMS to Legacy");
						waitForLoader();
						waitForLoader();

						setText(supervisorVzid, "", get("Username"));
						report.reportPass("Enter UserId", "UserId should be entered", "UserId is entered");
						setText(supervisorPasswd, "", decryptedPassword);
						report.reportPass("Enter Password", "Password should be entered", "Password is entered");
						clickUsingJavaScript(UpdateVMSBtn, "");
						report.reportPass("Click Update Button", "Update Button should be clicked",
								"Update Button is clicked");
						waitForLoader();
						waitForLoader();
					}

					else {

						if (strRecordingOptions.toLowerCase().contains(":x")) {
							// Deselect the recording options in Product and
							// Services page if available

							if (isDisplayed(lnkRecordingOptions_Selected, "", 1)) {
								String existingRecOption = lnkRecordingOptions_Selected.getText();
								clickUsingJavaScript(lnkRecordingOptions_Selected, "");
								report.reportPass("Deselect existing recording option if any.",
										"Existing recording option should be deselected if any.",
										"Deselected existing recording option " + existingRecOption);
								waitForLoader();
							}

						}

						else {

							if (isDisplayed(lnkRecordingOptions_Selected, "", 1)) {
								SelectedRecordingOptions = lnkRecordingOptions_Selected.getText();
								System.out.println(SelectedRecordingOptions);
							}
							// Check if recording option is already selected
							if (SelectedRecordingOptions.toLowerCase()
									.contains(strRecordingOptions.trim().toLowerCase())) {
								report.reportPass("To select RecordingOptions ",
										SelectedRecordingOptions + "is preselected as RecordingOptions",
										"No change in RecordingOptions Selection proceeding with Existing RecordingOptions "
												+ SelectedRecordingOptions);
							}

							// Gopal Updated this on 10/04/2017 need to push to
							// stash
							else {
								// Select the recording options in Product and
								// Services page

								String NoofDVR = get("NoOfDVR's").trim();

								try {

									if (strRecordingOptions.toLowerCase().equalsIgnoreCase("DVR Service")) {

										pageScroll(DVRRecordingOption, strRecordingOptions, true);
										clickUsingJavaScript(DVRRecordingOption, strRecordingOptions);
										report.reportPass("Select recording option",
												"Recording option should be selected.",
												"Selected " + strRecordingOptions + " recording option.");
										waitForLoader();

										if (!NoofDVR.isEmpty()) {
											for (int i = 1; i < Integer.parseInt(NoofDVR); i++) {
												if (isDisplayed(NumberofDVRs, "", 5)) {
													pageScroll(NumberofDVRs, "", true);
													clickUsingJavaScript(NumberofDVRs, "");

												}
											}
										}
									} else {
										pageScroll(lnkRecordingOptions_notSelected, strRecordingOptions, true);
										clickUsingJavaScript(lnkRecordingOptions_notSelected, strRecordingOptions);
										report.reportPass("Select recording option",
												"Recording option should be selected.",
												"Selected " + strRecordingOptions + " recording option.");
										waitForLoader();
									}
								} catch (Exception e) {

									strFailed = "Failed in Equipment section, Required recording option "
											+ strRecordingOptions + " not present.";
									report.reportFail("To verify if RecordingOptions is preselected",
											"RecordingOptions should have a preselected value", strFailed);
									report.updateMainReport("comments", strFailed);
									report.updateMainReport("ErrorMessage", strFailed);
									logger.error(strFailed);
									captureErrorMsg(strFailed);
									throw new UserDefinedException(strFailed);

								}

							}
						}
						// Mounika Polagoni (HLR Validations)

						if (get("HLRValidations").equalsIgnoreCase("Yes")) {
							// String RecordingOptionSelected="";
							if (isDisplayed(lnkRecordingOptions_Selected, "", 1)) {
								SelectedRecordingOptions = lnkRecordingOptions_Selected.getText();
								System.out.println(SelectedRecordingOptions);
								put("Display RecordingOption", SelectedRecordingOptions);
							}
						}

					}
				}

				// Added By Naresh,Madipelly : Exchange Options
				if (!get("ExchangeOptions").isEmpty() && get("FlowType").equals("Change")) {
					ExchangeOptions();

				}

				// To Select the Router
				if (!get("CentralAlarm").isEmpty()) {

					if (get("CentralAlarm").equalsIgnoreCase("Yes")) {
						clickUsingJavaScript(AlaramYes, extender);
						waitForLoader();
						clickUsingJavaScript(AlaramRouter, strRouterOptions);
					} else if (get("CentralAlarm").equalsIgnoreCase("No")) {
						clickUsingJavaScript(AlaramNo, extender);
						waitForLoader();
						clickUsingJavaScript(AlaramRouter, strRouterOptions);
					}
				} else if (!strRouterOptions.isEmpty() && (!FiosData.isEmpty() || !FiosTV.isEmpty())) {
					if (isDisplayed(routerSection, "", 1)) {
						pageScroll(routerSection, "", true);
						report.reportPass("To display Router section", "Display Router Section",
								"Displayed Router Section");
					}
					// Check if option is already selected

					if (isDisplayed(lnkRouterOptions_Selected, "", 0)) {
						SelectedRouter = lnkRouterOptions_Selected.getText();
						System.out.println(SelectedRouter);
						pageScroll(lnkRouterOptions_Selected, "", true);
						report.reportPass("To display Selected Router", "Display Selected Router",
								"Selected Router is: " + SelectedRouter);
					}

					// Check if router is already selected
					if (!SelectedEquip.contains(strRouterOptions.trim())) {

						try {
							pageScroll(lnkRouterOptions, strRouterOptions, true);
							clickUsingJavaScript(lnkRouterOptions, strRouterOptions);
							report.reportPass("To select RouterOptions ",
									strRouterOptions + "should be available as RouterOptions and be selectable",
									strRouterOptions + " RouterOptions is selected");
							waitForLoader();
						} catch (Exception e) {

							strFailed = "Failed in Equipment section, Required router option " + strRouterOptions
									+ " is not present.";
							report.reportFail("To select RouterOptions ",
									strRouterOptions + "should be available as RouterOptions and be selectable",
									strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							logger.error(strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);

						}

					} else {
						report.reportPass("To select RouterOptions ",
								SelectedRouter + "is preselected as RouterOptions",
								"No change in Router Selection proceeding with Existing Router " + SelectedRouter);
					}

					// Mounika Polagoni (HLR Validations)

					if (get("HLRValidations").equalsIgnoreCase("Yes")) {

						if (isDisplayed(lnkRouterOptions_Selected, "", 0)) {
							SelectedRouter = lnkRouterOptions_Selected.getText();
							System.out.println(SelectedRouter);
							if (SelectedRouter.contains("(OCO)")) {
								String SelRouter[] = SelectedRouter.split("\\)");
								System.out.println(SelRouter[1]);
								put("Display Router", SelRouter[1]);

							} else {
								pageScroll(lnkRouterOptions_Selected, "", true);
								put("Display Router", SelectedRouter);
								report.reportPass("To display Selected Router", "Display Selected Router",
										"Selected Router is: " + SelectedRouter);
							}
						}
					}

				}

				// Vikram script start
				// SLIP flow, Validates SLIP script and router pre-selection

				if (get("SubFlowType").equalsIgnoreCase("SLIP")) {
					System.out.println("Insdide SLIP Flows");
					try {
						if (isDisplayed(routerSection, "", 1)) {

							if (isDisplayed(routerSectionSlipScript)) {
								report.reportPass("To display SLIP script in router section", "Expected is SLIP script",
										"SLIP script is displayed");
							} else {
								report.reportFail("To display SLIP script in router section", "Expected is SLIP script",
										"SLIP script is not displayed");
							}

							pageScroll(routerSection, "", true);
							report.reportPass("To display Router section", "Display Router Section",
									"Displayed Router Section");

							// Check if option is already selected
							if (isDisplayed(lnkRouterOptions_Selected, "", 0)) {

								SelectedRouter = lnkRouterOptions_Selected.getText();
								System.out.println(SelectedRouter);
								pageScroll(lnkRouterOptions_Selected, "", true);
								report.reportPass("To display pre Selected Router", "Must Pre Select Router",
										SelectedRouter + "Router is Pre Selected");

								if (SelectedRouter.contains("Verizon Provided Fios Quantum Gateway")) {
									System.out.println("Pre Selected router" + SelectedRouter);
									report.reportPass("To validate pre Selected Router",
											"Must pre select Verizon Provided Fios Quantum Gateway",
											SelectedRouter + "Router is Pre Selected");

								} else {
									System.out.println("Selected router" + SelectedRouter);
									report.reportFail("To validate pre Selected Router",
											"Must pre select Verizon Provided Fios Quantum Gateway",
											SelectedRouter + "Router is Pre Selected");

								}

							} else {
								System.out.println("Selected router" + SelectedRouter);
								report.reportFail("To display pre Selected Router", "Must pre select Router",
										SelectedRouter + "Router is not Pre Selected");

							}
						}
					} catch (Exception e) {
						throw new UserDefinedException(strFailed);
					}
				}
				// vikram script end

				// Select the Extender

				if (!extender.isEmpty()) {
					pageScroll(Extenders, extender, true);
					clickUsingJavaScript(Extenders, extender);
					report.reportPass("To select ExtenderOption ",
							extender + "should be available as ExtenderOption and be selectable",
							extender + " ExtenderOption is selected");
					waitForLoader();
					if (!get("NoofBoosters").isEmpty()) {

						int NoOfBoosters = Integer.parseInt(get("NoofBoosters").trim());

						if (NoOfBoosters > 1) {
							for (int i = 1; i < NoOfBoosters; i++) {
								if (isDisplayed(Boosters, "", 5)) {
									pageScroll(Boosters, "", true);
									clickUsingJavaScript(Boosters, "");

								}
							}

						}
					}
					report.reportPass("To select ExtenderOption ",
							extender + "should be available as ExtenderOption and be selectable",
							extender + " ExtenderOption is selected");
					waitForLoader();
				}

				// Select the battery backup option in Product and Services page

				if ((HomePhone.contains("Fios Digital Voice")) || (HomePhone.contains("Home Phone"))
						|| (get("IPTV").toString().equalsIgnoreCase("yes")) && (!strBatteryBackup.isEmpty())) {

					// Validate if Tiles are preselected in Move As is

					if (isDisplayed(lnkBatteryBackupOptions_Selected, objectValue, 2)) {
						SelectedBatteryBackup = lnkBatteryBackupOptions_Selected.getText();
						System.out.println(SelectedBatteryBackup);
					}

					switchToDefaultcontent();
					switchToFrame("IfProducts");

					if (isDisplayed(batterybcp)) {
						pageScroll(batterybcp, extender, true);
						report.reportPass("To View Battery Backup Options ",
								"Verify Battery Backup Options are displayed", "Battery Backup Options are displayed");

					}
					switchToDefaultcontent();
					switchToFrame("IfProducts");
					if (SelectedBatteryBackup.toLowerCase().contains(strBatteryBackup.trim().toLowerCase())) {
						report.reportPass("To select Battery Backup Option ",
								SelectedBatteryBackup + "is preselected as Battery Backup Option.",
								"No change in Battery Backup Option selection proceeding with Existing Battery Backup Option "
										+ SelectedBatteryBackup);
					} else if (isDisplayed(Batterybackup_Agreement)) {
						clickUsingJavaScript(Batterybackup_Agreement, "");
					} else {

						if (isDisplayed(batterycustomer, objectValue)) {
							pageScroll(batterycustomer, (strBatteryBackup).trim(), true);
							clickUsingJavaScript(batterycustomer, (strBatteryBackup).trim());

							report.reportPass("To select Battery Backup Option ",
									strBatteryBackup + "should be available as Battery Backup Option and be selectable",
									strBatteryBackup + " Battery Backup Option is selected");
							waitForLoader();
						} else if (isDisplayed(selectBatteryBackupOptions, (strBatteryBackup).trim(), 1)) {
							try {
								// different from coa
								// pageScroll(batterySection, "");
								pageScroll(selectBatteryBackupOptions, (strBatteryBackup).trim(), true);
								clickUsingJavaScript(selectBatteryBackupOptions, (strBatteryBackup).trim());

								report.reportPass("To select Battery Backup Option ",
										strBatteryBackup
												+ "should be available as Battery Backup Option and be selectable",
										strBatteryBackup + " Battery Backup Option is selected");
								waitForLoader();

								// product-tile-list[@typeofprd='Battery']/div/div[2]
							} catch (Exception e) {

								strFailed = "Failed in Equipment section, Required Batterybackup option "
										+ strBatteryBackup + " is not present.";
								report.reportFail("To select Battery backup option",
										"Battery backup optoin should be selected.", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								logger.error(strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);

							}
						} else {
							if (isDisplayed(textbatterybackup, "", 1)) {

								String s = getTextFromElement(textbatterybackup, objectValue);
								System.out.println(s);
								try {
									// different from coa
									// pageScroll(batterySection, "");
									pageScroll(declinebatterybackup, objectValue, true);
									click(declinebatterybackup, objectValue);

									report.reportPass("To select Battery Backup Option ",
											s + "should be available as Battery Backup Option and be selectable",
											s + " Battery Backup Option is selected");
									waitForLoader();
									// update for FCP
									// mithra update decline reason
									// strBatteryBackupDeclineReason
									pageScroll(selectBatteryBackupDeclineReason, (strBatteryBackupDeclineReason).trim(),
											true);
									clickUsingJavaScript(selectBatteryBackupDeclineReason,
											(strBatteryBackupDeclineReason).trim());

									report.reportPass("To click Battery Backup decline reason Option ",
											strBatteryBackupDeclineReason
													+ "should be selected as Battery Backup decline reason",
											strBatteryBackupDeclineReason
													+ " Battery Backup decline reason Option is selected");
									waitForLoader();
									// update for FCP

								} catch (Exception e) {

									strFailed = "Failed in Equipment section, Required Batterybackup option " + s
											+ " is not present.";
									report.reportFail("To select Battery backup option",
											"Battery backup optoin should be selected.", s);
									report.updateMainReport("comments", strFailed);
									report.updateMainReport("ErrorMessage", strFailed);
									logger.error(strFailed);
									captureErrorMsg(strFailed);
									throw new UserDefinedException(strFailed);

								}
							}

						}

					}

				}
				if (get("SubFlowType").equalsIgnoreCase("TVStbpriceup") || get("SubFlowType").equalsIgnoreCase("HNP")) {
					validateHNP();
				}
				// select Equipment Return Option
				if (!equipReturnOpt.isEmpty()) {
					pageScroll(expandEquipmentReturnOption, objectValue, true);
					clickUsingJavaScript(expandEquipmentReturnOption, objectValue);
					waitForLoader();
					waitForLoader();
					waitForLoader();
					report.reportPass("To Display Equipment Return Options ",
							" Verify Equipment Return Options are displayed", "Equipment Return Options are displayed");
					if (isDisplayed(EquipmentReturnOptionTextList, objectValue, 5)) {
						report.reportPass("To select Equipment Return Option  ",
								equipReturnOpt + " should be selected if available", equipReturnOpt
										+ " is not selected since the message 'Equipment Delivery not needed for this order' is displayed.");
					} else {
						String OT = OneTime.getText();
						System.out.println(OT);
						// clickUsingJavaScript(OneTime, objectValue);
						if (OT.toLowerCase().contains(equipReturnOpt.toLowerCase().trim())) {

							report.reportPass("To select Equipment Return Option  ",
									equipReturnOpt + " should be selected if available",
									equipReturnOpt + " Equipment Return Option is selected");
							waitForLoader();
						} else {
							if (isDisplayed(EquipmentReturnOption, equipReturnOpt, 6)) {
								;
								pageScroll(EquipmentReturnOption, equipReturnOpt, true);
								clickUsingJavaScript(EquipmentReturnOption, equipReturnOpt);
								report.reportPass("To select Equipment Return Option  ",
										equipReturnOpt + " should be selected if available",
										equipReturnOpt + " Equipment Return Option is selected");
								waitForLoader();
							}
						}
						// Vignesh
						if (equipReturnOpt.contains("Store Pick Up")) {
							if (isDisplayed(DropOff_EmailSearch_txtbox)) {

								pageScroll(DropOff_EmailSearch_btn, "", true);
								clearText(DropOff_EmailSearch_txtbox, "");
								setText(DropOff_EmailSearch_txtbox, "", get("Email"));
								report.reportPass("Enter customer email address to send store locations",
										"customer email address should be entered",
										"customer email address is entered Successfully!");
								click(DropOff_EmailSearch_btn);
								waitForLoader();
								if (isDisplayed(DropOff_Email_success_msg, "", 10)) {
									report.reportPass("send store locations to customer email address",
											"Store locations should be sent Successfully", "Email Sent Successfully!");

								} else {

									report.reportFail("send store locations to customer email address",
											"Store locations should be sent Successfully",
											"Email is not Sent Successfully!");
								}
							} else {

								report.reportFail("verify option to send store location",
										"option to send store location should be available",
										"option to send store location is not available");
							}

						}
						// Vignesh
					}
				}

				// Exchange Options - Equipment Returns : Added By
				// Naresh,Madipelly
				if (!get("ExchangeOptions").isEmpty() && get("FlowType").equals("Change")) {
					validateEquipmentDeliveryAndReturns();
				}

				// Collapse Equipments
				if (getAttribute(expandEquipmentsAccessoriesRibbon, objectValue, "class").contains("open")) {
					pageScroll(expandEquipmentsAccessoriesRibbon, objectValue, true);
					clickUsingJavaScript(expandEquipmentsAccessoriesRibbon, objectValue);
					waitForLoader();
					waitForLoader();
					waitForLoader();
				}

				if (get("FlowType").contains("Move") || (get("FlowType").equalsIgnoreCase("MoveAsIs"))) {
					if (isDisplayed(expandEquipmentReturnOption, objectValue, 6)) {
						pageScroll(expandEquipmentReturnOption, objectValue, true);
						clickUsingJavaScript(expandEquipmentReturnOption, objectValue);
						waitForLoader();
						waitForLoader();
						waitForLoader();
					}
				}

				// Switching to Default Content
				switchToDefaultcontent();
			}

		} catch (Exception exe) {

			exe.printStackTrace();
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in Equipment section.");
			}

			throw exe;

		}
		Thread.sleep(5000);
		// Moving to PremiumChannels

		if (!get("FlowType").contains("OwnerShip")) {
			selectPremiumChannels();
		}
	}

	/**
	 * @Description: selectPremiumChannels is used to change the Number of Tv's,
	 *               Recording Options, TV Equipment, Router Option, Select
	 *               Battery Backup and Equipment Return Option for C2G and COA
	 *               Change
	 * @author: Mounika, Padmini
	 * @UpdatedBy - Shiva Kumar Simharaju -- 07/04/2018
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */
	public void selectPremiumChannels() throws Exception, UserDefinedException {

		System.out.println("->selectPremiumChannels");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "Negotiate Premium Channel section";
		strExpected = "Premium Channel section should be selected";
		strActual = "Premium Channel section is negotiated successfully";
		getUrl = ", URL Launched --> " + returnURL();

		try {

			// Switch Frame
			switchToDefaultcontent();

			switchToFrame("IfProducts");

			if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
				UIValidations_PremiumChannels();
			}

			String premiumChannels = get("PremiumChannels").trim();
			String payPerView = get("PayPerView").trim();
			String channelType = get("ChannelType").trim();

			String Video = "";
			String SelectedPremiums = "";
			ArrayList<String> SelectedPremiumChannelList = new ArrayList<String>();
			if (get("SubFlowType").equalsIgnoreCase("FiOS TV Premium Repackaging")) {

				if (get("FlowType").equalsIgnoreCase("Install") && get("Application").equalsIgnoreCase("COA")) {

					// to read selected TV from TV section
					if (isDisplayed(simplex_SelectedTV, "", 1)) {
						Video = getTextFromElement(simplex_SelectedTV, "");
						System.out.println(Video);
					}
					waitForLoader();
					String region = "NYDMA";

					// To define flow type i.e to know whether existing ultimate
					// or extreme Tv or new
					String flow = "";
					if (get("FlowType").equalsIgnoreCase("Install"))
						flow = "new";
					else if (!get("FlowType").equalsIgnoreCase("Install")) {
						if (isDisplayed(ExistingTV)) {
							if ((getTextFromElement(ExistingTV, "").toLowerCase().contains("ultimate")
									&& (Video.toLowerCase().contains("ultimate")))
									|| getTextFromElement(ExistingTV, "").toLowerCase().contains("extreme")
											&& (Video.toLowerCase().contains("extreme")))
								flow = "embedded";
							else
								flow = "new";

						} else
							flow = "new";
					}
					// to get bundletype
					String BundleType = "";
					if (Video.toLowerCase().contains("standalone"))
						BundleType = "standalone";
					else
						BundleType = "bundle";
					String tvproduct = "";
					String ZeroRatedPremium = "";
					if (Video.toLowerCase().contains("extreme") || Video.toLowerCase().contains("ultimate")) {
						if (Video.toLowerCase().contains("extreme"))
							tvproduct = "extreme";
						else if (Video.toLowerCase().contains("ultimate"))
							tvproduct = "ultimate";
						ArrayList<HashMap<String, String>> ZeroRatedPremiumList = ReadExcelData("InputSheetForMO.xls",
								"ZeroRatedPremium");
						for (int i = 0; i < ZeroRatedPremiumList.size(); i++) {
							System.out.println(ZeroRatedPremiumList.get(i).get("Video"));
							System.out.println(ZeroRatedPremiumList.get(i).get("Region"));
							System.out.println(ZeroRatedPremiumList.get(i).get("Type"));
							System.out.println(ZeroRatedPremiumList.get(i).get("Bundle"));
							if (ZeroRatedPremiumList.get(i).get("Video").contains(tvproduct.toLowerCase())
									&& ZeroRatedPremiumList.get(i).get("Region").contains(region.toLowerCase())
									&& ZeroRatedPremiumList.get(i).get("Type").contains(flow.toLowerCase())
									&& ZeroRatedPremiumList.get(i).get("Bundle").contains(BundleType.toLowerCase())) {
								ZeroRatedPremium = ZeroRatedPremiumList.get(i).get("ZeroRated");
								break;
							}
						}

						if (!getAttribute(Premium_Section, objectValue, "class").contains("open")) {
							pageScroll(Premium_Section, objectValue, true);
							clickUsingJavaScript(Premium_Section, objectValue);

						}
						if (isDisplayed(Selected_Premium, "", 0)) {
							SelectedPremiums = getTextFromElement(Selected_Premium, objectValue);
							System.out.println(SelectedPremiums);
							String[] SelectedPremiumsList = SelectedPremiums.split("\\+");

							for (String readChannel : SelectedPremiumsList) {
								if (readChannel.toLowerCase().trim().contains("(")) {
									SelectedPremiumChannelList
											.add(readChannel.substring(readChannel.indexOf("(") + 1).trim());
								} else if (readChannel.toLowerCase().trim().contains(")")) {
									SelectedPremiumChannelList
											.add(readChannel.substring(0, readChannel.indexOf(")")).trim());
								} else {
									SelectedPremiumChannelList.add(readChannel.trim());
								}

							}
						}

						if (ZeroRatedPremium.isEmpty() && SelectedPremiums.toLowerCase().contains("zero rated")) {
							for (int i = 0; i < SelectedPremiumChannelList.size(); i++) {
								if (SelectedPremiumChannelList.get(i).toLowerCase().contains("zero rated")) {
									report.reportFail("Verify Zero rated Premiums",
											"There should be no zero rated premium",
											"Zero rated premium" + SelectedPremiumChannelList.get(i));

								}
							}
						} else
							if (ZeroRatedPremium.isEmpty() && !SelectedPremiums.toLowerCase().contains("zero rated")) {
							report.reportPass("Verify Zero rated Premiums", "There should be no zero rated premium",
									"premium channel not zero rated");
						} else {

							String[] zeroratedlist = ZeroRatedPremium.split(",");
							for (String Premium : zeroratedlist) {
								boolean zerorated = false;
								for (int i = 0; i < SelectedPremiumChannelList.size(); i++) {
									if (SelectedPremiumChannelList.get(i).toLowerCase().contains(Premium.trim())
											&& SelectedPremiumChannelList.get(i).toLowerCase().contains("zero rated")) {
										report.reportPass("Verify Zero rated Premiums",
												Premium + " should be zero rated", "Zero rated premium" + Premium);

										zerorated = true;
										SelectedPremiumChannelList.remove(i);
									}
								}
								if (!zerorated) {
									report.reportFail("Verify Zero rated Premiums", Premium + " should be zero rated",
											Premium + " not zero rated");

								}

							}

							for (int i = 0; i < SelectedPremiumChannelList.size(); i++) {
								if (SelectedPremiumChannelList.get(i).toLowerCase().contains("zero rated")) {
									report.reportFail("Verify Zero rated Premiums",
											"There should be no zero rated premium",
											"Zero rated premium" + SelectedPremiumChannelList.get(i));

								}
							}

						}
					}
				}
			}
			// get selected premium plans
			if (isDisplayed(simplex_SelectedTV, "", 1)) {
				Video = getTextFromElement(simplex_SelectedTV, "");
				System.out.println(Video);
			}
			waitForLoader();

			if (!Video.isEmpty() && (!premiumChannels.isEmpty() || !payPerView.isEmpty())) {
				// Expand premium channels
				if (!getAttribute(Premium_Section, objectValue, "class").contains("open")) {
					pageScroll(Premium_Section, objectValue, true);
					clickUsingJavaScript(Premium_Section, objectValue);

				}

				// get the value of selected premium
				String[] channelTypelist = channelType.split(",");
				System.out.println(channelTypelist);
				String[] listChannels = premiumChannels.split(";");
				System.out.println(listChannels);

				if (isDisplayed(Selected_Premium, "", 0)) {
					SelectedPremiums = getTextFromElement(Selected_Premium, objectValue);
					System.out.println(SelectedPremiums);

					String[] SelectedPremiumsList = SelectedPremiums.split("\\+");

					for (String readChannel : SelectedPremiumsList) {
						if (readChannel.toLowerCase().trim().contains("(")) {
							SelectedPremiumChannelList.add(readChannel.substring(readChannel.indexOf("(") + 1).trim());
						} else if (readChannel.toLowerCase().trim().contains(")")) {
							SelectedPremiumChannelList.add(readChannel.substring(0, readChannel.indexOf(")")).trim());
						} else {
							SelectedPremiumChannelList.add(readChannel.trim());
						}

					}
				}
				// click more premium channels
				clickUsingJavaScript(More_Permium_channel, objectValue);
				report.reportPass("Click on more premium channels link",
						"More premium channels link should be clicked.", "Clicked on more premium channels link.");
				waitForLoader();

				waitForLoader();
				// Switch Frame
				switchToDefaultcontent();
				switchToFrame("IfProducts");
				String[] allChannels = null;
				if (!premiumChannels.isEmpty()) {

					// click on different channels types
					for (int i = 0; i < channelTypelist.length; i++) {

						try {
							pageScroll(MoreChannelType, channelTypelist[i].toLowerCase().trim(), true);
							clickUsingJavaScript(MoreChannelType, channelTypelist[i].toLowerCase().trim());
							report.reportPass("Click on category.", "Channel category should be clicked.",
									"Clicked on " + channelTypelist[i].trim() + "channel category");

						} catch (Exception e) {

							strFailed = "Failed in Premium channels section, Required channel category or type is not present, please check test data in run manager sheet.";
							report.reportFail("Select channel category.", "Channel category should be selected.",
									strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							logger.error(strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}

						allChannels = listChannels[i].split(",");

						// click on channels
						for (String premiumChannel : allChannels) {
							System.out.println(premiumChannel);
							if (premiumChannel.toUpperCase().contains(":X")) {
								premiumChannel = premiumChannel.split(":X")[0];
								if (SelectedPremiums.toLowerCase().contains(premiumChannel.toLowerCase().trim())) {
									clickUsingJavaScript(Premium_channel_tile, premiumChannel.trim());
									report.reportPass("Deselect channel" + premiumChannel,
											"Channel should be deselected.", "Deselected channel" + premiumChannel);
								}
							} else {
								boolean selectedChannel = false;
								for (int ch = 0; ch < SelectedPremiumChannelList.size(); ch++) {
									if (SelectedPremiumChannelList.get(ch).trim()
											.equalsIgnoreCase(premiumChannel.trim())) {
										selectedChannel = true;
									}
								}
								if (!selectedChannel) {
									// if
									// (!SelectedPremiums.toLowerCase().contains(premiumChannel.toLowerCase().trim()))
									// {

									try {
										premiumChannel = premiumChannel.trim();
										if (isDisplayed(Premium_channel_tile, premiumChannel, 0)) {
											pageScroll(Premium_channel_tile, premiumChannel.trim(), true);
											clickUsingJavaScript(Premium_channel_tile, premiumChannel.trim());
											report.reportPass(
													"Simplex Page  ordering - Verify able to check premium channel:"
															+ premiumChannel,
													"Should be able to check premium channel",
													"Able to check premium channel:" + premiumChannel);
										} else if (isDisplayed(Premium_channel_tile, premiumChannel.toLowerCase(), 0)) {
											pageScroll(Premium_channel_tile, premiumChannel.toLowerCase(), true);
											clickUsingJavaScript(Premium_channel_tile, premiumChannel.toLowerCase());
											report.reportPass(
													"Simplex Page  ordering - Verify able to check premium channel:"
															+ premiumChannel.toLowerCase(),
													"Should be able to check premium channel",
													"Able to check premium channel:" + premiumChannel.toLowerCase());
										} else if (isDisplayed(Premium_channel_tile, premiumChannel.toUpperCase(), 0)) {
											pageScroll(Premium_channel_tile, premiumChannel.toUpperCase(), true);
											clickUsingJavaScript(Premium_channel_tile, premiumChannel.toUpperCase());
											report.reportPass(
													"Simplex Page  ordering - Verify able to check premium channel:"
															+ premiumChannel.toUpperCase(),
													"Should be able to check premium channel",
													"Able to check premium channel:" + premiumChannel.toUpperCase());
										} else {
											premiumChannel = Character.toUpperCase(premiumChannel.charAt(0))
													+ premiumChannel.substring(1).toLowerCase();
											pageScroll(Premium_channel_tile, premiumChannel, true);
											clickUsingJavaScript(Premium_channel_tile, premiumChannel);
											report.reportPass(
													"Simplex Page  ordering - Verify able to check premium channel:"
															+ premiumChannel,
													"Should be able to check premium channel",
													"Able to check premium channel:" + premiumChannel);
										}

									} catch (Exception e) {
										strFailed = "Failed in Premium channels section, Required premium channel "
												+ premiumChannel + " not available.";
										report.reportFail("Select Premium channels",
												"Premium channels should be selected.", strFailed);
										report.updateMainReport("comments", strFailed);
										report.updateMainReport("ErrorMessage", strFailed);
										logger.error(strFailed);
										captureErrorMsg(strFailed);
										throw new UserDefinedException(strFailed);
									}

								}
							}
						}

					}
				}

				// payperview
				if (!payPerView.isEmpty()) {

					try {
						clickUsingJavaScript(PayPerView_Tab, objectValue);
						if (payPerView.equalsIgnoreCase("y")) {
							if (!getAttribute(Enable_PPV_isSelected, objectValue, "class").toLowerCase()
									.contains("selected"))
								clickUsingJavaScript(Enable_PayPerView, objectValue);
							report.reportPass("Simplex Page  ordering - Verify able to enable Pay Per View",
									"Should be able to enable Pay Per View", "Able to enable Pay Per View");
						} else if (payPerView.equalsIgnoreCase("n")) {
							if (!getAttribute(Disable_PPV_isSelected, objectValue, "class").toLowerCase()
									.contains("selected"))
								clickUsingJavaScript(Disable_PayPerView, objectValue);
							report.reportPass("Simplex Page  ordering - Verify able to disable Pay Per View",
									"Should be able to disable Pay Per View", "Able to disable Pay Per View");
						}
					} catch (Exception exe) {
						strFailed = "Failed in Premium channels section, Failed to select or deselect pay per view";
						report.reportFail("Select or deselect pay per view.",
								"Payper view should be selected or deselected based on test data.", strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						logger.error(strFailed);
						captureErrorMsg(strFailed);
						throw new UserDefinedException(strFailed);
					}
				}

				// Switch Frame
				switchToDefaultcontent();
				switchToFrame("IfProducts");

				// save changes
				clickUsingJavaScript(PremiumChannel_Update, objectValue);

				report.reportPass("Click on premium channel update button.",
						"Premium channel udpate button should be clicked.",
						"Clicked on premium channel udpate button.");

				if (isDisplayed(loyaltyUpdate, "", 2)) {
					clickUsingJavaScript(loyaltyUpdate, objectValue);
					waitForLoader();
				}

				// Switch Frame
				switchToDefaultcontent();
				switchToFrame("IfProducts");
				if (isDisplayed(manualOffers, "", 5)) {
					clickUsingJavaScript(manualOffers, objectValue);
					waitForLoader();
				}

				// save changes
				// clickUsingJavaScript(PremiumChannel_Update, objectValue);

				report.reportPass(strDescription + getUrl, strExpected, strActual);

				// Validating Marketing Offers in Premium channel section

				if (!get("MarketingOfferType").isEmpty() && !get("PremiumChannels").isEmpty()) {

					premiumChannelsMOValidations();
				}

				if (getAttribute(Premium_Section, objectValue, "class").contains("open")) {
					pageScroll(Premium_Section, objectValue, true);
					clickUsingJavaScript(Premium_Section, objectValue);

				}
			}

			// Switching to Default Content
			switchToDefaultcontent();

		} catch (Exception exe) {
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in Premium channels section.");
			}

			throw exe;
		}

		// Moving to Streaming Option
		selectStreamingOption();
	}

	/**
	 * @Description: selectStreamingOption is used to change the Streaming
	 *               Option
	 * @param: StreamingOptionString
	 *             is used to Select the Streaming Option
	 * @author: Mounika, Padmini
	 * @LastUpdatedBy -- Shiva Kumar Simharaju
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */
	public void selectStreamingOption() throws Exception, UserDefinedException {

		System.out.println("->selectStreamingOption");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		getUrl = ", URL Launched --> " + returnURL();
		try {
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			String streamingOption = get("StreamingOption").trim();

			if (!streamingOption.isEmpty()) {
				// Expand Streaming Option
				if (!getAttribute(tabStreamingOptionsSection, "", "class").contains("open")) {
					pageScroll(tabStreamingOptionsSection, "", true);
					clickUsingJavaScript(tabStreamingOptionsSection, "");
					waitForLoader();
				}

				// Set Streaming Option
				if (streamingOption.toLowerCase().contains(":x")) {
					// Deselect a preselected Streaming Option
					clickUsingJavaScript(tabStreamingOption_Selected, streamingOption);
					report.reportPass("DeSelect Streaming option", "Streaming option should be deselected.",
							"DeSelected " + streamingOption + " Steaming option");

				} else {
					try {
						// Select the recording options in Product and Services
						// page
						clickUsingJavaScript(lnkStreamingOptions_notSelected, streamingOption);
						report.reportPass("Select Streaming option", "Streaming option should be selected.",
								"Selected " + streamingOption + " Steaming option");
					} catch (Exception e) {
						strFailed = "Failed in Streaming options section, Required streaming option " + streamingOption
								+ " not available.";
						report.reportFail("Select streaming option.", "Streaming option should be selected.",
								strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						logger.error(strFailed);
						captureErrorMsg(strFailed);
						throw new UserDefinedException(strFailed);
					}

				}
				waitForLoader();
				if (isDisplayed(Yesbutton, objectValue)) {
					clickUsingJavaScript(Yesbutton, objectValue);
					waitForLoader();
				}

			}

			if (getAttribute(tabStreamingOptionsSection, "", "class").contains("open")) {
				pageScroll(tabStreamingOptionsSection, "", true);
				clickUsingJavaScript(tabStreamingOptionsSection, "");
				waitForLoader();
			}
			// Switching to Default Content
			switchToDefaultcontent();

		} catch (Exception exe) {
			exe.printStackTrace();
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in Streaming options section.");
			}
			throw exe;

		}

		// Moving to VAS Option
		if (get("Application").equalsIgnoreCase("C2G")) {
			selectVASOptionC2G();
		} else {

			selectVASOption();
		}
	}

	/**
	 * @Info selectVASOption
	 * @param VAS_Product
	 * @throws Exception
	 * @Author:Mounika,Padmini
	 * @lastModfiedBy Shiva Kumar SImharaju
	 * @LastUpdated :
	 * @Comments:
	 */

	public void selectVASOption() throws Exception, UserDefinedException {

		System.out.println("->selectVASOption");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "To negotiate VASOption section";
		strExpected = "VASOption section should be selected";
		strActual = "VASOption is negotiated successfully";
		getUrl = ", URL Launched --> " + returnURL();
		try {
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			String vasProduct = get("VASProduct").trim();
			String vasipMoveASIS = get("VasipMoveASIS").trim();
			String internetPlan = get("InternetPlan").trim();

			// String Data=getTextFromElement(OPOSelectedData, objectValue);

			String Data = "";

			if (!internetPlan.isEmpty() && get("GUI_Validations").equalsIgnoreCase("Yes")) {
				UIValidations_BBE_Validation();
			}

			if (isDisplayed(simplex_SelectedData, "")) {
				Data = simplex_SelectedData.getText().trim();
			}
			if ((!Data.isEmpty() && (!vasProduct.isEmpty())))

			{
				Set<String> allExistingWindows = driver.getWindowHandles();

				// Expanding VAS tab
				if (!tabVAS.getAttribute("class").contains("open")) {
					pageScroll(tabVAS, objectValue, true);
					clickUsingJavaScript(tabVAS, objectValue);
					report.reportPass("Expand BBE", "Expand BBE", "BBE is expanded");
					waitForLoader();
				}

				// AClicking on More VAS Option

				waitForLoader();
				waitForLoader();
				waitForLoader();
				waitForLoader();
				waitForLoader();

				waitForLoader();

				click(MoreVAS, objectValue);

				Thread.sleep(5000);
				Thread.sleep(5000);
				Thread.sleep(5000);
				Thread.sleep(5000);
				waitForLoader();
				waitForLoader();
				waitForLoader();

				report.reportPass("Click on more VAS options link", "More VAS options link should be clicked.",
						"Clicked on more VAS options link.");
				Thread.sleep(5000);
				String productsWindow = driver.getWindowHandle();
				// Switching to BBE window
				Set<String> allWindows = driver.getWindowHandles();
				for (String Child_Window : allWindows) {

					if (!allExistingWindows.contains(Child_Window)) {
						driver.switchTo().window(Child_Window);
						waitForLoader();
						waitForLoader();
						break;
					}

				}
				System.out.println(driver.getTitle());
				waitForLoader();

				// Selectiong the required Product from Vas Page

				String[] listChannels = vasProduct.split(";");
				System.out.println(listChannels);
				try {
					for (int i = 0; i < listChannels.length; i++) {
						System.out.println(listChannels[i]);
						if (listChannels[i].toUpperCase().contains(":X")) {

							String BBEProduct = listChannels[i].split(":X")[0];
							pageScroll(RemoveBBE, BBEProduct, true);
							report.reportPass("Display Existing BBE", "Display Existing BBE",
									"Existing BBE is displayed");
							clickUsingJavaScript(RemoveBBE, BBEProduct);
							waitForLoader();
							report.reportPass("Check whether BBE is removed", "Check whether BBE is removed",
									"BBE is removed");
							clickUsingJavaScript(ChangeBtn, BBEProduct);
							// waitForLoader();
							waitForLoader();
							waitForLoader();
							// clickUsingJavaScript(RemoveBBE, BBEProduct);

							waitForLoader();
							report.reportPass("Select Reason for Removing BBE", "Select Reason for Removing BBE",
									"Selected Reason for Removing BBE");
						} else {
							if (listChannels[i].equalsIgnoreCase("TechSure Plus")
									|| listChannels[i].equalsIgnoreCase("TechSure Premium")) {
								if (listChannels[i].equalsIgnoreCase("TechSure Plus")) {
									pageScroll(VASProduct_TechSurePlus_ProductsPage, productsWindow, true);
									clickUsingJavaScript(VASProduct_TechSurePlus_ProductsPage, "");
									waitForLoader();
									report.reportPass("Select VAS Product TechSure Plus",
											"VAS Product TechSure Plus must be selected", "TechSure Plus is selected");
								} else if (listChannels[i].equalsIgnoreCase("TechSure Premium")) {
									pageScroll(VASProduct_TechSurePremium_ProductsPage, productsWindow, true);
									clickUsingJavaScript(VASProduct_TechSurePremium_ProductsPage, "");
									report.reportPass("Select VAS Product TechSure Premium",
											"VAS Product TechSure Premium must be selected",
											"TechSure Plus Premium is selected");
									waitForLoader();
									if (isDisplayed(VASProduct_TechSurePremium_Coverage, productsWindow, 1)) {
										clickUsingJavaScript(VASProduct_TechSurePremium_Coverage, objectValue);
									}
								}
								System.out.println("");
								switchToFrame("IfProducts");

								List<WebElement> fsname = driver
										.findElements(By.xpath("//input[@id='txtParentFirstName']"));
								for (int x = 0; x < fsname.size(); x++) {
									if (isDisplayed(fsname.get(x))) {

										fsname.get(x).sendKeys("Passlow");
										waitForLoader();
										break;
									}
								}
								report.reportPass(
										"For VAS Product " + get("VASProduct").trim()
												+ " input must be provided in First Name field",
										"Input provided in First Name Field",
										"Input provided in First Name field is .Passlow");
								List<WebElement> Lsname = driver
										.findElements(By.xpath("//input[@id='txtParentLastName']"));
								for (int y = 0; y < Lsname.size(); y++) {

									if (isDisplayed(Lsname.get(y))) {

										Lsname.get(y).sendKeys("Customer");
										waitForLoader();
										break;
									}
								}
								report.reportPass(
										"For VAS Product " + get("VASProduct").trim()
												+ " input must be provided in Last Name field",
										"Input provided in Last Name Field",
										"Input provided in Last Name field is .Customer");

								// check for Junior & Senior selection
								if (get("TechSure_LifeLock_Adult").equalsIgnoreCase("Yes")) {
									if (get("TechSure_LifeLock_Adult_Quantity").equals("1")) {

										List<WebElement> CheckboxAdult = driver
												.findElements(By.xpath("//input[@id='chkDGAdultSubscription']"));
										for (int z = 0; z < CheckboxAdult.size(); z++) {

											if (isDisplayed(CheckboxAdult.get(z))) {

												CheckboxAdult.get(z).click();
												waitForLoader();
												break;
											}
										}

										List<WebElement> AdultFisrtName = driver
												.findElements(By.xpath("//input[@id='txtAdultFirstName']"));
										for (int x1 = 0; x1 < AdultFisrtName.size(); x1++) {

											if (isDisplayed(AdultFisrtName.get(x1))) {

												AdultFisrtName.get(x1).sendKeys("Yugendher");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Adult Product input must be provided in First Name field",
														"Input provided in First Name Field",
														"Input provided in First Name field is .Yegendher");
												break;
											}
										}
										List<WebElement> AdultLastName = driver
												.findElements(By.xpath("//input[@id='txtAdultLastName']"));
										for (int x2 = 0; x2 < AdultLastName.size(); x2++) {

											if (isDisplayed(AdultLastName.get(x2))) {
												AdultLastName.get(x2).sendKeys("Reddy");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Adult Product input must be provided in Last Name field",
														"Input provided in Last Name Field",
														"Input provided in Last Name field is .Yegendher");
												break;
											}
										}
										List<WebElement> AdultEmail = driver
												.findElements(By.xpath("//input[@id='txtAdultEmail']"));
										for (int x3 = 0; x3 < AdultEmail.size(); x3++) {

											if (isDisplayed(AdultEmail.get(x3))) {
												AdultEmail.get(x3).sendKeys("yugendhar.m.reddy@g.verizon.com");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Adult Product input must be provided in Email Name field",
														"Input provided in Email Field",
														"Input provided in Last Name field is .yugendhar.m.reddy@g.verizon.com");
												break;
											}
										}

									} else if (get("TechSure_LifeLock_Adult_Quantity").equals("2")) {
										List<WebElement> CheckboxAdult = driver
												.findElements(By.xpath("//input[@id='chkDGAdultSubscription']"));
										for (int z = 0; z < CheckboxAdult.size(); z++) {

											if (isDisplayed(CheckboxAdult.get(z))) {

												CheckboxAdult.get(z).click();
												waitForLoader();
												break;
											}
										}

										List<WebElement> AdultFisrtName = driver
												.findElements(By.xpath("//input[@id='txtAdultFirstName']"));
										for (int x1 = 0; x1 < AdultFisrtName.size(); x1++) {

											if (isDisplayed(AdultFisrtName.get(x1))) {

												AdultFisrtName.get(x1).sendKeys("Yugendher");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Adult Product input must be provided in First Name field",
														"Input provided in First Name Field",
														"Input provided in First Name field is .Yegendher");
												break;
											}
										}
										List<WebElement> AdultLastName = driver
												.findElements(By.xpath("//input[@id='txtAdultLastName']"));
										for (int x2 = 0; x2 < AdultLastName.size(); x2++) {

											if (isDisplayed(AdultLastName.get(x2))) {
												AdultLastName.get(x2).sendKeys("Reddy");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Adult Product input must be provided in Last Name field",
														"Input provided in Last Name Field",
														"Input provided in Last Name field is .Yegendher");
												break;
											}
										}
										List<WebElement> AdultEmail = driver
												.findElements(By.xpath("//input[@id='txtAdultEmail']"));
										for (int x3 = 0; x3 < AdultEmail.size(); x3++) {

											if (isDisplayed(AdultEmail.get(x3))) {
												AdultEmail.get(x3).sendKeys("yugendhar.m.reddy@g.verizon.com");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Adult Product input must be provided in Email Name field",
														"Input provided in Email Field",
														"Input provided in Last Name field is .yugendhar.m.reddy@g.verizon.com");
												break;
											}
										}

										List<WebElement> AddAdultSubscription = driver
												.findElements(By.xpath("//a[@id='lnkAddAdultSubscription']"));
										for (int x3 = 0; x3 < AddAdultSubscription.size(); x3++) {

											if (isDisplayed(AddAdultSubscription.get(x3))) {
												AddAdultSubscription.get(x3).click();
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Adult Product Add More Subscription link must be clicked",
														"Add more subscription link is clicked",
														"Add more subscription link is clicked");
												break;
											}
										}

										Thread.sleep(1000);
										List<WebElement> AdultFsName2 = driver
												.findElements(By.xpath("//input[contains(@id,'txtAdultFirstName2')]"));
										for (int x3 = 0; x3 < AdultFsName2.size(); x3++) {

											if (isDisplayed(AdultFsName2.get(x3))) {
												AdultFsName2.get(x3).sendKeys("Naresh");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Adult Product input must be provided in First Name field",
														"Input provided in First Name Field",
														"Input provided in First Name field is . Naresh");
												break;
											}
										}
										List<WebElement> AdultLsName2 = driver
												.findElements(By.xpath("//input[contains(@id,'txtAdultLastName2')]"));
										for (int x3 = 0; x3 < AdultLsName2.size(); x3++) {

											if (isDisplayed(AdultLsName2.get(x3))) {
												AdultLsName2.get(x3).sendKeys("Madipelly");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Adult Product input must be provided in Last Name field",
														"Input provided in Last Name Field",
														"Input provided in Last Name field is . Madipelly");
												break;
											}
										}

										List<WebElement> AdultEmail2 = driver
												.findElements(By.xpath("//input[contains(@id,'txtAdultEmail2')]"));
										for (int x3 = 0; x3 < AdultEmail2.size(); x3++) {

											if (isDisplayed(AdultEmail2.get(x3))) {
												AdultEmail2.get(x3).sendKeys("naresh.madipelly2@verizon.com");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Adult Product input must be provided in Email Name field",
														"Input provided in Email Field",
														"Input provided in Last Name field is . naresh.madipelly2@verizon.com");
												break;
											}
										}

									}

								}
								if (get("TechSure_LifeLock_Junior").equalsIgnoreCase("Yes")) {
									if (get("TechSure_LifeLock_Junior_Quantity").equals("1")) {

										List<WebElement> ChckboxJunior = driver
												.findElements(By.xpath("//input[@id='chkDGChildSubscription']"));
										for (int x3 = 0; x3 < ChckboxJunior.size(); x3++) {

											if (isDisplayed(ChckboxJunior.get(x3))) {
												ChckboxJunior.get(x3).click();
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Adult Product Add More Subscription link must be clicked",
														"Add more subscription link is clicked",
														"Add more subscription link is clicked");
												break;
											}
										}
										List<WebElement> JuniorFname = driver
												.findElements(By.xpath("//input[@id='txtChildFirstName']"));
										for (int x3 = 0; x3 < JuniorFname.size(); x3++) {

											if (isDisplayed(JuniorFname.get(x3))) {
												JuniorFname.get(x3).sendKeys("Soham");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Junior Product input must be provided in First Name field",
														"Input provided in First Name Field",
														"Input provided in First Name field is . Soham");
												break;
											}
										}
										List<WebElement> JuniorLname = driver
												.findElements(By.xpath("//input[@id='txtChildLastName']"));
										for (int x3 = 0; x3 < JuniorLname.size(); x3++) {

											if (isDisplayed(JuniorLname.get(x3))) {
												JuniorLname.get(x3).sendKeys("Shah");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Junior Product input must be provided in Last Name field",
														"Input provided in Last Name Field",
														"Input provided in Last Name field is .Shah");
												break;
											}
										}

									} else if (get("TechSure_LifeLock_Junior_Quantity").equals("2")) {
										List<WebElement> ChckboxJunior = driver
												.findElements(By.xpath("//input[@id='chkDGChildSubscription']"));
										for (int x3 = 0; x3 < ChckboxJunior.size(); x3++) {

											if (isDisplayed(ChckboxJunior.get(x3))) {
												ChckboxJunior.get(x3).click();
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Junior Product Add More Subscription link must be clicked",
														"Add more subscription link is clicked",
														"Add more subscription link is clicked");
												break;
											}
										}
										List<WebElement> JuniorFname = driver
												.findElements(By.xpath("//input[@id='txtChildFirstName']"));
										for (int x3 = 0; x3 < JuniorFname.size(); x3++) {

											if (isDisplayed(JuniorFname.get(x3))) {
												JuniorFname.get(x3).sendKeys("Soham");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Junior Product input must be provided in First Name field",
														"Input provided in First Name Field",
														"Input provided in First Name field is . Soham");
												break;
											}
										}
										List<WebElement> JuniorLname = driver
												.findElements(By.xpath("//input[@id='txtChildLastName']"));
										for (int x3 = 0; x3 < JuniorLname.size(); x3++) {

											if (isDisplayed(JuniorLname.get(x3))) {
												JuniorLname.get(x3).sendKeys("Shah");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Junior Product input must be provided in Last Name field",
														"Input provided in Last Name Field",
														"Input provided in Last Name field is .Shah");
												break;
											}
										}

										List<WebElement> JuniorMoreSubsc = driver
												.findElements(By.xpath("//a[@id='lnkAddChildSubscription']"));
										for (int x3 = 0; x3 < JuniorMoreSubsc.size(); x3++) {

											if (isDisplayed(JuniorMoreSubsc.get(x3))) {
												JuniorMoreSubsc.get(x3).click();
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Junior Product Add More Subscription link must be clicked",
														"Add more subscription link is clicked",
														"Add more subscription link is clicked");
												break;
											}
										}

										Thread.sleep(1000);
										List<WebElement> JuniorFname2 = driver
												.findElements(By.xpath("//input[contains(@id,'txtChildFirstName2')]"));
										for (int x3 = 0; x3 < JuniorFname2.size(); x3++) {

											if (isDisplayed(JuniorFname2.get(x3))) {
												JuniorFname2.get(x3).sendKeys("Alpha");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Junior Product input must be provided in First Name field",
														"Input provided in First Name Field",
														"Input provided in First Name field is .Alpha");
												break;
											}
										}
										List<WebElement> JuniorLname2 = driver
												.findElements(By.xpath("//input[contains(@id,'txtChildLastName2')]"));
										for (int x3 = 0; x3 < JuniorLname2.size(); x3++) {

											if (isDisplayed(JuniorLname2.get(x3))) {
												JuniorLname2.get(x3).sendKeys("Beta");
												waitForLoader();
												report.reportPass(
														"For Tech Sure - LifeLock Junior Product input must be provided in Last Name field",
														"Input provided in Last Name Field",
														"Input provided in Last Name field is .Beta");
												break;
											}
										}

									}

								}

							} else if (listChannels[i].equalsIgnoreCase("TechSure")) {
								pageScroll(VASProduct_TechSure_ProductsPage, productsWindow, true);
								clickUsingJavaScript(VASProduct_TechSure_ProductsPage, "");
								report.reportPass("Verify VASProduct is Selected",
										"Check whether Vas Product is Clicked", "VAS Product is Clicked:");

							} else {
								pageScroll(BBEOptions, listChannels[i].trim(), true);
								clickUsingJavaScript(BBEOptions, listChannels[i].trim());
								report.reportPass("Click on category.", "Channel category should be clicked.",
										"Clicked on " + listChannels[i] + "channel category");
							}
						}
					}

				} catch (Exception e) {
					strFailed = "Failed in VAS section, Required VAS product " + vasProduct + " not available.";
					report.reportFail("Select VAS option.", "VAS option should be selected.", strFailed);
					report.updateMainReport("comments", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					logger.error(strFailed);
					captureErrorMsg(strFailed);
					throw new UserDefinedException(strFailed);
				}

				waitForLoader();
				waitForLoader();
				waitForLoader();

				if (isDisplayed(YesButton, productsWindow, 1)) {
					clickUsingJavaScript(YesButton, objectValue);
					waitForLoader();
					waitForLoader();
				}
				if (isDisplayed(reasonForRemoval, productsWindow, 1)) {
					pageScroll(reasonForRemoval, productsWindow, true);
					report.reportPass("Click on Reason for Removal.", "Click on Reason for Removal.",
							"Reason for Removal is selected");
					selectDropDownUsingIndex(reasonForRemoval, "", 2);
					waitForLoader();
					waitForLoader();

				}

				if (isDisplayed(Submitbtn, productsWindow, 2)) {
					clickUsingJavaScript(Submitbtn, objectValue);
					waitForLoader();
					waitForLoader();
				}

				try {

					// Click on save and COntinue in BBE page
					pageScroll(VASSaveandContinue, productsWindow, true);
					report.reportPass("Click on VAS save and continue button.",
							"Save and continue button should be clicked.",
							"save and continue button should be clicked");
					clickUsingJavaScript(VASSaveandContinue, objectValue);

				} catch (Exception e) {
					strFailed = "Failed in VAS section, Required VAS product " + vasProduct + " not available.";
					report.reportFail("Select VAS option.", "VAS option should be selected.", strFailed);
					report.updateMainReport("comments", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					logger.error(strFailed);
					captureErrorMsg(strFailed);
					throw new UserDefinedException(strFailed);
				}

				Thread.sleep(10000);
				driver.switchTo().window(productsWindow);
				waitForLoader();
				waitForLoader();
				report.reportPass("Click on VAS save and continue button.",
						"Save and continue button should be clicked.", "Clicked on save and continue button.");
				switchToDefaultcontent();
				switchToFrame("IfProducts");

				if (!Data.isEmpty() && (vasipMoveASIS.equalsIgnoreCase("Y"))) {

					try {
						if (isDisplayed(bbeselected, objectValue)) {

							String bbe_selected = bbeselected.getText();
							System.out.println(bbe_selected);

							report.reportPass("To verify if bbe is preselected for moveAsIs",
									"bbe should be preselected", "bbe is PreSelected");
						}
					} catch (Exception e) {

						strFailed = "Failed in VAS section, BBE is not PreSelected";
						report.reportFail("To verify if bbe is preselected for moveAsIs", "BBE should be preselected",
								strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						logger.error(strFailed);
						captureErrorMsg(strFailed);
						throw new UserDefinedException(strFailed);

					}

				}

				if (tabVAS.getAttribute("class").contains("open")) {
					pageScroll(tabVAS, "", true);
					clickUsingJavaScript(tabVAS, objectValue);
				}
				// Switching to Default Content
				switchToDefaultcontent();
				switchToFrame("IfProducts");

			}
			// -----------------------------------------------------------------------------------------------------------
			// Naresh added Techsure IWMP (Inside Wire Maintenance) on
			// 23/07/2018

			if (vasProduct.equals("Inside Wire Maintenance") && Data.isEmpty()) {
				// Expanding VAS tab
				if (!tabVAS.getAttribute("class").contains("open")) {
					pageScroll(tabVAS, objectValue, true);
					clickUsingJavaScript(tabVAS, objectValue);
					report.reportPass("Expand BBE", "Expand BBE", "BBE is expanded");
					waitForLoader();
				}

				clickUsingJavaScript(IndieViewMaintenance, vasProduct);
				report.reportPass("Click Inside Wire Maintenance Plan", "Click Inside Wire Maintenance Plan",
						"Inside Wire Maintenance Plan is clicked");
				waitForLoader();
				waitForLoader();
				waitForLoader();
			}

			// -----------------------------------------------------------------------------------------------------------
			if (isDisplayed(tabVAS)) {
				if (tabVAS.getAttribute("class").contains("open")) {
					pageScroll(tabVAS, "", true);
					clickUsingJavaScript(tabVAS, objectValue);
				}
				// Switching to Default Content
				switchToDefaultcontent();
				switchToFrame("IfProducts");
			}

		} catch (Exception exe) {
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in VAS optoins section.");
			}
			throw exe;
		}

		String CoHoProduct = get("SmartHomeAccessories").trim();
		if (!CoHoProduct.isEmpty()) {

			selectCoHoOption();

		}

		// Moving to LEC Option
		SelectsetupInstall();

	}

	/**
	 * @Info To Negotiate LEC page
	 * @param FirstName
	 * @param LastName
	 * @param Additional
	 *            Lines
	 * @throws Exception
	 * @Modified by Sourish
	 * @Modified by Poovaraj
	 * @LastUpdated 13/03/2017
	 */

	public void LECPageNavigation() throws Exception {

		long timeNow = System.currentTimeMillis();
		System.out.println("->LECPageNavigation");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", FIRSTNAME = "", LASTNAME = "",
				AdditionalLines = "";
		try {

			// waitForLoader();

			String FlowType = get("FlowType").trim();
			String Application = get("Application").trim();
			String Standalone = get("Standalone").trim();
			String voicePlan = get("VoicePlan").trim();
			String HomePhone = null;

			HomePhone = simplex_SelectedVoice.getText();
			System.out.println(HomePhone);
			// Updated by Poovaraj on 06 Mar 2017
			if (get("Application").equalsIgnoreCase("COA") && (HomePhone.toLowerCase().contains("freedom")
					|| HomePhone.toLowerCase().contains("standalone"))) {

				FIRSTNAME = get("FirstName");
				LASTNAME = get("LastName");
				AdditionalLines = get("AdditionalLines");
				strDescription = "Negotiate LEC Page";
				strExpected = "Verify that LEC information is able to provide ";
				strActual = "LEC page is negotiated successfully";
				strFailed = "LEC page details are not getting updated successfully";
				getUrl = ", URL Launched --> " + returnURL();

				switchToDefaultcontent();
				switchToFrame("IfProducts");

				// Updated by poovaraj on 07-Mar-2017
				String baseWindow = driver.getWindowHandle();

				// clickUsingJavaScript(VoiceOptionsBar, objectValue);
				clickUsingJavaScript(VoiceMoreOptions, objectValue);

				// Switching to LEC page window
				pause();
				// waitForLoader();

				// Updated by poovaraj on 09-Mar-2017

				if (get("FlowType").equalsIgnoreCase("Install")) {
					switchToWindowWithURL("LineAndTN");
				} else {
					switchToWindowWithURL("LCW");
				}
				// maximizeBrowserWindow();

				waitForLoader();
				waitForLoader();
				/*
				 * if(isDisplayed(ExistingBTN, objectValue, 4)){
				 * 
				 * try{ clickUsingJavaScript(LinesAndTNEdit, objectValue);
				 * waitForLoader(); if(isDisplayed(termsok)){
				 * clickUsingJavaScript(termsok, objectValue); }
				 * waitForLoader(); clearText(NoOfLines, baseWindow);
				 * setText(NoOfLines, objectValue, "1");
				 * clickUsingJavaScript(BtnGetLines, objectValue);
				 * waitForLoader(); waitForLoader();
				 * clickUsingJavaScript(DeleteLine, objectValue);
				 * waitForLoader();
				 * 
				 * clickUsingJavaScript(BtnLinesOk, objectValue);
				 * waitForLoader(); waitForLoader(); LECPlanFeatures(FIRSTNAME,
				 * LASTNAME); waitForLoader(); waitForLoader();
				 * Thread.sleep(2000); clickUsingJavaScript(Intercepts,
				 * baseWindow); waitForLoader(); waitForLoader();
				 * 
				 * clickUsingJavaScript(SelectIntercept, baseWindow);
				 * waitForLoader();
				 * 
				 * clickUsingJavaScript(OkIntercept, baseWindow);
				 * waitForLoader(); waitForLoader(); Thread.sleep(2000);
				 * LECClickSaveAndContinue();
				 * 
				 * driver.switchTo().window(baseWindow); waitForLoader();
				 * waitForLoader(); Thread.sleep(3000);
				 * 
				 * } catch (Exception e) { strFailed =
				 * "Failed to click on OK button due to Object attribute is not availabe"
				 * ; getUrl = ", URL Launched --> " + returnURL();
				 * report.reportFail(
				 * "Clikcing on OK buttn under Lines and Assignment Section" +
				 * getUrl,
				 * "Verify Ok button is clicked in Lines and Tn Assignment section"
				 * ,
				 * "Failed to click on OK button due to Object attribute is not availabe"
				 * ); report.updateMainReport("comments", strFailed);
				 * report.updateMainReport("ErrorMessage", strFailed);
				 * logger.error(strFailed); captureErrorMsg(strFailed); throw e;
				 * 
				 * } }
				 * 
				 */

				if (isDisplayed(VoiceMailClose)) {
					clickUsingJavaScript(VoiceMailClose, objectValue);
					waitForLoader();

				}
				// Negotiating Lines & TN assignment Section
				// Entering number of New lines
				if (!AdditionalLines.isEmpty()) {
					if ((!AdditionalLines.equals("0") && (!AdditionalLines.isEmpty()))
							&& (isDisplayed(LinesAndTNEdit, baseWindow, 3))) {
						clickUsingJavaScript(LinesAndTNEdit, objectValue);
						waitForLoader();
						if (isDisplayed(termsok)) {
							clickUsingJavaScript(termsok, objectValue);
						}
						waitForLoader();
						waitForLoader();
					}
					if (isDisplayed(NoOfLines)) {
						// Gopal 11/10
						String S = NoOfLines.getAttribute("value");
						int N = Integer.parseInt(S);
						if (N == 0) {
							mouseOver(NoOfLines);
							clearText(NoOfLines, "");
							setText(NoOfLines, "", AdditionalLines);
							report.reportPass("Enter Number of New Lines.?" + AdditionalLines,
									"Verify is the number of New Lines entered",
									"No Of Lines are entered successfully");
						}

					}

					Thread.sleep(2000);
					// Clicking on Getlines
					if (isDisplayed(BtnGetLines)) {
						mouseOver(BtnGetLines);
						clickUsingJavaScript(BtnGetLines, "");
						Thread.sleep(100);
						waitForLoader();
						try {
							Alert alert = driver.switchTo().alert();
							alert.accept();
						} catch (Exception e) {
							System.out.println("No alert is present");
						}
						report.reportPass("Verify Getlines/Tn's button is clicked in Lines and Tn Assignment section",
								"Verify is Getlines/Tn's button is clicked in Lines and Tn Assignment section",
								"Getlines/Tn's button is clicked in Lines and Tn Assignment section");

					}

				}
				// Clicking on OK button in LEC page under TN Assignment Summary
				// section in LEC page
				try {
					waitForLoader();

					if (isDisplayed(BtnLinesOk)) {

						mouseOver(BtnLinesOk);
						clickUsingJavaScript(BtnLinesOk, "");
						System.out.println("BtnLinesOK under TNAssignment section has been clicked");
						report.reportPass("Clikcing on OK buttn under Lines and Assignment Section",
								"Verify Ok button is clicked in Lines and Tn Assignment section",
								"OK button is clicked in Lines and Tn Assignment section");
					}

				} catch (Exception e) {
					strFailed = "Failed to click on OK button due to Object attribute is not availabe";
					getUrl = ", URL Launched --> " + returnURL();
					report.reportFail("Clikcing on OK buttn under Lines and Assignment Section" + getUrl,
							"Verify Ok button is clicked in Lines and Tn Assignment section",
							"Failed to click on OK button due to Object attribute is not availabe");
					report.updateMainReport("comments", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					logger.error(strFailed);
					captureErrorMsg(strFailed);
					throw new UserDefinedException(strFailed);

				}

				// Spinner processing
				waitForLoader();

				if (AdditionalLines.isEmpty()) {
					AdditionalLines = "0";
				}
				int y = Integer.parseInt(AdditionalLines);
				List<WebElement> Linecheck = driver.findElements(By.xpath("//input[@type='checkbox']"));
				System.out.println(Linecheck.size());
				Linecheck.get(2).click();
				for (int i = 0; i <= y; i++) {

					Linecheck.get(i + 2).click();
					// click on GetDetailes Lines
					isDisplayed(GetDetailsforLines);
					mouseOver(GetDetailsforLines);
					clickUsingJavaScript(GetDetailsforLines, "");
					waitForLoader();
					waitForLoader();
					Thread.sleep(2000);
					if (i == 0 && y > 0) {

						if (!get("LEC_TPV").isEmpty()) {

							mouseOver(Long_Distance_Carrier);
							selectDropDownUsingVisibleText(Long_Distance_Carrier, "", get("LEC_TPV"));
							System.out.println("LONG DISTANCE plan Selected.");
							waitForLoader();
							waitForLoader();
							// Click on Apply under Calling Plan and Carrier
							// Info
							mouseOver(ApplyCallingPlan);
							clickUsingJavaScript(ApplyCallingPlan, "");
							System.out.println("Apply button is clicked under Calling Plans and Carrier Info section");
							report.reportPass("Clicking on apply button", "Verify that Apply button is clicked",
									"Apply button is clicked under Calling Paln and CArrier Info section successfully");
							// waitForLoader();
							waitForLoader();
							pause();
						}
					}
					// else{

					LECPlanFeatures(FIRSTNAME, LASTNAME);
					waitForLoader();
					// }
					if (i != y) {
						Linecheck = driver.findElements(By.xpath("//input[@type='checkbox']"));
						Linecheck.get(i + 2).click();
					}
				}

				// Spinner processing
				// waitForLoader();
				waitForLoader();

				// Clicking on OK in Intercept section
				InterceptOK();
				waitForLoader();

				// Clicking on OK in NRC section
				LECNRCOK();

				// Spinner processing
				// waitForLoader();
				waitForLoader();

				// Clicking on Save and Continue in LEC page
				boolean btn = true;
				try {
					LECClickSaveAndContinue();
				} catch (Exception e) {
					btn = false;
				}

				driver.switchTo().window(baseWindow);
				waitForLoader();
				waitForLoader();

				// clickUsingJavaScript(VoiceOptionsBar, objectValue);
				report.reportPass(strDescription + getUrl, strExpected, strActual);
				waitForLoader();

			}

		} catch (Exception exe) {
			/*
			 * exe.printStackTrace(); getUrl = ", URL Launched --> " +
			 * returnURL(); report.reportFail("strDescription" + getUrl,
			 * strExpected, strFailed); throw exe;
			 */

			strFailed = "LEC details is NOT selected";
			report.reportFail("Select LEC Details", "LEC details should be selected", strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);
		}

	}

	/**
	 * @Info To click on SaveAndContinue under LEC page
	 * @Modified by Sourish
	 * @Modified by Poovaraj
	 * @LastUpdated 03/13/2017
	 */

	public void LECClickSaveAndContinue() throws Exception {

		mouseOver(LECSaveAndContinue);
		clickUsingJavaScript(LECSaveAndContinue, "");// click not working

		if (isDisplayed(LecEdit, objectValue, 10)) {
			String x = getTextFromElement(LecEdit, objectValue);
			System.out.println(x);
			String strFailed = "After clicking Save And Continue in LEC Page getting error: " + x;
			report.reportFail("Click on Save And Continue in LEC Page",
					"Save And Continue in LEC Page should be clicked", strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);
		}

		// waitForLoader();
		// if(isDisplayed(LECSaveAndContinue))
		// {
		// mouseOver(LECSaveAndContinue);
		// clickUsingJavaScript(LECSaveAndContinue, "");
		// }
		System.out.println("SAVEANDCONTINUE is getting clicked");
	}

	/**
	 * Modified by Anu - intercept Ok under lec page
	 * 
	 **/

	public void InterceptOK() throws Exception {
		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		try {
			strDescription = "Click on Intercept OK under LEC page";
			strExpected = "Verify that OK button is getting clicked in LEC page under NRC";
			strActual = "Intercept Ok button is getting clicked successfully";
			strFailed = "Intercept ok is not getting clicked,since it is getting failed";
			getUrl = ", URL Launched --> " + returnURL();
			// Clicking on OK under Intercept section
			// waitForElementDisplay(OkIntercept, "", 2);

			if (isDisplayed(OkIntercept)) {
				mouseOver(OkIntercept);
				clickUsingJavaScript(OkIntercept, "");// click working
				System.out.println("OK is getting clicked");
				report.reportPass(strDescription + getUrl, strExpected, strActual);
			}

		} catch (Exception e) {
			strFailed = "Intercept button is not clicked";
			report.reportFail("Click on Intercept button", "Intercept button should be clicked", strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);

		}
	}

	/**
	 * @Info To click on NRCOk under LEC page
	 * @Modified by Sourish
	 * @LastUpdated 02/02/2017
	 */
	public void LECNRCOK() throws Exception {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		try {
			strDescription = "Click on NRC OK under LEC page";
			strExpected = "Verify that OK button is getting clicked in LEC page under NRC";
			strActual = "NRC Ok button is getting clicked successfully";
			strFailed = "NRC ok is not getting clicked,since it is getting failed";
			getUrl = ", URL Launched --> " + returnURL();
			// Clicking on OK under NRC section
			// waitForElementDisplay(NRCOK, "", 2);

			if (isDisplayed(NRCOK)) {
				mouseOver(NRCOK);
				clickUsingJavaScript(NRCOK, "");// click working
				System.out.println("OK is getting clicked");
				report.reportPass(strDescription + getUrl, strExpected, strActual);
			}

		} catch (Exception e) {
			strFailed = "NCR button is not clicked";
			report.reportFail("Click on NCR button", "NCR button should be clicked", strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);

		}
	}

	/**
	 * @Info To handle of Spinner Load
	 * @Modified by Sourish
	 * @LastUpdated 02/02/2017
	 */

	public void waitForSpinnerLoad() throws Exception {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		try {
			strDescription = "Wait for Spinner to load completly";
			strExpected = "Wait till Spinner to load";
			strActual = "Spinner is getting loaded successfully";
			strFailed = "Spinner is not getting loaded completly,since it is getting failed";
			getUrl = ", URL Launched --> " + returnURL();

			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(
					By.xpath("//span[contains(text(),'Please wait while we process your request...')]")));
			System.out.println("Waited successfully for the Spinner page to load");
			report.reportPass(strDescription + getUrl, strExpected, strActual);
		} catch (Exception e) {
			getUrl = ", URL Launched --> " + returnURL();
			report.reportFail(strDescription + getUrl, strExpected, strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
		}

	}

	/**
	 * @Info To handle of Spinner Load
	 * @Modified by Surya Teja Padala
	 * @LastUpdated 05/11/2017
	 */

	public void waitForEquipmentsLoad() throws Exception {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		try {
			strDescription = "Wait for Spinner to load completly";
			strExpected = "Wait till Spinner to load";
			strActual = "Spinner is getting loaded successfully";
			strFailed = "Spinner is not getting loaded completly,since it is getting failed";
			getUrl = ", URL Launched --> " + returnURL();

			WebDriverWait wait60 = new WebDriverWait(driver, 60);
			WebDriverWait wait30 = new WebDriverWait(driver, 30);
			wait60.until(ExpectedConditions.visibilityOf(EquipmentLoading));
			wait60.until(ExpectedConditions
					.invisibilityOfElementLocated(By.xpath("//img[not(contains(@id,'equipmentLoading'))]")));
			// wait30.until(ExpectedConditions.visibilityOf(OPOLoading));
			System.out.println("Waited successfully for the Spinner page to load");
			report.reportPass(strDescription + getUrl, strExpected, strActual);
		} catch (Exception e) {
			// getUrl = ", URL Launched --> " + returnURL();
			// report.reportFail(strDescription + getUrl, strExpected,
			// strFailed);
			// report.updateMainReport("ErrorMessage", strFailed);
		}

	}

	/**
	 * @Info To Negotiate Plan adn Features under LEC page
	 * @param FirstName
	 * @param LastName
	 * @throws Exception
	 * @Modified by Sourish
	 * @LastUpdated 02/02/2017
	 */
	public void LECPlanFeatures(String FIRSTNAME, String LASTNAME) throws Exception {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		try {
			strDescription = "Negotiate Plan and Features under LEC Page";
			strExpected = "Verify that Plan and features options are getting selected ";
			strActual = "Plan and features options are getting selected successfully";
			strFailed = "Plan and Features options are not being selected,since it is getting failed";
			getUrl = ", URL Launched --> " + returnURL();

			// Negotiating Calling Plans and Carrier Info Section in LEC page
			try {
				String LecVoicePackage = get("LecVoicePackage").trim();
				String VerizoncallingService = get("VerizonCallingService").trim();
				String TransportType = get("TransportType").trim();

				if (TransportType.trim().contains("Copper")) {
					pageScroll(Moreoptions, "", true);
					clickUsingJavaScript(Moreoptions, "");
					waitForLoader();

					if (isDisplayed(TransportMethod)) {

						mouseOver(Override);
						clickUsingJavaScript(Override, "");
						Thread.sleep(1000);
						pageScroll(TransportMethod, "", true);
						selectDropDownUsingVisibleText(TransportMethod, "", TransportType);
						waitForLoader();
						report.reportPass("Selecting Transport Method from Dropdown",
								"Transport Method should be Selectedfrom Dropdown",
								"Transport Method is selecting from Dropdown successfully");
						waitForLoader();
						clickUsingJavaScript(ApplytoSelectedLine, "");
						waitForLoader();
						clickUsingJavaScript(OkButton, "");
						waitForLoader();

					}
				}
				if ((!LecVoicePackage.contains("None")) && (!LecVoicePackage.isEmpty())) {
					pageScroll(Lecvoicepackage, "", true);
					selectDropDownUsingValue(Lecvoicepackage, "", LecVoicePackage);
					waitForPageToLoad(driver);
					waitForLoader();
					if ((LecVoicePackage.contains("PGO8R")) || (LecVoicePackage.contains("PGO6R"))) {
						if (isDisplayed(Domestic_LD_Plan)) {
							mouseOver(Domestic_LD_Plan);
							selectDropDownUsingValue(Domestic_LD_Plan, "", "O5V2X");
							System.out.println("Domestic LD Plan has been selected from dropdown");
							waitForLoader();
							waitForLoader();
							waitForLoader();
						}
					}
				}

				if (LecVoicePackage.contains("None")) {
					if (isDisplayed(Moreoptions)) {
						pageScroll(Moreoptions, "", true);
						clickUsingJavaScript(Moreoptions, "");
						waitForLoader();
						waitForLoader();
						report.reportPass("Clicking on More options button", "More options button should be clicked",
								"More options button is clicked under Calling Paln and CArrier Info section successfully");
					}
					waitForLoader();

					if (isDisplayed(VerizonCallingPackage)) {
						pageScroll(VerizonCallingPackage, "", true);
						selectDropDownUsingValue(VerizonCallingPackage, "", LecVoicePackage);
						waitForLoader();
						waitForLoader();
						report.reportPass("Selecting Verizon Calling Package from dropdown",
								"Verizon Calling Package should be selected from dropdown",
								"Verizon Calling Package is selecting from dropdown");
					}
					WebElement drop_down = driver.findElement(By.xpath(
							"//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_dropdownCallingService']"));
					Select verizoncallingservice = new Select(drop_down);
					List<WebElement> options = verizoncallingservice.getOptions();
					if (isDisplayed(drop_down)) {
						try {
							int flag = 0;
							breakLoop: for (int i = 0; i < options.size(); i++) {
								if (options.get(i).getText().contains(VerizoncallingService)) {
									verizoncallingservice.selectByValue(VerizoncallingService);
									flag = 1;
									waitForLoader();
									break breakLoop;
								}

							}
							if (flag == 0) {
								verizoncallingservice.selectByValue("1FR");
								waitForLoader();
							}

							waitForLoader();
							waitForLoader();
							report.reportPass("Selecting Verizon Calling Service from dropdown",
									"Verizon Calling Service should be selected from dropdown",
									"Verizon Calling Service is selecting from dropdown");

							if (isDisplayed(Domestic_LD_Plan)) {
								mouseOver(Domestic_LD_Plan);
								String Domesticldplan = get("LEC_Domestic_LD_Plan").trim();
								selectDropDownUsingValue(Domestic_LD_Plan, "", Domesticldplan);
								System.out.println("Domestic LD Plan has been selected from dropdown");
								waitForLoader();
								waitForLoader();
								waitForLoader();
							}
							if (isDisplayed(DrpIEPlan)) {
								mouseOver(DrpIEPlan);
								String Internationalplan = get("LEC_International_Plan").trim();
								selectDropDownUsingValue(DrpIEPlan, "", Internationalplan);
								System.out.println("International Plan has been selected from dropdown");
								waitForSpinnerLoad();
								Thread.sleep(500);
							}

							if (isDisplayed(ApplytoSelectedLine)) {
								pageScroll(ApplytoSelectedLine, "", true);
								clickUsingJavaScript(ApplytoSelectedLine, "");
								waitForLoader();
								report.reportPass("Verify Apply to Selected Line button is clicked or not",
										"Apply to Selected Line Button should be Clicked",
										"Apply to Selected Line Button is Clicking");
								waitForLoader();
							}
							if (isDisplayed(OkButton)) {
								pageScroll(OkButton, "", true);
								clickUsingJavaScript(OkButton, "");
								waitForLoader();
								report.reportPass("Verify Ok button is clicked or not", "OK Button should be Clicked",
										"Ok Button is Clicking");
								waitForLoader();
								waitForLoader();
							}

						} catch (Exception e) {
							e.printStackTrace();
							report.reportFail("Selecting Verizon Calling Service from dropdown",
									"Verizon Calling Service should be selected from dropdown",
									"Verizon Calling Service is not selected from dropdown");
						}
					}

				}
				waitForLoader();

				if (TransportType.trim().contains("Fiber"))

				{
					if (isDisplayed(Moreoptions)) {
						pageScroll(Moreoptions, "", true);
						clickUsingJavaScript(Moreoptions, "");
						waitForLoader();
						waitForLoader();
						report.reportPass("Clicking on More options button", "More options button should be clicked",
								"More options button is clicked under Calling Paln and CArrier Info section successfully");
					}

					if (isDisplayed(TransportMethod)) {
						pageScroll(TransportMethod, "", true);
						selectDropDownUsingVisibleText(TransportMethod, "", TransportType);
						waitForLoader();
						report.reportPass("Selecting Transport Method from Dropdown",
								"Transport Method should be Selectedfrom Dropdown",
								"Transport Method is selecting from Dropdown successfully");
						waitForLoader();
					}
					if (isDisplayed(ApplytoSelectedLine)) {
						pageScroll(ApplytoSelectedLine, "", true);
						clickUsingJavaScript(ApplytoSelectedLine, "");
						waitForLoader();
						report.reportPass("Verify Apply to Selected Line button is clicked or not",
								"Apply to Selected Line Button should be Clicked",
								"Apply to Selected Line Button is Clicking");
						waitForLoader();
					}
					if (isDisplayed(OkButton)) {
						pageScroll(OkButton, "", true);
						clickUsingJavaScript(OkButton, "");
						waitForLoader();
						report.reportPass("Verify Ok button is clicked or not", "OK Button should be Clicked",
								"Ok Button is Clicking");
						waitForLoader();
					}
				}
				waitForLoader();
				waitForLoader();

				if (!get("LEC_Long_Distance_Carrier").isEmpty()) {
					mouseOver(Long_Distance_Carrier);
					selectDropDownUsingVisibleText(Long_Distance_Carrier, "", get("LEC_Long_Distance_Carrier"));
					System.out.println("LONG DISTANCE plan Selected.");
					pause();
				}
				if (!get("LEC_Domestic_LD_Plan").isEmpty()) {

					mouseOver(Domestic_LD_Plan);
					String DomesticLdPlan = get("LEC_Domestic_LD_Plan").trim().toUpperCase();
					selectDropDownUsingValue(Domestic_LD_Plan, "", DomesticLdPlan);
					System.out.println("Domestic LD plan Selected.");
					pause();
				}

				// selecting International Plan
				// waitForElementDisplay(DrpIEPlan, "", 2);
				String Internationalplan = get("LEC_International_Plan").trim().toUpperCase();
				if (!Internationalplan.isEmpty()) {
					mouseOver(DrpIEPlan);
					selectDropDownUsingValue(DrpIEPlan, "", Internationalplan);
					System.out.println("International Plan has been selected from dropdown");
					waitForLoader();
					waitForLoader();

					mouseOver(DrpIEPlan);
					selectDropDownUsingValue(DrpIEPlan, "", Internationalplan);
					System.out.println("International Plan has been selected from dropdown");
					waitForLoader();
					waitForLoader();
				}

				// Click on Apply under Calling Plan and Carrier Info
				// waitForElementDisplay(ApplyCallingPlan, "", 2);
				mouseOver(ApplyCallingPlan);
				clickUsingJavaScript(ApplyCallingPlan, "");
				System.out.println("Apply button is clicked under Calling Plans and Carrier Info section");
				report.reportPass("Clicking on apply button", "Verify that Apply button is clicked",
						"Apply button is clicked under Calling Paln and CArrier Info section successfully");

			} catch (Exception e) {
				getUrl = ", URL Launched --> " + returnURL();
				report.reportFail("Clicking on apply button" + getUrl, "Verify that Apply button is clicked",
						"Failed to click th apply button due to object not in ready state");
				report.updateMainReport("ErrorMessage",
						"Failed to click th apply button due to object not in ready state");
			}

			// Spinner processing
			waitForSpinnerLoad();
			Thread.sleep(1000);

			// Negotiating Features Section in LEC page

			/*
			 * if(!isSelected(ChkBoxUnderFeatures, "Maintenance Plan")){ try {
			 * 
			 * // Clicking on Check box Maintenance Plan //
			 * waitForElementDisplay(ChkBoxUnderFeatures, "Maintenance // Plan",
			 * 2); mouseOver(ChkBoxUnderFeatures, "Maintenance Plan");
			 * clickUsingJavaScript(ChkBoxUnderFeatures, "Maintenance Plan");
			 * System.out.println("MAINTENANCE PLANSETUP is checked");
			 * report.reportPass("Selecting Maintenance check box",
			 * "Verify that Maintenance check box is selected",
			 * "Maintanence chec box is checked successfully");
			 * 
			 * // Spinner processing waitForSpinnerLoad(); Thread.sleep(1000);
			 * if (!isDisplayed(Maintenance_Plan_Window)) {
			 * click(setup_Maintenance_Plan); } waitForSpinnerLoad();
			 * Thread.sleep(1000); // Selecting WMR Maintenance Yes Plan
			 * 
			 * String lecMaintenancePlan = get("LecMaintenancePlan").trim();
			 * 
			 * if (lecMaintenancePlan.contains("WMR") ||
			 * lecMaintenancePlan.contains("OWM") ||
			 * lecMaintenancePlan.contains("NMC") ||
			 * (lecMaintenancePlan.contains("MNTPB")||lecMaintenancePlan.
			 * contains("SEQ1X"))) { mouseOver(Inside_Wire_Maintainance,
			 * lecMaintenancePlan);
			 * clickUsingJavaScript(Inside_Wire_Maintainance,
			 * lecMaintenancePlan); click(Inside_Wire_Maintainance,
			 * lecMaintenancePlan); System.out.println(
			 * "WMR inside wire Maintenance Plan is selected");
			 * report.reportPass("Selecting" +"lecMaintenancePlan"+
			 * " inside wire Maintenance Plan", "Verify that "
			 * +"lecMaintenancePlan"+"inside wire Maintenance Plan is selected",
			 * "" +"lecMaintenancePlan"+
			 * " inside wire Maintenance Plan chec box is checked successfully"
			 * ); } // Spinner processing waitForSpinnerLoad();
			 * Thread.sleep(1000);
			 * 
			 * // Clicking on OK/Apply to the selected lines under Maintenance
			 * // Plan set up frame // waitForElementDisplay(MaintenanceOK, "",
			 * 2); mouseOver(MaintenanceOK); clickUsingJavaScript(MaintenanceOK,
			 * ""); System.out.println(
			 * "OK/Apply to the selected lines button is clicked");
			 * report.reportPass(
			 * "Clicking the OK button under Maintenance plan set up",
			 * "Verify that OK button is getting clicked under the Maintenance Plan set up frame"
			 * , "Ok is clicked successfully");
			 * 
			 * 
			 * } catch (Exception e) { getUrl = ", URL Launched --> " +
			 * returnURL(); report.reportFail(
			 * "Negotiating Maintenance Plane set up" + getUrl,
			 * "Verify that Maintenance Plan set up is negotiating sucessfully",
			 * "Failed to do the Action");
			 * report.updateMainReport("ErrorMessage", "Failed to do the Action"
			 * ); }
			 * 
			 * } // Spinner processing waitForSpinnerLoad(); Thread.sleep(1000);
			 */

			if (!isSelected(ChkBoxUnderFeatures, "Voice Backup")) {
				if (isDisplayed(ChkBoxUnderFeatures, "Voice Backup", 1)) {
					// Handling of Voice Backup Power
					try {
						// Clicking on Voice Backup Power
						// waitForElementDisplay(ChkBoxUnderFeatures, "Voice
						// Backup",
						// 2);

						waitForLoader();
						mouseOver(ChkBoxUnderFeatures, "Voice Backup");
						clickUsingJavaScript(ChkBoxUnderFeatures, "Voice Backup");
						System.out.println("VOICE BACKUP POWER check box is checked");
						report.reportPass("Checking the VOICE BACKUP POWER check box",
								"Verify that VOICE BACKUP POWER is checked",
								"VOICE BACKUP POWER is checked successfully");

						// Spinner processing
						waitForSpinnerLoad();
						Thread.sleep(1000);
						if (!isDisplayed(Voice_Backup_Power_Window)) {
							clickUsingJavaScript(setup_Voice_Backup_Power, objectValue);
							waitForLoader();
						}
						// Selecting Voice Power Backup Setup

						String lecVoiceBackupPower = get("LecVoiceBackupPower").trim();
						try {
							if (!lecVoiceBackupPower.isEmpty()) {
								waitForLoader();
								if (isDisplayed(Battery_options, lecVoiceBackupPower, 5)) {
									mouseOver(Battery_options, lecVoiceBackupPower);
									click(Battery_options, lecVoiceBackupPower);
									System.out.println("Battery Backup  is selected ");
									report.reportPass("Selecting Voice Backup Power Setup",
											"Verify that able to select the  Voice Backup Power setup",
											" Voice Backup Power Setup is selected successfully");
								} else {
									mouseOver(batteryoptions, lecVoiceBackupPower);
									click(batteryoptions, lecVoiceBackupPower);
									System.out.println("Battery Backup  is selected ");
									report.reportPass("Selecting Voice Backup Power Setup",
											"Verify that able to select the  Voice Backup Power setup",
											" Voice Backup Power Setup is selected successfully");

								}
							}
						} catch (Exception e) {

							logger.error("Lec Battery backup" + lecVoiceBackupPower + "is not Present");

							report.updateMainReport("comments",
									"Lec Battery backup" + lecVoiceBackupPower + "is not Present");
							report.updateMainReport("ErrorMessage",
									"Lec Battery backup" + lecVoiceBackupPower + "is not Present");
							captureErrorMsg("Lec Battery backup" + lecVoiceBackupPower + "is not Present");

							report.reportFail("Check if battery backup is selected",
									"battery backup should be selected",
									"Lec Battery backup" + lecVoiceBackupPower + "is not Present");
							throw new UserDefinedException(
									"Lec Battery backup" + lecVoiceBackupPower + "is not Present");
						}

						// Spinner processing
						waitForSpinnerLoad();

						// Clicking on OK in Voice Backup Power Fee setup
						// waitForElementDisplay(VoiceBkppowerOK, " ", 2);
						mouseOver(VoiceBkppowerOK);
						clickUsingJavaScript(VoiceBkppowerOK, " ");
						System.out.println("OK button is clicked in Voice BAckup Power setup");
						report.reportPass("Clicking the OK button under Voice BAckup Power set up",
								"Verify that OK button is getting clicked under Voice backup Power set up frame",
								"OK is clicked successfully");

					} catch (Exception e) {
						getUrl = ", URL Launched --> " + returnURL();
						report.reportFail("Negotiating Voice Backup Power set up" + getUrl,
								"Verify that Voice Backup Power set up is negotiating sucessfully",
								"Failed to do the Action");
						report.updateMainReport("ErrorMessage", "Failed to do the Action");

					}
					// Spinner processing
					waitForSpinnerLoad();
					Thread.sleep(1000);

				}

			}

			// Handling of Jacks
			if (!isSelected(ChkBoxUnderFeatures, "Jacks")) {
				try {

					// Clicking on Jacks
					// waitForElementDisplay(ChkBoxUnderFeatures, "Jacks", 2);
					mouseOver(ChkBoxUnderFeatures, "Jacks");
					clickUsingJavaScript(ChkBoxUnderFeatures, "Jacks");
					System.out.println("JACKS check box is checked ");
					report.reportPass("Checking the JACKS check box", "Verify that JACKS is checked",
							"JACKS is checked successfully");

					// Spinner processing
					waitForSpinnerLoad();

					if (!isDisplayed(Jacks_Window)) {
						clickUsingJavaScript(setup_Jacks, objectValue);

					}
					waitForSpinnerLoad();

					// Selecting Jacks

					String Jacktype = get("ChangeVoiceJack").trim();

					if (Jacktype.contains("Primary")) {
						mouseOver(Jacks_Type);
						clickUsingJavaScript(Jacks_Type, Jacktype);
						click(ADDLinkJack);
						waitForSpinnerLoad();
						Thread.sleep(1000);
						System.out.println("Primary Jack is selected in Jacks/Fixed Fee Setup");
						report.reportPass("Selecting Jacks/Fixed Fee Setup",
								"Verify that able to select Primary Jack in Jacks/Fixed Fee setup",
								"Primary Jack is selected successfully");
					} else if (Jacktype.contains("Additional")) {
						mouseOver(Jacks_Type);
						clickUsingJavaScript(Jacks_Type, Jacktype);
						click(ADDLinkJack);
						waitForSpinnerLoad();
						Thread.sleep(1000);
						System.out.println("Additional Jack is selected in Jacks/Fixed Fee Setup");
						report.reportPass("Selecting Jacks/Fixed Fee Setup",
								"Verify that able to select Additional Jack in Jacks/Fixed Fee setup",
								"Additional Jack is selected successfully");
					}
					// Selecting No Jacks
					else {
						mouseOver(ChkbxLECNoJacks);
						clickUsingJavaScript(ChkbxLECNoJacks, "");
						System.out.println("NO JACKS is selected in Jacks/Fixed Fee Setup");
						report.reportPass("Selecting Jacks/Fixed Fee Setup",
								"Verify that able to select NO JACKS in Jacks/Fixed Fee setup",
								"NO JACKS is selected successfully");
					}

					// Spinner processing
					waitForSpinnerLoad();
					Thread.sleep(1000);

					// Clicking on OK in Jacks setup
					// waitForElementDisplay(NoJackOK, " ", 2);
					mouseOver(BtnLECJackOk);
					clickUsingJavaScript(BtnLECJackOk, " ");
					System.out.println("OK button is clicked in Jacks/Fixed Fee Setup");
					report.reportPass("Clicking the OK button under Jacks/Fixed Fee Setup",
							"Verify that OK button is getting clicked under Jacks/Fixed Fee Setup frame",
							"Ok is clicked successfully");

				} catch (Exception e) {
					getUrl = ", URL Launched --> " + returnURL();
					report.reportFail("Negotiating Jacks/Fixed Fee Setup" + getUrl,
							"Verify that Jacks/Fixed Fee Setup is negotiating sucessfully", "Failed to do the Action");
					report.updateMainReport("ErrorMessage", "Failed to do the Action");

				}
			}

			// Spinner processing
			// Spinner processing
			waitForSpinnerLoad();
			Thread.sleep(1000);
			String featureproducts = get("LecFeatureProducts").trim();

			if (!featureproducts.isEmpty()) {
				try {

					if (featureproducts.contains(";")) {
						String[] Productslist = featureproducts.split(";");
						for (String Pdslist : Productslist) {
							mouseOver(lnkAllProducts, "");
							clickUsingJavaScript(lnkAllProducts, "");
							System.out.println("All Products link is Clicked");
							report.reportPass("Verify All Products link is clicking or not",
									"All Products link should be clicked", "All Products lick is clicking");

							// Spinner processing
							waitForSpinnerLoad();
							waitForLoader();
							if (isDisplayed(TxtBoxUsoc)) {
								mouseOver(TxtBoxUsoc, "");
								clearText(TxtBoxUsoc, "");
								setText(TxtBoxUsoc, "", Pdslist);
								waitForLoader();
								clickUsingJavaScript(UscoSearchButton, "");
								waitForLoader();
								mouseOver(UsocCheckBox, Pdslist);
								clickUsingJavaScript(UsocCheckBox, Pdslist);
								mouseOver(UsocApplyButton);
								clickUsingJavaScript(UsocApplyButton, "");
								waitForLoader();
								if (isDisplayed(UsocApplyButton)) {
									clickUsingJavaScript(UsocApplyButton, "");
								}
								waitForLoader();

								if (isDisplayed(ErrorMessage)) {
									if (ErrorMessage.getText()
											.contains("You have entered a product that is not available")) {
										System.out.println("Feature Products not Selected " + ErrorMessage.getText());
										report.reportPass("Verify All Feature Products Selected or not",
												"All Feature Products should not be selected",
												"Feature Products not Selected" + ErrorMessage.getText());
										clickUsingJavaScript(UsocCloseButton, "");
									}
								} else {
									System.out.println("Feature Products Selected " + Pdslist);
									report.reportPass("Verify All Feature Products Selected or not",
											"All Feature Products should be selected",
											"Feature Products Selected" + Pdslist);
								}

								if (isDisplayed(AdditionalProductsHeader)) {
									if (isDisplayed(RequiredProductGroup)) {
										int count = RequiredProductGroups.size();

										for (int i = 0; i < count; i++) {
											String j = String.valueOf(i);
											if (!isSelected(RequiredFID, j)) {
												waitForLoader();
												clickUsingJavaScript(RequiredFID, j);
											}
										}

										if (isDisplayed(ProductNWTFeatures)) {
											mouseOver(ProductNWTFeatures);
											clickUsingJavaScript(ProductNWTFeatures, "");
										} else if (isDisplayed(FIDCOMM)) {
											mouseOver(FIDCOMM);
											selectDropDownUsingIndex(FIDCOMM, "", 0);
										}

									}
									waitForLoader();
									WebElement FIDSOK = driver.findElement(By.xpath(
											"//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_lnkAdditionalProductOk']"));
									FIDSOK.click();
									waitForLoader();

								}

							}

						}
					} else {
						// Clicking on All Products link
						mouseOver(lnkAllProducts, "");
						clickUsingJavaScript(lnkAllProducts, "");
						System.out.println("All Products link is Clicked");
						report.reportPass("Verify All Products link is clicking or not",
								"All Products link should be clicked", "All Products lick is clicking");

						// Spinner processing
						waitForSpinnerLoad();
						waitForLoader();
						if (isDisplayed(TxtBoxUsoc)) {
							mouseOver(TxtBoxUsoc, "");
							setText(TxtBoxUsoc, "", featureproducts);
							waitForLoader();
							clickUsingJavaScript(UscoSearchButton, "");
							waitForLoader();
							mouseOver(UsocCheckBox, featureproducts);
							clickUsingJavaScript(UsocCheckBox, featureproducts);
							mouseOver(UsocApplyButton);
							clickUsingJavaScript(UsocApplyButton, "");
							waitForLoader();
							waitForLoader();
							if (isDisplayed(UsocApplyButton)) {
								clickUsingJavaScript(UsocApplyButton, "");
							}
							waitForLoader();

							if (isDisplayed(ErrorMessage)) {
								if (ErrorMessage.getText()
										.contains("You have entered a product that is not available")) {
									System.out.println("Feature Products not Selected " + ErrorMessage.getText());
									report.reportPass("Verify All Feature Products Selected or not",
											"All Feature Products should not be selected",
											"Feature Products not Selected" + ErrorMessage.getText());
									clickUsingJavaScript(UsocCloseButton, "");
								}
							} else {
								System.out.println("Feature Products Selected " + featureproducts);
								report.reportPass("Verify All Feature Products Selected or not",
										"All Feature Products should be selected",
										"Feature Products Selected" + featureproducts);
							}
							if (isDisplayed(AdditionalProductsHeader)) {
								if (isDisplayed(RequiredProductGroup)) {
									int count = RequiredProductGroups.size();

									for (int i = 0; i < count; i++) {
										String j = String.valueOf(i);
										if (!isSelected(RequiredFID, j)) {
											waitForLoader();
											clickUsingJavaScript(RequiredFID, j);
										}
									}

									if (isDisplayed(ProductNWTFeatures)) {
										mouseOver(ProductNWTFeatures);
										clickUsingJavaScript(ProductNWTFeatures, "");
									} else if (isDisplayed(FIDCOMM)) {
										mouseOver(FIDCOMM);
										selectDropDownUsingIndex(FIDCOMM, "", 0);
									}

								}
								waitForLoader();
								WebElement FIDSOK = driver.findElement(By.xpath(
										"//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_lnkAdditionalProductOk']"));
								FIDSOK.click();
								waitForLoader();

							}
						}

					}
					mouseOver(ProductsApplyButton, "");
					clickUsingJavaScript(ProductsApplyButton, "");
					waitForLoader();
					waitForLoader();

					if (isDisplayed(NPDWallJack, "", 5)) {
						WebElement ele = driver.findElement(By.xpath(
								"//*[contains(@id , 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAccountProfileSection_AccountTreeViewt')]//span[contains(text(), 'RJ11W')]"));
						Actions act = new Actions(driver);
						act.moveToElement(ele);
						act.contextClick(ele).build().perform();
						WebElement elementOpen = driver.findElement(By
								.xpath("//*[@id = 'productMenuforQuantifyUSOC']//a[contains(text(), 'Review Setup')]"));
						elementOpen.click();
						waitForLoader();
						waitForLoader();
						if (isDisplayed(BtnOptionalFIDs)) {
							mouseOver(BtnOptionalFIDs);
							clickUsingJavaScript(BtnOptionalFIDs, "");
						}

						String LECAdditionalFIDs = get("LECAdditionalFIDs").trim();
						if (!LECAdditionalFIDs.isEmpty()) {
							mouseOver(OptionalFIDS, LECAdditionalFIDs);
							clickUsingJavaScript(OptionalFIDS, LECAdditionalFIDs);
						}

						Thread.sleep(2000);
						clickUsingJavaScript(FIDSOK, "");
						waitForLoader();
						waitForLoader();
					}

				} catch (Exception e) {
					getUrl = ", URL Launched --> " + returnURL();
					report.reportFail("Negotiating Jacks/Fixed Fee Setup" + getUrl,
							"Verify that Jacks/Fixed Fee Setup is negotiating sucessfully", "Failed to do the Action");
					report.updateMainReport("ErrorMessage", "Failed to do the Action");

				}
			}

			// Handling of Directory Listing
			try {
				// Clicking on Edit link
				// waitForElementDisplay(DLEdit, "", 2);
				mouseOver(DLEdit);
				clickUsingJavaScript(DLEdit, "");// click not working
				System.out.println("EDIT link is clicked");
				report.reportPass("Clicking on EDIT under Directory Listing", "Verify that EDIT is getting clicked",
						"EDIT is getting clicked successfully");

				// Spinner processing
				waitForSpinnerLoad();
				Thread.sleep(1000);

				String LecListingPlan = get("LecListingPlan").trim();

				if (!LecListingPlan.isEmpty()) {
					if (isDisplayed(PublicationStatus)) {
						if (LecListingPlan.contains("NPU")) {
							mouseOver(PublicationStatus);
							selectDropDownUsingValue(PublicationStatus, "", "NON_PUBLISHED");
							report.reportPass("Selecting NON_PUBLISHED under Directory Listing",
									"Verify that NON_PUBLISHED should be selected under Directory Listing",
									"NON_PUBLISHED under Directory Listing selected Successfully");
						} else if (LecListingPlan.contains("NLT")) {
							mouseOver(PublicationStatus);
							selectDropDownUsingValue(PublicationStatus, "", "DIR_ASSIST_ONLY");
							report.reportPass("Selecting DIR_ASSIST_ONLY under Directory Listing",
									"Verify that DIR_ASSIST_ONLY should be selected under Directory Listing",
									"DIR_ASSIST_ONLY under Directory Listing selected Successfully");
						}
						waitForSpinnerLoad();
						Thread.sleep(2000);
					}
				}

				// Entering First Name
				// waitForElementDisplay(DLLastName, "", 2);
				mouseOver(DLLastName);
				clearText(DLLastName, strFailed);
				setText(DLLastName, "", LASTNAME);
				System.out.println("Last Name" + LASTNAME + "is entered successfully");
				report.reportPass("Entering LAST NAME", "Verify that able to LAST NAME in Directory Listing",
						"LAST NAME is entered successfully");

				// Spinner processing
				waitForSpinnerLoad();
				Thread.sleep(1000);

				// Entering Last Name
				// waitForElementDisplay(DLFirstName, "", 2);
				mouseOver(DLFirstName);
				clearText(DLFirstName, strFailed);
				setText(DLFirstName, "", FIRSTNAME);
				System.out.println("FIRSTNAME" + FIRSTNAME + "is entered successfully");
				report.reportPass("Entering FIRST NAME", "Verify that able to FIRST NAME in Directory Listing",
						"FIRST NAME is entered successfully");

				// Spinner processing
				waitForSpinnerLoad();
				Thread.sleep(1000);

				// Entering OK button in Directory Listing
				// waitForElementDisplay(DLOK, "", 2);
				mouseOver(DLOK);
				clickUsingJavaScript(DLOK, "");// click not working
				System.out.println("OK is getting clicked");
				report.reportPass("Clicking OK button in Directory Listing",
						"Verify tha the OK button i sgetting clicked", "OK button is getting clicked successfully");

				// Spinner processing
				waitForSpinnerLoad();
				Thread.sleep(1000);

				// Code for E911 Disclosure - 2/2/2019 - Prakash
				if (isDisplayed(E911Disclosure)) {
					pageScroll(E911Disclosure, "", true);
					clickUsingJavaScript(E911Disclosure, "");
					waitForLoader();
					report.reportPass("Verify E911 Disclosure ", "E911 Disclosure clicked", "E911 Disclosure clicked");
					waitForLoader();
				}

				// Clicking on OK in Package, Plan and features
				// waitForElementDisplay(PlanFeaturesOK, "", 2);
				mouseOver(PlanFeaturesOK);
				clickUsingJavaScript(PlanFeaturesOK, "");// click not working
				System.out.println("OK is clicked");
				report.reportPass("Clicking on OK button under Plan and features", "Verify that OK is getting clicked",
						"OK is getting clicked successfully");

			} catch (Exception e) {
				getUrl = ", URL Launched --> " + returnURL();
				report.reportFail("Negotiating Directory Listing " + getUrl,
						"Verify that Directory Listing section is negotiating sucessfully", "Failed to do the Action");
				report.updateMainReport("ErrorMessage", "Failed to do the Action");

			}
			report.reportPass(strDescription + getUrl, strExpected, strActual);
		} catch (Exception e) {
			report.reportPass(strDescription + getUrl, strExpected, strFailed);
		}

	}

	/**
	 * @Info setupInstallSelection
	 * @param Outlets
	 * @throws Exception
	 * @Author:Mounika,Padmini
	 * @LastUpdatedBy -- SHiva Kumar Simharaju -- 07/04/2018
	 * @LastUpdated :
	 * @Comments:
	 */

	public void SelectsetupInstall() throws Exception, UserDefinedException {

		System.out.println("->SelectsetupInstall");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "To negotiate Setup Install section";
		strExpected = "Setup Install section should be selected";
		strActual = "Setup Install is negotiated successfully";
		getUrl = ", URL Launched --> " + returnURL();

		try {

			// Switch Frame
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
				UIValidations_SetupInstall();
			}
			String outlets = get("Outlets").trim();
			String Video = "";
			String selectedData = "";
			String SelectedPremiums = "";
			String selectedOutlets = "";

			// get selected vocie plan
			if (isDisplayed(simplex_SelectedTV, "", 1)) {
				Video = getTextFromElement(simplex_SelectedTV, objectValue);
			}
			if (isDisplayed(simplex_SelectedData, "", 1)) {
				selectedData = getTextFromElement(simplex_SelectedData, objectValue);
			}
			waitForLoader();

			if (!getAttribute(Setup_section, objectValue, "class").contains("open")) {
				pageScroll(Setup_section, objectValue, true);
				clickUsingJavaScript(Setup_section, objectValue);
				waitForLoader();
				report.reportPass("Expand Setup Install", "Expand Setup Install",
						"Expand Setup Install should be expanded");
			}

			if (isDisplayed(SetupSatelliteNo, selectedOutlets, 3)) {
				clickUsingJavaScript(SetupSatelliteNo, objectValue);
				report.reportPass("Click No for TV service Satellite", "Click No for TV service Satellite",
						"No is clicked for TV service Satellite");
				waitForLoader();
			}

			if (getAttribute(Setup_section, objectValue, "class").contains("open")) {
				pageScroll(Setup_section, objectValue, true);
				clickUsingJavaScript(Setup_section, objectValue);
				waitForLoader();
			}

			if ((!Video.isEmpty() | !selectedData.isEmpty()) && (!outlets.isEmpty())) {
				// Expand premium channels
				if (!getAttribute(Setup_section, objectValue, "class").contains("open")) {
					pageScroll(Setup_section, objectValue, true);
					clickUsingJavaScript(Setup_section, objectValue);
					waitForLoader();
				}

				// select the outlets and additional outlets

				String[] Outletsval = outlets.split(",");
				for (String Outlet : Outletsval) {
					if (Outlet.toUpperCase().contains(":X")) {
						Outlet = Outlet.split(":X")[0];
						if (isDisplayed(Selected_Outlets, "", 1)) {
							selectedOutlets = getTextFromElement(Selected_Outlets, objectValue);
						}
						if (selectedOutlets.toLowerCase().contains(Outlet.toLowerCase().trim())) {
							clickUsingJavaScript(Outlet_Tile, Outlet.trim());
							report.reportPass("Simplex Page  ordering - Verify able to uncheck the outlet:" + Outlet,
									"Should be able to uncheck the outlet", "Able to uncheck the outlet:" + Outlet);
						}

					} else {
						if (isDisplayed(Selected_Outlets, "", 1)) {
							selectedOutlets = getTextFromElement(Selected_Outlets, objectValue);
						}

						if (!selectedOutlets.toLowerCase().contains(Outlet.toLowerCase().trim())) {
							try {
								clickUsingJavaScript(Outlet_Tile, Outlet.trim());
								report.reportPass("Simplex Page  ordering - Verify able to check the outlet:" + Outlet,
										"Should be able to check the outlet", "Able to check the outlet:" + Outlet);

							} catch (Exception e) {
								strFailed = "Failed in setup install section, Required outlet product " + Outlet
										+ " not available.";
								report.reportFail("Select outlet.", "Outlet should be selected.", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								logger.error(strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							}
						}
					}
				}

				if (getAttribute(Setup_section, objectValue, "class").contains("open")) {
					pageScroll(Setup_section, objectValue, true);
					clickUsingJavaScript(Setup_section, objectValue);
					waitForLoader();
				}

			}

			// Switching to Default Content
			switchToDefaultcontent();

		} catch (Exception exe) {
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in SetupInstall section.");
			}
			throw exe;
		}

		// Moving to Checkout
		goToCheckout();
	}

	/**
	 * @param PriceComparisonRequired
	 * @param TaxApplicable
	 * @param FlowType
	 * @param S_No
	 * @info click on checkout tab
	 * @author Vignesh Babu
	 * @Changes made: TO validate the MO in Checkout pop-up window
	 * @Changed by: Jeevitha S
	 * @Date: 02/20/2017
	 * @Changes: Added condition before clicking on Checkout
	 * @Chanegdby:Jeevitha S
	 * @Date: 02/27/2017
	 */
	public void goToCheckout() throws Exception, UserDefinedException {

		System.out.println("->goToCheckout");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "To negotiate whethre Review and Checkout button is selected";
		strExpected = " Review and Checkout button should be selected";
		strActual = " Review and Checkout button is selected successfully";
		getUrl = ", URL Launched --> " + returnURL();

		String tvPlan = get("TvPlan").trim();
		String priceQuote = get("PriceQuote").trim();
		String email = get("Email_ID").trim();
		try {

			waitForLoader();

			waitForLoader();
			// setting frame to required frame-'IfProducts'
			switchToDefaultcontent();
			switchToFrame("IfProducts");
			waitForLoader();
			waitForLoader();
			waitForLoader();
			waitForLoader();
			if (isDisplayed(PleaseReview, "", 3)) {
				pageScroll(PleaseReview);
				clickUsingJavaScript(PleaseReview, "");
				waitForLoader();
				waitForLoader();
			}
			if (isDisplayed(InterceptsPleaseReview, getUrl, 3)) {
				pageScroll(InterceptsPleaseReview, getUrl, true);
				report.reportPass("Check whether Please Review is dispalyed",
						"Check whether Please Review is dispalyed", "Please Review is displayed");
				clickUsingJavaScript(InterceptsPleaseReview, getUrl);
				waitForLoader();
				waitForLoader();
				clickUsingJavaScript(MoreOptions, objectValue);
				waitForLoader();
				waitForLoader();
				waitForLoader();
				report.reportPass("Check whether Intercepts Popup dispalyed",
						"Check whether Intercepts Popup is dispalyed", "Intercepts Popup is displayed");
				clickUsingJavaScript(saveChanges, objectValue);
				waitForLoader();
				waitForLoader();
				waitForLoader();
				waitForLoader();

			}
			if (isDisplayed(RequiredSetupInstall, getUrl, 3)) {
				if (!getAttribute(Setup_section, objectValue, "class").contains("open")) {
					pageScroll(Setup_section, objectValue, true);
					clickUsingJavaScript(Setup_section, objectValue);
					waitForLoader();
					report.reportPass("Expand Setup Install", "Expand Setup Install",
							"Expand Setup Install should be expanded");
				}

				if (isDisplayed(SetupSatelliteNo, "", 3)) {
					clickUsingJavaScript(SetupSatelliteNo, objectValue);
					report.reportPass("Click No for TV service Satellite", "Click No for TV service Satellite",
							"No is clicked for TV service Satellite");
					waitForLoader();
				}

				if (getAttribute(Setup_section, objectValue, "class").contains("open")) {
					pageScroll(Setup_section, objectValue, true);
					clickUsingJavaScript(Setup_section, objectValue);
					waitForLoader();
				}
			}

			// Click on Review order

			switchToDefaultcontent();
			switchToFrame("IfProducts");
			try {
				waitForElementDisplay(revbtn, objectValue, 15);
			} catch (Exception exe) {

			}
			if (isEnabled(btnReviewOrder)) {

				if (!get("MarketingOfferType").isEmpty()) {
					OPOPriceValidation();
				}

				// Actions action = new Actions(driver);
				// action.moveToElement(driver.findElement(By.xpath("//div[not(contains(@class,'ng-hide'))]/button[contains(@ng-click,'showBillingEstimate')]"))).perform();
				// action.moveToElement(driver.findElement(By.xpath("//div[not(contains(@class,'ng-hide'))]/button[contains(@ng-click,'showBillingEstimate')]"))).click().perform();

				// btnReviewOrder.sendKeys(Keys.ENTER);
				switchToDefaultcontent();
				switchToFrame("IfProducts");
				if (isDisplayed(getTotals, email, 2)) {
					clickUsingJavaScript(getTotals, email);
					waitForLoader();
					waitForLoader();
				}

				if (isDisplayed(mtly_chrgs_OPO, email, 3)) {
					String Monthly_chrgs_opo = getTextFromElement(mtly_chrgs_OPO, objectValue);
					System.out.println(Monthly_chrgs_opo);
					report.reportPass("Display Monthly Charges in Checkout", "Display Monthly Charges in Checkout",
							"Monthly Charges in Checkout is: " + Monthly_chrgs_opo);
					if (!Monthly_chrgs_opo.isEmpty()) {
						put("Monthly Estimated Charge in OPO", Monthly_chrgs_opo);
					}
				} else if (isDisplayed(mtly_chrgs_OPO2, email, 3)) {
					String Monthly_chrgs_opo = getTextFromElement(mtly_chrgs_OPO2, objectValue);
					System.out.println(Monthly_chrgs_opo);
					report.reportPass("Display Monthly Charges in Checkout", "Display Monthly Charges in Checkout",
							"Monthly Charges in Checkout is: " + Monthly_chrgs_opo);
					if (!Monthly_chrgs_opo.isEmpty()) {
						put("Monthly Estimated Charge in OPO", Monthly_chrgs_opo);
					}
				}
				clickUsingJavaScript(btnReviewOrder, objectValue);
				waitForLoader();
				waitForLoader();
				/*
				 * if(!get("ETF").isEmpty()){ validateRSNBCFees(); }
				 */
			}

			else {
				// List<WebElement> lst = null;
				try {
					// lst =
					// driver.findElements(By.xpath("//a[contains(text(),'required')
					// and
					// not(contains(@class,'hide'))]/ancestor::li//div/span[contains(@class,'accordion-title')][1]"));

					// if(lst.size()>0){
					/*
					 * for (int i = 0; i < lst.size(); i++) { String list1 =
					 * lst.get(i).getText();
					 * 
					 * 
					 * if (!list1.isEmpty()) { //pageScroll(lst.get(i), list1,
					 * true);
					 * 
					 * strFailed =
					 * "Review Order button is not clicked because a required field is showing in: "
					 * +lst.get(i).getText();
					 * 
					 * report.reportFail(
					 * "Failed in clicking Review order button",
					 * "Failed in clicking Review order button",
					 * "Review Order button is not clicked because a required field is showing in: "
					 * +lst.get(i).getText());
					 * report.updateMainReport("comments", strFailed);
					 * report.updateMainReport("ErrorMessage", strFailed);
					 * logger.error(strFailed); captureErrorMsg(strFailed);
					 * throw new UserDefinedException(strFailed);
					 * 
					 * } }
					 */
					if (RequiredReviewOrder.size() > 0) {
						for (int i = 0; i < RequiredReviewOrder.size(); i++) {
							String list1 = RequiredReviewOrder.get(i).getText();
							if (!list1.isEmpty()) {
								// WebElement bndl_cmpnts =
								// bndl_components.get(i);
								pageScroll(RequiredReviewOrder.get(i), email, true);

								strFailed = "Review Order button is not clicked because a required field is showing in: "
										+ list1;

								report.reportFail("Failed in clicking Review order button",
										"Failed in clicking Review order button",
										"Review Order button is not clicked because a required field is showing in: "
												+ list1);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								logger.error(strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);

							}
						}
					}
				}

				catch (Exception ex) {
					if (!strFailed.contains("required field is")) {
						strFailed = "Failed in clicking review button, Button is not enabled.. Skiping execution.";
					}
					report.reportFail("Select Review button", "Review button should be selected.", strFailed);
					report.updateMainReport("comments", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					logger.error(strFailed);
					captureErrorMsg(strFailed);
					throw new UserDefinedException(strFailed);
				}

			}

			waitForLoader();
			if (get("GUI_Validations").equalsIgnoreCase("Yes")) {
				waitForLoader();
				waitForLoader();
				waitForLoader();
				if (isDisplayed(btnCheckout, email, 10)) {

					UIValidation_Checkout_Page();
				}
			}

			// Validating MArketing Offers in Summary Checkout window

			if (!get("MarketingOfferType").isEmpty()) {

				MOCheckoutReview();

			}

			// Kept below logic for Marketing offers
			if (get("Switch-Over").trim().equalsIgnoreCase("No") || get("Switch-Over").trim().isEmpty()) {
				waitForLoader();
				switchToDefaultcontent();
				switchToFrame("IfProducts");
				waitForLoader();
				if (isDisplayed(customerCurrentProvider, email, 2)) {
					pageScroll(customerCurrentProvider, email, true);
					clickUsingJavaScript(customerCurrentProvider, email);
					report.reportPass(strDescription + getUrl, strExpected, strActual);
				}

				// Validating ETF in One Time Charges Section
				if (!get("ETF").isEmpty()) {
					validateETFReviewOrder();
				}

				// Naresh - Validating IWMP

				if (get("VASProduct").equals("Inside Wire Maintenance") && get("InternetPlan").isEmpty()) {
					validateIWMP();
				}

				// Exchange Options Added By : Naresh,Madipelly
				if (!get("ExchangeOptions").isEmpty() && get("FlowType").equals("Change")) {
					validateExchangeOptionsInCheckout();
				}

				System.out.println("latest jar");
				// waitForElementDisplay(btnCheckout, "", 60);
				waitForLoader();
				waitForLoader();
				waitForLoader();
				waitForLoader();
				waitForLoader();
				pause();
				report.reportPass("Display Review Order details in checkout",
						"Display Review Order details in checkout", "Review Order details are displayed in checkout");
						// waitForElementDisplay(btnCheckout, "", 30);

				// Analse the details and go to checkout page with price quote
				if (priceQuote.equalsIgnoreCase("Yes")) {

					clearText(emailText, objectValue);
					setText(emailText, objectValue, email);
					clickUsingJavaScript(btnSendQuote, objectValue);
					waitForLoader();
					if (isDisplayed(sendQuoteerror, email, 4)) {
						strFailed = "Failed in Sending Quote";
						logger.error(strFailed);
						report.reportFail("Send Quote should be done", "Send Quote should be done", strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						captureErrorMsg(strFailed);
						throw new UserDefinedException(strFailed);

					}

				}

				/*
				 * if (get("FastPassOrder").equalsIgnoreCase("Yes") &&
				 * (get("Application").equalsIgnoreCase("C2G"))) {
				 * 
				 * if(get("Application").equalsIgnoreCase("C2G")){
				 * clickUsingJavaScript(btnFastPassC2G, objectValue);
				 * report.reportPass("Clicking Save Button in Checkout",
				 * "Verify that Save Button is clicked in Checkout",
				 * "Save Button is clicked in Checkout successfully"); }
				 * 
				 * waitForLoader(); switchToFrame("PopupIFrame");
				 * 
				 * clearText(fastpassemail, objectValue); Thread.sleep(2000);
				 * setText(fastpassemail, objectValue,
				 * "mounika.polagoni@one.verizon.com"); pageScroll(yesButton,
				 * objectValue, true); clickUsingJavaScript(yesButton,
				 * objectValue); report.reportPass(
				 * "Entered Email and clicked Yes button in Checkout",
				 * "Verify Entered Email and clicked Yes button in Checkout",
				 * "Entered Email and clicked Yes button in Checkout successfully"
				 * ); waitForLoader(); clickUsingJavaScript(btnSaveOrder,
				 * objectValue); report.reportPass(
				 * "Clicking Save Order Button in Checkout",
				 * "Verify that Save Order Button is clicked in Checkout",
				 * "Save Order Button is clicked in Checkout successfully");
				 * waitForLoader(); waitForLoader();
				 * 
				 * 
				 * 
				 * }
				 * 
				 */
				report.reportPass(strDescription + getUrl, strExpected, strActual);
				// get each product details

				for (int i = 0; i < bndl_components.size(); i++) {

					try {
						// WebElement bndl_cmpnts = bndl_components.get(i);
						pageScroll(bndl_components.get(i), email, true);

						report.reportPass("Display Bundle Components in Checkout Page",
								"Display Bundle Components in Checkout Page",
								"Bundle Components in Checkout Page are: " + bndl_components.get(i).getText());

						waitForPageToLoad(driver);

					} catch (Exception e) {
						System.out.print(e.getMessage());
					}
				}

				waitForLoader();

				// EstimatedMonthlyProducts

				for (int i = 0; i < bndl_EstimatedMonthlyProducts.size(); i++) {

					try {
						// WebElement bndl_cmpnts = bndl_components.get(i);
						pageScroll(bndl_EstimatedMonthlyProducts.get(i), email, true);
						report.reportPass("Display Estimated Monthly Products in Checkout Page",
								"Display Estimated Monthly Products in Checkout Page",
								"Estimated Monthly Products in Checkout Page are: "
										+ bndl_EstimatedMonthlyProducts.get(i).getText());

						waitForPageToLoad(driver);

					} catch (Exception e) {
						System.out.print(e.getMessage());
					}
				}
				// Mounika Polagoni (HLR Validations)

				if (get("HLRValidations").equalsIgnoreCase("Yes")) {

					switchToDefaultcontent();
					switchToFrame("IfProducts");

					try {
						if (!get("Display Internet").isEmpty()) {
							String IP = get("Display Internet");
							System.out.println(IP);

							if (isDisplayed(ReviewOrderDetailsInternet, "", 1)) {
								pageScroll(ReviewOrderDetailsInternet, "", true);
								String BundleComponentsInternet = getTextFromElement(ReviewOrderDetailsInternet, email);
								String BCI[] = BundleComponentsInternet.split("Fios Internet");
								System.out.println(BundleComponentsInternet);
								String[] IPlan = IP.split("M");
								System.out.println(BCI[1]);
								// System.out.println(BCI[2]);
								if (BCI[1].contains(IPlan[0])) {
									report.reportPass("Internet Plan should be same in OPO and Checkout",
											"Internet Plan should be same in OPO and Checkout",
											"Internet is same in OPO and Checkout");
								} else {
									report.reportFail("Internet Plan should be same in OPO and Checkout",
											"Internet Plan should be same in OPO and Checkout",
											"Internet is not same in OPO and Checkout");
								}
							} else if (isDisplayed(ReviewOrderDetailsInternet2, "", 1)) {
								pageScroll(ReviewOrderDetailsInternet2, "", true);
								String BundleComponentsInternet = getTextFromElement(ReviewOrderDetailsInternet2,
										email);
								String BCI[] = BundleComponentsInternet.split("Fios Internet");
								System.out.println(BundleComponentsInternet);
								String[] IPlan = IP.split("M");
								System.out.println(BCI[1]);
								// System.out.println(BCI[2]);
								if (BCI[1].contains(IPlan[0])) {
									report.reportPass("Internet Plan should be same in OPO and Checkout",
											"Internet Plan should be same in OPO and Checkout",
											"Internet is same in OPO and Checkout");
								} else {
									report.reportFail("Internet Plan should be same in OPO and Checkout",
											"Internet Plan should be same in OPO and Checkout",
											"Internet is not same in OPO and Checkout");
								}
							} else {
								report.reportFail("Internet Plan should be same in OPO and Checkout",
										"Internet Plan should be same in OPO and Checkout",
										"Selected Internet Plan is not displayed in checkout");
							}
						}

					} catch (Exception e) {

					}

					// TV
					try {
						if (!get("Display Video").isEmpty()) {
							String TP = get("Display Video");
							System.out.println(TP);

							if (isDisplayed(ReviewOrderDetailsTV, "", 1)) {
								pageScroll(ReviewOrderDetailsTV, "", true);
								String BundleComponentsTV = getTextFromElement(ReviewOrderDetailsTV, email);
								System.out.println(BundleComponentsTV);
								if (BundleComponentsTV.contains(TP) || (TP.contains(BundleComponentsTV))) {
									report.reportPass("TV Plan should be same in OPO and Checkout",
											"TV Plan should be same in OPO and Checkout",
											"TV is same in OPO and Checkout");
								} else {
									report.reportFail("TV Plan should be same in OPO and Checkout",
											"TV Plan should be same in OPO and Checkout",
											"TV is not same in OPO and Checkout");
								}
							}

							else if (isDisplayed(ReviewOrderDetailsTV2, "", 1)) {
								pageScroll(ReviewOrderDetailsTV2, "", true);
								String BundleComponentsTV = getTextFromElement(ReviewOrderDetailsTV2, email);
								System.out.println(BundleComponentsTV);
								if (BundleComponentsTV.contains(TP) || (TP.contains(BundleComponentsTV))) {
									report.reportPass("TV Plan should be same in OPO and Checkout",
											"TV Plan should be same in OPO and Checkout",
											"TV is same in OPO and Checkout");
								} else {
									report.reportFail("TV Plan should be same in OPO and Checkout",
											"TV Plan should be same in OPO and Checkout",
											"TV is not same in OPO and Checkout");
								}
							} else {
								report.reportFail("TV Plan should be same in OPO and Checkout",
										"TV Plan should be same in OPO and Checkout",
										"Selected TV Plan is not displayed in checkout");
							}

						}
					} catch (Exception e) {

					}

					// Voice
					try {
						if (!get("Display Voice").isEmpty()) {
							String VP = get("Display Voice");
							System.out.println(VP);
							if (VP.contains("Fios Digital Voice")) {
								String VP2 = "Fios Digital Voice";

								if (isDisplayed(ReviewOrderDetailsVoice, "", 1)) {
									pageScroll(ReviewOrderDetailsVoice, "", true);
									String BundleComponentsVoice = getTextFromElement(ReviewOrderDetailsVoice, email);
									System.out.println(BundleComponentsVoice);
									if (BundleComponentsVoice.contains(VP2)) {
										report.reportPass("Voice Plan should be same in OPO and Checkout",
												"Voice Plan should be same in OPO and Checkout",
												"Voice is same in OPO and Checkout");
									} else {
										report.reportFail("Voice Plan should be same in OPO and Checkout",
												"Voice Plan should be same in OPO and Checkout",
												"Voice is not same in OPO and Checkout");
									}

								} else if (isDisplayed(ReviewOrderDetailsVoice2, "", 1)) {
									pageScroll(ReviewOrderDetailsVoice2, "", true);
									String BundleComponentsVoice = getTextFromElement(ReviewOrderDetailsVoice2, email);
									System.out.println(BundleComponentsVoice);
									if (BundleComponentsVoice.contains(VP2)) {
										report.reportPass("Voice Plan should be same in OPO and Checkout",
												"Voice Plan should be same in OPO and Checkout",
												"Voice is same in OPO and Checkout");
									} else {
										report.reportFail("Voice Plan should be same in OPO and Checkout",
												"Voice Plan should be same in OPO and Checkout",
												"Voice is not same in OPO and Checkout");
									}
								} else {
									report.reportFail("Voice Plan should be same in OPO and Checkout",
											"Voice Plan should be same in OPO and Checkout",
											"Selected Voice Plan is not displayed in checkout");
								}
							}

						}
					} catch (Exception e) {

					}

					// router

					try {
						if (!get("Display Router").isEmpty()) {
							String Rtr = get("Display Router");
							System.out.println(Rtr);
							if (Rtr.contains("Customer")) {
								report.reportPass(
										"Customer Provided Router should not be dispalyed in Checkout as it is Zero Rated",
										"Customer Provided Router should not be dispalyed in Checkout as it is Zero Rated",
										"Customer Provided Router is not dispalyed in Checkout since it is Zero Rated");
							} else {
								if (isDisplayed(getRouterDetails, Rtr, 1)) {
									pageScroll(getRouterDetails, "", true);
									String Router = getTextFromElement(getRouterDetails, email);
									if (Router.contains(Rtr)) {
										report.reportPass("Router should be same in OPO and Checkout",
												"Router should be same in OPO and Checkout",
												"Router is same in OPO and Checkout");
									} else {
										report.reportFail("Router should be same in OPO and Checkout",
												"Router should be same in OPO and Checkout",
												"Router is not same in OPO and Checkout");
									}
								}

								else {
									report.reportFail("Router should be same in OPO and Checkout",
											"Router should be same in OPO and Checkout",
											"Router is not displayed in Checkout");
								}
							}
						}
					} catch (Exception e) {

					}

					// Recording Option
					try {
						if (!get("Display RecordingOption").isEmpty()) {
							String RecOpt = get("Display RecordingOption");
							System.out.println(RecOpt);
							if (isDisplayed(getRecordingOptions, RecOpt, 1)) {
								pageScroll(getRecordingOptions, "", true);
								String RecordingOption = getTextFromElement(getRecordingOptions, email);
								if (RecordingOption.contains(RecOpt)) {
									report.reportPass("Recording Option should be same in OPO and Checkout",
											"Recording Option should be same in OPO and Checkout",
											"Recording Option is same in OPO and Checkout");
								} else {
									report.reportFail("Recording Option should be same in OPO and Checkout",
											"Recording Option should be same in OPO and Checkout",
											"Recording Option is not same in OPO and Checkout");
								}
							}

							else {
								report.reportFail("Recording Option should be same in OPO and Checkout",
										"Recording Option should be same in OPO and Checkout",
										"Recording Option is not displayed in Checkout");
							}
						}
					} catch (Exception e) {

					}

					// Number Of Tv

					try {
						if (!get("Display NumberOfTv").isEmpty()) {
							String NumOfTvPlan = get("Display NumberOfTv");
							System.out.println(NumOfTvPlan);
							if (isDisplayed(getSTB, NumOfTvPlan, 1)) {
								pageScroll(getSTB, "", true);
								String StbTv = getTextFromElement(getSTB, email);
								String[] StbSplit1 = StbTv.split("Set-Top Box");
								String[] StbSplit2 = StbSplit1[0].split("Rent: ");
								System.out.println(StbSplit2[1]);
								if (StbSplit2[1].contains(NumOfTvPlan)) {
									report.reportPass("Number Of Tv should be same in OPO and Checkout",
											"Number Of Tv should be same in OPO and Checkout",
											"Number Of Tv is same in OPO and Checkout");
								} else {
									report.reportFail("Number Of Tv should be same in OPO and Checkout",
											"Number Of Tv should be same in OPO and Checkout",
											"Number Of Tv is not same in OPO and Checkout");
								}
							} else {
								report.reportFail("Number Of Tv should be same in OPO and Checkout",
										"Number Of Tv should be same in OPO and Checkout",
										"Number Of Tv is not displayed in Checkout");
							}
						}
					} catch (Exception e) {

					}

				}

				// *************************************************************************************************************************
				// VAS Product validation code in review order page

				String vasProducts = get("VASProduct").trim();
				String reviewVSProd = "";
				String reviewVSProdStat = "";
				boolean bbeProdPresent = false;
				boolean bbeProdNotPresent = false;
				boolean bbeProdStat = false;
				// int vs = 1;

				/*
				 * //if (!vasProducts.isEmpty()){ if (!vasProducts.isEmpty() &&
				 * get("Application").trim().equalsIgnoreCase("COA") ){ try {
				 * 
				 * strDescription =
				 * "Validate the newly Added BBE product  in review order page";
				 * strExpected =
				 * "Added BBE product should be present in the review order page and should be displayed as New"
				 * ; strFailed =
				 * "Failed in VAS optoins Validation in Review order page.";
				 * 
				 * if(vasProducts.contains(";")){
				 * 
				 * 
				 * String[] vsProds = vasProducts.split(";");
				 * 
				 * System.out.println(
				 * "VAS products to be validated in review order page "+
				 * vsProds);
				 * 
				 * for (int i = 0; i < vsProds.length; i++) { bbeProdPresent =
				 * false; for ( int vs = 1 ; vs <=
				 * bndl_EstimatedMonthlyProducts.size(); vs++){ reviewVSProd =
				 * getTextFromElement(ProductsAndPromotionsName,
				 * String.valueOf(vs)); System.out.println(vsProds[i]);
				 * if(vsProds[i].toUpperCase().contains(":X") ){
				 * System.out.println("Opted Removing the BBE products : " +
				 * vsProds[i]); if(vsProds[i].equalsIgnoreCase(reviewVSProd)){
				 * System.out.println("Removed BBE product : " + vsProds[i] +
				 * "  is displayed in the review order page");
				 * report.reportFail(
				 * "Validate removed BBE product in review order page  " +
				 * getUrl, "Removed BBE product : " + vsProds[i] +
				 * "  should not be displayed in the review order page",
				 * "Removed BBE product : " + vsProds[i] +
				 * "  is displayed in the review order page");
				 * report.updateMainReport("ErrorMessage", strFailed); }else{
				 * bbeProdNotPresent=true; System.out.println(
				 * "Removed BBE product : " + vsProds[i] +
				 * "  is not displayed in the review order page");
				 * report.reportPass(
				 * "Validate removed BBE product in review order page  " +
				 * getUrl, "Removed BBE product : " + vsProds[i] +
				 * "  should not be displayed in the review order page",
				 * "Removed BBE product : " + vsProds[i] +
				 * "  is not displayed in the review order page"); } }else{
				 * 
				 * if(vsProds[i].equalsIgnoreCase(reviewVSProd)){ bbeProdPresent
				 * = true; reviewVSProdStat =
				 * getTextFromElement(ProductsAndPromotionsNameStatus,
				 * String.valueOf(vs)); if(reviewVSProdStat.contains("New")){
				 * strActual = "Added BBE product : "+ vsProds[i] +
				 * " is present in the review order page and displayed displayed as : "
				 * + reviewVSProdStat ; report.reportPass(strDescription +
				 * getUrl, strExpected, strActual); System.out.println(
				 * vsProds[i] +
				 * "  :  BBE product is displayed in the review order. and the status is displayed as : "
				 * + reviewVSProdStat); }else{ strFailed =
				 * "Added BBE product : "+ vsProds[i] +
				 * " is present in the review order page and displayed displayed as : "
				 * + reviewVSProdStat ; report.reportFail(strDescription +
				 * getUrl, strExpected, strFailed);
				 * report.updateMainReport("ErrorMessage", strFailed);
				 * System.out.println( vsProds[i] +
				 * "  :  BBE product is displayed in the review order. and the status is displayed as : "
				 * + reviewVSProdStat);
				 * 
				 * }
				 * 
				 * }
				 * 
				 * } } if(!bbeProdPresent &&
				 * !vsProds[i].toUpperCase().contains(":X")){
				 * 
				 * strDescription = "Validate the newly Added :"+ vasProducts +
				 * " BBE product in review order page"; strExpected = "Added  :"
				 * + vasProducts +
				 * " BBE product should be present in the review order page and should be displayed as New"
				 * ; strFailed = "Added BBE :"+ vasProducts +
				 * "  product not displayed in review order page";
				 * report.reportFail(strDescription + getUrl, strExpected,
				 * strFailed); report.updateMainReport("ErrorMessage",
				 * strFailed); } if(!bbeProdNotPresent &&
				 * vsProds[i].toUpperCase().contains(":X")){ System.out.println(
				 * "Removed BBE product : " + vsProds[i] +
				 * "  is displayed in the review order page");
				 * report.reportFail(
				 * "Validate removed BBE product in review order page  " +
				 * getUrl, "Removed BBE product : " + vsProds[i] +
				 * "  should not be displayed in the review order page",
				 * "Removed BBE product : " + vsProds[i] +
				 * "  is displayed in the review order page");
				 * report.updateMainReport("ErrorMessage", strFailed); } }
				 * 
				 * } else if(!vasProducts.toUpperCase().contains(":X")){
				 * 
				 * for (int vsp = 1; vsp <=
				 * bndl_EstimatedMonthlyProducts.size(); vsp++){
				 * 
				 * reviewVSProd = getTextFromElement(ProductsAndPromotionsName,
				 * String.valueOf(vsp));
				 * 
				 * if(vasProducts.equalsIgnoreCase(reviewVSProd)){
				 * bbeProdPresent = true; reviewVSProdStat =
				 * getTextFromElement(ProductsAndPromotionsNameStatus,
				 * String.valueOf(vsp)); if(reviewVSProdStat.contains("New")){
				 * bbeProdStat = true; strActual = "Added BBE product : "+
				 * vasProducts +
				 * " is present in the review order page and displayed displayed as : "
				 * + reviewVSProdStat ; report.reportPass(strDescription +
				 * getUrl, strExpected, strActual); System.out.println(
				 * vasProducts +
				 * "  :  BBE product is displayed in the review order. and the status is displayed as : "
				 * + reviewVSProdStat); }else{ strFailed =
				 * "Added BBE product : "+ vasProducts +
				 * " is present in the review order page and displayed displayed as : "
				 * + reviewVSProdStat ; report.reportFail(strDescription +
				 * getUrl, strExpected, strFailed);
				 * report.updateMainReport("ErrorMessage", strFailed);
				 * System.out.println( vasProducts +
				 * "  :  BBE product is displayed in the review order. and the status is displayed as : "
				 * + reviewVSProdStat);
				 * 
				 * } }
				 * 
				 * }
				 * 
				 * if(!bbeProdPresent){
				 * 
				 * strDescription = "Validate the newly Added :"+ vasProducts +
				 * " BBE product in review order page"; strExpected = "Added  :"
				 * + vasProducts +
				 * " BBE product should be present in the review order page and should be displayed as New"
				 * ; strFailed = "Added BBE :"+ vasProducts +
				 * "  product not displayed in review order page";
				 * report.reportFail(strDescription + getUrl, strExpected,
				 * strFailed); report.updateMainReport("ErrorMessage",
				 * strFailed); } } else
				 * if(vasProducts.toUpperCase().contains(":X")){
				 * 
				 * for (int vspd = 1; vspd <=
				 * bndl_EstimatedMonthlyProducts.size(); vspd++){
				 * 
				 * reviewVSProd = getTextFromElement(ProductsAndPromotionsName,
				 * String.valueOf(vspd));
				 * 
				 * if(vasProducts.equalsIgnoreCase(reviewVSProd)){
				 * System.out.println("Opted Removing the BBE products : " +
				 * vasProducts); System.out.println("Removed BBE product : " +
				 * vasProducts + "  is displayed in the review order page");
				 * report.reportFail(
				 * "Validate removed BBE product in review order page  " +
				 * getUrl, "Removed BBE product : " + vasProducts +
				 * "  should not be displayed in the review order page",
				 * "Removed BBE product : " + vasProducts +
				 * "  is displayed in the review order page");
				 * report.updateMainReport("ErrorMessage", strFailed); }else{
				 * bbeProdNotPresent=true; System.out.println(
				 * "Removed BBE product : " + vasProducts +
				 * "  is not displayed in the review order page");
				 * report.reportPass(
				 * "Validate removed BBE product in review order page  " +
				 * getUrl, "Removed BBE product : " + vasProducts +
				 * "  should not be displayed in the review order page",
				 * "Removed BBE product : " + vasProducts +
				 * "  is not displayed in the review order page"); }
				 * 
				 * }
				 * 
				 * if(!bbeProdNotPresent &&
				 * vasProducts.toUpperCase().contains(":X")){
				 * System.out.println("Removed BBE product : " + vasProducts +
				 * "  is displayed in the review order page");
				 * report.reportFail(
				 * "Validate removed BBE product in review order page  " +
				 * getUrl, "Removed BBE product : " + vasProducts +
				 * "  should not be displayed in the review order page",
				 * "Removed BBE product : " +vasProducts +
				 * "  is displayed in the review order page");
				 * report.updateMainReport("ErrorMessage", strFailed); } }
				 * 
				 * 
				 * }catch (Exception exe) { if (!isUserDefinedException(exe)) {
				 * strFailed =
				 * "Failed in VAS optoins Validation in Review order page.";
				 * report.reportFail(strDescription + getUrl, strExpected,
				 * strFailed); report.updateMainReport("ErrorMessage",
				 * strFailed); captureErrorMsg(
				 * "Failed in VAS options Validation in Review order page."); }
				 * throw exe; }
				 * 
				 * 
				 * }
				 */
				// *************************************************************************************************************************

				strDescription = "Validate that Estimated Monthly Charges of checkout should match with Footer price on OPO ";
				strExpected = "Estimated Monthly Charges of checkout should match with Footer price on OPO";
				strActual = "Estimated Monthly Charges of checkout matched with Footer price on OPO";
				strFailed = "Estimated Monthly Charges of checkout not matched with Footer price on OPO";
				getUrl = ", URL Launched --> " + returnURL();
				if (isDisplayed(mtly_chrgs_Checkout, email, 2)) {
					String Monthly_chrgs_checkout = getTextFromElement(mtly_chrgs_Checkout, objectValue);
					System.out.println(Monthly_chrgs_checkout);
					report.reportPass("Display Monthly Charges in Checkout", "Display Monthly Charges in Checkout",
							"Monthly Charges in Checkout is: " + Monthly_chrgs_checkout);
					// if (!get("Monthly Estimated Charge in OPO").isEmpty()){
					// if (get("Monthly Estimated Charge in
					// OPO").equals(Monthly_chrgs_checkout)) {
					// report.reportPass(strDescription + get("Monthly Estimated
					// Charge in OPO"), strExpected, strActual);
					// }
					// else{
					// report.reportPass(strDescription + get("Monthly Estimated
					// Charge in OPO"), strExpected, "Estimated Monthly Charges
					// of checkout "+Monthly_chrgs_checkout+" not matched with
					// Footer price on OPO "+get("Monthly Estimated Charge in
					// OPO"));
					// }
					// }
				}
				if (isDisplayed(DisReason, "", 3)) {
					selectDropDownUsingIndex(DisReason, reviewVSProdStat, 1);
					waitForLoader();

				}

				// Vignesh
				if (get("SubFlowType").equalsIgnoreCase("TVStbpriceup") || get("SubFlowType").equalsIgnoreCase("HNP")) {
					Validateinreview();
				}
				// Analse the details and go to checkout page
				// FCP update Mithra
				if (get("Project_ID").contains("FCP")) {
					reviewOrderOfferValidation();
				}
				if (isDisplayed(btnCheckout, "", 1)) {
					clickUsingJavaScript(btnCheckout, objectValue);
					report.reportPass(strDescription + getUrl, strExpected, strActual);
				} else if (isDisplayed(btnChkt, "", 1)) {
					clickUsingJavaScript(btnChkt, objectValue);
					report.reportPass(strDescription + getUrl, strExpected, strActual);
				} else {
					clickUsingJavaScript(btnAddToCart, objectValue);
					report.reportPass(strDescription + getUrl, strExpected, strActual);
					waitForLoader();
					waitForLoader();
					waitForLoader();
					waitForLoader();
					waitForElementDisplay(btnPriceQuoteCheckout, reviewVSProdStat, 20);
					report.reportPass(strDescription + getUrl, strExpected, strActual);
					clickUsingJavaScript(btnPriceQuoteCheckout, objectValue);
				}

			}

			waitForLoader();
			waitForLoader();
			waitForLoader();

			// resetting the frame to default contents
			switchToDefaultcontent();
		} catch (Exception exe) {
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in clicking review button.");
			}
			throw exe;
		}
	}

	/**
	 * @info To deselect any service which was added by default based on our
	 *       RunManager
	 * @author Praveen
	 * @param "Service"
	 *            should be Given as Parameter
	 * @return No return Value
	 * @LastModified -Shiva Kumar Simharaju 07/04/2018
	 */

	public void Deselectservice(String Service) throws Exception, UserDefinedException {

		// To uncheck the speed selection
		try {
			if (isDisplayed(SelectedService, Service, 0)) {
				clickUsingJavaScript(SelectedService, Service);
				waitForLoader();
			}

			report.reportPass(
					"One Page  ordering - Verify whether user is able to Uncheck Preselected " + Service + " Product",
					"Should be able to uncheck Preselected " + Service + " Product",
					"Able to uncheck Preselected " + Service + " Product");
		} catch (Exception e) {
			String strFailed = "Failed in Service Deselection, Unable to deselect " + Service + " product";
			report.reportFail("Verify whether user is able to Uncheck Preselected",
					"Preselected service should be deselected.", strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);

		}
	}

	/**
	 * @Description: method used for handling Disconnect service page
	 * @author: Yuvraj
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */
	public void DisconnectPage() throws Exception {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "DisConnect Service page";
		strExpected = "Handle the Disconnect service page";
		strActual = "Disconnect service page is handled";
		strFailed = "Disconnect service page is not handled";
		getUrl = ", URL Launched --> " + returnURL();
		try {

			List<WebElement> DisconnectPage = driver.findElements(By.xpath("//select[@id='ddlVzCatgoryReason']"));
			if (DisconnectPage.size() > 0) {
				if (DisconnectCategory.isDisplayed()) {

					try {
						selectDropDownUsingVisibleText(DisconnectCategory, objectValue, "Moves");
						Thread.sleep(3000);

						Select dropdown1 = new Select(DisconnectReason);
						dropdown1.selectByIndex(1);

						// SelectDropDown(DisconnectReason,
						// objectValue,"Moves");
						clickUsingJavaScript(DisconnectSaveContinueBtn, objectValue);
						report.reportPass(strDescription + getUrl, strExpected, strActual);
						// waitForPageLoad("dvOPOLoader");
						waitForLoader();

					} catch (Exception e) {
						report.reportFail(strDescription + getUrl, strExpected, strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						throw new UserDefinedException("Element_validation - failed..");
					}
				}
			}

		} catch (Exception exe) {

			exe.printStackTrace();
			report.reportFail(strDescription + getUrl, strExpected, strFailed + exe.getCause());
			report.updateMainReport("ErrorMessage", strFailed);
			throw new UserDefinedException("Failed in Disconnect Page");

		}
	}

	/**
	 * @Description: method used for handling BBE in C2G
	 * @author: Padmini
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */

	public void selectVASOptionC2G() throws Exception, UserDefinedException {

		System.out.println("->selectVASOption");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "To negotiate VASOption section";
		strExpected = "VASOption section should be selected";
		strActual = "VASOption is negotiated successfully";
		getUrl = ", URL Launched --> " + returnURL();
		try {
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			String vasProduct = get("VASProduct").trim();
			String vasipMoveASIS = get("VasipMoveASIS").trim();
			String internetPlan = get("InternetPlan").trim();
			// String Data=getTextFromElement(OPOSelectedData, objectValue);

			String Data = "";

			if (!internetPlan.isEmpty() && get("GUI_Validations").equalsIgnoreCase("Yes")) {
				UIValidations_BBE_Validation();
			}

			if (isDisplayed(simplex_SelectedData, "")) {
				Data = simplex_SelectedData.getText().trim();
			}
			if ((!Data.isEmpty() && (!vasProduct.isEmpty())))

			{
				Set<String> allExistingWindows = driver.getWindowHandles();
				System.out.println("WIndow counts:" + allExistingWindows.size());

				// Expanding VAS tab
				if (!tabVAS.getAttribute("class").contains("open")) {
					pageScroll(tabVAS, objectValue, true);
					clickUsingJavaScript(tabVAS, objectValue);
				}

				// AClicking on More VAS Option
				clickUsingJavaScript(MoreVASC2G, objectValue);
				report.reportPass("Click  on more VAS options link", "More VAS options link should be clicked.",
						"Clicked on more VAS options link.");
				waitForLoader();
				waitForLoader();
				waitForLoader();
				pause();

				switchToDefaultcontent();
				switchToFrame("IfProducts");
				switchToFrame("externalframe");

				// Selectiong the required Product from Vas Page
				try {
					waitForElementDisplay(VASAlertmsg, "", pageTimeoutInSeconds);

					pageScroll(BBEOptionsC2G, vasProduct, true);
					clickUsingJavaScript(BBEOptionsC2G, vasProduct);

					if (vasProduct.toLowerCase().equals("tv protection plan")
							&& (isDisplayed(BBEOptionsTOSTvProtectionPlan, objectValue))) {
						pageScroll(BBEOptionsTOSTvProtectionPlan, "", true);
						clickUsingJavaScript(BBEOptionsTOSTvProtectionPlan, "");
					} else if (vasProduct.toLowerCase().equals("total protection pak 250 gb")
							&& (isDisplayed(BBEOptionsTOSTotalProtectionPak250GB, objectValue))) {
						pageScroll(BBEOptionsTOSTotalProtectionPak250GB, "", true);
						clickUsingJavaScript(BBEOptionsTOSTotalProtectionPak250GB, "");
					} else if (vasProduct.toLowerCase().equals("total protection pak 1 tb")
							&& (isDisplayed(BBEOptionsTOSTotalProtectionPak1TB, objectValue))) {
						pageScroll(BBEOptionsTOSTotalProtectionPak1TB, "", true);
						clickUsingJavaScript(BBEOptionsTOSTotalProtectionPak1TB, "");
					} else if (vasProduct.toLowerCase().equals("premium technical support - per use (c)")
							&& (isDisplayed(BBEOptionsTOSPremiumTechnicalSupportPerUse, objectValue))) {
						pageScroll(BBEOptionsTOSPremiumTechnicalSupportPerUse, "", true);
						clickUsingJavaScript(BBEOptionsTOSPremiumTechnicalSupportPerUse, "");
					} else if (vasProduct.toLowerCase().equals("premium device protection plan")
							&& (isDisplayed(BBEOptionsTOSPremiumDeviceProtectionPlan, objectValue))) {
						pageScroll(BBEOptionsTOSPremiumDeviceProtectionPlan, "", true);
						clickUsingJavaScript(BBEOptionsTOSPremiumDeviceProtectionPlan, "");
					} else if (vasProduct.toLowerCase().equals("device protection plan")
							&& (isDisplayed(BBEOptionsTOSDeviceProtectionPlan, objectValue))) {
						pageScroll(BBEOptionsTOSDeviceProtectionPlan, "", true);
						clickUsingJavaScript(BBEOptionsTOSDeviceProtectionPlan, "");
					} else if (vasProduct.toLowerCase().equals("Whole Home Device Protection Plan")
							&& (isDisplayed(BBEOptionsTOSWholeHomeProtectionPlan, objectValue))) {
						pageScroll(BBEOptionsTOSWholeHomeProtectionPlan, "", true);
						clickUsingJavaScript(BBEOptionsTOSWholeHomeProtectionPlan, "");
					}

					report.reportPass("Verify  VASProduct is Selected", "Check whether Vas Product is Clicked",
							"VAS Product is Clicked:" + vasProduct);
					// Click on save and COntinue in BBE page
					clickUsingJavaScript(VASSaveandContinue, objectValue);
					report.reportPass("Click on VAS save and continue button.",
							"Save and continue button should be clicked.", "Clicked on save and continue button.");
				} catch (Exception e) {
					strFailed = "Failed in VAS section, Required VAS product " + vasProduct + " not available.";
					report.reportFail("Select VAS option.", "VAS option should be selected.", strFailed);
					report.updateMainReport("comments", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					logger.error(strFailed);
					captureErrorMsg(strFailed);
					throw new UserDefinedException(strFailed);
				}

				pause();
				waitForLoader();
				waitForLoader();
				// driver.switchTo().window(productsWindow);
				waitForLoader();
				switchToDefaultcontent();
				switchToFrame("IfProducts");
			}
			if (!Data.isEmpty() && (vasipMoveASIS.equalsIgnoreCase("Y"))) {

				try {
					if (isDisplayed(bbeselected, objectValue)) {

						String bbe_selected = bbeselected.getText();
						System.out.println(bbe_selected);

						report.reportPass("To verify if bbe is preselected for moveAsIs", "bbe should be preselected",
								"bbe is PreSelected");
					}
				} catch (Exception e) {

					strFailed = "Failed in VAS section, BBE is not PreSelected";
					report.reportFail("To verify if bbe is preselected for moveAsIs", "BBE should be preselected",
							strFailed);
					report.updateMainReport("comments", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					logger.error(strFailed);
					captureErrorMsg(strFailed);
					throw new UserDefinedException(strFailed);

				}

			}

			if (tabVAS.getAttribute("class").contains("open")) {
				pageScroll(tabVAS, "", true);
				clickUsingJavaScript(tabVAS, objectValue);
			}
			// Switching to Default Content
			switchToDefaultcontent();
			switchToFrame("IfProducts");

		} catch (Exception exe) {
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in VAS optoins section.");
			}
			throw exe;
		}

		// Updated by 06th April 2017 by Poovaraj
		if ((get("TestCase_Name").contains("New_Install_Double_LEC_Select_HD_MTM_in_FSRC")) || (get("TestCase_Name")
				.contains("COAC002_Standalone_DP_Voice_Video_2_POTS_LINE_Ultimate_HD_TV_MRDVR_SetUp_Charge_150"))) {
			// LECPageNavigation();
		} else {
			// Moving to LEC Option
			SelectsetupInstall();
		}
	}

	/**
	 * @Description: selectLecVoice is used to add or update line in Lec voice
	 *               option
	 * @param: VoicePlan,AddLecLine,ChangeVoiceJack
	 *             and Standalone are used to update line in Lec Voice section
	 * @author: Mounika, Padmini
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */

	public void selectLecVoice() throws Exception, UserDefinedException {

		System.out.println("->Lec Section");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "To negotiate Lec Section in C2G";
		strExpected = "Negotiate Lec Section";
		strFailed = "Failed in Lec Section";
		strActual = "Negotiated Lec Section";
		getUrl = ", URL Launched --> " + returnURL();

		int addLineTabCount = 0;
		try {

			String VoicePlan = get("VoicePlan");
			String AddLecLine = get("AddLecLine");
			String ChangeVoiceJack = get("ChangeVoiceJack");
			String LecMaintenancePlan = get("LecMaintenancePlan");
			String LecVoiceBackupPower = get("LecVoiceBackupPower");
			String Standalone = get("Standalone");
			String LecVoicePackage = get("LecVoicePackage");
			String strFirstName = get("FirstName");
			String strLastName = get("LastName");

			switchToDefaultcontent();
			switchToFrame("IfProducts");

			waitForLoader();
			waitForLoader();
			waitForLoader();

			// click add new line

			addLineTabCount = NoOfAddlineTab.size();
			System.out.println("No Of  Addline Tab is:" + addLineTabCount);

			try {

				if (!AddLecLine.isEmpty()) {
					int addlineCount = Integer.parseInt(AddLecLine);

					System.out.println("addlineCount value is:" + addlineCount);
					for (int i = 1; i <= addlineCount; i++) {

						if (isDisplayed(BtnLECAddNewLine, objectValue)) {

							if ((!isDisplayed(lecPageDisplay, "", 30))) {
								// pageScroll(BtnLECAddNewLine, objectValue,
								// true);
								clickUsingJavaScript(BtnLECAddNewLine, objectValue);
								waitForLoader();
								waitForLoader();
								waitForLoader();
								waitForLoader();
								// waitForElementDisplay(lecPageDisplay, "",
								// pageTimeoutInSeconds);

								report.reportPass("Click on Add Line in LEC", "Add new Line should be clicked.",
										"Clicked on Add new Line in LEC window");
								addLineTabCount++;
							} else if (!isDisplayed(lecPageDisplay, "", 20) || (i >= addLineTabCount)) {
								// pageScroll(BtnLECAddNewLine, objectValue,
								// true);
								clickUsingJavaScript(BtnLECAddNewLine, objectValue);
								waitForLoader();
								waitForLoader();
								waitForLoader();
								waitForLoader();
								waitForLoader();

								waitForElementDisplay(lecPageDisplay, "", pageTimeoutInSeconds);

								report.reportPass("Click on Add Line  in LEC", "Add new Line should be clicked.",
										"Clicked on Add new Line in LEC window");
								addLineTabCount++;
							}

							waitForLoader();
							waitForLoader();

							waitForElementDisplay(lecPageDisplay, "", pageTimeoutInSeconds);
							// Maintenance Flow
							try {
								if ((!LecVoicePackage.contains("None")) && (!LecVoicePackage.isEmpty())) {
									if (isDisplayed(callingPackageLECVoice, objectValue, 5)) {
										// clickUsingJavaScript(callingPackageLECVoice,
										// objectValue);
										selectDropDownUsingValue(callingPackageLECVoice, "", LecVoicePackage);
										report.reportPass("Click on Calling Package in Lec Window",
												"Calling Package should be clicked in Lec Window",
												"Calling Package is clicked in Lec Window");
										waitForLoader();
										waitForLoader();

									}
								}

							} catch (Exception e) {

								strFailed = "Failed in LEC Window, Calling Package is not selected";
								logger.error(strFailed, e);
								report.reportFail("Failed in LEC Window", "Calling Package is not selected", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							}
							switchToDefaultcontent();
							switchToFrame("IfProducts");
							switchToFrame("PopupIFrame");

							if (isDisplayed(chkDisclosure, objectValue)) {
								// pageScroll(chkDisclosure, objectValue, true);
								clickUsingJavaScript(chkDisclosure, objectValue);
								report.reportPass("Click on Disclosure Checkbox in Lec Window",
										"Disclosure Checkbox should be clicked in Lec Window",
										"Disclosure Checkbox is clicked in Lec Window");
								waitForLoader();
								waitForLoader();

							}

							/*
							 * try { if (isDisplayed(LinkLECMaintenanceDetails,
							 * objectValue)) {
							 * clickUsingJavaScript(LinkLECMaintenanceDetails,
							 * objectValue); waitForLoader(); waitForLoader();
							 * waitForLoader(); waitForLoader(); }
							 * 
							 * driver.switchTo().frame(driver.findElement(By.
							 * xpath(
							 * "//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]"
							 * ))); // switchToFrame(jackVoiceFrame);
							 * 
							 * System.out.println("Switched to frame");
							 * 
							 * if(isDisplayed(ChkbxLECNoMaintainance, "",5)){
							 * //pageScroll(ChkbxLECNoMaintainance, objectValue,
							 * true);
							 * clickUsingJavaScript(ChkbxLECNoMaintainance,
							 * objectValue); report.reportPass(
							 * "Click on No Mainatinance Plan in LEC",
							 * "No Mainatinance Plan should be clicked",
							 * "No Mainatinance Plan is clicked"); } else{
							 * if(isDisplayed(ChkbxLECMaintainanceplan,
							 * LecMaintenancePlan,5)) { //
							 * pageScroll(ChkbxLECMaintainanceplan,
							 * LecMaintenancePlan, true);
							 * click(notChkbxLECMaintainanceplan,
							 * LecMaintenancePlan); report.reportPass(
							 * "Click on Mainatinance Plan in LEC",
							 * "Mainatinance Plan should be clicked",
							 * "Mainatinance Plan is clicked");
							 * //clickUsingJavaScript(ChkbxLECMaintainanceplan,
							 * objectValue); } else{
							 * click(notChkbxLECMaintainanceplan,
							 * LecMaintenancePlan); report.reportPass(
							 * "Click on Mainatinance Plan in LEC",
							 * "Mainatinance Plan should be clicked",
							 * "Mainatinance Plan is clicked"); } }
							 * waitForLoader(); waitForLoader();
							 * waitForLoader(); waitForLoader();
							 * 
							 * 
							 * switchToDefaultcontent();
							 * switchToFrame("IfProducts");
							 * switchToFrame("PopupIFrame");
							 * driver.switchTo().frame(driver.findElement(By.
							 * xpath(
							 * "//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]"
							 * )));
							 * 
							 * if (isDisplayed(linkOkMaintainanceGN,
							 * objectValue)) { //
							 * pageScroll(linkOkMaintainanceGN, objectValue,
							 * true); clickUsingJavaScript(linkOkMaintainanceGN,
							 * objectValue); report.reportPass(
							 * "Click on Ok in Mainatinance Plan in LEC",
							 * "Ok in Mainatinance Plan should be clicked",
							 * "Ok in Mainatinance Plan is clicked");
							 * waitForLoader(); } pause(); //pause();
							 * 
							 * 
							 * } catch (Exception e) { strFailed =
							 * "Failed in LEC Window, Maintainance Plan is not negotiated"
							 * ; logger.error(strFailed, e); report.reportFail(
							 * "Failed in LEC Window",
							 * "Maintainance Plan should be negotiated",
							 * strFailed); report.updateMainReport("comments",
							 * strFailed);
							 * report.updateMainReport("ErrorMessage",
							 * strFailed); captureErrorMsg(strFailed); throw new
							 * UserDefinedException(strFailed); }
							 */

							System.out.println("Switched to frame");
							waitForLoader();
							waitForLoader();
							waitForLoader();
							waitForLoader();
							// Voice backup power details

							switchToDefaultcontent();
							switchToFrame("IfProducts");
							switchToFrame("PopupIFrame");
							pause();

							try {
								if (isDisplayed(HyperlinkVoicebackupLEC, objectValue)) {
									// pageScroll(HyperlinkVoicebackupLEC,
									// objectValue, true);
									clickUsingJavaScript(HyperlinkVoicebackupLEC, objectValue);
									report.reportPass("Click on Hyperlink Voicebackup",
											"Hyperlink Voicebackup should be clicked",
											"Hyperlink Voicebackup is clicked");
									waitForLoader();
									waitForLoader();
									waitForLoader();
									pause();

									driver.switchTo().frame(driver.findElement(
											By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
									// switchToFrame(jackVoiceFrame);
									System.out.println("Switched to frame");

									click(ChkbxLECVoiceBackUpplan, LecVoiceBackupPower);

									pause();
									// pause();

									// clickUsingJavaScript(ChkbxLECVoiceBackUpplan,
									// objectValue);
									report.reportPass("Click on  Voicebackup", "Voicebackup should be clicked",
											"Voicebackup is clicked"); // pageScroll(linkOk,
																		// objectValue,
																		// true);
									clickUsingJavaScript(linkOk, objectValue);
									waitForLoader();
									pause();
									// pause();

								}

							} catch (Exception e) {
								strFailed = "Failed in LEC Window, Voice BackUp Power is not negotiated";
								logger.error(strFailed, e);
								report.reportFail("Failed in LEC Window", "Voice BackUp Power should be negotiated",
										strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							}

							// 911 Disclosure for Battery

							try {

								waitForLoader();
								waitForLoader();
								switchToDefaultcontent();
								switchToFrame("IfProducts");
								switchToFrame("PopupIFrame");
								pause();

								if (isDisplayed(Disclosure)) {
									System.out.println(Disclosure.getText());
									clickUsingJavaScript(CustomerAcceptance, "");
									report.reportPass(
											"Validate wether Customer Indicated understanding of 911 limitations is Accepted or not",
											"Customer Indicated understanding of 911 limitations should be Accepted",
											"Customer Indicated understanding of 911 limitations is Accepted");
								}

							} catch (Exception e) {
								e.printStackTrace();

							}

							// Jack Flow

							try {
								waitForLoader();
								waitForLoader();
								waitForLoader();
								waitForLoader();
								waitForLoader();
								if (isDisplayed(jackVoiceLink, objectValue)) {
									// pageScroll(jackVoiceLink, objectValue,
									// true);
									clickUsingJavaScript(jackVoiceLink, objectValue);
									report.reportPass("Click on Jack Voice Link", "Jack Voice Link should be clicked",
											"Jack Voice Link is clicked");
									waitForLoader();
									waitForLoader();
									waitForLoader();
									// pause();

									driver.switchTo().frame(driver.findElement(
											By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

									// switchToFrame(jackVoiceFrame);
									waitForLoader();
									waitForLoader();
									System.out.println("Switched to frame");

									// update jack
									waitForLoader();
									waitForLoader();
									waitForLoader();
									switchToDefaultcontent();
									switchToFrame("IfProducts");
									switchToFrame("PopupIFrame");
									driver.switchTo().frame(driver.findElement(
											By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
									// pageScroll(ChkbxLECNoJacks);

									if (isDisplayed(ChkbxLECNoJacks, objectValue)) {

										if (!ChangeVoiceJack.isEmpty()) {

											System.out.println("ChangeVoiceJack count:" + valuesForVoiceJack.size());
											for (WebElement el : valuesForVoiceJack) {
												System.out.println("Value for Jack text:" + el.getText());

												for (WebElement el1 : chkBoxesForVoiceJack) {
													if (el.getText().contains(ChangeVoiceJack.trim())) {
														// clickUsingJavaScript(JackWorkPhone,
														// objectValue);
														click(JackWorkPhone, objectValue);
														report.reportPass("Click on Jack in Jack Section",
																"Jack in Jack Section should be clicked",
																" Jack in Jack Section is clicked");

														// ((JavascriptExecutor)
														// driver).executeScript("arguments[0].click();",
														// el1);
														// waitForLoader();
														waitForLoader();
														waitForLoader();

														break;
													}
												}
											}

											switchToDefaultcontent();
											switchToFrame("IfProducts");
											switchToFrame("PopupIFrame");
											driver.switchTo().frame(driver.findElement(By.xpath(
													"//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

											click(ADDLinkJack, objectValue);
											waitForLoader();
											waitForLoader();
											waitForLoader();

										} else {
											// no Jacks needed clicked
											waitForLoader();
											waitForLoader();
											switchToDefaultcontent();
											switchToFrame("IfProducts");
											switchToFrame("PopupIFrame");
											driver.switchTo().frame(driver.findElement(By.xpath(
													"//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
											pageScroll(ChkbxLECNoJacks, objectValue, true);
											clickUsingJavaScript(ChkbxLECNoJacks, objectValue);
											report.reportPass("Click on No Jack in Jack Section",
													"No Jack in Jack Section should be clicked",
													"No Jack in Jack Section is clicked");
											waitForLoader();
											waitForLoader();

										}

									}
									// Link Ok
									switchToDefaultcontent();
									switchToFrame("IfProducts");
									switchToFrame("PopupIFrame");
									driver.switchTo().frame(driver.findElement(
											By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
									if (isDisplayed(BtnLECJackOk, objectValue)) {
										// Clicking on OK for jacks
										// pageScroll(BtnLECJackOk, objectValue,
										// true);
										clickUsingJavaScript(BtnLECJackOk, objectValue);
										report.reportPass("Click on Ok in Jack Section",
												"Ok in Jack Section should be clicked",
												"Ok in Jack Section is clicked");
										waitForLoader();
										waitForLoader();
										waitForLoader();
										waitForLoader();
										waitForElementDisplay(lecPageDisplay, Standalone, pageTimeoutInSeconds);
									}
									pause();

								} else {

								}
							} catch (Exception e) {
								strFailed = "Failed in LEC Window, Voice Jack is not negotiated";
								logger.error(strFailed, e);
								report.reportFail("Failed in LEC Window", "Voice Jack should be negotiated", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							}

							/// Mian Directory Listing
							if (isDisplayed(MainDirectoryListingEdit, objectValue)) {
								// pageScroll(jackVoiceLink, objectValue, true);
								clickUsingJavaScript(MainDirectoryListingEdit, objectValue);
								report.reportPass("Click on Main Directory Listing edit",
										"Main Directory Listing edit should be clicked",
										"Main Directory Listing edit is clicked");
								waitForLoader();
								waitForLoader();
								waitForLoader();
								// pause();

								switchToDefaultcontent();
								switchToFrame("IfProducts");
								switchToFrame("PopupIFrame");
								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

								if (!strFirstName.isEmpty()) {

									clearText(txtMainDirectoryFirstName, "");
									setText(txtMainDirectoryFirstName, "", strFirstName);
									waitForLoader();
									waitForLoader();
									waitForLoader();
									switchToDefaultcontent();
									switchToFrame("IfProducts");
									switchToFrame("PopupIFrame");
									driver.switchTo().frame(driver.findElement(
											By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

									clearText(txtMainDirectoryLastName, "");
									setText(txtMainDirectoryLastName, "", strLastName);
								}
								waitForLoader();
								switchToDefaultcontent();
								switchToFrame("IfProducts");
								switchToFrame("PopupIFrame");
								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

								clickUsingJavaScript(btnMainDirectoryApplyListing, objectValue);
								waitForLoader();
								waitForLoader();
								waitForLoader();
								waitForLoader();

								switchToDefaultcontent();
								switchToFrame("IfProducts");
								switchToFrame("PopupIFrame");
								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
								clickUsingJavaScript(btnMainDirectoryApplyListingok, objectValue);
								waitForLoader();
								waitForLoader();
								waitForLoader();
								waitForLoader();
								pause();

							}

						}
					}

					if (addlineCount == 0) {
						/*******************************
						 * Due to new WR Maintenance plan will not be displayed
						 * in LEC
						 **********************/
						/*
						 * try { if (isDisplayed(LinkLECMaintenanceDetails,
						 * objectValue)) {
						 * clickUsingJavaScript(LinkLECMaintenanceDetails,
						 * objectValue); waitForLoader(); waitForLoader();
						 * waitForLoader(); waitForLoader(); }
						 * 
						 * driver.switchTo().frame(driver.findElement(By.xpath(
						 * "//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]"
						 * ))); // switchToFrame(jackVoiceFrame);
						 * 
						 * System.out.println("Switched to frame");
						 * 
						 * if(isDisplayed(ChkbxLECNoMaintainance, "",5)){
						 * //pageScroll(ChkbxLECNoMaintainance, objectValue,
						 * true); clickUsingJavaScript(ChkbxLECNoMaintainance,
						 * objectValue); report.reportPass(
						 * "Click on No Mainatinance Plan in LEC",
						 * "No Mainatinance Plan should be clicked",
						 * "No Mainatinance Plan is clicked"); } else{
						 * if(isDisplayed(ChkbxLECMaintainanceplan, "",5)) { //
						 * pageScroll(ChkbxLECMaintainanceplan,
						 * LecMaintenancePlan, true);
						 * //click(ChkbxLECMaintainanceplan,
						 * LecMaintenancePlan); report.reportPass(
						 * "Click on Mainatinance Plan in LEC",
						 * "Mainatinance Plan should be clicked",
						 * "Mainatinance Plan is clicked");
						 * //clickUsingJavaScript(ChkbxLECMaintainanceplan,
						 * objectValue); } else{
						 * click(notChkbxLECMaintainanceplan,
						 * LecMaintenancePlan); report.reportPass(
						 * "Click on Mainatinance Plan in LEC",
						 * "Mainatinance Plan should be clicked",
						 * "Mainatinance Plan is clicked"); } } waitForLoader();
						 * waitForLoader(); waitForLoader(); waitForLoader();
						 * 
						 * 
						 * switchToDefaultcontent();
						 * switchToFrame("IfProducts");
						 * switchToFrame("PopupIFrame");
						 * driver.switchTo().frame(driver.findElement(By.xpath(
						 * "//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]"
						 * )));
						 * 
						 * if (isDisplayed(linkOkMaintainanceGN, objectValue)) {
						 * // pageScroll(linkOkMaintainanceGN, objectValue,
						 * true); clickUsingJavaScript(linkOkMaintainanceGN,
						 * objectValue); report.reportPass(
						 * "Click on Ok in Mainatinance Plan in LEC",
						 * "Ok in Mainatinance Plan should be clicked",
						 * "Ok in Mainatinance Plan is clicked");
						 * waitForLoader(); } pause();
						 * 
						 * 
						 * } catch (Exception e) { strFailed =
						 * "Failed in LEC Window, Maintainance Plan is not negotiated"
						 * ; logger.error(strFailed, e); report.reportFail(
						 * "Failed in LEC Window",
						 * "Maintainance Plan should be negotiated", strFailed);
						 * report.updateMainReport("comments", strFailed);
						 * report.updateMainReport("ErrorMessage", strFailed);
						 * captureErrorMsg(strFailed); throw new
						 * UserDefinedException(strFailed); }
						 */
						System.out.println("Switched to frame");
						waitForLoader();
						waitForLoader();
						waitForLoader();
						waitForLoader();
						// Voice backup power details

						switchToDefaultcontent();
						switchToFrame("IfProducts");
						switchToFrame("PopupIFrame");
						pause();

						try {
							if (isDisplayed(HyperlinkVoicebackupLEC, objectValue)) {
								// pageScroll(HyperlinkVoicebackupLEC,
								// objectValue, true);
								clickUsingJavaScript(HyperlinkVoicebackupLEC, objectValue);
								report.reportPass("Click on Hyperlink Voicebackup",
										"Hyperlink Voicebackup should be clicked", "Hyperlink Voicebackup is clicked");
								waitForLoader();
								waitForLoader();
								waitForLoader();
								pause();

								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
								// switchToFrame(jackVoiceFrame);
								System.out.println("Switched to frame");

								click(ChkbxLECVoiceBackUpplan, LecVoiceBackupPower);
								pause();
								// clickUsingJavaScript(ChkbxLECVoiceBackUpplan,
								// objectValue);
								// pageScroll(linkOk, objectValue, true);
								clickUsingJavaScript(linkOk, objectValue);
								pause();

								waitForLoader();

							}

						} catch (Exception e) {
							strFailed = "Failed in LEC Window, Voice BackUp Power is not negotiated";
							logger.error(strFailed, e);
							report.reportFail("Failed in LEC Window", "Voice BackUp Power should be negotiated",
									strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}

						// Jack Flow

						try {
							waitForLoader();
							waitForLoader();
							waitForLoader();
							if (isDisplayed(jackVoiceLink, objectValue)) {
								// pageScroll(jackVoiceLink, objectValue, true);
								clickUsingJavaScript(jackVoiceLink, objectValue);
								report.reportPass("Click on Jack Voice Link", "Jack Voice Link should be clicked",
										"Jack Voice Link is clicked");
								waitForLoader();
								waitForLoader();
								waitForLoader();
								// pause();

								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

								// switchToFrame(jackVoiceFrame);
								waitForLoader();
								waitForLoader();
								System.out.println("Switched to frame");

								// update jack
								waitForLoader();
								waitForLoader();
								waitForLoader();
								switchToDefaultcontent();
								switchToFrame("IfProducts");
								switchToFrame("PopupIFrame");
								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
								// pageScroll(ChkbxLECNoJacks);

								if (isDisplayed(ChkbxLECNoJacks, objectValue)) {

									if (!ChangeVoiceJack.isEmpty()) {

										System.out.println("ChangeVoiceJack count:" + valuesForVoiceJack.size());
										for (WebElement el : valuesForVoiceJack) {
											System.out.println("Value for Jack text:" + el.getText());

											for (WebElement el1 : chkBoxesForVoiceJack) {
												if (el.getText().contains(ChangeVoiceJack.trim())) {
													// clickUsingJavaScript(JackWorkPhone,
													// objectValue);
													click(JackWorkPhone, objectValue);
													report.reportPass("Click on Jack in Jack Section",
															"Jack in Jack Section should be clicked",
															" Jack in Jack Section is clicked");

													// ((JavascriptExecutor)
													// driver).executeScript("arguments[0].click();",
													// el1);
													// waitForLoader();
													waitForLoader();
													waitForLoader();

													break;
												}
											}
										}

										switchToDefaultcontent();
										switchToFrame("IfProducts");
										switchToFrame("PopupIFrame");
										driver.switchTo().frame(driver.findElement(
												By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

										click(ADDLinkJack, objectValue);
										waitForLoader();
										waitForLoader();
										waitForLoader();

									} else {
										// no Jacks needed clicked
										waitForLoader();
										waitForLoader();
										switchToDefaultcontent();
										switchToFrame("IfProducts");
										switchToFrame("PopupIFrame");
										driver.switchTo().frame(driver.findElement(
												By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
										pageScroll(ChkbxLECNoJacks, objectValue, true);
										clickUsingJavaScript(ChkbxLECNoJacks, objectValue);
										// report.reportPass("Click on No Jack
										// in Jack Section", "No Jack in Jack
										// Section should be clicked", "No Jack
										// in Jack Section is clicked");
										waitForLoader();
										waitForLoader();

									}

								}
								// Link Ok
								switchToDefaultcontent();
								switchToFrame("IfProducts");
								switchToFrame("PopupIFrame");
								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
								if (isDisplayed(BtnLECJackOk, objectValue)) {
									// Clicking on OK for jacks
									// pageScroll(BtnLECJackOk, objectValue,
									// true);
									clickUsingJavaScript(BtnLECJackOk, objectValue);
									report.reportPass("Click on Ok in Jack Section",
											"Ok in Jack Section should be clicked", "Ok in Jack Section is clicked");
									waitForLoader();
									waitForLoader();
									waitForLoader();
									waitForLoader();
									waitForElementDisplay(lecPageDisplay, Standalone, pageTimeoutInSeconds);
								}
								pause();

							} else {

							}
						} catch (Exception e) {
							strFailed = "Failed in LEC Window, Voice Jack is not negotiated";
							logger.error(strFailed, e);
							report.reportFail("Failed in LEC Window", "Voice Jack should be negotiated", strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}

						// Main Directory Listing should be negotiated
						try {

							waitForLoader();
							waitForLoader();
							waitForLoader();
							// driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

							if (isDisplayed(MainDirectoryListingEdit, objectValue)) {
								// pageScroll(jackVoiceLink, objectValue, true);
								clickUsingJavaScript(MainDirectoryListingEdit, objectValue);
								report.reportPass("Click on Main Directory Listing edit",
										"Main Directory Listing edit should be clicked",
										"Main Directory Listing edit is clicked");
								waitForLoader();
								waitForLoader();
								waitForLoader();
								// pause();

								switchToDefaultcontent();
								switchToFrame("IfProducts");
								switchToFrame("PopupIFrame");
								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

								if (!strFirstName.isEmpty()) {

									clearText(txtMainDirectoryFirstName, "");
									setText(txtMainDirectoryFirstName, "", strFirstName);
									waitForLoader();
									waitForLoader();
									waitForLoader();
									switchToDefaultcontent();
									switchToFrame("IfProducts");
									switchToFrame("PopupIFrame");
									driver.switchTo().frame(driver.findElement(
											By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

									clearText(txtMainDirectoryLastName, "");
									setText(txtMainDirectoryLastName, "", strLastName);
								}
								waitForLoader();
								switchToDefaultcontent();
								switchToFrame("IfProducts");
								switchToFrame("PopupIFrame");
								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

								clickUsingJavaScript(btnMainDirectoryApplyListing, objectValue);
								waitForLoader();
								waitForLoader();
								waitForLoader();
								waitForLoader();

								switchToDefaultcontent();
								switchToFrame("IfProducts");
								switchToFrame("PopupIFrame");
								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
								clickUsingJavaScript(btnMainDirectoryApplyListingok, objectValue);
								waitForLoader();
								waitForLoader();
								waitForLoader();
								waitForLoader();
								pause();

							}

						} catch (Exception e) {
							strFailed = "Failed in LEC Window, . Main Directory Listing is not negotiated";
							logger.error(strFailed, e);
							report.reportFail("Failed in LEC Window", ". Main Directory Listing should be negotiated",
									strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}

						// Intercept
						try {
							waitForLoader();
							waitForLoader();
							waitForLoader();
							if (isDisplayed(linkIntercept, objectValue)) {
								// pageScroll(jackVoiceLink, objectValue, true);
								clickUsingJavaScript(linkIntercept, objectValue);
								report.reportPass("Click on linkIntercept edit", "linkIntercept edit should be clicked",
										"linkIntercept edit is clicked");
								waitForLoader();
								waitForLoader();
								waitForLoader();
								// pause();

								switchToDefaultcontent();
								switchToFrame("IfProducts");
								switchToFrame("PopupIFrame");
								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
								clickUsingJavaScript(linkInterceptSelectAll, objectValue);
								waitForLoader();
								waitForLoader();
								waitForLoader();

								switchToDefaultcontent();
								switchToFrame("IfProducts");
								switchToFrame("PopupIFrame");
								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
								clickUsingJavaScript(linkInterceptok, objectValue);
								waitForLoader();
								waitForLoader();
								waitForLoader();

								pause();

							}

						} catch (Exception e) {
							strFailed = "Failed in LEC Window, . Intercept is not negotiated";
							logger.error(strFailed, e);
							report.reportFail("Failed in LEC Window", ". Intercept should be negotiated", strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}
					}

					switchToDefaultcontent();
					switchToFrame("IfProducts");
					switchToFrame("PopupIFrame");
					if (isDisplayed(MandatoryBatteryBackup) && (addlineCount == 0)) {
						// Voice backup power details
						switchToDefaultcontent();
						switchToFrame("IfProducts");
						switchToFrame("PopupIFrame");

						try {
							if (isDisplayed(HyperlinkVoicebackupLEC, objectValue)) {

								clickUsingJavaScript(HyperlinkVoicebackupLEC, objectValue);
								report.reportPass("Click on Hyperlink Voicebackup",
										"Hyperlink Voicebackup should be clicked", "Hyperlink Voicebackup is clicked");
								waitForLoader();
								waitForLoader();
								waitForLoader();

								driver.switchTo().frame(driver.findElement(
										By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

								System.out.println("Switched to frame");

								click(ChkbxLECVoiceBackUpplan, LecVoiceBackupPower);
								clickUsingJavaScript(linkOk, objectValue);
								waitForLoader();

							}

						} catch (Exception e) {
							strFailed = "Failed in LEC Window, Voice BackUp Power is not negotiated";
							logger.error(strFailed, e);
							report.reportFail("Failed in LEC Window", "Voice BackUp Power should be negotiated",
									strFailed);
							report.updateMainReport("comments", strFailed);
							report.updateMainReport("ErrorMessage", strFailed);
							captureErrorMsg(strFailed);
							throw new UserDefinedException(strFailed);
						}
					}
				}

			} catch (Exception e) {
				if (!isUserDefinedException(e)) {
					report.reportFail(strDescription + getUrl, strExpected, strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					captureErrorMsg("Failed in Lec section.");
				}
				throw e;
			}

			waitForLoader();
			waitForLoader();
			// Clicking on Save and Continue

			switchToDefaultcontent();
			switchToFrame("IfProducts");
			switchToFrame("PopupIFrame");

			if (isDisplayed(E911DisclosureC2G)) {
				clickUsingJavaScript(E911DisclosureC2G, objectValue);
				waitForLoader();
				waitForLoader();

			}

			if (isDisplayed(BtnLECSaveAndCont, objectValue)) {
				// pageScroll(BtnLECSaveAndCont, objectValue, true);
				clickUsingJavaScript(BtnLECSaveAndCont, objectValue);
				report.reportPass("Click on Save And Continue in Lec Window",
						"Save And Continue in Lec Window should be clicked",
						"Save And Continue in Lec Window is clicked");
				waitForLoader();

			}
			waitForLoader();

			if (isDisplayed(Service_Must_Migrate_to_Fiber_OKbtn)) {

				clickUsingJavaScript(BtnLECSaveAndCont, objectValue);
				report.reportPass("Click on ok for 'Voice Service Must Migrate to Fiber for this Order'",
						"'OK' for 'Voice Service Must Migrate to Fiber for this Order' should be clicked",
						"'OK' for 'Voice Service Must Migrate to Fiber for this Order' is clicked");
				waitForLoader();

			}

			waitForLoader();
			waitForLoader();
			if (isDisplayed(lecErrorMessgage, objectValue, 3)) {
				String S = getTextFromElement(lecErrorMessgage, strLastName);
				report.reportFail("Lec Negotaition should be successfull" + getUrl,
						"Lec Negotaition should be successfull",
						"Failed in Lec Negotaition an error message is displayed after clicking Save & Continue:" + S);
				report.updateMainReport("ErrorMessage",
						"Failed in Lec Negotaition " + S + " is displayed after clicking Save & Continue");
				report.updateMainReport("comments",
						"Failed in Lec Negotaition " + S + " is displayed after clicking Save & Continue");
				captureErrorMsg(
						"Failed in Lec Negotaition an error message is displayed after clicking Save & Continue");
				logger.error("Failed in Lec Negotaition an error message is displayed after clicking Save & Continue");
				captureErrorMsg(
						"Failed in Lec Negotaition an error message is displayed after clicking Save & Continue");
				throw new UserDefinedException(
						"Failed in Lec Negotaition an error message is displayed after clicking Save & Continue");
			}
			waitForLoader();
			waitForLoader();
			waitForLoader();
			Thread.sleep(10000);

		} catch (Exception e) {
			if (!isUserDefinedException(e)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in Lec section.");
			}
			throw e;
		}
	}

	public void internetUpgradeDowngrade() throws Exception, UserDefinedException {

		try {
			String strFailed = "";
			String internetPlan = get("InternetPlan");
			// To Upgrade or Downgrade Internet

			if (internetPlan.equalsIgnoreCase("Upgrade")) {

				if (isDisplayed(internetUpgrade, objectValue, 2)) {
					clickUsingJavaScript(internetUpgrade, objectValue);
					report.reportPass("Upgrade InternetPlan ", internetPlan + "if available",
							"internetPlan  is Upgraded");
				} else if (isDisplayed(internetUpgrade2, objectValue, 2)) {

					clickUsingJavaScript(internetUpgrade2, objectValue);
					report.reportPass("Upgrade InternetPlan ", internetPlan + "if available",
							"InternetPlan is Upgraded");
				} else {
					strFailed = "InternetPlan is not Upgradable since already in Highest plan";
					report.reportFail("Upgrade Internet plan", "Internet  plan should be Upgraded.", strFailed);
					report.updateMainReport("comments", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					logger.error(strFailed);
					captureErrorMsg(strFailed);
					throw new UserDefinedException(strFailed);
				}

			} else if (internetPlan.equalsIgnoreCase("Downgrade")) {

				if (isDisplayed(internetDowngrade, internetPlan, 2)) {
					clickUsingJavaScript(internetDowngrade, objectValue);
					report.reportPass("Downgrade InternetPlan ", internetPlan + "if available",
							"internetPlan  is Downgraded");

				} else if (isDisplayed(internetDowngrade2, objectValue, 2)) {

					clickUsingJavaScript(internetDowngrade2, objectValue);
					report.reportPass("Downgrade InternetPlan ", internetPlan + "if available",
							"InternetPlan is Downgraded");
				} else {

					if (get("Application").equalsIgnoreCase("C2G")) {
						report.reportPass("Downgrade Should not be allowed in C2G",
								"Downgrade of Internet plan is not allowed",
								"Downgrade of TV plan is not allowed in C2G");
					} else {
						strFailed = "InternetPlan is not Downgradable since already in Lowest plan";
						report.reportFail("Downgrade Internet plan", "Internet  plan should be Downgraded.", strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						logger.error(strFailed);
						captureErrorMsg(strFailed);
						throw new UserDefinedException(strFailed);

					}
				}

			}

		} catch (Exception exe) {

			if (!isUserDefinedException(exe)) {
				captureErrorMsg("Failed in InternetUpgradeDowngrade");
			}

			throw new UserDefinedException("Failed in InternetUpgradeDowngrade");
		}
	}

	public void tvUpgradeDowngrade() throws Exception, UserDefinedException {

		try {

			String tvPlan = get("TvPlan");
			// To Upgrade or Downgrade Internet

			if (tvPlan.equalsIgnoreCase("Upgrade")) {

				if (tvUpgrade.isDisplayed()) {
					clickUsingJavaScript(tvUpgrade, objectValue);
					report.reportPass("Upgrade tvPlan ", tvPlan + "if available", "tvPlan  is Upgraded");
				} else {

					report.reportPass("Upgrade tvPlan ", tvPlan + "if available",
							"tvPlan is not Upgraded since already in highest plan");

				}

			} else if (tvPlan.equalsIgnoreCase("Downgrade")) {

				if (isDisplayed(tvDowngrade, tvPlan, 5)) {
					clickUsingJavaScript(tvDowngrade, objectValue);
					report.reportPass("Downgrade InternetPlan ", tvPlan + "if available", "tvPlan  is Downgraded");
				} else {

					if (get("Application").equalsIgnoreCase("C2G")) {
						report.reportPass("Downgrade Should not be allowed in C2G",
								"Downgrade of TV plan is not allowed", "Downgrade of TV plan is not allowed in C2G");
					} else {

						String strFailed = "TV Plan is not Downgradable since already in Lowest plan";
						report.reportFail("Downgrade TV plan", "TV  plan should be Downgraded.", strFailed);
						report.updateMainReport("comments", strFailed);
						report.updateMainReport("ErrorMessage", strFailed);
						logger.error(strFailed);
						captureErrorMsg(strFailed);
						throw new UserDefinedException(strFailed);
					}

				}

			}
		} catch (Exception exe) {
			exe.printStackTrace();

			throw new UserDefinedException("Failed in TvUpgradeDowngrade");
		}
	}

	public void UIValidations_Equipment_And_Accessories() throws Exception {

		if (get("ProductsAndServices_GUI").equalsIgnoreCase("Yes")) {
			String pageName = "OPO Equipment & Accessories";

			String internetPlan = get("InternetPlan");
			String tvPlan = get("TvPlan");
			String voicePlan = get("VoicePlan");
			waitForLoader();
			clickUsingJavaScript(tabEquipmentsAccessoriesRibbon, "");
			waitForLoader();

			try {

				List<WebElement> lst = driver.findElements(By.xpath("//div[@data-equal-height='internet-FNE']"));

				for (int i = 0; i < lst.size(); i++) {
					String list1 = lst.get(i).getText();
					if (!list1.isEmpty()) {
						// String list1
						// =getTextFromElement(PremiumChannels_List.get(i),"");
						report.reportPass("Router Validations", "Router section details", lst.get(i).getText());
						System.out.println(list1);
					}
				}

			} catch (Exception e) {
				report.reportFail("Router Validations", "Router section details not displayed",
						"Router section details not displayed");
				report.updateMainReport("ErrorMessage", "Price of router  not displayed");
				System.out.print(e.getMessage());
			}

			// Router Descriptions
			/*
			 * System.out.println(lnkRouterOptions_Selected.getText());
			 * guiValidateInVisibility(lnkRouterOptions_Selected, pageName,
			 * "Router descriptions", "Router descriptions is displayed",
			 * "Router descriptions is not displayed");
			 * 
			 * // Router Price String selectedrouter =
			 * lnkRouterOptions_Selected.getText(); String routerprice =
			 * selectedrouter.substring(selectedrouter.indexOf("$"),
			 * selectedrouter.length()); System.out.println("Router price " +
			 * routerprice); if (!routerprice.isEmpty()) { report.reportPass(
			 * "Validate GUI of Router Price in" + pageName, "displayed",
			 * "Price of router " + routerprice + "displayed"); } else {
			 * report.reportFail("Validate GUI of Router Price in" + pageName,
			 * "not displayed", "Price of router " + routerprice +
			 * "not displayed"); report.updateMainReport("ErrorMessage",
			 * "Price of router " + routerprice + "not displayed"); }
			 */

			// VMS Checkpoint
			if ((!tvPlan.isEmpty()) && (!tvPlan.equalsIgnoreCase("Deselect"))) {
				try {

					List<WebElement> lst = driver
							.findElements(By.xpath("//*[@ng-if='!equipmentAdditionalInfo.IsStarterPackEligible']"));

					for (int i = 0; i < lst.size(); i++) {
						String list1 = lst.get(i).getText();
						if (!list1.isEmpty()) {
							// String list1
							// =getTextFromElement(PremiumChannels_List.get(i),"");
							report.reportPass("Recording Options Validations", "Recording Option details",
									lst.get(i).getText());
							System.out.println(list1);
						}
					}

				} catch (Exception e) {
					report.reportFail("Recording Options Validations", "Recording Option details not displayed",
							"Recording Option details not displayed");
					report.updateMainReport("ErrorMessage", "VMS Option not displayed");
					System.out.print(e.getMessage());
				}
			}

			waitForLoader();

			try {
				// Internet Equipment when click on Internet Accessories

				if ((!internetPlan.isEmpty()) && internetPlan.equalsIgnoreCase("Deselect")) {
					waitForLoader();
					clickUsingJavaScript(Internet_Accessories_Open, " ");
					switchToDefaultcontent();
					switchToFrame("IfProducts");
					if (isDisplayed(Internet_Equipment)) {
						report.reportPass("Internet_Equipment", "Internet_Equipment page displayed",
								"Internet_Equipment page displayed");
					}

					List<WebElement> lst = driver
							.findElements(By.xpath("//div[@data-modal-select='modal-multi-choice']"));

					for (int i = 0; i < lst.size(); i++) {
						String list1 = lst.get(i).getText();
						// String list1
						// =getTextFromElement(PremiumChannels_List.get(i),"");
						report.reportPass("Internet_Equipment page Validations", "Internet_Equipment page details",
								lst.get(i).getText());
						System.out.println(list1);
					}
				}
				clickUsingJavaScript(Internet_Accessories_Close, "");
				clickUsingJavaScript(Internet_Accessories_Close, "");
				switchToDefaultcontent();
				switchToFrame("IfProducts");
			} catch (Exception e)

			{
				report.reportFail("Internet_Equipment", "Internet_Equipment page not displayed",
						"Internet_Equipment page not displayed");
				report.updateMainReport("ErrorMessage", "Internet_Equipment page not displayed");
			}

			// Router Tile
			try {
				waitForLoader();

				if (isDisplayed(Router_Tile_Details_link)) {
					report.reportPass("Router Tile Details link", "Router Tile Details_link  displayed",
							"Router Tile Details_link displayed");
				}
			} catch (Exception e) {
				report.reportFail("Router Tile Details link", "Router Tile Details_link displayed",
						"Router Tile Details_link not displayed");
				report.updateMainReport("ErrorMessage", "Router Tile Details_link not displayed");
			}

			// TV equipment validation when click on Other TV equipment tile
			try {

				if ((!tvPlan.isEmpty()) && (!tvPlan.equalsIgnoreCase("Deselect"))) {
					waitForLoader();
					if (isDisplayed(OtherTV_Equip)) {
						report.reportPass("Other TV Equip link", "Other TV Equip tile displayed",
								"Other TV Equip tile displayed");
					} else {
						report.reportFail("Other TV Equip link", "Other TV Equip tile displayed",
								"Other TV Equip tile not displayed");
						report.updateMainReport("ErrorMessage", "Other TV Equip tile not displayed");
					}

					clickUsingJavaScript(OtherTV_Equip, " ");
					switchToFrame("IfProducts");

					List<WebElement> lst = driver.findElements(By.xpath(
							".//div[@id='tv-more-equipment-holder']//div[@ng-repeat='product in equipment.Products']"));

					for (int i = 0; i < lst.size(); i++) {
						String list1 = lst.get(i).getText();
						if (!list1.isEmpty()) {
							// String list1
							// =getTextFromElement(PremiumChannels_List.get(i),"");
							report.reportPass("Other TV Equip link Validations", "TV Equipment details",
									lst.get(i).getText());
							System.out.println(list1);
						}
					}

					clickUsingJavaScript(TVEquip_Cancel, "");
					switchToDefaultcontent();
					switchToFrame("IfProducts");
				}
			} catch (Exception e) {
				report.reportFail("OtherTV_Equip Details link", "OtherTV_Equip link not displayed",
						"OtherTV Equip link not displayed");
				report.updateMainReport("OtherTV_Equip Details link", "OtherTV Equip link not displayed");
			}
			// Recording option

			// Battery backup option
			waitForLoader();
			if (!voicePlan.isEmpty()) {

				if (voicePlan.equalsIgnoreCase("FDV")) {

					// Power Reserve Price
					try {

						List<WebElement> lst = driver.findElements(By.xpath("//div[@data-equal-height='Battery']"));

						for (int i = 0; i < lst.size(); i++) {
							String list1 = lst.get(i).getText();
							report.reportPass("Battery backup Options Validations",
									"Battery backup Options Validations", lst.get(i).getText());
							System.out.println(list1);
						}
						/*
						 * if (isDisplayed(lnkBatteryBackupOptions_Selected)) {
						 * report.reportPass("Batter Backup option",
						 * "Battery backup option displayed",
						 * "Actual Message is:" +
						 * lnkBatteryBackupOptions_Selected.getText()); }
						 */

					} catch (Exception e) {
						report.reportFail(" Batter Backup Option", "Battery backup option displayed",
								"Battery backup option  not displayed");
						report.updateMainReport("ErrorMessage", "Battery backup option  not displayed");
					}

					System.out.println(Script_Above_Router.getText());
					waitForLoader();
					// Script above Router
					try {
						if (isDisplayed(Script_Above_Router)) {
							report.reportPass("Script above Router", "Script above Router displayed",
									"Actual Message is:" + Script_Above_Router.getText());
						}
					} catch (Exception e) {
						report.reportFail(" Script above Route", "Script above Router displayed",
								"Script above Router  not displayed");
						report.updateMainReport("ErrorMessage", "Script above Router  not displayed");
					}

					try {
						/*
						 * if (isDisplayed(lnkBatteryBackupOptions_Selected)) {
						 * report.reportPass("Battery Backup Options",
						 * "Battery Backup Options displayed",
						 * "Battery Backup Options displayed"); }
						 */

						List<WebElement> lst = driver
								.findElements(By.xpath("//div[@data-equal-height='BatteryShipment']"));

						for (int i = 0; i < lst.size(); i++) {
							String list1 = lst.get(i).getText();
							if (!list1.isEmpty()) {
								report.reportPass("Battery Backup shipment Options Validations",
										"Battery Backup shipment Options Validations", lst.get(i).getText());
								System.out.println(list1);
							}
						}

					} catch (Exception e) {
						report.reportFail("Battery Backup shipment Options",
								"Battery Backup shipment Options not displayed",
								"Battery Backup shipment Options not displayed");
						report.updateMainReport("ErrorMessage", "Battery Backup Options not displayed");
					}

					// Battery backup script
					waitForLoader();
					try {
						if (isDisplayed(Script_Battery_Backup)) {
							report.reportPass("Script Battery Backup", "Script for Battery Backup is displayed",
									"Script for Battery Backup is displayed");
						}
					} catch (Exception e) {
						report.reportFail("Script Battery Backup", "Script for Battery Backup is displayed",
								"Script for Battery Backup is not displayed");
						report.updateMainReport("ErrorMessage", "Script for Battery Backup is not displayed");
					}

					// Battery Backup Shipping Method description validation
				}
			}

			// Display Header info
			try {
				waitForLoader();
				if (isDisplayed(Eq_ExtraProduct_Display_Header)) {

					report.reportPass("Product Display Header", "Product Display Header is displayed",
							Eq_ExtraProduct_Display_Header.getText().toString());
				}
			} catch (Exception e) {
				report.reportFail("Product Display Header", "Product Display Header is displayed",
						"Product Display Header is not displayed");
				report.updateMainReport("ErrorMessage", "Product Display Header is not displayed");
			}

			// Display Header price
			try {
				waitForLoader();
				if (isDisplayed(Eq_ExtraProduct_Display_Header_Price)) {
					report.reportPass("Product Display Header Price", "Product Display Header Price is displayed",
							Eq_ExtraProduct_Display_Header_Price.getText().toString());
				}
			} catch (Exception e) {
				report.reportFail("Product Display Header Price", "Product Display Header Price is displayed",
						"Product Display Header price is not displayed");
				report.updateMainReport("ErrorMessage", "Product Display Header price is not displayed");
			}

		}
	}

	public void UIValidations_BBE_Validation() throws Exception {

		String internetPlan = get("InternetPlan");
		if (get("ProductsAndServices_GUI").equalsIgnoreCase("Yes")) {

			if (!(internetPlan.isEmpty() && internetPlan.equalsIgnoreCase("Deselect"))) {
				String pageName = "OPO Equipment & Accessories";
				clickUsingJavaScript(tabVAS, objectValue);
				waitForLoader();
				// Offer description check point under Security, support &
				// storage
				waitForLoader();

				try {
					List<WebElement> lst = driver.findElements(By.xpath("//li[@ng-controller='VasipCtrl']"));

					for (int i = 0; i < lst.size(); i++) {
						String list1 = lst.get(i).getText();
						report.reportPass("Security, Support & Storage Validation",
								"Security, Support & Storage Validation", lst.get(i).getText());
						System.out.println(list1);
					}
					/*
					 * if (isDisplayed(VASIP_ISSuite)) { report.reportPass(
					 * "Security, Support & Storage Validation ",
					 * "Security, Support & Storage Validation ",
					 * "BBE Offer description under Security, support & storage displayed"
					 * ); }
					 */
				} catch (Exception e) {
					report.reportFail("Security, Support & Storage Validation",
							"Security, Support & Storage Validation ",
							"BBE Offer description under Security, support & storage not displayed");
					report.updateMainReport("ErrorMessage",
							"BBE Offer description under Security, support & storage not displayed");
				}

				// More BBE products validation on More Security, Support &
				// Storage
				// options tile
				waitForLoader();

				System.out.println(driver.getTitle());
				waitForLoader();
				try {

					if (isDisplayed(MoreVAS, objectValue)) {
						report.reportPass("Security, Support & Storage Validation ",
								"Security, Support & Storage Validation ",
								"More BBE product option displayed when click on More VAS link");
					}
				} catch (Exception e)

				{
					report.reportFail("Security, Support & Storage Validation ",
							"Security, Support & Storage Validation ",
							"More BBE product option not displayed when click on More VAS link");
					report.updateMainReport("ErrorMessage",
							"More BBE product option not displayed when click on More VAS link");
				}

				waitForLoader();

				// Header section under Security, support & storage
				try {
					if (isDisplayed(VAS_Products_Display_Header)) {
						report.reportPass("Security, Support & Storage Validation",
								"Security, Support & Storage Header Validation ",
								VAS_Products_Display_Header.getText().toString());
					}
				} catch (Exception e) {
					report.reportFail("Security, Support & Storage Validation validations",
							"Security, Support & Storage  Header validations",
							"Security, Support & Storage Header products not displayed");
					report.updateMainReport("ErrorMessage",
							"Security, Support & Storage Header products not displayed");
				}

				// Price under Security, support & storage
				waitForLoader();

				// Header section under Security, support & storage
				try {
					if (isDisplayed(VAS_Products_Display_Header_Price)) {
						report.reportPass("Security, Support & Storage Validation",
								"Security, Support & Storage Header price Validation ",
								VAS_Products_Display_Header_Price.getText().toString());
					}
				} catch (Exception e) {
					report.reportFail("Security, Support & Storage Validation validations",
							"Security, Support & Storage  Header price validations",
							"Security, Support & Storage Header Price not displayed");
					report.updateMainReport("ErrorMessage", "Security, Support & Storage Header Price not displayed");
				}

			}
		}
	}

	public void UIValidations_Voiceoptions() throws Exception {

		if (get("ProductsAndServices_GUI").equalsIgnoreCase("Yes")) {
			String pageName = "OPO Equipment & Accessories";
			clickUsingJavaScript(clkVoiceOptions, objectValue);
			waitForLoader();

			// No.of lines
			report.reportPass("Lines count", " " + "if available", TNLines.size() + "is displayed");
			System.out.println(TNLines.size());
			// International Plans
			waitForLoader();
			try {
				if (isDisplayed(IP_VW300)) {
					report.reportPass("International Plans", "Verizon World Plan 300  displayed",
							"Verizon World Plan 300  displayed");
				}
			} catch (Exception e) {
				report.reportFail("International Plans", "Verizon World Plan 300  displayed",
						"Verizon World Plan 300 not displayed");
				report.updateMainReport("ErrorMessage", "Verizon World Plan 300 not displayed");
			}

			try {
				if (isDisplayed(IP_VW500)) {
					report.reportPass("International Plans", "Verizon World Plan 500  displayed",
							"Verizon World Plan 500  displayed");
				}
			} catch (Exception e) {
				report.reportFail("International Plans", "Verizon World Plan 500  displayed",
						"Verizon World Plan 500 not displayed");
				report.updateMainReport("ErrorMessage", "Verizon World Plan 500 not displayed");
			}

			try {
				if (isDisplayed(IP_IntCallingPlan)) {
					report.reportPass("International Plans", "International Calling Plan displayed",
							"International Calling Plan displayed");
				}
			} catch (Exception e) {
				report.reportFail("International Plans", "International Calling Plan displayed",
						"International Calling Plan not displayed");
				report.updateMainReport("ErrorMessage", "International Calling Plan not displayed");
			}

			waitForLoader();
			// Inside Wire Maintenance Plan
			try {
				if (isDisplayed(IWMP)) {
					report.reportPass("Inside Wire Maintenance Plan", "Inside Wire Maintenance Plan displayed",
							"Inside Wire Maintenance Plan displayed");
				}
			} catch (Exception e) {
				report.reportFail("Inside Wire Maintenance Plan", "Inside Wire Maintenance Plan displayed",
						"Inside Wire Maintenance Plan not displayed");
				report.updateMainReport("ErrorMessage", "Inside Wire Maintenance Plan not displayed");
			}

			// More Options link
			waitForLoader();
			try {
				if (isDisplayed(Phone_More_Options_link)) {
					report.reportPass("More Options link", "Phone More Options link displayed",
							"Phone More Options link displayed");
				}
			} catch (Exception e) {
				report.reportFail("More Options link", "Phone More Options link displayed",
						"Phone More Options link not displayed");
				report.updateMainReport("ErrorMessage", "Phone More Options link not displayed");
			}

			clickUsingJavaScript(MoreOptions, objectValue);
			switchToFrame("IfProducts");

			// Voice mail
			try {
				if (isDisplayed(Voicemail_option)) {
					report.reportPass("Voice Mail Options link", "Voice Mail Options_link displayed",
							"Voice Mail Options_link  displayed");
				}
			} catch (Exception e) {
				report.reportFail("Voice Mail Options link", "Voice Mail Options_link displayed",
						"Voice Mail Options_link not displayed");
				report.updateMainReport("ErrorMessage", "Voice Mail Options_link not displayed");
			}

			// Virtual Lines
			try {
				if (isDisplayed(Virtual_Lines)) {
					report.reportPass("Virtual Lines Options link", "Virtual Lines Options link displayed",
							"Virtual Lines Options link displayed");
				}
			} catch (Exception e)

			{
				report.reportFail("Virtual Lines Options link", "Virtual Lines Options link displayed",
						"Virtual Lines Options link not displayed");
				report.updateMainReport("ErrorMessage", "Virtual Lines Options link not displayed");
			}

			// TN Assignment
			try {
				if (isDisplayed(TNNumberAssign)) {
					report.reportPass("TN Assignment link", "TN Assignment link displayed",
							"TN Assignment link not displayed");
				}
			} catch (Exception e) {
				report.reportFail("TN Assignment link", "TN Assignment link displayed",
						"TN Assignment link not displayed");
				report.updateMainReport("ErrorMessage", "TN Assignment link not displayed");
			}

			// Directory Listing option
			try {
				if (isDisplayed(Phone_Directory_Listing)) {
					report.reportPass("Phone Directory Listing", "Phone Directory Listing link displayed",
							"Phone Directory Listing link not displayed");
				}
			} catch (Exception e)

			{
				report.reportFail("Phone Directory Listing", "Phone Directory Listing link displayed",
						"Phone Directory Listing link not displayed");
				report.updateMainReport("ErrorMessage", "Phone Directory Listing link not displayed");
			}

			// FDV Bring Your Own Number
			try {
				if (isDisplayed(BYON)) {
					report.reportPass("FDV Bring Your Own Number", "FDV Bring Your Own Numbern link displayed",
							"FDV Bring Your Own Number not displayed");
				}
			} catch (Exception e) {
				report.reportFail("FDV Bring Your Own Number", "FDV Bring Your Own Numbern link displayed",
						"FDV Bring Your Own Number not displayed");
				report.updateMainReport("ErrorMessage", "FDV Bring Your Own Number not displayed");
			}

			// clickUsingJavaScript(MoreOptions, objectValue);
			clickUsingJavaScript(Phone_Options_Close, objectValue);
			switchToDefaultcontent();
			switchToFrame("IfProducts");
			try {
				// Display Header
				if (isDisplayed(Voice_Options_Display_Header)) {
					report.reportPass("Voice Options Display Header", "Voice Options Display Header displayed",
							"Voice Options Display Header displayed");
				}
			} catch (Exception e) {
				report.reportFail("Voice Options Display Header", "Voice Options Display Header displayed",
						"Voice Options Display Header not displayed");
				report.updateMainReport("ErrorMessage", "Voice Options Display Header not displayed");
			}

			// Display Price
			try {
				if (isDisplayed(Voice_Options_Display_Header_Price)) {
					report.reportPass("Voice Options Display Header Price",
							"Voice Options Display Header Price displayed",
							"Voice Options Display Header Price displayed");
				}
			} catch (Exception e) {
				report.reportFail("Voice Options Display Header Price", "Voice Options Display Header Price displayed",
						"Voice Options Display Header Price not displayed");
				report.updateMainReport("ErrorMessage", "Voice Options Display Header Price not displayed");
			}

		}
	}

	/**
	 * @Description: Premium Channels GUI Validations
	 * @param: Premium
	 *             channels Section
	 * @author: Shilpa, Ravula
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */

	public void UIValidations_PremiumChannels() throws Exception {

		String tvPlan = get("TvPlan").trim();

		String FiosTV = "";
		if (isDisplayed(simplex_SelectedTV, "", 1)) {
			FiosTV = simplex_SelectedTV.getText();

		}

		if (get("ProductsAndServices_GUI").equalsIgnoreCase("Yes")
				&& ((!tvPlan.isEmpty() && (!tvPlan.equalsIgnoreCase("Deselect"))) || (!FiosTV.isEmpty()))) {
			try {

				String pageName = "OPO-Premium Channels Tab";
				// Premium Channel Header capture
				if (isDisplayed(PremiumChannelsTile, "", 0)) {
					String header = PremiumChannelsTile.getText();
					report.reportPass("Premium Channel Tile Validation",
							"Get the Text from Premium CHannel tile header",
							"Premium Channels tile Hearder is : " + header);
				} else {
					report.reportFail("Premium Channel Tile Validation",
							"Get the Text from Premium CHannel tile header",
							"Premium Channels tile Hearder Not Displayed ");
					report.updateMainReport("ErrorMessage", "Premium Channels tile Hearder Not Displayed ");
				}

				// Expand Premium Channel Section
				clickUsingJavaScript(PremiumChannelsTileExpand, objectValue);
				report.reportPass("Premium Channel Tile Validation", "Premium CHannel tile Expansion",
						"Premium Channels tile Expanded");
				waitForLoader();

				// get all the Premium Channels List
				List<WebElement> lst = driver.findElements(By.xpath(
						"//div[@data-equal-height='premium-channel']//p[contains(@class,'blocks_equipment-title')]"));

				String allChannels = "";
				for (int i = 0; i < lst.size(); i++) {
					String list = lst.get(i).getText();
					// String list
					// =getTextFromElement(PremiumChannels_List.get(i),"");

					if (!list.isEmpty()) {
						allChannels = allChannels + ";" + list;
					}
				}
				report.reportPass("Get all the premium Channel Details", "List all Premium channels",
						"Premium Channels are   :" + allChannels);

				List<WebElement> lst1 = driver.findElements(By
						.xpath("//div[@ng-click='ShopItem(channel, channelList)']/p/span[contains(@class,'sprite')]"));

				String allChannels1 = "";

				for (int j = 0; j < lst1.size(); j++) {
					allChannels1 = allChannels1 + ";" + lst1.get(j).getAttribute("class").substring(7);
					// allChannels1=getAttribute(PremiumChannels_List2.get(j),
					// objectValue, "class").substring(7);

				}
				report.reportPass("Get all the premium Channel Details", "List all Premium channels",
						"Premium Channels are   :" + allChannels1);

				// Validating More Premium Channels Section
				clickUsingJavaScript(More_Permium_channel, objectValue);
				waitForLoader();

				// Getting Speciality Tab Channel List
				clickUsingJavaScript(specialty_tab, objectValue);
				waitForLoader();
				guiValidateVisibility(specialty_tab, pageName, "More Premium Channels", "specialty_tab is Active",
						"specialty_tab is Not Active");

				List<WebElement> lstSpeciality = driver.findElements(By.xpath(
						"//div[contains(@ng-click,'special')]//div[@data-equal-height='more-premium-channel']//p[contains(@class,'blocks_equipment-title')]"));

				String allSpeciality = "";
				for (int i = 0; i < lstSpeciality.size(); i++) {
					allSpeciality = allSpeciality + ";" + lstSpeciality.get(i).getText();
					// allSpeciality=getTextFromElement(specialtyChannels.get(i),
					// "");

				}
				report.reportPass("Get all the premium Channel Details", "List all Premium channels",
						"Premium Channels are   :" + allSpeciality);

				// Getting Movies Tab Channel List
				clickUsingJavaScript(movies_tab, objectValue);
				waitForLoader();
				guiValidateVisibility(movies_tab, pageName, "More Premium Channels", "movies_tab is Active",
						"movies_tab is Not Active");
				// Getting International Tab Channel List

				clickUsingJavaScript(international_tab, objectValue);
				waitForLoader();
				guiValidateVisibility(international_tab, pageName, "More Premium Channels",
						"international_tab is Active", "international_tab is Not Active");

				List<WebElement> lstInternational = driver.findElements(By.xpath(
						"//div[contains(@ng-click,'internationalChannel')]//div[@data-equal-height='more-premium-channel']//p[contains(@class,'blocks_equipment-title')]"));
				String allInternational = "";
				for (int i = 0; i < lstInternational.size(); i++) {
					allInternational = allInternational + ";" + lstInternational.get(i).getText();
					// allInternational=getTextFromElement(internationalChannels.get(i),
					// "");

				}
				report.reportPass("Get all the premium Channel Details", "List all Premium channels",
						"Premium Channels are   :" + allInternational);

				// Getting Sports Tab Channel List
				clickUsingJavaScript(sports_tab, objectValue);
				waitForLoader();
				guiValidateVisibility(sports_tab, pageName, "More Premium Channels", "international_tab is Active",
						"international_tab is Not Active");

				List<WebElement> lstSports = driver.findElements(By.xpath(
						"//div[contains(@ng-click,'sportsChannel')]//div[@data-equal-height='more-premium-channel']//p[contains(@class,'blocks_equipment-title')]"));

				String allSports = "";
				for (int i = 0; i < lstSports.size(); i++) {
					allSports = allSports + ";" + lstSports.get(i).getText();
					// allSports=getTextFromElement(sportsChannels.get(i), "");

				}
				report.reportPass("Get all the premium Channel Details", "List all Premium channels",
						"Premium Channels are   :" + allSports);

				clickUsingJavaScript(btncancel, objectValue);
				waitForLoader();

				switchToDefaultcontent();
				switchToFrame("IfProducts");

				clickUsingJavaScript(PremiumChannelsTileExpand, objectValue);
				waitForLoader();
			} catch (Exception exe) {
				exe.printStackTrace();
				throw exe;
			}

		}
	}

	/**
	 * @Description: SetupInstall Section Validation
	 * @param: SetupInstall
	 * @author: Shilpa, Ravula
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments:
	 */

	public void UIValidations_SetupInstall() throws Exception {

		if (get("ProductsAndServices_GUI").equalsIgnoreCase("Yes")) {
			try {
				String pageName = "SetupInstall Section";
				// Setup_section Header capture
				if (isDisplayed(Setup_section, "", 0)) {
					String header = Setup_section.getText();
					report.reportPass("Setup_section Tile Validation", "Get the Text from Setup_section tile header",
							"Setup_section tile Hearder is : " + header);
				} else {
					report.reportFail("Setup_section Tile Validation", "Get the Text from Setup_section tile header",
							"Setup_section tile Hearder Not Displayed ");
					report.updateMainReport("ErrorMessage", "Setup_section tile Hearder Not Displayed ");
				}

				clickUsingJavaScript(Setup_section, objectValue);
				// Get Products Information From Setup Section
				List<WebElement> list = driver.findElements(By.xpath("//div[contains(@data-equal-height,'setup')]"));
				String Setuplist = " ";

				for (int i = 0; i < list.size(); i++) {
					Setuplist = Setuplist + ";" + list.get(i).getText();

				}
				report.reportPass("Setup_section Products Validation", "Get the Products from Setup_section",
						"Setup_section Products are : " + Setuplist);
				clickUsingJavaScript(Setup_section, objectValue);
			} catch (Exception exe) {
				exe.printStackTrace();
				throw exe;
			}
		}
	}

	/**
	 * @author v878795
	 * @Description:UIValidation_Checkout_Page
	 * @return: No return type
	 * @exception Throws
	 *                Exception
	 * @ModifiedDate:
	 * @ModifiedBY:
	 * @Comments:
	 */

	public void UIValidation_Checkout_Page() throws Exception {

		if (get("ProductsAndServices_GUI").equalsIgnoreCase("Yes")) {

			String strDescription = "", strExpected = "", strActual = "", strFailed = "";
			String getUrl = "";
			String pageName = "Checkout_Page";

			// double Monthly_chrgs_opo = 99999.99999;
			// double Monthly_chrgs_checkout = 99999.99999;

			try {

				// Product details in checkout page

				waitForLoader();

				strDescription = "Validate wether Product details is present in checkout page";
				strExpected = "Product details should be present in checkout page";
				strActual = "Product details is present in checkout page";
				strFailed = "Product details is not present in checkout page";
				getUrl = ", URL Launched --> " + returnURL();

				if (isDisplayed(Product_details_checkout, "")) {
					report.reportPass(strDescription + Product_details_checkout.getText(), strExpected, strActual);
				} else {
					report.reportFail(strDescription, strExpected, strFailed);
					report.updateMainReport("ErrorMessage", strFailed);

				}

				// get each product details

				for (int i = 0; i < bndl_components.size(); i++) {

					try {
						// WebElement bndl_cmpnts = bndl_components.get(i);

						report.reportPass(strDescription + bndl_components.get(i).getText(), strExpected, strActual);

						waitForPageToLoad(driver);

					} catch (Exception e) {
						System.out.print(e.getMessage());
					}
				}

				waitForLoader();

				// EstimatedMonthlyProducts

				for (int i = 0; i < bndl_EstimatedMonthlyProducts.size(); i++) {

					try {
						// WebElement bndl_cmpnts = bndl_components.get(i);

						report.reportPass(strDescription + bndl_EstimatedMonthlyProducts.get(i).getText(), strExpected,
								strActual);

						waitForPageToLoad(driver);

					} catch (Exception e) {
						System.out.print(e.getMessage());
					}
				}

				// Make changes Button Validation

				strDescription = "Validate that Make changes buttion is there or not in checkout page";
				strExpected = "Make changes buttion Should be Enabled in checkout page";
				strActual = "Make changes buttion is Enabled in checkout page";
				strFailed = "Make changes buttion is not Enabled in checkout page";
				getUrl = ", URL Launched --> " + returnURL();

				if (isDisplayed(mk_chngs_btn)) {
					report.reportPass(strDescription, strExpected, strActual);
				} else {
					report.reportFail(strDescription, strExpected, strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
				}

				// checkout Button Validation

				strDescription = "Validate that checkout buttion is there or not in checkout page";
				strExpected = "checkout buttion Should be Enabled in checkout page";
				strActual = "checkout buttion is Enabled in checkout page";
				strFailed = "checkout buttion is not Enabled in checkout page";
				getUrl = ", URL Launched --> " + returnURL();

				if (isDisplayed(checkout_btn)) {
					report.reportPass(strDescription, strExpected, strActual);
				} else {
					report.reportFail(strDescription, strExpected, strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
				}

				// Email Address field validation

				strDescription = "Validate that Mailid field is there or not in checkout page";
				strExpected = "Mailid field Should be Enabled in checkout page";
				strActual = "Mailid field is Enabled in checkout page";
				strFailed = "Mailid field is not Enabled in checkout page";
				getUrl = ", URL Launched --> " + returnURL();

				if (isDisplayed(mailid_checkout)) {
					pageScroll(mailid_checkout, objectValue, true);
					report.reportPass(strDescription + mailid_checkout.getText(), strExpected, strActual);
				} else {
					report.reportFail(strDescription, strExpected, strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
				}

				clearText(mailid_checkout, "");

				String email = get("Email_ID");

				setText(mailid_checkout, objectValue, email);

				// clicking on send quote

				waitForLoader();

				clickUsingJavaScript(sendquote, objectValue);
				if (isDisplayed(SendQuoteresponse, email, 2)) {
					report.reportFail("Mail Should be Sent Succesfully", "Mail Should be Sent Succesfully",
							"Getting Error in sending mail, hence Send Quote is not working");
					report.updateMainReport("ErrorMessage",
							"Getting Error in sending mail, hence Send Quote is not working");
				} else {
					report.reportPass("Mail Should be Sent Succesfully upon clicking Send Quote",
							"Mail Should be Sent Succesfully upon clicking Send Quote", "Mail is sent successfully!!");
				}
				// Price compare between OPO and Checkout page

				waitForLoader();
				clickUsingJavaScript(close_btn_checkout, objectValue);
				waitForLoader();
				waitForLoader();
				Thread.sleep(1000);
				switchToDefaultcontent();
				switchToFrame("IfProducts");

				if (isDisplayed(mtly_chrgs_OPO2, email, 2)) {
					String Monthly_chrgs_opo = getTextFromElement(mtly_chrgs_OPO2, objectValue);
					System.out.println(Monthly_chrgs_opo);
					if (!Monthly_chrgs_opo.isEmpty()) {
						put("Monthly Estimated Charge in OPO", Monthly_chrgs_opo);
					}
					clickUsingJavaScript(Review_btn, objectValue);
					waitForLoader();
					waitForPageToLoad(driver);

					String Monthly_chrgs_checkout = getTextFromElement(mtly_chrgs_Checkout, objectValue);
					System.out.println(Monthly_chrgs_checkout);
					// Double.parseDouble((mtly_chrgs_Checkout).getText().replace("$",
					// "").trim());

					strDescription = "Validate that Estimated Monthly Charges of checkout should match with Footer price on OPO ";
					strExpected = "Estimated Monthly Charges of checkout should match with Footer price on OPO";
					strActual = "Estimated Monthly Charges of checkout matched with Footer price on OPO";
					strFailed = "Estimated Monthly Charges of checkout not matched with Footer price on OPO";
					getUrl = ", URL Launched --> " + returnURL();

					if (Monthly_chrgs_opo.equals(Monthly_chrgs_checkout)) {
						report.reportPass(strDescription + Monthly_chrgs_opo, strExpected,
								"Estimated Monthly Charges of checkout: " + Monthly_chrgs_checkout
										+ " is Same as Estimated Monthly Charges in Footer price on OPO: "
										+ Monthly_chrgs_opo);
					} else {
						report.reportFail(strDescription, strExpected,
								"Estimated Monthly Charges of checkout: " + Monthly_chrgs_checkout
										+ " is not Same as Estimated Monthly Charges in Footer price on OPO: "
										+ Monthly_chrgs_opo);
						report.updateMainReport("ErrorMessage",
								"Estimated Monthly Charges of checkout: " + Monthly_chrgs_checkout
										+ " is not Same as Estimated Monthly Charges in Footer price on OPO: "
										+ Monthly_chrgs_opo);
					}
				} else if (isDisplayed(mtly_chrgs_OPO, email, 2)) {
					String Monthly_chrgs_opo = getTextFromElement(mtly_chrgs_OPO, objectValue);
					System.out.println(Monthly_chrgs_opo);
					if (!Monthly_chrgs_opo.isEmpty()) {
						put("Monthly Estimated Charge in OPO", Monthly_chrgs_opo);
					}
					clickUsingJavaScript(Review_btn, objectValue);
					waitForLoader();
					waitForPageToLoad(driver);

					String Monthly_chrgs_checkout = getTextFromElement(mtly_chrgs_Checkout, objectValue);
					System.out.println(Monthly_chrgs_checkout);
					// Double.parseDouble((mtly_chrgs_Checkout).getText().replace("$",
					// "").trim());

					strDescription = "Validate that Estimated Monthly Charges of checkout should match with Footer price on OPO ";
					strExpected = "Estimated Monthly Charges of checkout should match with Footer price on OPO";
					strActual = "Estimated Monthly Charges of checkout matched with Footer price on OPO";
					strFailed = "Estimated Monthly Charges of checkout not matched with Footer price on OPO";
					getUrl = ", URL Launched --> " + returnURL();

					if (Monthly_chrgs_opo.equals(Monthly_chrgs_checkout)) {
						report.reportPass(strDescription + Monthly_chrgs_opo, strExpected, strActual);
					} else {
						report.reportFail(strDescription + Monthly_chrgs_opo, strExpected,
								strFailed + Monthly_chrgs_checkout);
						report.updateMainReport("ErrorMessage", strFailed + Monthly_chrgs_checkout);
					}
				}
				// Double.p((mtly_chrgs_OPO).getText());
				// .replace("$", "").trim());

			} catch (Exception exe) {
				exe.printStackTrace();
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				throw exe;
			}
		}
	}

	public void GUIValidation_OPO() throws Exception {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		// GUI Validations for Hero Tiles Displayed or Not

		/*
		 * try { if (!getAttribute(tabRecommendation, objectValue,
		 * "class").contains("open")) { pageScroll(tabRecommendation,
		 * objectValue, true); clickUsingJavaScript(tabRecommendation,
		 * objectValue); report.reportPass("Recommedations Section",
		 * "Recommedations Section Displayed",
		 * "Recommedation Section icon Displayed"); } else { report.reportFail(
		 * "Recommedations Section", "Recommedations Section not Displayed",
		 * "Recommedation Section icon not Displayed"); } // clicking on more
		 * recommendations section
		 * 
		 * if (isDisplayed(moreRecommendation, "")) {
		 * clickUsingJavaScript(moreRecommendation, objectValue);
		 * report.reportPass("Recommedations Section Expansion",
		 * "Able to expand Recommedation",
		 * "Able to expand Recommedations Section"); } } catch (Exception e) {
		 * report.reportFail("Recommedations Section Expansion",
		 * "Unable to expand Recommedation",
		 * "Unable to expand Recommedations Section"); System.out.print(
		 * "there is no recommendaytions icon"); } waitForLoader();
		 * System.out.println(platinumOffers.size()); try { for (int i = 0; i <
		 * platinumOffers.size(); i++) { // try { String sValue =
		 * platinumOffers.get(i).getText(); System.out.println(sValue);
		 * report.reportPass("Platinum offers", "Platinum offer displayed",
		 * platinumOffers.get(i).getText());
		 * 
		 * waitForPageToLoad(driver);
		 * 
		 * } } catch (Exception e) { report.reportFail("Platinum offers",
		 * "Platinum offer not displayed", "Platinum offer not displayed");
		 * System.out.print(e.getMessage()); }
		 */
		waitForLoader();
		waitForLoader();
		waitForLoader();

		// Internet Tab Validations
		try {
			clickUsingJavaScript(expandInternet, objectValue);
			List<WebElement> lst = driver.findElements(By.xpath("//div[contains(@data-equal-height,'Internet')]"));

			String allChannels = "";
			for (int i = 0; i < lst.size(); i++) {
				String list1 = lst.get(i).getText();
				// String list1
				// =getTextFromElement(PremiumChannels_List.get(i),"");
				report.reportPass("Internet Tab Validations", "Internet Tab details", lst.get(i).getText());
				System.out.println(list1);
			}

		} catch (Exception e) {
			report.reportFail("Internet Tab Validations", "Unable to do Internet Tab Validations",
					"Unable to do Internet Tab Validations");
			System.out.print(e.getMessage());
		}

		// TV Tab Validation

		try {
			clickUsingJavaScript(expandTv, objectValue);
			List<WebElement> lst1 = driver.findElements(By.xpath("//li[@ng-controller='VideoCtrl']"));

			String list2 = lst1.get(0).getText();
			System.out.println(lst1.size());
			/*
			 * for (int i = 0; i < lst1.size(); i++) { String list1 =
			 * lst1.get(i).getText(); // String list1
			 * =getTextFromElement(PremiumChannels_List.get(i),"");
			 * System.out.println(list1);
			 * 
			 * }
			 */

			String[] Off = list2.split("details");
			List<String> itemList = new ArrayList<String>(Arrays.asList(Off));

			for (int i = 0; i < itemList.size(); i++) {
				String list1 = itemList.get(i).toString().trim();
				// String list1
				// =getTextFromElement(PremiumChannels_List.get(i),"");
				report.reportPass("FTV Tab Validations", "FTV Tab product details", itemList.get(i).toString().trim());
				System.out.println(list1);

			}

		} catch (Exception e) {
			report.reportFail("FTV Tab Validations", "Unable to do FTV Tab Validations",
					"Unable to do FTV Tab Validations");
			System.out.print(e.getMessage());
		}

		try {
			// clickUsingJavaScript(expandVoice, objectValue);
			if (!getAttribute(expandVoice, objectValue, "class").contains("open")) {
				pageScroll(expandVoice, objectValue, true);
				clickUsingJavaScript(expandVoice, objectValue);
				waitForLoader();
			}
			// List<WebElement> lst2 =
			// driver.findElements(By.xpath("//li[@ng-controller='VoiceCtrl as
			// voiceController']"));
			List<WebElement> lst2 = driver.findElements(By.xpath("//div[@ng-if ='$parent.SectionVisible.Voice']"));
			System.out.println(lst2.size());
			for (int i = 0; i < lst2.size(); i++) {
				String list1 = lst2.get(i).getText();
				// String list1
				// =getTextFromElement(PremiumChannels_List.get(i),"");
				report.reportPass("Voice Tab Validations", "Voice Tab details", lst2.get(i).getText());
				System.out.println(list1);

			}
		} catch (Exception e) {
			report.reportFail("Voice Tab Validations", "Unable to do Voice Tab Validations",
					"Unable to do Voice Tab Validations");
			System.out.print(e.getMessage());
		}

		try {
			// li[@ng-controller='VoiceCtrl as voiceController']
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			waitForLoader();
			if (!getAttribute(expandContract, objectValue, "class").contains("open")) {
				pageScroll(expandContract, objectValue, true);
				clickUsingJavaScript(expandContract, objectValue);
				waitForLoader();
			}
			// clickUsingJavaScript(expandContract, objectValue);
			report.reportPass("Agreement tab Validations", "Agreement tab Expanded", "Able to do expand Agreement tab");
			waitForLoader();

			if (NoagreementOfferList.size() > 0) {

				clickUsingJavaScript(NoagreementOffer, objectValue);
				report.reportPass("Agreement tab Validations", "M2M Agreement tab Expanded",
						"Able to do expand M2M Agreement tab");
			}
		} catch (Exception e) {
			report.reportFail("Agreement tab Validations", "Unable to do Agreement tab Validations",
					"Unable to do Agreement tab Validations");
			System.out.print(e.getMessage());
		}

		waitForLoader();
		List<WebElement> OfferTileSelection = null;
		if (get("FlowType").equalsIgnoreCase("Install")) {
			// OfferTileSelection
			// =driver.findElement(By.xpath("//div[@ng-controller='OffersCtrl']")).findElements(By.xpath("//div[@class='tiles_content']//span[@class='tiles_header']"));
			OfferTileSelection = driver.findElement(By.xpath("//div[@ng-controller='OffersCtrl']"))
					.findElements(By.xpath("//div[@name='offerTiles']"));
		} else if (get("FlowType").equalsIgnoreCase("Change")) {

			// OfferTileSelection =
			// driver.findElement(By.xpath("//div[@class='w_tiles
			// padding-left-medium']")).findElements(By.xpath("//div[contains(@id,
			// 'Offer')]"));
			OfferTileSelection = driver.findElement(By.xpath("//div[@class='w_tiles padding-left-medium']"))
					.findElements(By.xpath("//div[@data-equal-height='offer']"));
		}

		try {
			int offersize = OfferTileSelection.size();
			System.out.println("offertilesize" + offersize);

			String[] TempTileOffer = new String[offersize];
			for (int i = 0; i < offersize; i++) {
				// String tile_text =
				// driver.findElement(By.xpath("//div[@class='w_tiles
				// margin-left-tiny']//div[" + i + "]/div")).getText();
				System.out.println(OfferTileSelection.get(i).getText());

				String tile_text = OfferTileSelection.get(i).getText();

				if (tile_text.contains("Verizon Wireless Gift Card")) {
					report.reportPass("Verizon gift card offer", "Verizon gift card offer displayed", tile_text);
					System.out.println("VZW gift card offer present");
				}

				if (tile_text.isEmpty()) {
					report.reportPass("Agreement tab Validations", "Agreement tab offer Validations",
							"No offers available for the current selection");
				} else {
					report.reportPass("Agreement tab Validations", "Agreement tab offer Validations", tile_text);
				}

			}

		} catch (Exception e) {
			report.reportFail("Agreement tab Validations", "Unable to do Agreement tab Validations",
					"Unable to do Agreement tab Validations");
			System.out.print(e.getMessage());
		}
	}

	/****************************************************
	 * Method Name: MarketingOffValidation Method Description: Validating
	 * Marketing Offers based on provided PCR sheets Author: Jeevitha S Date:
	 * 02/17/17 Changed For: Added the code for valdiating Duplicates in Tiles
	 * level and inside the Details Link Changed by : Jeevitha S Date:03/10/2017
	 ******************************************************/
	public void MarketingOffValidation() throws Exception, UserDefinedException {

		// Reading the values from Input sheet for MO type, Description Display
		// in OfferTile, Description Display in Details section
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl = "";
		getUrl = ", URL Launched --> " + returnURL();
		String MOType = get("MarketingOfferType");
		String OfferTileDisplay = get("OfferTileDesc");
		String[] off_tile = OfferTileDisplay.split(",");
		String OfferDisplayinDetails = get("OfferDescInDetails");
		String[] Offer = OfferDisplayinDetails.split(",");
		int offerlength = Offer.length;
		String Contract = get("Contract");
		if (Contract.toLowerCase().equalsIgnoreCase("2year"))
			Contract = "2-Year Agreement";
		else if (Contract.toLowerCase().equalsIgnoreCase("m2m"))
			Contract = "No Agreement";

		boolean offerDisplayed = false;

		HashMap<String, ArrayList<String>> missingOffer = new HashMap<String, ArrayList<String>>();
		HashMap<String, ArrayList<String>> presentOffer = new HashMap<String, ArrayList<String>>();

		long timeNow = System.currentTimeMillis();
		waitForLoader();

		// Switch Frame
		switchToDefaultcontent();
		switchToFrame("IfProducts");

		waitForLoader();
		try {

			if (get("Standalone").isEmpty()) {
				if (get("FlowType").equalsIgnoreCase("Install")) {
					// Expanding No Agreement offer for Install Flow
					try {

						if (NoagreementOfferList.size() > 0) {
							clickUsingJavaScript(NoagreementOffer, objectValue);
							waitForLoader();
							report.reportPass("One Page ordering -Verify able to  Click \"View No Agreement Offers\"",
									"Able to Click \"View No Agreement Offers\"",
									"\"View No Agreement Offers\" is getting clicked successfully ");
						} else {
							report.reportPass("One Page ordering -Verify able to  Click \"View No Agreement Offers\"",
									"View Agreement should be expanded",
									"View No Agreement Offers is already expanded");
						}

					} catch (Exception e) {
						report.reportFail("One Page ordering -Verify able to  Click \"View No Agreement Offers\"",
								"Not able to  Click \"View No Agreement Offers\" ", e.getMessage());

					}
				}

				try {

					CList<Element> OfferTileList = null;

					if (get("FlowType").equalsIgnoreCase("Install")) {
						OfferTileList = InstallOfferTileList;

					} else if (get("FlowType").equalsIgnoreCase("Change")) {

						OfferTileList = ChangeOfferTileList;
					}

					// Identifying the DUplicates presents in TIle Offer
					String[] TempTileOffer = new String[OfferTileList.size()];

					// Validate the Duplicates Offer TIle present in Tiles
					for (int i = 0; i < OfferTileList.size(); i++) {
						String tile_text = getTextFromElement(OfferTileList.get(i), objectValue);
						TempTileOffer[i] = tile_text;
						waitForLoader();
					}

					Boolean Dup = ToFindDuplicates(TempTileOffer, OfferTileList.size());

					if (Dup)
						report.reportFail("Offers Display in Tiles", "Offers not be getting repeated in Tiles",
								"Offers are getting repeated in Tiles");

					else {
						report.reportPass("Offers Display in Tiles", "Offers not be getting repeated in Tiles",
								"Offers are not getting repeated in Tiles");
					}

					if (Contract.isEmpty()) {
						for (int i = 0; i < OfferTileList.size(); i++) {
							if (OfferTileList.get(i).getAttribute("data-agreement-selection").equals("active")) {
								System.out.println(
										"contract value" + getTextFromElement(OfferTileList.get(i), objectValue));
								if (getTextFromElement(OfferTileList.get(i), objectValue).contains("2-Year Agreement"))
									Contract = "2-Year Agreement";
								else
									Contract = "No Agreement";

							}
						}
					}

					int tile_cnt = 1;
					for (int i = 0; i < OfferTileList.size(); i++) {
						String OfferTileText = getTextFromElement(OfferTileList.get(i), objectValue);
						if (OfferTileText.contains(Contract)) {
							if (!isSelected(OfferTileList.get(i)))
								clickUsingJavaScript(OfferTileList.get(i), objectValue);
							waitForLoader();
							boolean tile = false;
							if (OfferTileList.get(i).getAttribute("id").equals("Offers_More_Popup")) {
								break;
							}

							// Get offer tile text and verify with the input
							if (!OfferTileDisplay.isEmpty()) {

								for (String tile1 : off_tile) {
									if (OfferTileText.contains(tile1.trim())) {
										tile = true;
									} else {
										tile = false;
										break;
									}
								}
							} else {
								tile = true;
							}
							if (tile && !OfferDisplayinDetails.isEmpty()) {

								ArrayList<String> offer_missed = new ArrayList<String>();
								ArrayList<String> offer_present = new ArrayList<String>();

								// Clicking on Detail link under the Offer Tile
								if (get("FlowType").equalsIgnoreCase("Install")) {
									clickUsingJavaScript(OfferDetailLinkInstall.get(i), objectValue);
								}
								if (get("FlowType").equalsIgnoreCase("Change")) {
									clickUsingJavaScript(OfferDetailLinkChange.get(i), objectValue);
								}
								waitForLoader();
								waitForLoader();

								String offerpopupdetails = getTextFromElement(MOInDetails, objectValue);
								System.out.println("offerpopupdetails" + offerpopupdetails);

								// Finding duplicate Offer description inside
								// the
								// Details section
								String[] Off = offerpopupdetails.split("\n");

								Boolean DupInDetail = ToFindDuplicates(Off, Off.length);

								if (DupInDetail) {
									report.reportFail("Offer Display in Detail Section",
											"No Offers should be getting repeated in Detail Section",
											"Offers are getting repeated in Details Section");

								}

								else {
									report.reportPass("Offer Display in Detail Section",
											"No Offers should be getting repeated in Detail Section",
											"Offers are available without Duplicates in Detail Section");
								}
								// Validation of Offer description in Detail

								int offer_cnt = 0;
								for (int j = 0; j < offerlength; j++) {
									if (offerpopupdetails.contains(Offer[j].trim())) {

										offer_cnt = offer_cnt + 1;
										offer_present.add(Offer[j].trim());
										presentOffer.put(String.valueOf(tile_cnt), offer_present);
										if (offer_cnt == offerlength) {
											offerDisplayed = true;
											break;
										}

									} else {
										offerDisplayed = false;
										offer_missed.add(Offer[j].trim());
									}

								}

								// Closing the Detail window

								if (offerDisplayed) {

									clickUsingJavaScript(DetailsClose, objectValue);

									break;

								}

								else {
									missingOffer.put(String.valueOf(tile_cnt), offer_missed);

									clickUsingJavaScript(DetailsClose, objectValue);
								}

							}

						}
						tile_cnt++;
					}

					// Verifying result whether offer matched for given scenario
					if (offerDisplayed && MOType.equalsIgnoreCase("Positive")) {
						report.reportPass("Offer Display in bundle page",
								"Offers :" + "<br/>" + "<b>" + OfferDisplayinDetails + "<b/>"
										+ " is displayed in Bundle page",
								"Offers :" + "<br/>" + "<b>" + OfferDisplayinDetails + "<b/>"
										+ " Offers are getting sucessfully displayed in Bundle page");
					}

					if (offerDisplayed && MOType.equalsIgnoreCase("Negative")) {
						report.reportFail("Offer Display in bundle page",
								"Offers :" + "<br/>" + OfferDisplayinDetails + " is not displayed in Bundle page",
								"Offers :" + "<br/>" + "<b>" + OfferDisplayinDetails + "<b/>"
										+ " Offers are not displayed in Bundle page");
					}

					if (!offerDisplayed && MOType.equalsIgnoreCase("Positive")) {

						int maxkey = 0, maxval = 0;

						for (Map.Entry tile_no : missingOffer.entrySet()) {

							String arrkey = tile_no.getKey().toString();
							String[] arrval = tile_no.getValue().toString().split(",");

							if (maxkey == 0 && maxval == 0) {
								maxkey = Integer.valueOf(arrkey);
								maxval = arrval.length;
							} else {
								if (maxval > arrval.length) {
									maxkey = Integer.valueOf(arrkey);
									maxval = arrval.length;
								}

							}

						}
						// ((JavascriptExecutor)
						// driver).executeScript("arguments[0].click();",
						// driver.findElement(By.xpath("//div[@class='w_tiles
						// margin-left-tiny']//div[" + maxkey + "]/div")));

						clickUsingJavaScript(OfferTileList.get(maxkey - 1), objectValue);
						report.reportFail("Offer Display in bundle page",
								"Offers :" + "<br/>" + OfferDisplayinDetails + " is displayed in Bundle page",
								"Offers :" + "<br/>" + "<b>" + missingOffer.get(String.valueOf(maxkey)) + "<b/>"
										+ "Offers is not getting displayed in Bundle page");
					}

					if (!offerDisplayed && MOType.equalsIgnoreCase("Negative")) {
						report.reportPass("Offer Display in bundle page",
								"Offers:" + OfferDisplayinDetails + " are not getting displayed in Bundle page",
								"Offers :" + "<br/>" + "<b>" + OfferDisplayinDetails + "<b/>"
										+ "Offers are not available in Bundle Page");
					}

				} catch (Exception e) {

				}

			}

			else {
				if (get("Standalone").toLowerCase().contains("data")) {
					MarketingOffValidation_stdalone("ShowStandaloneDataOffers");

				}
				if (get("Standalone").toLowerCase().contains("tv")) {
					MarketingOffValidation_stdalone("ShowStandaloneVideoOffers");
				}
				if (get("Standalone").toLowerCase().contains("voice")) {
					MarketingOffValidation_stdalone("ShowStandaloneVoiceOffers");
				}

			}

			// timelapsed - console
			System.out.println(System.currentTimeMillis() - timeNow + " Milliseconds");
		} catch (Exception e) {

		}

	}

	/****************************************************
	 * Method Name: MarketingOffValidation Method Description: Validating
	 * Marketing Offers based on provided PCR sheets Author: Jeevitha S Date:
	 * 02/17/17
	 ******************************************************/

	public void MOCheckoutReview() throws Exception, UserDefinedException {

		long timeNow = System.currentTimeMillis();
		System.out.println("->MO validation in Checkout console");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		getUrl = ", URL Launched --> " + returnURL();
		String internetPlan = get("OfferCheckout");
		strDescription = "Verify that Offer Display in Summary in CHeckout Window";
		strExpected = "Offer discription shall be getting displayed correctly";
		strActual = "Offer descritpion is getting dispalyed successfully under Summary section in Checkout pop up window";
		strFailed = "Offer Description is not getting displayed as expected under Summary Section in Checkout pop up window";
		waitForLoader();
		String OfferSummary = get("OfferCheckout");
		String[] OFferDisplay = OfferSummary.split(",");
		Boolean OfferDIspaly = false;
		String MOType = get("MarketingOfferType");

		// Switch Frame
		switchToDefaultcontent();
		switchToFrame("IfProducts");

		try {
			// Checking offer in checkout window
			try {
				try {
					// By Shobana
					// To take screenshot of Estimated Monthly Charges
					report.reportPass("Review Order Page is displayed ",
							"Review Order Page should be displayed after clicking Review Order Button",
							"After Clicking Review Order Button, able to see Review Order Page");
					WebElement estimateMonthlyCharge = driver
							.findElement(By.xpath("//h6[contains(text(),'Estimated Monthly Charges ')]"));
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(false);",
							estimateMonthlyCharge);
					report.reportPass("Estimated Montly Charges is displayed ",
							"Estimated Montly Charges should be getting clicked",
							"Estimated Montly Charges is clicked successfully");
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",
							estimateMonthlyCharge);
					report.reportPass("Estimated Montly Charges is displayed ",
							"Estimated Montly Charges should be scrolled",
							"Estimated Montly Charges is scrolled successfully");
				} catch (Exception e) {
					report.reportFail("Estimated Montly Charges is displayed ",
							"Estimated Montly Charges is not clicked", "Estimated Montly Charges is not clicked");
				}

				try {
					WebElement offer_summary = driver
							.findElement(By.xpath("//span[text()='Offer Summary']/parent::li[@aria-expanded='true']"));
					// ((JavascriptExecutor)
					// driver).executeScript("arguments[0].scrollIntoView(true);",
					// offer_summary);
					((JavascriptExecutor) driver).executeScript("arguments[0].click();", offer_summary);
					report.reportPass("FNSummary is getting dispalyed and able to expandable",
							"FNSumamry should be getting clicked", "FNSummary is abel to ckecked successfully");
				} catch (Exception e) {
					report.reportPass("FNSummary is getting displayed", "FNSummary will not be getting dispalyed",
							"FNSUmamry is not getting displayed successfully" + e.getMessage());
				}
				Thread.sleep(2000);

				// By Shobana
				// To scroll down and take screenshot of Offer Summary
				WebElement summaryExpansion = driver
						.findElement(By.xpath("//span[text()='Offer Summary']/parent::li/following-sibling::li"));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(false);", summaryExpansion);

				String offer_text = driver
						.findElement(By.xpath("//span[text()='Offer Summary']/parent::li/following-sibling::li"))
						.getText();
				Thread.sleep(3000);

				if (!OfferSummary.isEmpty()) {
					for (String text1 : OFferDisplay) {
						if (offer_text.contains(text1.trim())) {
							OfferDIspaly = true;
							report.reportPass(strDescription + getUrl, strExpected, strActual);

						} else {
							OfferDIspaly = false;
							report.reportFail(strDescription, strExpected, strFailed);

						}
					}
				}

				// Verifying result whether offer matched for given scenario
				if (OfferDIspaly && MOType.equalsIgnoreCase("Positive")) {
					report.reportPass(strDescription, OfferSummary + strExpected, OfferSummary + strActual);
				}

				if (OfferDIspaly && MOType.equalsIgnoreCase("Negative")) {
					report.reportFail(strDescription, OfferSummary + strExpected, OfferSummary + strFailed);
				}

				if (!OfferDIspaly && MOType.equalsIgnoreCase("Positive")) {
					report.reportFail(strDescription, OfferSummary + strExpected, OfferSummary + strFailed);
				}

				if (!OfferDIspaly && MOType.equalsIgnoreCase("Negative")) {
					report.reportPass(strDescription, OfferSummary + strExpected, OfferSummary + strFailed);
				}

			}

			catch (Exception e) {

			}

			// Price Validation in Checkout window
			double Review_BundlePrice = 0.00f;
			if (isDisplayed(reviewBundlePrice, ""))
				Review_BundlePrice = Double
						.parseDouble(getTextFromElement(reviewBundlePrice, objectValue).replace("$", "").trim());
			double Review_MonthlyCharge_WOTax = Double
					.parseDouble(getTextFromElement(reviewMonthlyChargewoTax, objectValue).replace("$", "").trim());
			double Review_MonthlyCharge_WithTax = Double
					.parseDouble(getTextFromElement(reviewMonthlyChargeWithTax, objectValue).replace("$", "").trim());

			double opo_BundlePrice = Double.parseDouble(get("ProductServicePageBundlePrice").replace("$", "").trim());
			double opo_MonthlyCharge_WOTax = Double
					.parseDouble(get("ProductServicePageMonthlyCharge_WOTax").replace("$", "").trim());
			double opo_MonthlyCharge_WithTax = Double
					.parseDouble(get("ProductServicePageMonthlyCharge").replace("$", "").trim());

			if (opo_BundlePrice == Review_BundlePrice)
				report.reportPass("Review Page: Verifying Bundle Price",
						"Verify whether Bundle price in review page is matched with OPO page",
						"Bundle price in review page is matched with OPO page");
			else
				report.reportFail("Review Page: Verifying Bundle Price",
						"Verify whether Bundle price in review page is matched with OPO page",
						"Bundle price in review page is not matched with OPO page");

			if (opo_MonthlyCharge_WOTax == Review_MonthlyCharge_WOTax)
				report.reportPass("Review Page: Verifying Monthly Charge without tax Price",
						"Verify whether Monthly Charge without tax in review page is matched with OPO page",
						"Monthly Charge without tax in review page is matched with OPO page");
			else
				report.reportFail("Review Page: Verifying Monthly Charge without tax Price",
						"Verify whether Monthly Charge without tax in review page is matched with OPO page",
						"Monthly Charge without tax in review page is not matched with OPO page");

			if (opo_MonthlyCharge_WithTax == Review_MonthlyCharge_WithTax)
				report.reportPass("Review Page: Verifying Monthly Charge with tax",
						"Verify whether Bundle priceMonthly Charge with tax in review page is matched with opo page",
						"Monthly Charge with tax in review page is matched with OPO page");
			else
				report.reportFail("Review Page: Verifying Monthly Charge with tax",
						"Verify whether Monthly Charge with tax in review page is matched with OPO page",
						"Monthly Charge with tax in review page is not matched with OPO page");

			// timelapsed - console
			System.out.println(System.currentTimeMillis() - timeNow + " Milliseconds");
		} catch (Exception e) {

		}

	}

	/**
	 * @Info To Negotiate Plan adn Features under LEC page
	 * @param FirstName
	 * @param LastName
	 * @throws Exception
	 * @Modified by Poovaraj
	 * @LastUpdated 03/13/2017
	 */
	public void AddingLECPlanDetails() throws Exception {

		String FIRSTNAME = get("FirstName");
		String LASTNAME = get("LastName");
		String strInsideWireMaintenace = get("Wiremaintanance").trim().toUpperCase();

		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		try {
			// strDescription = "Negotiate Plan and Features under LEC Page";
			strExpected = "Verify that Plan and features options are getting selected ";
			strActual = "Plan and features options are getting selected successfully";
			strFailed = "Plan and Features options are not being selected,since it is getting failed";
			getUrl = ", URL Launched --> " + returnURL();

			// Negotiating Calling Plans and Carrier Info Section in LEC page
			try {
				// selecting International Plan
				mouseOver(DrpIEPlan);
				selectDropDownUsingVisibleText(DrpIEPlan, "", "NICP No International Calling Plan $0 $0");
				System.out.println("International Plan has been selected from dropdown");

				// Click on Apply under Calling Plan and Carrier Info
				mouseOver(ApplyCallingPlan);
				clickUsingJavaScript(ApplyCallingPlan, "");
				System.out.println("Apply button is clicked under Calling Plans and Carrier Info section");
				report.reportPass("Clicking on apply button", "Verify that Apply button is clicked",
						"Apply button is clicked under Calling Paln and CArrier Info section successfully");
				waitForLoader();
				pause();

			} catch (Exception e) {
				getUrl = ", URL Launched --> " + returnURL();
				report.reportFail("Clicking on apply button" + getUrl, "Verify that Apply button is clicked",
						"Failed to click th eapply button due to object not in ready state");
			}
		} catch (Exception e) {
			report.reportFail("Select Plan and Features Options.", "Plan and Features options should be selected",
					strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);
		}

		try {
			// Select Maintenance Plan Checkbox
			mouseOver(lnkMaintenancePlanCheckBox);
			clickUsingJavaScript(lnkMaintenancePlanCheckBox, "");
			waitForLoader();

			// Select Maintenance Plan Setup
			mouseOver(lnkMaintenancePlanSetUp);
			clickUsingJavaScript(lnkMaintenancePlanSetUp, "");
			waitForLoader();

			// Select No Maintenace Options

			if (strInsideWireMaintenace.equalsIgnoreCase("YES")) {
				waitForElementDisplay(lstWMRInsideWireMaintenance, objectValue, 15);
				mouseOver(lstWMRInsideWireMaintenance);
				waitForLoader();
				mouseclick(lstWMRInsideWireMaintenance, objectValue);
				System.out.print(lstWMRInsideWireMaintenance.getText());
				waitForLoader();
			} else {
				waitForElementDisplay(lstNoMainteancePlan, objectValue, 15);
				mouseOver(lstNoMainteancePlan);
				waitForLoader();
				mouseclick(lstNoMainteancePlan, objectValue);
				System.out.print(lstNoMainteancePlan.getText());
				waitForLoader();
			}

			waitForElementDisplay(lstApplySelectedLines, objectValue, 15);
			mouseOver(lstApplySelectedLines);
			mouseclick(lstApplySelectedLines, objectValue);
			// clickUsingJavaScript(lstApplySelectedLines, "");
			waitForLoader();
			pause();

			report.reportPass("Select Maintenance Plan", "Maintenance Plan should be selected",
					"Maintenance Plan is selected successfully");

		} catch (Exception e) {
			report.reportFail("Select Maintenance Plan", "Maintenance Plan should be selected",
					"Maintenance Plan is NOT selected successfully");
			report.reportFail("Select Plan and Features Options.", "Plan and Features options should be selected",
					strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);
		}

		try {
			// Select Voice Back Up Plan
			mouseOver(lnkVoiceBackUpSetUp);
			clickUsingJavaScript(lnkVoiceBackUpSetUp, "");
			waitForLoader();

			// Select No Maintenace Options
			waitForElementDisplay(lstVoiceBackUpSetUpOptions, objectValue, 15);
			mouseOver(lstVoiceBackUpSetUpOptions);
			// Dynamically changing every time
			// selectDropDownUsingVisibleText(lstVoiceBackUpSetUpOptions,
			// objectValue, "FEKZG Customer Declined Voice Backup Power Reserve
			// (after addressing any questions) $0.00");
			mouseclick(lstVoiceBackUpSetUpOptions, objectValue);
			System.out.print(lstVoiceBackUpSetUpOptions.getText());
			waitForLoader();

			waitForElementDisplay(btnVoiceBackUpOK, objectValue, 15);
			mouseOver(btnVoiceBackUpOK);
			mouseclick(btnVoiceBackUpOK, objectValue);
			// clickUsingJavaScript(btnVoiceBackUpOK, "");
			waitForLoader();
			pause();

			report.reportPass("Select Voice Back Up Plan", "Voice Back Up Plan should be selected",
					"Voice Back Up Plan is selected successfully");

		} catch (Exception e) {
			report.reportFail("Select Voice Back Up Plan", "Voice Back Up Plan should be selected",
					"Voice Back Up Plan is NOT selected");
			report.reportFail("Select Plan and Features Options.", "Plan and Features options should be selected",
					strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);
		}

		try {
			// Select Jack options
			mouseOver(lnkJackSetUp);
			clickUsingJavaScript(lnkJackSetUp, "");
			waitForLoader();

			// Select No Maintenace Options
			waitForElementDisplay(chkNoJackNeedOption, objectValue, 15);
			mouseOver(chkNoJackNeedOption);
			mouseclick(chkNoJackNeedOption, objectValue);
			// clickUsingJavaScript(chkNoJackNeedOption, "");
			waitForLoader();

			waitForElementDisplay(btnNoJackOptionOK, objectValue, 15);
			mouseOver(btnNoJackOptionOK);
			mouseclick(btnNoJackOptionOK, objectValue);
			// clickUsingJavaScript(btnNoJackOptionOK, "");
			waitForLoader();
			pause();

			report.reportPass("Select Jack Optin", "Jack Option should be selected",
					"Jack Option is selected successfully");

		} catch (Exception e) {
			report.reportFail("Select Jack Optin", "Jack Option should be selected",
					"Jack Option is NOT selected successfully");
			report.reportFail("Select Plan and Features Options.", "Plan and Features options should be selected",
					strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);
		}

		// Click On Apply Button
		waitForElementDisplay(btnLECFeaturesApply, objectValue, 15);
		mouseOver(btnLECFeaturesApply);
		mouseclick(btnLECFeaturesApply, objectValue);
		// clickUsingJavaScript(btnLECFeaturesApply, "");
		waitForLoader();
		pause();

		// Handling of Directory Listing
		try {
			// Clicking on Edit link
			// waitForElementDisplay(DLEdit, "", 2);
			waitForElementDisplay(DLEdit, objectValue, 15);
			mouseOver(DLEdit);
			clickUsingJavaScript(DLEdit, "");// click not working
			System.out.println("EDIT link is clicked");
			report.reportPass("Clicking on EDIT under Directory Listing", "Verify that EDIT is getting clicked",
					"EDIT is getting clicked successfully");

			// Spinner processing
			// waitForLoader();
			pause();

			// Entering First Name
			mouseOver(DLLastName);
			clearText(DLLastName, objectValue);
			setText(DLLastName, "", LASTNAME);
			System.out.println("Last Name" + LASTNAME + "is entered successfully");
			report.reportPass("Entering LAST NAME", "Verify that able to LAST NAME in Directory Listing",
					"LAST NAME is entered successfully");

			// Spinner processing
			waitForLoader();

			// Entering Last Name
			mouseOver(DLFirstName);
			clearText(DLFirstName, objectValue);
			setText(DLFirstName, "", FIRSTNAME);
			System.out.println("FIRSTNAME" + FIRSTNAME + "is entered successfully");
			report.reportPass("Entering FIRST NAME", "Verify that able to FIRST NAME in Directory Listing",
					"FIRST NAME is entered successfully");

			// Spinner processing
			waitForLoader();

			// Entering OK button in Directory Listing
			// waitForElementDisplay(DLOK, "", 2);
			mouseOver(DLOK);
			clickUsingJavaScript(DLOK, "");// click not working
			System.out.println("OK is getting clicked");
			report.reportPass("Clicking OK button in Directory Listing", "Verify tha the OK button i sgetting clicked",
					"OK button is getting clicked successfully");

			// Spinner processing
			// waitForLoader();
			pause();

			// Clicking on OK in Package, Plan and features
			// waitForElementDisplay(PlanFeaturesOK, "", 2);
			mouseOver(PlanFeaturesOK);
			clickUsingJavaScript(PlanFeaturesOK, "");// click not working
			System.out.println("OK is clicked");
			report.reportPass("Clicking on OK button under Plan and features", "Verify that OK is getting clicked",
					"OK is getting clicked successfully");
			// waitForLoader();
			pause();

		} catch (Exception e) {
			getUrl = ", URL Launched --> " + returnURL();
			report.reportFail("Negotiating Directory Listing " + getUrl,
					"Verify that Directory Listing section is negotiating sucessfully", "Failed to do the Action");
			report.reportFail("Select Plan and Features Options.", "Plan and Features options should be selected",
					strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);
		}
	}

	public void premiumChannelsMOValidations() throws Exception {

		HashMap<String, ArrayList<HashMap<String, String>>> PremiumMOinputs = null;

		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		// select Voice type
		strDescription = "Price Validaiton under Premium section based on the channel selection";
		strExpected = "Price Validation should be matched for Premium Channel";
		strActual = "Price Validation matched for Premium Channel";
		strFailed = "Price Validation not matched for Premium Channel Section";
		getUrl = ", URL Launched --> " + returnURL();
		int IncludedChannel = 0;

		double OfferAmount = 0;

		String OfferTile = get("OfferTileDesc");
		String OfferCheckout = get("OfferCheckout");
		String MOType = get("MarketingOfferType");
		String SelectedTVTileText = get("ZeroRatedPremium");
		String NoOfChannel = null;

		String IncludeChannel = null;
		ArrayList<String> SelectedPremiumChannelList = new ArrayList<String>();
		ArrayList<String> PickPremiumChannelList = new ArrayList<String>();
		String SelectedPremiums = "";
		String[] PremiumChannels = { "HBO", "Cinemax", "STARZ", "EPIX", "Showtime" };
		try {

			// Getting the values of MO Offers across channels displayed under
			// Premium Channel Section
			PremiumMOinputs = PremiumUsingInput();

			if (isDisplayed(Selected_Premium, "", 0)) {
				SelectedPremiums = getTextFromElement(Selected_Premium, objectValue);
				System.out.println(SelectedPremiums);
				// Capturing each selected premeium channel and store it in
				// array
				String[] SelectedPremiumsList = SelectedPremiums.split("\\+");

				for (String readChannel : SelectedPremiumsList) {
					if (readChannel.toLowerCase().trim().contains("(")) {
						SelectedPremiumChannelList.add(readChannel.substring(readChannel.indexOf("(") + 1).trim());
					} else if (readChannel.toLowerCase().trim().contains(")")) {
						SelectedPremiumChannelList.add(readChannel.substring(0, readChannel.indexOf(")")).trim());
					} else {
						SelectedPremiumChannelList.add(readChannel.trim());
					}

				}

			}

			// getting Pick your premium channel and its count from all selected
			// premium channel and store it in array
			int ChannelCount = 0;
			for (String PC : PremiumChannels) {

				if (SelectedPremiumChannelList.contains(PC.trim())) {
					PickPremiumChannelList.add(PC.trim());
					ChannelCount = ChannelCount + 1;
				}
			}

			// Store pick your premium channels alone in array
			String[] Premiumlist = new String[ChannelCount];
			for (int ch = 0; ch < PickPremiumChannelList.size(); ch++) {
				Premiumlist[ch] = PickPremiumChannelList.get(ch).trim();
			}
			System.out.println("tempChannel test" + ChannelCount);

			// Getting the Display amount for Premium Section
			String DisplayAmt = PremiumChannelPrice.getText().replace("$", "").trim();
			double DisplayDollor = Double.parseDouble(DisplayAmt);

			// Getting the No of Channel which is not come under Offer (Zero
			// Rated Premium)
			if (!SelectedTVTileText.isEmpty()) {

				for (String GettingChannelcount : Premiumlist) {
					if (SelectedTVTileText.toLowerCase().contains(GettingChannelcount.toLowerCase())) {
						IncludedChannel = ChannelCount - 1;
						int temp = IncludedChannel;
						ChannelCount = temp;

					} else {
						IncludedChannel = ChannelCount;
					}
				}

				NoOfChannel = Integer.toString(IncludedChannel);
			}
			// if no zero rated premium then assign default selected premium
			// channel count
			else {

				NoOfChannel = Integer.toString(ChannelCount);

			}

			// Getting the Without Offer Price for the combination of Channel
			// Selection
			String GetPriceWOOffer = PremiumMOinputs.get(NoOfChannel).get(0).get("ChannelPrice").toString();
			double ChannelAmtWOOffer = Double.parseDouble(GetPriceWOOffer);

			// Identifying that the list of Premium channel will become under
			// which Combination of Offer Selection
			Boolean ChannelPresent = false;
			boolean onlyonematching = false;
			String offerPrice = null;
			int AvailableChannelcount = 0;
			SelectedPremiums = getTextFromElement(Selected_Premium, objectValue);

			if (!PremiumMOinputs.get(NoOfChannel).get(1).isEmpty() && MOType.contains("Positive")
					&& (OfferTile.toLowerCase().contains("premium")
							|| OfferCheckout.toLowerCase().contains("premium"))) {
				HashMap<String, String> m = PremiumMOinputs.get(NoOfChannel).get(1);

				// To predict the channel count for which offer applied
				for (String PC : PremiumChannels) {

					if (OfferTile.toLowerCase().contains((PC).toLowerCase())) {
						AvailableChannelcount++;
					}
				}

				if (AvailableChannelcount == 0) {
					AvailableChannelcount = ChannelCount;

				}

				for (int i = AvailableChannelcount; i >= 1; i--) {

					for (Entry<String, String> Entry : m.entrySet()) {
						// Set<String> Set=new
						// HashSet<String>(Arrays.asList(Channel));

						String Key = Entry.getKey();
						Boolean Flag = false;
						int NoofTVsintheKey = Key.split("&").length;
						int CHpresent = 0;
						String[] Chlist = Key.split("&");
						for (String ChArr : Chlist) {
							if (OfferTile.toLowerCase().contains(ChArr.toLowerCase())
									|| SelectedPremiums.toLowerCase().contains(ChArr.toLowerCase())) {
								CHpresent++;
							}

						}
						if (CHpresent == NoofTVsintheKey) {
							Flag = true;
						}
						if (Key.contains("&") && NoofTVsintheKey == i && Flag) {

							int matching = 0;

							for (String EachChannel : Premiumlist) {
								// return aa.contains(EachChannel);

								if (Key.toLowerCase().contains(EachChannel.toLowerCase().trim())) {
									matching++;
								}

							}

							if (matching == i) {
								offerPrice = Entry.getValue();
								System.out.println(Entry.getKey());
								ChannelPresent = true;
								break;
							}

						}

					}
					if (ChannelPresent) {
						break;
					}
				}

				if (!ChannelPresent) {

					for (Entry<String, String> Entry : m.entrySet()) {

						String Key = Entry.getKey();
						int NoOfTV = Key.split("/").length;

						if (Key.contains("/") && AvailableChannelcount == NoOfTV) {

							for (String EachChannel : Premiumlist) {
								// return aa.contains(EachChannel);
								if (Key.toLowerCase().contains(EachChannel.toLowerCase())) {

									onlyonematching = true;

								}

							}
						} else if (AvailableChannelcount == NoOfTV) {

							for (String EachChannel : Premiumlist) {
								if (Key.toLowerCase().contains(EachChannel.toLowerCase())) {
									onlyonematching = true;

								}
							}

						}

						if (onlyonematching) {
							offerPrice = Entry.getValue();
							break;
						}

					}
				}
			}

			System.out.println(offerPrice);
			// Comparing the Offer/WithoutOffer amount with the Total amount
			// display on Premium Sectiomn
			if (ChannelPresent || onlyonematching) {
				OfferAmount = Double.parseDouble(offerPrice);
				if (DisplayDollor == OfferAmount) {
					System.out.println("OfferPrice are getting dispalyed correctly");
					report.reportPass("Price validation",
							"<b>" + "OfferPrice: " + OfferAmount + "<br/>" + "PremiumChannel Price: " + DisplayDollor
									+ "</b>" + "<br/>" + "Both should be matched",
							"<b>" + "OfferPrice: " + OfferAmount + "<br/>" + "PremiumChannel Price: " + DisplayDollor
									+ "</b>" + "<br/>" + "Prices are getting Matched");
				} else {

					System.out.println("OfferPrice are not getting dispalyed correctly");
					report.reportFail("Price validation",
							"<b>" + "OfferPrice: " + OfferAmount + "<br/>" + "PremiumChannel Price: " + DisplayDollor
									+ "</b>" + "<br/>" + "Both should be matched",
							"<b>" + "OfferPrice: " + OfferAmount + "<br/>" + "PremiumChannel Price: " + DisplayDollor
									+ "</b>" + "<br/>" + "Prices are not getting Matched");

				}
			} else if (DisplayDollor == ChannelAmtWOOffer) {
				System.out.println("Offers are not getting included");
				report.reportPass("Price Validation",
						"<b>" + "PremiumChannel Price: " + DisplayDollor + "<br/>" + "PriceWOOffer: "
								+ ChannelAmtWOOffer + "</b>" + "<br/>" + "Both should be macthed",
						"<b>" + "PremiumChannel Price: " + DisplayDollor + "<br/>" + "PriceWOOffer: "
								+ ChannelAmtWOOffer + "</b>" + "<br/>" + "Prices are getting matched");
			} else {
				report.reportFail("Price Validation",
						"<b>" + "PremiumChannel Price: " + DisplayDollor + "<br/>" + "PriceWOOffer: "
								+ ChannelAmtWOOffer + "</b>" + "<br/>" + "Both should be macthed",
						"<b>" + "PremiumChannel Price: " + DisplayDollor + "<br/>" + "PriceWOOffer: "
								+ ChannelAmtWOOffer + "</b>" + "<br/>" + "Prices are not getting matched");
			}
			report.reportPass(strDescription, strExpected, strActual);
		} catch (Exception e) {

			report.reportFail(strDescription + getUrl, strExpected, strFailed);
		}

	}

	/*
	 * Method Name : OPOPriceValidation Method Description : This is used to
	 * Validate Price details in OPO page
	 * 
	 * @param No
	 * 
	 * @throws Exception throws exception of type Exception
	 * 
	 * @author Rathna B
	 */

	public void OPOPriceValidation() throws Exception, UserDefinedException {

		System.out.println("->Price Validation");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		// select Voice type
		strDescription = "Price Validation in OPO Page";
		strExpected = "Price Validation should be matched";
		strActual = "Price Validation matched";
		strFailed = "Price Validation not matched";
		getUrl = ", URL Launched --> " + returnURL();

		try {

			// Switch Frame
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			DecimalFormat df = new DecimalFormat("#,###,##0.00");

			double total_offer_12months = 0.00f;
			double total_offer_24months = 0.00f;
			double total_offer_36months = 0.00f;

			double flt_PremiumChannel_Price = 0.00;
			double flt_Security_Price = 0.00;
			double flt_voice_option_Price = 0.00;
			double flt_Setup_Price = 0.00;
			double flt_Loyalty_Price = 0.00;
			double flt_Equip_Acc_Price = 0.00;

			ArrayList<String> arrList_12months = new ArrayList<String>();
			ArrayList<String> arrList_24months = new ArrayList<String>();
			ArrayList<String> arrList_36months = new ArrayList<String>();

			Calendar date = Calendar.getInstance();
			date.setTime(new Date());
			Format f = new SimpleDateFormat("MM/dd/yy");
			String currentdate = f.format(date.getTime());
			date.add(Calendar.YEAR, 1);
			String oneYear_Date = f.format(date.getTime());
			date.add(Calendar.YEAR, 1);
			String twoYear_Date = f.format(date.getTime());
			date.add(Calendar.YEAR, 1);
			String threeYear_Date = f.format(date.getTime());

			// Read Internet, Tv & Voice Product

			String Internet_Product = getTextFromElement(simplex_SelectedData, objectValue).trim();
			String TV_Product = getTextFromElement(simplex_SelectedTV, objectValue).trim();
			String Voice_Product = getTextFromElement(simplex_SelectedVoice, objectValue).trim();
			put("ProductServicePageSelectedInternet", Internet_Product);
			put("ProductServicePageSelectedTV", TV_Product);
			put("ProductServicePageSelectedVoice", Voice_Product);

			// Read Internet Price from application
			String str_internet_Price = getTextFromElement(InternetPrice, objectValue).replace("$", "").trim();
			put("ProductServicePageInternetPrice", str_internet_Price);
			double flt_internet_Price = Double.parseDouble(str_internet_Price);

			// Read Video Price from application
			String str_video_Price = getTextFromElement(VideoPrice, objectValue).replace("$", "").trim();
			put("ProductServicePageTVPrice", str_video_Price);
			double flt_video_Price = Double.parseDouble(str_video_Price);

			// Read Voice Price from application
			String str_voice_Price = getTextFromElement(VoicePrice, objectValue).replace("$", "").trim();
			put("ProductServicePageVoicePrice", str_voice_Price);
			double flt_voice_Price = Double.parseDouble(str_voice_Price);

			// Read Offer Value from application
			String str_agreement_offer_Price = getTextFromElement(AgreementPrice, objectValue);
			if (str_agreement_offer_Price.contains("$0.00")) {
				str_agreement_offer_Price = getTextFromElement(AgreementPrice, objectValue).replace("$", "").trim();
			} else {
				str_agreement_offer_Price = getTextFromElement(AgreementPrice, objectValue).replace("-$", "").trim();
			}
			put("ProductServicePageOfferPrice", str_agreement_offer_Price);
			double flt_agreement_offer_Price = Double.parseDouble(str_agreement_offer_Price);

			// Manipulate offer price from offer detail section and validate
			// with Agreement_offer section price

			// To Expand Agreement section
			if (!getAttribute(expandContract, objectValue, "class").contains("open")) {
				pageScroll(expandContract, objectValue, true);
				clickUsingJavaScript(expandContract, objectValue);
			}

			// Switch Frame
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			// Get total offer tile displayed and its size
			CList<Element> OfferTileList = null;
			if (get("FlowType").equalsIgnoreCase("Install") && get("Standalone").isEmpty())
				OfferTileList = InstallOfferTileList;
			else if (get("FlowType").equalsIgnoreCase("Change") && get("Standalone").isEmpty())
				OfferTileList = ChangeOfferTileList;

			if (get("Standalone").isEmpty()) {
				for (int i = 0; i < OfferTileList.size(); i++) {

					if (OfferTileList.get(i).getAttribute("data-agreement-selection").equals("active")) {

						if (get("FlowType").equalsIgnoreCase("Install"))
							clickUsingJavaScript(OfferDetailLinkInstall.get(i), objectValue);

						else if (get("FlowType").equalsIgnoreCase("Change"))
							clickUsingJavaScript(OfferDetailLinkChange.get(i), objectValue);

					}
				}
			}

			if (get("FlowType").equalsIgnoreCase("Install") && get("Standalone").toLowerCase().contains("data"))
				clickUsingJavaScript(standAloneOfferDetailsLink, "ShowStandaloneDataOffers");

			if (get("FlowType").equalsIgnoreCase("Install") && get("Standalone").toLowerCase().contains("tv"))
				clickUsingJavaScript(standAloneOfferDetailsLink, "ShowStandaloneVideoOffers");

			if (get("FlowType").equalsIgnoreCase("Install") && get("Standalone").toLowerCase().contains("voice"))
				clickUsingJavaScript(standAloneOfferDetailsLink, "ShowStandaloneVoiceOffers");

			waitForLoader();

			for (WebElement off : OfferPopupDetails) {
				// for(WebElement off: offerdetails){
				String offer_Txt = off.getText();
				if (offer_Txt.contains("36 Months") && !offer_Txt.contains("Pick Your Premium")
						&& !offer_Txt.contains("Fios Quantum TV")) {

					arrList_12months.add(offer_Txt);
					arrList_24months.add(offer_Txt);
					arrList_36months.add(offer_Txt);

				} else if (offer_Txt.contains("24 Months") && !offer_Txt.contains("Pick Your Premium")
						&& !offer_Txt.contains("Fios Quantum TV")) {
					arrList_12months.add(offer_Txt);
					arrList_24months.add(offer_Txt);
				} else if (offer_Txt.contains("12 Months") && !offer_Txt.contains("Pick Your Premium")
						&& !offer_Txt.contains("Fios Quantum TV")) {

					arrList_12months.add(offer_Txt);

				}

				else if (!offer_Txt.contains("Pick Your Premium") && !offer_Txt.contains("Fios Quantum TV")) {
					arrList_12months.add(offer_Txt);
					arrList_24months.add(offer_Txt);
					arrList_36months.add(offer_Txt);
				}

			}

			if (!arrList_12months.isEmpty()) {
				for (String temp : arrList_12months) {
					if (temp.contains("$")) {
						String[] offer_text = temp.replace("$", "").trim().split(" ");
						double flt_offer_Price = Double.parseDouble(offer_text[1].trim());
						total_offer_12months = total_offer_12months + flt_offer_Price;
					}

				}

				for (WebElement off_price : OfferDetailsPrice) {
					if (off_price.getText().contains("12 months") || off_price.getText().contains(oneYear_Date)) {
						String Expected_total_offer_12months = df.format(
								(flt_internet_Price + flt_video_Price + flt_voice_Price) - total_offer_12months);
						if (off_price.getText().contains(Expected_total_offer_12months))
							report.reportPass("One Page ordering: Price Validation in offer details popup",
									"Verify whether price for 12 months displayed in offer details popup is correct",
									"Price for 12 months displayed in offer details popup is correct - Bundle Price for 12 months - $"
											+ Expected_total_offer_12months);
						else
							report.reportFail("One Page ordering: Price Validation in offer details popup",
									"Verify whether price for 12 months displayed in offer details popup is correct",
									"Price for 12 months displayed in offer details popup is incorrect - Expected Bundle Price for 12 months - $"
											+ Expected_total_offer_12months + " Actual Price is "
											+ off_price.getText().trim());
					}

				}
			}

			if (!arrList_24months.isEmpty()) {
				for (String temp : arrList_24months) {
					if (temp.contains("$")) {
						String[] offer_text = temp.replace("$", "").trim().split(" ");
						double flt_offer_Price = Double.parseDouble(offer_text[1].trim());
						total_offer_24months = total_offer_24months + flt_offer_Price;
					}
				}
				for (WebElement off_price : OfferDetailsPrice) {
					if (off_price.getText().contains("24 months") || off_price.getText().contains(twoYear_Date)) {
						String Expected_total_offer_24months = df.format(
								(flt_internet_Price + flt_video_Price + flt_voice_Price) - total_offer_24months);
						if (off_price.getText().contains(Expected_total_offer_24months))

							report.reportPass("One Page ordering: Price Validation in offer details popup",
									"Verify whether price for 24 months displayed in offer details popup is correct",
									"Price for 24 months displayed in offer details popup is correct - Bundle Price for 24 months - $"
											+ Expected_total_offer_24months);
						else
							report.reportFail("One Page ordering: Price Validation in offer details popup",
									"Verify whether price for 24 months displayed in offer details popup is correct",
									"Price for 24 months displayed in offer details popup is incorrect - Expected Bundle Price for 24 months - $"
											+ Expected_total_offer_24months + " Actual Price is "
											+ off_price.getText().trim());

					}

				}

			}
			if (!arrList_36months.isEmpty()) {
				for (String temp : arrList_36months) {
					if (temp.contains("$")) {
						String[] offer_text = temp.replace("$", "").trim().split(" ");
						double flt_offer_Price = Double.parseDouble(offer_text[1].trim());
						total_offer_36months = total_offer_36months + flt_offer_Price;
					}
				}
				for (WebElement off_price : OfferDetailsPrice) {
					if (off_price.getText().contains("36 months") || off_price.getText().contains(threeYear_Date)) {
						String Expected_total_offer_36months = df.format(
								(flt_internet_Price + flt_video_Price + flt_voice_Price) - total_offer_36months);
						if (off_price.getText().contains(Expected_total_offer_36months))
							report.reportPass("One Page ordering: Price Validation in offer details popup",
									"Verify whether price for 36 months displayed in offer details popup is correct",
									"Price for 36 months displayed in offer details popup is correct - Bundle Price for 36 months - $"
											+ Expected_total_offer_36months);
						else
							report.reportFail("One Page ordering: Price Validation in offer details popup",
									"Verify whether price for 36 months displayed in offer details popup is correct",
									"Price for 36 months displayed in offer details popup is incorrect - Expected Bundle Price for 36 months - $"
											+ Expected_total_offer_36months + " Actual Price is "
											+ off_price.getText().trim());

					}

				}
			}

			if (total_offer_12months == flt_agreement_offer_Price)
				report.reportPass("One Page ordering: Price Validation in Agreement + Offer Section",
						"Verify whether Price displayed in Agreement & offer section is correct",
						"Agreement & offer section price dispalyed $" + flt_agreement_offer_Price);
			else
				report.reportFail("One Page ordering: Price Validation in Agreement + Offer Section",
						"Verify whether Price displayed in Agreement & offer section is correct",
						"Agreement & offer section price displayed incorrectly. Expected Offer Price is $"
								+ total_offer_12months + "Price displayed in OPO Page is $"
								+ flt_agreement_offer_Price);

			// Closing the Detail window
			clickUsingJavaScript(DetailsClose, objectValue);

			// Read Bundle Price from application
			// Read Bundle Price from application
			String str_BundlePrice = "";
			for (Element Bundle_Price : BundlePriceList) {
				if (isDisplayed(Bundle_Price, "")) {
					str_BundlePrice = getTextFromElement(Bundle_Price, objectValue).replace("$", "").trim();
					break;
				}
			}

			put("ProductServicePageBundlePrice", str_BundlePrice);
			double flt_BundlePrice = Double.parseDouble(str_BundlePrice);

			// Calculate Bundle Price
			String Expected_BundlePrice = df
					.format((flt_internet_Price + flt_video_Price + flt_voice_Price) - flt_agreement_offer_Price);
			double flt_Expected_BundlePrice = Double.parseDouble(Expected_BundlePrice);

			// Verify Actual Bundle Price with Expected
			if (flt_BundlePrice == flt_Expected_BundlePrice)
				report.reportPass("One Page ordering: Bundle Price Validation",
						"Verify whether Bundle Price displayed in OPO Page is correct",
						"Bundle Price displayed in OPO Page is correct. Bundle price displayed - $"
								+ flt_Expected_BundlePrice);
			else
				report.reportFail("One Page ordering: Bundle Price Validation",
						"Verify whether Bundle Price displayed in OPO Page is correct",
						"Bundle Price displayed in OPO Page is incorrect . Expected Bundle price is $"
								+ Expected_BundlePrice + "Price displayed in OPO Page is $" + flt_BundlePrice);

			// Read Equipment_Accessories Price from application
			if (isDisplayed(Equip_AccessPrice, objectValue)) {
				String str_Equip_Acc_Price = getTextFromElement(Equip_AccessPrice, objectValue).replace("$", "").trim();
				flt_Equip_Acc_Price = Double.parseDouble(str_Equip_Acc_Price);
			}

			// Read Premium Channel Price from application

			if (isDisplayed(PremiumChannelPrice, objectValue)) {
				String str_PremiumChannel_Price = getTextFromElement(PremiumChannelPrice, objectValue).replace("$", "")
						.trim();
				flt_PremiumChannel_Price = Double.parseDouble(str_PremiumChannel_Price);
			}

			// Read Security & support Price from application
			if (isDisplayed(SecuritySupportPrice, objectValue)) {
				String str_Security_Price = getTextFromElement(SecuritySupportPrice, objectValue).replace("$", "")
						.trim();
				flt_Security_Price = Double.parseDouble(str_Security_Price);
			}

			// Read Voice option Price from application
			if (isDisplayed(VoiceOptionPrice, objectValue)) {
				String str_voice_option_Price = getTextFromElement(VoiceOptionPrice, objectValue).replace("$", "")
						.trim();
				flt_voice_option_Price = Double.parseDouble(str_voice_option_Price);
			}

			// Read Setup option Price from application
			if (isDisplayed(SetupOptionPrice, objectValue)) {
				String str_Setup_Price = getTextFromElement(SetupOptionPrice, objectValue).replace("$", "").trim();
				flt_Setup_Price = Double.parseDouble(str_Setup_Price);
			}

			// Read Loyalty offer Price from application
			if (isDisplayed(LoyaltyPrice, objectValue)) {
				String str_Loyalty_Price = getTextFromElement(LoyaltyPrice, objectValue).replace("$", "").trim();
				flt_Loyalty_Price = Double.parseDouble(str_Loyalty_Price);
			}

			// Calculate Equipment & Extras Price
			String Expected_Equipment_Extras_Price = df.format(flt_Equip_Acc_Price + flt_PremiumChannel_Price
					+ flt_Security_Price + flt_voice_option_Price + flt_Setup_Price + flt_Loyalty_Price);
			double flt_Expected_Equipment_Extras_Price = Double.parseDouble(Expected_Equipment_Extras_Price);

			// Read Equipment and Extras Price from application
			String str_Equipment_Extras_Price = getTextFromElement(EquipExtrasPrice, objectValue).replace("$", "")
					.trim();
			double flt_Equipment_Extras_Price = Double.parseDouble(str_Equipment_Extras_Price);

			// Verify Actual Equipment and Extras Price Price with Expected
			if (flt_Expected_Equipment_Extras_Price == flt_Equipment_Extras_Price)
				report.reportPass("One Page ordering: Price Validation in Equipment and Extras section",
						"Verify whether Price displayed in Equipment & Extras Section is correct",
						"Price displayed in Exquipment & Extras section is correct. Price in Equipment & Extras Section - $"
								+ flt_Equipment_Extras_Price);
			else
				report.reportFail("One Page ordering: Price Validation in Equipment and Extras section",
						"Verify whether Price displayed in Equipment & Extras Section is correct",
						"Price displayed in Exquipment & Extras section is incorrect. Expected Price in Equipment & Extras Section - "
								+ flt_Expected_Equipment_Extras_Price + "Actual Price displayed is "
								+ flt_Equipment_Extras_Price);

			// Calculating overall monthly charges
			double flt_overall_Expected_Price = flt_Expected_BundlePrice + flt_Expected_Equipment_Extras_Price;

			// Wait for Page to load
			waitForLoader();
			waitForLoader();
			waitForLoader();

			// Read monthly charges from application
			switchToDefaultcontent();
			switchToFrame("IfProducts");
			for (Element getTotal : GetTotalsList) {
				if (isDisplayed(getTotal, objectValue)) {
					clickUsingJavaScript(getTotal, objectValue);
					report.reportPass("One Page ordering: Clicking Get Totals", "Verify  Get Totals clicked on Footer",
							"OPO page-  Get Totals button is clicked ");
					break;
				}
			}
			waitForPageToLoad(driver);
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			String Monthly_charge = "";
			if (get("FlowType").equalsIgnoreCase("Install")) {
				Monthly_charge = getTextFromElement(MonthlyChargesPrice, objectValue).replace("$", "").trim();
			} else if (get("FlowType").equalsIgnoreCase("Change")) {

				Monthly_charge = getTextFromElement(NewMonthlyCharges, objectValue).replace("$", "").trim();

			}

			put("ProductServicePageMonthlyCharge", Monthly_charge);
			double flt_Monthly_charge = Double.parseDouble(Monthly_charge);

			String Tax_Amount = "";
			if (get("FlowType").equalsIgnoreCase("Install")) {
				Tax_Amount = getTextFromElement(TaxAmount, objectValue).replace("$", "").trim();
			} else if (get("FlowType").equalsIgnoreCase("Change")) {

				Tax_Amount = getTextFromElement(ChangeTaxAmount, objectValue).replace("$", "").trim();
			}

			put("ProductServicePageTaxAmount", Tax_Amount);
			double flt_Tax_Amount = Double.parseDouble(Tax_Amount);

			String Monthly_Charge_WOTax = String.valueOf(flt_Monthly_charge - flt_Tax_Amount);
			put("ProductServicePageMonthlyCharge_WOTax", Monthly_Charge_WOTax);
			// Verify Actual monthly charges without tax with Expected
			if (flt_Monthly_charge == flt_overall_Expected_Price + flt_Tax_Amount)
				report.reportPass("One Page ordering: Price Validation in monthly charges",
						"Verify whether Price displayed in monthly charges is correct",
						"Price displayed in monthly charges is correct. Monthly Charge Displayed: $"
								+ flt_Monthly_charge);
			else
				report.reportFail("One Page ordering: Price Validation in monthly charges",
						"Verify whether Price displayed in monthly charges is correct",
						"Price displayed in monthly charges is incorrect. Expected Monthly charge : $"
								+ (flt_overall_Expected_Price + flt_Tax_Amount) + "Monthly charge displayed in OPO : $"
								+ flt_Monthly_charge);

		} catch (Exception exe) {

			exe.printStackTrace();
			report.reportFail(strDescription + getUrl, strExpected, strFailed);
			throw exe;

		}

	}

	/****************************************
	 * MethodName: Description: Finding Duplicates in OfferTiles and Offer
	 * Description in Details Author: Jeevitha S Date: 03/09/2017
	 * 
	 * @throws Exception
	 ****************************************/
	public Boolean ToFindDuplicates(String[] array, int Size) throws Exception {

		String[] temp = new String[Size];
		int a = 0;
		Boolean Dup = false;

		try {
			for (int k = 0; k < Size; k++) {
				System.out.println(array[k]);
				for (int l = 0; l < Size; l++) {
					System.out.println(array[l]);
					if (k != l && array[k].equalsIgnoreCase(array[l]) && !array[k].contains("No offers")) {
						System.out.println("Offers are getting repeated" + array[k]);
						temp[a] = array[k];
						Dup = true;
						if (!array[k].equals(null)) {
							report.reportFail("Searching for Duplicates", "There should be no Duplicates",
									"Duplicates are getting displayed" + "\n" + array[k]);
						} else {
							report.reportFail("Searching for Duplicates", "There should be no Duplicates",
									"Null is getting readed from tile due to the application Issue");
						}
						a++;
					}

				}

			}

			String DuplicateOff = Arrays.toString(temp);
			System.out.println(DuplicateOff);
			// report.reportPass("Searching for DUplicates","Duplicates should
			// not available " , "Duplicates are not getting displayed");
			return Dup;

		} catch (Exception e) {
			report.reportFail("Validaiton of Duplicates", "Identifying Duplicates",
					"Identifying Duplicates are not successful");
			return Dup;
		}

	}

	/********************************************************************************
	 * @MethodName:PremiumUsingInput
	 * @Description: Reading the Premium channel price valuebased on Input sheet
	 * @author shanmje
	 * @Date:03/03/2017
	 * @return
	 * @throws IOException
	 *********************************************************************************/

	public HashMap<String, ArrayList<HashMap<String, String>>> PremiumUsingInput() {

		// Initializing HashMap
		HashMap<String, ArrayList<HashMap<String, String>>> PremiumChannelMO = new HashMap<String, ArrayList<HashMap<String, String>>>();
		String NoOfChannel = "";

		try {
			String IPSheet = new File(System.getProperty("user.dir")).getAbsolutePath()
					+ "\\Files\\InputSheetForMO.xlsx";
			Thread.sleep(200);
			FileInputStream IPFile = new FileInputStream(new File(IPSheet));
			XSSFWorkbook MOInput = new XSSFWorkbook(IPFile);
			XSSFSheet sheet = MOInput.getSheet("PCPriceInfo");
			if (MOInput != null) {
				for (Row row : sheet) {
					// ArrayList<String> Cha_Price=new ArrayList<String>();
					HashMap<String, String> ChannelPriceWOOffer = new HashMap<String, String>();
					HashMap<String, String> ChannelPriceWOffer = new HashMap<String, String>();
					ArrayList<HashMap<String, String>> ArrPremiumOff = new ArrayList<HashMap<String, String>>();
					if (row.getRowNum() != 0) {
						int i = 0;
						Iterator<Cell> cellIterator = row.cellIterator();
						while (cellIterator.hasNext()) {
							Cell CellValue = row.getCell(i);
							String reqcellValue = "";
							switch (CellValue.getCellType()) {
							case Cell.CELL_TYPE_BOOLEAN:
								reqcellValue = new Boolean(CellValue.getBooleanCellValue()).toString();
								break;
							case Cell.CELL_TYPE_NUMERIC:
								int value = (int) CellValue.getNumericCellValue();
								reqcellValue = value + "";
								break;
							case Cell.CELL_TYPE_STRING:
								reqcellValue = CellValue.getRichStringCellValue().toString();
								break;
							}

							if (i == 0) {

								NoOfChannel = reqcellValue;

							} else if (i == 1) {
								ChannelPriceWOOffer.put("ChannelPrice", reqcellValue);
							} else {

								if (reqcellValue.contains(":")) {
									String[] IncldueChannel = reqcellValue.split(":");
									ChannelPriceWOffer.put(IncldueChannel[0], IncldueChannel[1].substring(1).trim());

								}

							}

							i++;
							cellIterator.next();

						}
						ArrPremiumOff.add(ChannelPriceWOOffer);
						ArrPremiumOff.add(ChannelPriceWOffer);
						PremiumChannelMO.put(NoOfChannel, ArrPremiumOff);

					}
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return PremiumChannelMO;
	}

	public void MarketingOffValidation_stdalone(String object_val) throws Exception, UserDefinedException {

		// Reading the values from Input sheet for MO type, Description Display
		// in OfferTIle, Description Display in Details section
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl = "";
		getUrl = ", URL Launched --> " + returnURL();
		String MOType = get("MarketingOfferType");
		String OfferTileDisplay = get("OfferTileDesc");
		String[] off_tile = OfferTileDisplay.split(",");
		String OfferDisplayinDetails = get("OfferDescInDetails");
		String[] Offer = OfferDisplayinDetails.split(",");
		int offerlength = Offer.length;
		String Contract = get("Contract").substring(1);
		boolean offerDisplayed = false;

		long timeNow = System.currentTimeMillis();
		waitForLoader();

		ArrayList<String> offer_missed = new ArrayList<String>();
		ArrayList<String> offer_present = new ArrayList<String>();

		try {
			// Switch Frame
			switchToDefaultcontent();
			switchToFrame("IfProducts");

			waitForLoader();

			if (isDisplayed(standAloneOfferTile, object_val, 2)) {

				clickUsingJavaScript(standAloneOfferTile, object_val);
				String tile_text = getTextFromElement(standAloneOfferTile, object_val);
				System.out.println("tile_text" + tile_text);
				boolean tile = false;
				if (!OfferTileDisplay.isEmpty()) {

					for (String tile1 : off_tile) {
						if (tile_text.contains(tile1.trim())) {
							tile = true;
						} else {
							tile = false;
							break;
						}
					}
				} else {
					tile = true;
				}

				if (tile && !OfferDisplayinDetails.isEmpty()) {

					// Clicking on Detail link under the Offer TIle

					clickUsingJavaScript(standAloneOfferDetailsLink, object_val);

					String offerpopupdetails = getTextFromElement(MOInDetails, object_val);

					int offer_cnt = 0;
					for (int j = 0; j < offerlength; j++) {
						if (offerpopupdetails.contains(Offer[j].trim())) {

							offer_cnt = offer_cnt + 1;
							offer_present.add(Offer[j].trim());
							if (offer_cnt == offerlength) {
								offerDisplayed = true;
								break;
							}

						} else {
							offerDisplayed = false;
							offer_missed.add(Offer[j].trim());
						}

					}

					// Closing the Detail window
					clickUsingJavaScript(DetailsClose, objectValue);
				}

				if (offerDisplayed && MOType.toLowerCase().equalsIgnoreCase("positive")) {
					report.reportPass("Offer Display in bundle page",
							"Offers :" + "<br/>" + "<b>" + OfferDisplayinDetails + "<b/>"
									+ " is displayed in Bundle page",
							"Offers :" + "<br/>" + "<b>" + OfferDisplayinDetails + "<b/>"
									+ " Offers are getting sucessfully displayed in Bundle page");
				} else if (!offerDisplayed && MOType.toLowerCase().equalsIgnoreCase("positive")) {
					report.reportFail("Offer Display in bundle page",
							"Offers :" + "<br/>" + OfferDisplayinDetails + " is displayed in Bundle page",
							"Offers :" + "<br/>" + "<b>" + offer_missed + "<b/>"
									+ "Offers is not getting displayed in Bundle page");
				} else if (offerDisplayed && MOType.toLowerCase().equalsIgnoreCase("negative")) {
					report.reportFail("Offer Display in bundle page",
							"Offers :" + "<br/>" + OfferDisplayinDetails + " is displayed in Bundle page",
							"Offers :" + "<br/>" + "<b>" + offer_present + "<b/>"
									+ "Offers is not getting displayed in Bundle page");
				} else if (!offerDisplayed && MOType.toLowerCase().equalsIgnoreCase("negative")) {
					report.reportPass("Offer Display in bundle page",
							"Offers :" + "<br/>" + "<b>" + OfferDisplayinDetails + "<b/>"
									+ " is not displayed in Bundle page",
							"Offers :" + "<br/>" + "<b>" + OfferDisplayinDetails + "<b/>"
									+ " Offers are not getting  displayed in Bundle page");
				}

			}
		} catch (Exception e) {

		}

	}
	// Siva Ram Lanka - added code for coho

	public void selectCoHoOption() throws Exception, UserDefinedException {

		System.out.println("->selectCoHoOption");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "To negotiate CoHoOption section";
		strExpected = "CoHoOption section should be selected";
		strActual = "CoHoOption is negotiated successfully";
		getUrl = ", URL Launched --> " + returnURL();
		try {

			String CoHoProduct = get("SmartHomeAccessories").trim();
			String internetPlan = get("InternetPlan").trim();
			String strAccessoriesShipping = get("AccessoriesShipping").trim();

			if (!internetPlan.isEmpty()) {

				pageScroll(SmartHomeAccessoriesSecuritySupportStorage, "", true);
				clickUsingJavaScript(SmartHomeAccessoriesSecuritySupportStorage, "");
				waitForLoader();
				Thread.sleep(5000);

				if (CoHoProduct.equalsIgnoreCase("GethrHome Nest Starter Kit _LN")) {
					pageScroll(GethrHomeNestStarterKitLN, "", true);
					clickUsingJavaScript(GethrHomeNestStarterKitLN, "");
					waitForLoader();
					Thread.sleep(5000);
					report.reportPass("CoHo Products should be selected", "CoHo poduct need to be selected.",
							"Clicked on CoHo Products." + CoHoProduct);

				} else if (CoHoProduct.equalsIgnoreCase("GethrHome Nest Security Starter Kit_LN")) {

					pageScroll(GethrHomeNestSecurityStarterKitLN, "", true);
					clickUsingJavaScript(GethrHomeNestSecurityStarterKitLN, "");
					waitForLoader();
					Thread.sleep(5000);
					report.reportPass("CoHo Products should be selected", "CoHo poduct need to be selected.",
							"Clicked on CoHo Products." + CoHoProduct);
				} else {
					System.out.println("Mentioned CoHo Products not available:" + CoHoProduct);
					report.reportPass("CoHo Products should be selected.", "CoHo poduct need to be selected.",
							"Clicked on CoHo Products." + CoHoProduct);
				}
				if (!CoHoProduct.isEmpty()) {
					pageScroll(SmartHomeAccessories, "", true);
					clickUsingJavaScript(SmartHomeAccessories, "");
					waitForLoader();
					Thread.sleep(5000);
					report.reportPass("Selected CoHo Products should be expanded",
							"Selected CoHo Accessories to be Displayed.", "Selected CoHo Products are " + CoHoProduct);

					if (!strAccessoriesShipping.isEmpty()) {
						pageScroll(EquipmentDeliveryandReturn, "", true);
						clickUsingJavaScript(EquipmentDeliveryandReturn, "");
						waitForLoader();
						Thread.sleep(5000);
						report.reportPass("Selected EquipmentDeliveryandReturn should be expanded",
								"Selected EquipmentDeliveryandReturn to be Displayed.",
								"Selected EquipmentDeliveryandReturn");

						pageScroll(Accessories, "", true);
						clickUsingJavaScript(Accessories, "");
						waitForLoader();
						Thread.sleep(5000);
						report.reportPass("Selected Accessories should be expanded",
								"Selected Accessories to be Displayed.", "Selected Accessories");

						pageScroll(AccessoriesShipping, strAccessoriesShipping, true);
						clickUsingJavaScript(AccessoriesShipping, strAccessoriesShipping);
						waitForLoader();
						Thread.sleep(5000);
						report.reportPass("Selected AccessoriesShipping should be expanded",
								"Selected AccessoriesShipping to be Displayed.",
								"Selected AccessoriesShipping is  " + strAccessoriesShipping);

					} else {
						System.out.println(" AccessoriesShipping Products should not be empty");
					}

				} else {
					System.out.println(" SmartHomeAccessories Products should not be empty");
				}

			} else {
				System.out.println(" Internet Products should not be empty");
			}

		} catch (Exception exe) {
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in CoHo optoins section.");
			}
			throw exe;
		}

	}

	/*********** To Edit PIN****@author Bharathi*****SAC *******/
	public void editPIN() throws Exception {
		// TODO Auto-generated method stub

		getUrl = ", URL Launched --> " + returnURL();
		Thread.sleep(3000);
		// TODO Auto-generated method stub
		System.out.println("Trying to Edit pin");

		waitForLoader();

		if (editPINPopup.isDisplayed()) {

			clearText(pinNumber, objectValue);
			setText(pinNumber, objectValue, get("NEWPIN").trim());
			System.out.println("New PIN:" + get("NEWPIN"));
			report.reportPass("Opened Edit pin Popup", "Enter New PIN", "PIN Entered:" + get("NEWPIN"));
			waitForElementDisplay(savePIN, objectValue, pageTimeoutInSeconds);
			savePIN.click();
			waitForLoader();

			waitForElementDisplay(getPIN, objectValue, pageTimeoutInSeconds);

			String NewPIN = getPIN.getText();
			System.out.println("new pin text" + NewPIN);
			report.reportPass("PIN Updated in Snapshot" + getUrl,
					"New PIN" + get("NEWPIN") + "Entered matches Snapshot screen PIN" + NewPIN,
					"New PIN Updated:" + NewPIN);
			System.out.println("current url" + getUrl);
			waitForLoader();
		}

		Thread.sleep(2000);
	}

	/********* To Change Password*******SAC*********@author Bharathi ***/
	public void changePassword() throws Exception {
		// TODO Auto-generated method stub
		getUrl = ", URL Launched --> " + returnURL();
		System.out.println("trying to Change Password");

		Thread.sleep(3000);
		waitForLoader();
		if (Popup.isDisplayed()) {
			waitForElementDisplay(passwordTextbox, objectValue, pageTimeoutInSeconds);
			setText(passwordTextbox, objectValue, get("NewPassword").trim());
			report.reportPass("Opened Change Password popup" + getUrl, "Entered Password",
					"New Password Entered:" + get("NewPassword"));
			changePwdBtn.click();
		}
		System.out.println("Current URL" + getUrl);
		report.reportPass("Password Changed" + getUrl, "Entered Password",
				"New Password Entered:" + get("NewPassword"));
		Thread.sleep(2000);
	}

	/**
	 * @author Soham Shah
	 * @Date - 05 March 2018
	 */
	public void validateETFReviewOrder() throws Exception {
		try {
			System.out.println("---> Validating ETF in Review Order");
			if (get("Contract").equalsIgnoreCase("M2M") && get("FlowType").equalsIgnoreCase("Change")
					|| get("Contract").equalsIgnoreCase("M2M") && get("FlowType").equalsIgnoreCase("Move")) {

				pageScroll(oneTimeCharges);

				String strDescription = "For Term to M2M Order, check in Review Order page, whether ETF text is displayed or not";
				String strExpected = "ETF must be displayed in Review order";
				String strActual = "ETF is displayed in Review Order";
				String strFailed = "ETF is not displayed in Review Order";

				String etfText = oneTimeCharges_EarlyTerminationFee.getText().trim();
				String oneTimeCharges = oneTimeCharges_list.getText();

				if (etfText.equals("24 Month Bundle Early Termination Fee")) {
					report.reportPass(strDescription, strExpected,
							strActual + " - Products displayed under One Time Charges Section is " + oneTimeCharges);

				} else {
					report.reportFail(strDescription, strExpected,
							strFailed + " - Products displayed under One Time Charges Section is " + oneTimeCharges);
				}
			} else if (get("Contract").equalsIgnoreCase("2Year") && get("FlowType").equalsIgnoreCase("Change")
					|| get("Contract").equalsIgnoreCase("2Year") && get("FlowType").equalsIgnoreCase("Move")) {

				String strDescription = "For Term Order check whether ETF text is displayed in Review Order Page or not";
				String strExpected = "ETF text must not be displayed";
				String strActual = "ETF is not displayed";
				String strFailed = "ETF text is displayed";

				String oneTimeCharges = oneTimeCharges_list.getText();
				if (oneTimeCharges.contains("24 Month Bundle Early Termination Fee")) {
					report.reportFail(strDescription, strExpected,
							strFailed + " - Products displayed under One Time Charges Section is " + oneTimeCharges);

				} else {
					report.reportPass(strDescription, strExpected,
							strActual + " - Products displayed under One Time Charges Section is " + oneTimeCharges);

				}

			}

		} catch (Exception e) {

			report.reportFail("Failed in getting ETF Charges in Review Order Page",
					"Failed in getting ETF Charges in Review Order Page",
					"Failed in getting ETF Charges in Review Order Page");
			e.printStackTrace();
		}
	}

	/**
	 * @Description: if TV plan is selected ,verify RSN & BC charges
	 * @author: Naresh,Madipelly
	 * @return:No Return Type
	 * @ModifiedDate: 02-22-2018
	 */
	public void validateRSNBCFees() throws Exception {

		String tvPlan = get("TvPlan").trim();
		try {
			if (!tvPlan.isEmpty() && tvPlan != "Local") {
				pageScroll(scrollToViewRegionalSportsFee);
				String regionalSportsFee = getTextFromElement(getRegionalSportsFee, "");
				System.out.println("========================= Review Page  : Regional SPorts Fees is ::"
						+ regionalSportsFee + "===========================");
				String fiosTVBroadCastFee = getTextFromElement(getFiosTVBroadcastFee, "");
				System.out.println("========================= Review Page  : Fios TV BroadCast Fees is ::"
						+ fiosTVBroadCastFee + "===========================");

				if (regionalSportsFee.equalsIgnoreCase(regionalSportsFee)) {
					report.reportPass("Regioanl Sports Network fee",
							"Regional Sports Network fees is (read test data from runmanager) ",
							"Regional Sports Network fee is " + regionalSportsFee + " matching"); // change
																									// actual
																									// value,
																									// read
																									// it
																									// from
																									// runmanager
																									// time
																									// being
																									// putting
																									// expected
																									// actual
																									// same
				} else {
					report.reportFail("Regioanl Sports Network fee",
							"Regional Sports Network fees is (read test data from runmanager) ",
							"Regional Sports Network fee is " + regionalSportsFee + " is not matching");
				}

				if (fiosTVBroadCastFee.equalsIgnoreCase(fiosTVBroadCastFee)) {
					report.reportPass("Broadcast fee", "Broadcast fee  is (read test data from runmanager) ",
							"Broadcast fee is " + fiosTVBroadCastFee + " matching"); // change
																						// actual
																						// value,
																						// read
																						// it
																						// from
																						// runmanager
																						// time
																						// being
																						// putting
																						// expected
																						// actual
																						// same
				} else {
					report.reportFail("Broadcast fee", "Broadcast fee  is (read test data from runmanager)",
							"Broadcast fee is " + fiosTVBroadCastFee + " is not matching");
				}
			}
		} catch (Exception e) {

			e.printStackTrace();
			report.reportFail("RSN and BC fees validations in Review Page", "get RSN and BC values from Review Page",
					"Unable to get RSN and BC fees due to page unavailability");
			System.out.print("RSN and BC fees are not available in Review Page");
		}

	}

	/**
	 * @param Disconnect
	 * @param TaxApplicable
	 * @param FlowType
	 * @param S_No
	 * @info click on checkout tab
	 * @author Mounika Polagoni
	 * @Date: 04/12/2018
	 */
	public void Disconnect() throws Exception, UserDefinedException {

		System.out.println("->Disconnect Flow");
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "To negotiate Disconnect Flow";
		strExpected = " To negotiate Disconnect Flow";
		strActual = "To negotiate Disconnect Flow";
		getUrl = ", URL Launched --> " + returnURL();

		try {

			waitForLoader();
			try {
				// waitForElementDisplay(enableProducts, objectValue,
				// pageTimeoutInSeconds);
				waitForElementDisplay(OPOPage, getUrl, pageTimeoutInSeconds);
			} catch (Exception e) {

			}
			pause();
			pause();
			waitForLoader();
			waitForLoader();
			waitForLoader();
			report.reportPass("To check whether OPO is loaded", "To check whether OPO is loaded", "OPO is loaded");
			if (get("SubFlowType").equalsIgnoreCase("DisconnectSave")) {
				selectAdditionalOffer();
			} else {
				// setting frame
				switchToDefaultcontent();

				if (isDisplayed(clickQA, objectValue, 10)) {
					clickUsingJavaScript(clickQA, objectValue);
				}

				waitForLoader();
				waitForLoader();
				selectRGQuestoins(get("Questionaire"));

				waitForLoader();

				System.out.println();
				switchToDefaultcontent();
				waitForElementDisplay(confirmYes, objectValue, 60);
				clickUsingJavaScript(confirmYes, objectValue);
				waitForLoader();
				waitForLoader();
				waitForLoader();
				if (isDisplayed(saleswindow, objectValue, 60)) {
					report.reportPass("To check whether sales popup is displayed",
							"To check whether sales popup is displayed", "sales popup is displayed");
					clickUsingJavaScript(saleswindow, objectValue);

				}
				waitForLoader();
				waitForLoader();
				waitForLoader();
				try {
					waitForElementDisplay(IfProducts, getUrl, 100);
				} catch (Exception exe) {

				}

				// setting frame to required frame-'IfProducts'
				switchToDefaultcontent();
				switchToFrame("IfProducts");

				waitForLoader();
				waitForLoader();
				Thread.sleep(5000);
				if (isDisplayed(DisconnectLoyaltyCategory, objectValue, 3)) {
					try {
						selectDropDownUsingIndex(DisconnectLoyaltyCategory, objectValue, 1);
						report.reportPass("Select Disconnect Category in Disconnect Tab",
								"Select Disconnect category Customer Circumstances in Disconnect Tab if Exists",
								"Selecting Disconnect category Customer Circumstances in Disconnect Tab");
						waitForLoader();
						Thread.sleep(1000);
					} catch (Exception exe) {
						report.reportFail("Select Disconnect Category in Disconnect Tab",
								"Select Disconnect category if exists",
								"Not able to Select Disconnect category due to Object not displayed");
						report.updateMainReport("ErrorMessage",
								"Not able to Select Disconnect category due to Object not displayed");
						throw new UserDefinedException("Failed in Disconnect Page");

					}
				}
				if (isDisplayed(DisconnectLoyaltyReason, objectValue, 3)) {
					try {
						selectDropDownUsingIndex(DisconnectLoyaltyReason, getUrl, 1);
						report.reportPass("Select Disconnect Reason in Disconnect Tab",
								"Select Disconnect Reason Customer Cannot Afford in Disconnect Tab if Exists",
								"Selecting Disconnect Reason Customer Cannot Afford in Disconnect Tab");
						waitForLoader();
					} catch (Exception exe) {
						report.reportFail("Select Disconnect Reason in Disconnect Tab",
								"Select Disconnect Reason if exists",
								"Not able to Select Disconnect Reason due to Object not displayed");
						report.updateMainReport("ErrorMessage",
								"Not able to Select Disconnect Reason due to Object not displayed");
						throw new UserDefinedException("Failed in Disconnect Page");

					}
				}

				if (isDisplayed(checkbxConfirm, objectValue)) {
					try {
						clickUsingJavaScript(checkbxConfirm, objectValue);
						report.reportPass("Select Checkbox Confirm in Disconnect Tab",
								"Select Checkbox Confirm in Disconnect Tab if Exists",
								"Selecting Checkbox Confirm in Disconnect Tab");
						waitForLoader();
					} catch (Exception exe) {
						report.reportFail("Select Checkbox Confirm in Disconnect Tab",
								"Select Checkbox Confirm in Disconnect Tab if exists",
								"Not able to Click Checkbox Confirm in Disconnect Tab due to Object not displayed");
						report.updateMainReport("ErrorMessage",
								"Not able to Click Checkbox Confirm in Disconnect Tab due to Object not displayed");
						throw new UserDefinedException("Failed in Disconnect Page");

					}
				}

				if (isDisplayed(btnSaveContinue, "")) {
					try {
						clickUsingJavaScript(btnSaveContinue, objectValue);
						report.reportPass("Click Save And Continue", "Click Save And Continue if Exists",
								"Click Save And Continue");
					} catch (Exception exe) {
						report.reportFail("Click Save And Continue Button", "Click Save And Continue Button if Exists",
								"Not able to Click Save And Continue Button in Discoonect Tab due to Object not displayed");
						report.updateMainReport("ErrorMessage",
								"Not able to click Click Save And Continue Button in Discoonect Tab due to Object not displayed");
						throw new UserDefinedException("Failed in Disconnect Page");

					}
				}
				waitForLoader();
				waitForLoader();
				// Click Proceed
				if (isDisplayed(btnproceed, "")) {
					try {
						clickUsingJavaScript(btnproceed, objectValue);
						report.reportPass("Click button proceed in partial disconnect flow",
								"Click button proceed in partial disconnect flow if Exists",
								"Clicking button proceed in partial disconnect flow");
						waitForLoader();
					} catch (Exception exe) {
						report.reportFail("Click button proceed in partial disconnect flow",
								"Select button proceed in partial disconnect flow if exists",
								"Not able to button proceed in partial disconnect flow due to Object not displayed");
						report.updateMainReport("ErrorMessage",
								"Not able to button proceed in partial disconnect flow due to Object not displayed");
						throw new UserDefinedException("Failed in Disconnect Page");

					}
				}
				if (get("ChangeType").equalsIgnoreCase("Disconnect") || get("SubFlowType").equalsIgnoreCase("SA")) {

					// for disconnect

					if (isDisplayed(SelectIntercept, objectValue, 3)) {
						report.reportPass("Check whether Intercepts Popup dispalyed",
								"Check whether Intercepts Popup is dispalyed", "Intercepts Popup is displayed");
						mouseOver(SelectIntercept, objectValue);
						clickUsingJavaScript(SelectIntercept, objectValue);
						waitForLoader();
						waitForLoader();
						mouseOver(InterceptsOK, objectValue);
						clickUsingJavaScript(InterceptsOK, objectValue);
						report.reportPass("Check whether Intercepts Popup dispalyed",
								"Check whether Intercepts Popup is dispalyed", "Intercepts Popup is displayed");
						waitForLoader();
						waitForLoader();

					}

					if (isDisplayed(btnFiosSaveContinue, objectValue)) {
						clickUsingJavaScript(btnFiosSaveContinue, objectValue);
						waitForLoader();
						waitForLoader();
					}

					else if (isDisplayed(btnFDVSaveContinue, objectValue)) {
						clickUsingJavaScript(btnFDVSaveContinue, objectValue);
						waitForLoader();
						waitForLoader();
					}
					try {
						if (isDisplayed(disconnectSaveContinue, objectValue)) {
							clickUsingJavaScript(disconnectSaveContinue, objectValue);
							report.reportPass("Click Save And Continue In Disconnect",
									"Click Save And Continue In Disconnect if Exists",
									"Click Save And Continue In Disconnect");
							waitForLoader();
						}
					} catch (Exception exe) {
						report.reportFail("Click Save And Continue Button", "Click Save And Continue Button if Exists",
								"Not able to Click Save And Continue Button due to Object not displayed");
						report.updateMainReport("ErrorMessage",
								"Not able to click Click Save And Continue Button due to Object not displayed");
						throw new UserDefinedException("Failed in Disconnect Page");

					}

				} else {

					if (isDisplayed(OPOPage, objectValue, 30)) {
						report.reportPass("OPO Page should be dispalyed", "OPO Page should be dispalyed",
								"OPO Page is dispalyed");

						if (isDisplayed(FDVRemoved, getUrl, 5)) {

							if (isDisplayed(InterceptsPleaseReview, getUrl, 5)) {
								pageScroll(InterceptsPleaseReview, getUrl, true);
								report.reportPass("Check whether Please Review is dispalyed",
										"Check whether Please Review is dispalyed", "Please Review is displayed");
								clickUsingJavaScript(InterceptsPleaseReview, getUrl);
								waitForLoader();
								waitForLoader();
								clickUsingJavaScript(MoreOptions, objectValue);
								waitForLoader();
								waitForLoader();
								waitForLoader();
								report.reportPass("Check whether Intercepts Popup dispalyed",
										"Check whether Intercepts Popup is dispalyed", "Intercepts Popup is displayed");
								clickUsingJavaScript(saveChanges, objectValue);
								waitForLoader();
								waitForLoader();
								goToCheckout();

							} else {
								strFailed = "Intercepts popup is not displayed";
								logger.error(strFailed);
								report.reportFail("Select Intercepts", "Intercepts should be selected.", strFailed);
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);
							}
						}

						else {
							selectPackage();
						}
					}
				}

			}

		} catch (Exception exe) {
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in clicking review button.");
			}
			throw exe;
		}
	}

	/**
	 * Selects RG questions in sequence from given semicolon separated
	 * questioner data.
	 * 
	 * @author Mounika Polagoni
	 * @param semicolonSeperatedQuestions
	 * @throws Exception
	 */
	public void selectRGQuestoins(String semicolonSeperatedQuestions) throws Exception {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		String getUrl = "";

		try {
			strDescription = "Selecting RG Questions";
			strExpected = "Answering RG questions and completing the flow.";
			strActual = "Answering RG Questions in RG Page was successful";
			strFailed = "Answering RG Questions in RG Page was not successful";

			waitForLoader();
			switchToDefaultcontent();
			getUrl = ", URL Launched --> " + returnURL();

			try {
				if (get("ChangeType").contains("Disconnect")) {
					waitForElementDisplay(getQuestionerType, "LOYAL", pageTimeoutInSeconds);
				}

				System.out.println("RG Page-->Negotiating RG");
			} catch (Exception e) {

				strFailed = "RG page is not loaded even after 80 seconds";
				logger.error(strFailed);

				report.updateMainReport("comments", strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg(strFailed);

				report.reportFail("Check display of RG page", "RG page should be loaded and displayed.",
						"RG page was not loaded.");
				throw new UserDefinedException("RG page is not loaded even after 80 seconds");
			}

			String[] Ques = semicolonSeperatedQuestions.split(";");

			for (String currentAns : Ques) {

				String[] optionalAns = currentAns.split("<OR>");

				for (String ans : optionalAns) {
					if (ans.contains("#")) {
						String[] ans2 = ans.split("#");
						for (String currentans2 : ans2) {
							clickUsingJavaScript(RGQuestions, currentans2.trim());
							report.reportPass("Select RG questions", currentans2 + " should be selected.",
									"selected " + currentans2 + " RG question");
						}
					}

					if (isDisplayed(RGQuestions, ans.trim(), 1)) {
						clickUsingJavaScript(RGQuestions, ans.trim());
						report.reportPass("Select RG questions", ans + " should be selected.",
								"selected " + ans + " RG question");
						break;
					} else {

						// Enable below statements validate RG specific RG
						// questions --- Shiva
						// report.reportFail("Select RG questions", ans + "
						// should be selected.", "Unable to select " + v + "
						// RG question");
						// throw new UserDefinedException(ans+"Answer was
						// not available.");
					}

				}

				if (btnRGNextList.size() > 0) {

					if (isDisplayed(btnRGNext, "", 0)) {
						clickUsingJavaScript(btnRGNext, objectValue);
						waitForLoader();
						switchToDefaultcontent();
					}
				}
				// Entering Billing Telephone Number in check port
				// eligibility pag
				if (txtBTNList.size() > 0) {
					try {

						if (isDisplayed(txtBTN, "", 0)) {
							setText(txtBTN, objectValue, get("Alternate_Phone_No"));
							waitForLoader();
							switchToDefaultcontent();
						}
					}

					catch (Exception e) {
						System.out.println(
								"Billing Telephone Number is not present in this flow as no check portability page ");
					}
				}

				// Click on Next button in check port eligibility page
				if (btnBTNxtList.size() > 0) {
					try {

						if (isDisplayed(btnBTNxt, "", 0)) {
							clickUsingJavaScript(btnBTNxt, objectValue);
							waitForLoader();
							switchToDefaultcontent();
						}
					} catch (Exception e) {
						System.out.println("Next Button present in this flow as no check portability page ");
					}

				}

			}

			waitForLoader();
			waitForLoader();

			if (get("FlowType").equalsIgnoreCase("Install") || (get("FlowType").contains("Move"))
					|| (get("FlowType").equalsIgnoreCase("MoveAsIs"))) {
				if (!isNotDisplayed(addressValidated, 100)) {
					strFailed = "Failed in RG Selection, RG questionnaire was not correct..please check the given data.";
					logger.error(strFailed);
					report.reportFail("Select RG questions.", "RG questions should be selected according to flow.",
							strFailed);
					report.updateMainReport("comments", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					captureErrorMsg(strFailed);
					throw new UserDefinedException(strFailed);
				}
			} else if (get("ChangeType").contains("Disconnect")) {
				if (!isNotDisplayed(Disconnect, 100)) {
					strFailed = "Failed in RG Selection, RG questionnaire was not correct..please check the given data.";
					logger.error(strFailed);
					report.reportFail("Select RG questions.", "RG questions should be selected according to flow.",
							strFailed);
					report.updateMainReport("comments", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					captureErrorMsg(strFailed);
					throw new UserDefinedException(strFailed);

				}

			}

			waitForLoader();

			report.reportPass(strDescription + getUrl, strExpected, strActual);
			waitForLoader();

		} catch (Exception exe) {
			exe.printStackTrace();
			if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
			}

			throw exe;
		}

	}

	/**
	 * @Info TechSure
	 * 
	 * @throws Exception
	 * @Modified by Naresh
	 * 
	 * @LastUpdated 10/04/2018
	 */

	public void vasScenario_TechSureProduct() throws Exception {
		if ((get("VASProduct").equalsIgnoreCase("TechSure Plus"))
				|| (get("VASProduct").equalsIgnoreCase("TechSure Premium"))) {
			// System.out.println(get("VAS_FirstName"));

			System.out.println("");
			switchToFrame("IfProducts");
			if (!tabVAS.getAttribute("class").contains("open")) {
				pageScroll(tabVAS, objectValue, true);
				clickUsingJavaScript(tabVAS, objectValue);
				waitForLoader();
			}
			System.out.println("");
			System.out.println("");
			if (get("VASProduct").equalsIgnoreCase("TechSure Plus")) {
				clickUsingJavaScript(VASProduct_TechSurePlus_ProductsPage, "");
			} else if (get("VASProduct").equalsIgnoreCase("TechSure Premium")) {
				clickUsingJavaScript(VASProduct_TechSurePremium_ProductsPage, "");
				waitForLoader();
				clickUsingJavaScript(VASProduct_TechSurePremium_Coverage, objectValue);
			}
			System.out.println("");
			switchToFrame("IfProducts");
			setText(VAS_FirstName, "", "Passlow");
			report.reportPass(
					"For VAS Product " + get("VASProduct").trim() + " input must be provided in First Name field",
					"Input provided in First Name Field", "Input provided in First Name field is .Passlow");
			setText(VAS_LastName, "", "Customer");
			report.reportPass(
					"For VAS Product " + get("VASProduct").trim() + " input must be provided in Last Name field",
					"Input provided in Last Name Field", "Input provided in Last Name field is .Customer");

			// check for Junior & Senior selection
			if (get("TechSure_LifeLock_Adult").equalsIgnoreCase("Yes")) {
				if (get("TechSure_LifeLock_Adult_Quantity").equals("1")) {
					clickUsingJavaScript(VAS_LifeLock_Adult, objectValue);
					setText(VAS_LifeLock_Adult_FirstName, "", "Yugendher");
					report.reportPass(
							"For Tech Sure - LifeLock Adult Product input must be provided in First Name field",
							"Input provided in First Name Field", "Input provided in First Name field is .Yegendher");

					setText(VAS_LifeLock_Adult_LastName, "", "Reddy");
					report.reportPass(
							"For Tech Sure - LifeLock Adult Product input must be provided in Last Name field",
							"Input provided in Last Name Field", "Input provided in Last Name field is .Reddy");

					setText(VAS_LifeLock_Adult_Email, "", "yugendhar.m.reddy@g.verizon.com");
					report.reportPass(
							"For Tech Sure - LifeLock Adult Product input must be provided in Email Name field",
							"Input provided in Email Field",
							"Input provided in Last Name field is .yugendhar.m.reddy@g.verizon.com");

				} else if (get("TechSure_LifeLock_Adult_Quantity").equals("2")) {
					clickUsingJavaScript(VAS_LifeLock_Adult, objectValue);
					setText(VAS_LifeLock_Adult_FirstName, "", "Yugendher");
					report.reportPass(
							"For Tech Sure - LifeLock Adult Product input must be provided in First Name field",
							"Input provided in First Name Field", "Input provided in First Name field is .Yugendher");

					setText(VAS_LifeLock_Adult_LastName, "", "Reddy");
					report.reportPass(
							"For Tech Sure - LifeLock Adult Product input must be provided in Last Name field",
							"Input provided in Last Name Field", "Input provided in Last Name field is .Reddy");

					setText(VAS_LifeLock_Adult_Email, "", "yugendhar.m.reddy@g.verizon.com");
					report.reportPass(
							"For Tech Sure - LifeLock Adult Product input must be provided in Email Name field",
							"Input provided in Email Field",
							"Input provided in Last Name field is . yugendhar.m.reddy@g.verizon.com");

					clickUsingJavaScript(VAS_LifeLock_Adult, objectValue);
					report.reportPass(
							"For Tech Sure - LifeLock Adult Product Add More Subscription link must be clicked",
							"Add more subscription link is clicked", "Add more subscription link is clicked");
					Thread.sleep(1000);
					setText(VAS_LifeLock_Adult_FirstName_2, "", "Naresh");
					report.reportPass(
							"For Tech Sure - LifeLock Adult Product input must be provided in First Name field",
							"Input provided in First Name Field", "Input provided in First Name field is . Naresh");

					setText(VAS_LifeLock_Adult_LastName_2, "", "Madipelly");
					report.reportPass(
							"For Tech Sure - LifeLock Adult Product input must be provided in Last Name field",
							"Input provided in Last Name Field", "Input provided in Last Name field is . Madipelly");

					setText(VAS_LifeLock_Adult_Email_2, "", "naresh.madipelly2@verizon.com");
					report.reportPass(
							"For Tech Sure - LifeLock Adult Product input must be provided in Email Name field",
							"Input provided in Email Field",
							"Input provided in Last Name field is . naresh.madipelly2@verizon.com");

				}

			}
			if (get("TechSure_LifeLock_Junior").equalsIgnoreCase("Yes")) {
				if (get("TechSure_LifeLock_Junior_Quantity").equals("1")) {
					clickUsingJavaScript(VAS_LifeLock_Junior, objectValue);
					setText(VAS_LifeLock_Junior_FirstName, "", "Soham");
					report.reportPass(
							"For Tech Sure - LifeLock Junior Product input must be provided in First Name field",
							"Input provided in First Name Field", "Input provided in First Name field is . Soham");
					setText(VAS_LifeLock_Junior_LastName, "", "Shah");
					report.reportPass(
							"For Tech Sure - LifeLock Junior Product input must be provided in Last Name field",
							"Input provided in Last Name Field", "Input provided in Last Name field is .Shah");

				} else if (get("TechSure_LifeLock_Junior_Quantity").equals("2")) {
					clickUsingJavaScript(VAS_LifeLock_Junior, objectValue);
					setText(VAS_LifeLock_Junior_FirstName, "", "Soham");
					report.reportPass(
							"For Tech Sure - LifeLock Junior Product input must be provided in First Name field",
							"Input provided in First Name Field", "Input provided in First Name field is .Soham");
					setText(VAS_LifeLock_Junior_LastName, "", "Shah");
					report.reportPass(
							"For Tech Sure - LifeLock Junior Product input must be provided in Last Name field",
							"Input provided in Last Name Field", "Input provided in Last Name field is .Shah");

					clickUsingJavaScript(VAS_LifeLock_Junior, objectValue);
					Thread.sleep(1000);
					setText(VAS_LifeLock_Child_FirstName_2, "", "Alpha");
					report.reportPass(
							"For Tech Sure - LifeLock Junior Product input must be provided in First Name field",
							"Input provided in First Name Field", "Input provided in First Name field is .Alpha");
					setText(VAS_LifeLock_Child_LastName_2, "", "Beta");
					report.reportPass(
							"For Tech Sure - LifeLock Junior Product input must be provided in Last Name field",
							"Input provided in Last Name Field", "Input provided in Last Name field is .Beta");

				}

			}

			clickUsingJavaScript(VASSaveandContinueTechSure, objectValue);
			report.reportPass("Click on VAS save and continue button.", "Save and continue button should be clicked.",
					"Clicked on save and continue button.");
		}

		if (get("VAS_TechSure_Product").equalsIgnoreCase("TechSure")) {

			clickUsingJavaScript(VASProduct_TechSure_ProductsPage, "");
			report.reportPass("Verify VASProduct is Selected", "Check whether Vas Product is Clicked",
					"VAS Product is Clicked:" + get("VAS_TechSure_Product"));
			String vasproductText = VASProduct_TechSure_ProductsPage.getText();
			if (vasproductText.equals(get("VAS_TechSure_Product"))) {
				report.reportPass("Check whehter correct VAS product is displayed in VAS Section or not",
						"Selected VAS Product is displayed", "Selected VAS Product is:" + get("VAS_TechSure_Product"));

			} else {
				report.reportFail("Check whehter selected VAS product is displayed in VAS Section or not",
						"Selected VAS Product is displayed", "Selected VAS Product is:" + get("VAS_TechSure_Product"));

			}
		}

		if (tabVAS.getAttribute("class").contains("open")) {
			pageScroll(tabVAS, "", true);
			clickUsingJavaScript(tabVAS, objectValue);
		}
		// Switching to Default Content
		switchToDefaultcontent();
		switchToFrame("IfProducts");

		String CoHoProduct = get("SmartHomeAccessories").trim();
		if (!CoHoProduct.isEmpty()) {

			selectCoHoOption();

		}

		// Moving to LEC Option
		SelectsetupInstall();

	}

	// Naresh IWMP Changes

	public void validateIWMP() throws Exception {

		if (get("VASProduct").equals("Inside Wire Maintenance")) {
			if (IWMPValidationReviewOrder.isDisplayed()) {
				report.reportPass("Verify whether Inside wire maintenance is added in Review page or not",
						"Inside Wire Maintenance should display in Review Order Page",
						"Inside Wire Maintenance price is added in Review order page");
			} else {
				report.reportFail("Verify whether Inside wire maintenance is added in Review page or not",
						"Inside Wire Maintenance should display in Review Order Page",
						"Inside Wire Maintenance price is not added in Review order page");
			}
		}
	}

	/*********************************** lakshmi ***********************************/

	// Added to select Additional offer/bookshelf offers -BHARATHI J
	public void selectAdditionalOffer() throws Exception {
		try {

			String addOffer = get("AdditionalOffer").trim();
			getUrl = ", URL Launched --> " + returnURL();
			System.out.println("selectAdditionalOffer");
			switchToDefaultcontent();
			switchToFrame("IfProducts");
			waitForElementDisplay(Valueaddedoffersection, objectValue, pageTimeoutInSeconds);
			pageScroll(Valueaddedoffersection, objectValue, true);
			clickUsingJavaScript(Valueaddedoffersection, objectValue);
			report.reportPass("Expand Additional offer section", "Expanded", "Passed");
			waitForLoader();

			if (!addOffer.isEmpty()) {
				pageScroll(SelectRetainOffer, objectValue, true);

				if (isDisplayed(NRCRetainOffer, addOffer, 1)) {
					clickUsingJavaScript(NRCRetainOffer, addOffer);
					report.reportPass("Selected NRC offer" + getUrl, "Offer selected", "Offer Selected" + addOffer);
				} else {
					clickUsingJavaScript(SelectRetainOffer, addOffer);
					report.reportPass("Selected offer" + getUrl, "Offer selected", "Offer Selected" + addOffer);
				}
				waitForLoader();

			}
			goToCheckout();
		} catch (Exception e) {
			if (!isUserDefinedException(e)) {
				report.reportFail("Failed at Retain offer section" + getUrl, "Retain offer not found",
						"Failed while selecting retain offer");
				report.updateMainReport("ErrorMessage", "Failed while selecting retain offer");
				captureErrorMsg("Failed in SetupInstall section.");
			}
		}

	}

	public void Validateinreview() throws Exception {

		String strFailed = "";
		if (get("NoOfTV_Price").contains("New")) {

			String newTVcount = get("NoOfTv").trim();
			String desc_in_review = "Rent: " + newTVcount + " Set-Top Box";

			String New_NoOfTV_Price = "";

			if (Integer.valueOf(newTVcount) == 1) {

				New_NoOfTV_Price = "$12";
			} else if (Integer.valueOf(newTVcount) == 2) {

				New_NoOfTV_Price = "$24";
			} else if (Integer.valueOf(newTVcount) == 3) {

				New_NoOfTV_Price = "$30";
			} else if (Integer.valueOf(newTVcount) == 4) {

				New_NoOfTV_Price = "$36";
			} else if (Integer.valueOf(newTVcount) >= 5) {

				New_NoOfTV_Price = "$42";
			}

			try {
				WebElement TVdetail = driver.findElement(By
						.xpath("//*[@ng-repeat ='product in EstimatedMonthlyProducts track by $index']/div[1][contains(text(),'New')]/following-sibling::div[1][contains(.,'"
								+ desc_in_review + "')]/following-sibling::div[1][contains(.,'" + New_NoOfTV_Price
								+ "')]"));
				if (TVdetail.isDisplayed()) {

					report.reportPass("Verify ReView page",
							desc_in_review + "=" + New_NoOfTV_Price + " should be displayed in review page",
							desc_in_review + "=" + New_NoOfTV_Price + " is displayed in review page");
				} else {
					report.reportFail("Verify ReView page",
							desc_in_review + "=" + New_NoOfTV_Price + " should be displayed in review page",
							desc_in_review + "=" + New_NoOfTV_Price + " is not displayed in review page");
					strFailed = desc_in_review + "=" + New_NoOfTV_Price + " is not displayed in review page";
					throw new UserDefinedException(strFailed);
				}
			} catch (Exception ex) {
				report.reportFail("Verify ReView page",
						desc_in_review + "=" + New_NoOfTV_Price + " should be displayed in review page",
						desc_in_review + "=" + New_NoOfTV_Price + " is not displayed in review page");
				strFailed = desc_in_review + "=" + New_NoOfTV_Price + " is not displayed in review page";
				throw new UserDefinedException(strFailed);

			}
		}

	}

	void validateHNP() throws Exception {
		String HNP = get("HNP").trim();

		String strFailed = "";
		if (!HNP.isEmpty()) {

			switchToDefaultcontent();

			switchToFrame("IfProducts");

			// Expanding VAS tab
			if (!tabVAS.getAttribute("class").contains("open")) {
				pageScroll(tabVAS, objectValue, true);
				clickUsingJavaScript(tabVAS, objectValue);
				report.reportPass("Expand BBE", "Expand BBE", "BBE is expanded");
				waitForLoader();
			}

			if (HNP.equalsIgnoreCase("AutoAdded")) {

				try {
					if (isDisplayed(HNP_selected_disabled)) {

						report.reportPass("validate Home Network Protection",
								"Home Network Protection should be automatically added",
								"Home Network Protection is automatically added");

					} else {

						report.reportFail("validate Home Network Protection",
								"Home Network Protection should be automatically added",
								"Home Network Protection is not automatically added");
						strFailed = "Home Network Protection is not automatically added";
						throw new UserDefinedException(strFailed);
					}
				} catch (Exception ex) {

					report.reportFail("validate Home Network Protection",
							"Home Network Protection should be automatically added",
							"Home Network Protection is not automatically added");
					strFailed = "Home Network Protection is not automatically added";
					throw new UserDefinedException(strFailed);
				}

			}

			else if (HNP.equalsIgnoreCase("NotAutoAdded")) {
				try {
					if (!isDisplayed(HNP_selected_disabled)) {

						report.reportPass("validate Home Network Protection",
								"Home Network Protection should not be automatically added",
								"Home Network Protection is not automatically added");

					} else {

						report.reportFail("validate Home Network Protection",
								"Home Network Protection should not be automatically added",
								"Home Network Protection is automatically added");
						strFailed = "Home Network Protection is automatically added";
						throw new UserDefinedException(strFailed);
					}
				} catch (Exception ex) {

					report.reportPass("validate Home Network Protection",
							"Home Network Protection should not be automatically added",
							"Home Network Protection is not automatically added");
				}

			} else if (HNP.equalsIgnoreCase("blockdeletion")) {
				try {
					if (isDisplayed(HNP_selected_disabled)) {

						report.reportPass("validate Home Network Protection",
								"Home Network Protection should be disbaled and grayed out",
								"Home Network Protection is disbaled and grayed out");

					} else {

						report.reportFail("validate Home Network Protection",
								"Home Network Protection should be disbaled and grayed out",
								"Home Network Protection is not disbaled and not grayed out");
						strFailed = "Home Network Protection is disbaled and  not grayed out";
						throw new UserDefinedException(strFailed);
					}
				} catch (Exception ex) {
					report.reportFail("validate Home Network Protection",
							"Home Network Protection should be disbaled and grayed out",
							"Home Network Protection is not disbaled and not grayed out");
					strFailed = "Home Network Protection is disbaled and  not grayed out";
					throw new UserDefinedException(strFailed);
				}
			}
			if (tabVAS.getAttribute("class").contains("open")) {
				pageScroll(tabVAS, "", true);
				clickUsingJavaScript(tabVAS, objectValue);
			}
			// Switching to Default Content
			switchToDefaultcontent();
			switchToFrame("IfProducts");

		}

	}

	// Added By Naresh,Madipelly : Exchange Options
	public void ExchangeOptions() {

		if (isDisplayed(simplex_SelectedTV, "", 3)) {
			if (isDisplayed(vmsClickOnExchangeOptions, "", 3)) {
				try {
					clickUsingJavaScript(vmsClickOnExchangeOptions, objectValue);
					waitForLoader();
					waitForLoader();
					clickUsingJavaScript(vmstoWifiVoiceRemote, get("ExchangeOptions"));
					waitForLoader();
					waitForLoader();

					if (isDisplayed(vmsReadExchangeOptionsTermsToCustomer, "", 3)) {
						report.reportPass("Validate New Set up box terms and conditions",
								"Valdiate all the Terms and conditions are displaying to customer or not",
								"All the terms and conditions are displaying to customer");
						clickUsingJavaScript(vmsReadExchangeOptionsTermsToCustomer, objectValue);
						waitForLoader();
						clickUsingJavaScript(vmsUpdateExchangeOptions, objectValue);
						waitForLoader();

						if (isDisplayed(isVMSSelected)) {
							report.reportPass("Validate whether VMS is selected or not", "VMS should be selected",
									"VMS is selected");
						} else {
							report.reportFail("Validate whether VMS is selected or not", "VMS should be selected",
									"VMS is not selected");
						}
					} else {
						report.reportFail("Validate New Set up box terms and conditions",
								"Valdiate all the Terms and conditions are displaying to customer or not",
								"All the terms and conditions are not displaying to customer");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

	// Added By Naresh,Madipelly : Exchange Options
	public void validateEquipmentDeliveryAndReturns() {

		if (!get("ExchangeOptions").isEmpty()) {
			try {
				// pageScroll(EquipmentDeliveryandReturn, "", true);
				waitForLoader();
				// clickUsingJavaScript(EquipmentDeliveryandReturn, "");
				waitForLoader();
				// Thread.sleep(5000);
				// report.reportPass("Selected EquipmentDeliveryandReturn should
				// be expanded", "Selected EquipmentDeliveryandReturn to be
				// Displayed.", "Selected EquipmentDeliveryandReturn");

				// clickUsingJavaScript(deliveryOptions_tvEquipTechnicialInstall,
				// objectValue);
				waitForLoader();
				CList<Element> returningItems = getElementList(getItemsToBeReturned, objectValue);

				String items = returningItems.get(0).getText();
				// clickUsingJavaScript(EquipmentDeliveryandReturn, "");
				System.out.println("Total Items :" + items);
				String itemsToBeReturned = returningItems.get(1).getText();
				System.out.println("Total Items to be returned :" + itemsToBeReturned);
				if (items.equals(itemsToBeReturned)) {
					report.reportPass("Validate Items to be returned",
							"Total items should match with Items to be returned",
							"Items to be returned is matching with total items");
				} else {
					report.reportFail("Validate Items to be returned",
							"Total items should match with Items to be returned",
							"Items to be returned is not matching with total items");
				}

				waitForLoader();

				if (!get("MoreOffers").isEmpty()) {
					if (isDisplayed(LoyaltyAdditionalOffers, "", 3)) {
						waitForLoader();
						clickUsingJavaScript(LoyaltyAdditionalOffers, objectValue);

						if (isDisplayed(MoreOfffers, "", 3)) {
							waitForLoader();
							clickUsingJavaScript(MoreOfffers, objectValue);
							waitForLoader();
							if (isDisplayed(FionQuantumGateway_Data, objectValue, 3)) {
								clickUsingJavaScript(FionQuantumGateway_Data, objectValue);
								report.reportPass("Select Fios Quatum Gateway -Data Router",
										"Should able to select the router", "Able to select the router");
								clickUsingJavaScript(UpdateManualOffers, objectValue);
								waitForLoader();
								waitForLoader();
							}

						}
					}
				}

			} catch (Exception e) {

				e.printStackTrace();
			}

		}

	}

	public void Partialdisconnectreason() throws Exception {
		if (get("ChangeType").equalsIgnoreCase("Loyalty")) {
			// waitForElementDisplay(IfProducts, objectValue,
			// pageTimeoutInSeconds);
		}
		switchToDefaultcontent();
		switchToFrame("IfProducts");
		waitForLoader();
		Thread.sleep(10000);
		waitForLoader();
		waitForLoader();
		if (isDisplayed(DisconnectReason, objectValue, 3)) {
			try {
				// selectDropDownUsingVisibleText(DisconnectCategory,
				// objectValue, "Customer Circumstances");

				report.reportPass("Select Disconnect Category in Disconnect Tab",
						"Select Disconnect category Customer Circumstances in Disconnect Tab if Exists",
						"Selecting Disconnect category Customer Circumstances in Disconnect Tab");
				waitForLoader();
				Thread.sleep(1000);
			} catch (Exception exe) {
				report.reportFail("Select Disconnect Category in Disconnect Tab",
						"Select Disconnect category if exists",
						"Not able to Select Disconnect category due to Object not displayed");
				report.updateMainReport("ErrorMessage",
						"Not able to Select Disconnect category due to Object not displayed");
				throw new UserDefinedException("Failed in Disconnect Page");

			}

			try {
				selectDropDownUsingVisibleText(DisconnectReason, objectValue, "Better Offer from Cable Competitor");
				report.reportPass("Select Disconnect Reason in Disconnect Tab",
						"Select Disconnect Reason Customer Cannot Afford in Disconnect Tab if Exists",
						"Selecting Disconnect Reason Customer Cannot Afford in Disconnect Tab");
				waitForLoader();
			} catch (Exception exe) {
				report.reportFail("Select Disconnect Reason in Disconnect Tab", "Select Disconnect Reason if exists",
						"Not able to Select Disconnect Reason due to Object not displayed");
				report.updateMainReport("ErrorMessage",
						"Not able to Select Disconnect Reason due to Object not displayed");
				throw new UserDefinedException("Failed in Disconnect Page");
			}

			if (isDisplayed(checkbxConfirm, objectValue)) {
				try {
					clickUsingJavaScript(checkbxConfirm, objectValue);
					report.reportPass("Select Checkbox Confirm in Disconnect Tab",
							"Select Checkbox Confirm in Disconnect Tab if Exists",
							"Selecting Checkbox Confirm in Disconnect Tab");
					waitForLoader();
				} catch (Exception exe) {
					report.reportFail("Select Checkbox Confirm in Disconnect Tab",
							"Select Checkbox Confirm in Disconnect Tab if exists",
							"Not able to Click Checkbox Confirm in Disconnect Tab due to Object not displayed");
					report.updateMainReport("ErrorMessage",
							"Not able to Click Checkbox Confirm in Disconnect Tab due to Object not displayed");
					throw new UserDefinedException("Failed in Disconnect Page");

				}
			}

			if (isDisplayed(btnSaveContinue, "")) {
				try {
					clickUsingJavaScript(btnSaveContinue, objectValue);
					report.reportPass("Click Save And Continue", "Click Save And Continue if Exists",
							"Click Save And Continue");
				} catch (Exception exe) {
					report.reportFail("Click Save And Continue Button", "Click Save And Continue Button if Exists",
							"Not able to Click Save And Continue Button in Discoonect Tab due to Object not displayed");
					report.updateMainReport("ErrorMessage",
							"Not able to click Click Save And Continue Button in Discoonect Tab due to Object not displayed");
					throw new UserDefinedException("Failed in Disconnect Page");

				}
			}

			waitForLoader();
			waitForLoader();
			// Click Proceed
			if (isDisplayed(Disconnectsave, "")) {
				try {
					clickUsingJavaScript(Disconnectsave, objectValue);
					report.reportPass("Click button Save and continue in partial disconnect flow",
							"Click button proceed in partial disconnect flow if Exists",
							"Clicking button proceed in partial disconnect flow");
					waitForLoader();
				} catch (Exception exe) {
					report.reportFail("Click button proceed in partial disconnect flow",
							"Select button proceed in partial disconnect flow if exists",
							"Not able to button proceed in partial disconnect flow due to Object not displayed");
					report.updateMainReport("ErrorMessage",
							"Not able to button proceed in partial disconnect flow due to Object not displayed");
					throw new UserDefinedException("Failed in Disconnect Page");

				}
			}

			waitForLoader();
			waitForLoader();
			// Click Proceed
			if (isDisplayed(btnproceed, "")) {
				try {
					clickUsingJavaScript(btnproceed, objectValue);
					report.reportPass("Click button proceed in partial disconnect flow",
							"Click button proceed in partial disconnect flow if Exists",
							"Clicking button proceed in partial disconnect flow");
					waitForLoader();
				} catch (Exception exe) {
					report.reportFail("Click button proceed in partial disconnect flow",
							"Select button proceed in partial disconnect flow if exists",
							"Not able to button proceed in partial disconnect flow due to Object not displayed");
					report.updateMainReport("ErrorMessage",
							"Not able to button proceed in partial disconnect flow due to Object not displayed");
					throw new UserDefinedException("Failed in Disconnect Page");

				}
			}

		}

	}

	String fd = get("FullDisconnect").trim();

	public void pegaRecommendations() throws Exception {
		String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
		strDescription = "Validate Recommended section.";
		strExpected = "Recommended section should be validated";
		strActual = "Selected Recommeded section.";
		strFailed = "Failed to validate recommended section due to object unavailability.";
		getUrl = " URL Launched --> " + returnURL();
		String temp = null;
		String selectPackage = get("SelectPackage").trim();
		String changeType = get("ChangeType").trim();
		String env = get("Environment").trim();

		env = "NTE1";
		String bundlePriceProduct = "";
		String PegaBP = "", tile_text = null;
		String proposition1 = "NA", proposition2 = "NA", proposition3 = "NA";
		waitForLoader();
		HashMap<String, String> data = new HashMap<>();

		if (changeType.trim().equalsIgnoreCase("Loyalty")) {

			List<WebElement> kk = driver.findElements(by.xpath("//li[@class='m_accordion-details border-none']"));

			System.out.println(kk.size());
			try {
				dashboardService d = new dashboardService();
				Map<String, String> bigruleResults = d
						.bigRuleResults(getUrl.substring(getUrl.indexOf("SIT"), getUrl.indexOf("&FlowType")), env);
				System.out.println(bigruleResults);
				for (String key : bigruleResults.keySet()) {
					report.updateMainReport("BR_" + key, bigruleResults.get(key).toString());
				}

				System.out.println("test");
				// mrc price
				HashMap<String, HashMap<String, String>> serviceMrcProducts = d.validateMRCProducts();
				HashMap<String, Float> mrcPrices = d.calculateMrc(serviceMrcProducts);
				System.out.println(mrcPrices);
				/*
				 * HashMap<String, Float> mrcdiff =
				 * d.compareTotalPricewithMrc(mrcPrices);
				 * //report.updateMainReport("OrderOrgSystem",
				 * mrcdiff.toString()); report.updateMainReport(
				 * "SSP Order Submission",mrcPrices.toString()); for(String
				 * key:mrcdiff.keySet()) { if(mrcdiff.get(key) >0)
				 * System.out.println(mrcdiff.get(key));; }
				 */
			} catch (Exception e) {
				System.out.println("Failed in Big Rules Validation ");
			}

			switchToDefaultcontent();
			try {
				try {
					waitForElementDisplay(enableProducts, objectValue, pageTimeoutInSeconds);
				} catch (Exception e) {
				}
				// waitForElementDisplay(IfProducts, selectPackage,
				// pageTimeoutInSeconds);
				/*
				 * switchToDefaultcontent(); switchToFrame("IfProducts");
				 */
				if (isDisplayed(pegaRecommendation, objectValue, 20)) {
					if ((!selectPackage.isEmpty()) && (!selectPackage.equalsIgnoreCase("No"))) {
						/*
						 * switchToDefaultcontent();
						 * switchToFrame("IfProducts");
						 */

						// Expand recommendation tab in product and services
						// page
						/*
						 * if (!getAttribute(pegaRecommendation, objectValue,
						 * "class").contains("open")) {
						 * pageScroll(pegaRecommendation, objectValue, true);
						 * clickUsingJavaScript(pegaRecommendation,
						 * objectValue);}
						 */

						report.reportPass("Prepositions Tiles", "Prepositions Tiles should be displayed",
								"Prepositions Tiles displayed");

						int t = 1, count = pegaTiles.size(), tileNo = 0;
						System.out.println(pegaTiles.size());
						String[] TempTileOffer = new String[pegaTiles.size()];
						try {
							if (pegaRecommendation.getText().contains("No Compass recommendation")) {
								report.reportFail("Offers Display in Tiles", "Compass Displayed or not in Product page",
										"Compass is not displayed in Product page");
								report.updateMainReport("PropositionSelected", "No Compass Recommendations Found");
							}

						} catch (Exception exe) {
							if (!isUserDefinedException(exe)) {
								report.reportFail(strDescription + getUrl, strExpected, strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								captureErrorMsg("Failed in Internet section.");
							}
							throw exe;

						}
						// Start Big Rule B.31
						// Validate the Duplicates Offer TIle present in Tiles
						for (int i = 0; i < pegaTiles.size(); i++) {
							tile_text = getTextFromElement(pegaTiles.get(i), objectValue);
							TempTileOffer[i] = tile_text;
							/*
							 * if(i==0)proposition1=tileTitle.get(i).getText();
							 * if(i==1)proposition2=tileTitle.get(i).getText();
							 * if(i==2)proposition3=tileTitle.get(i).getText();
							 */

							waitForLoader();
						}
						/*
						 * System.out.println("Prop: "
						 * +proposition1+"\t"+proposition2+"\t"+proposition3);
						 */
						Boolean Dup = ToFindDuplicates(TempTileOffer, pegaTiles.size());
						if (Dup)
							report.reportFail("Offers Display in Tiles", "Offers not be getting repeated in Tiles",
									"Offers are getting repeated in Tiles");
						else
							report.reportPass("Offers Display in Tiles", "Offers not be getting repeated in Tiles",
									"Offers are not getting repeated in Tiles");
						// End Big Rule B.31
						// Start Big Rule B.22
						if ((Dup) && (pegaTiles.size() == 3)) {
							if (proposition1 == proposition2) {
								report.reportPass("Offers Display in Tiles", "Offers not be getting repeated in Tiles",
										"Offers are not getting repeated in Tiles");
							} else
								report.reportFail("Offers Display in Tiles", "Offers not be getting repeated in Tiles",
										"Offers are getting repeated in Tiles");

						}

						// End Big Rule B.22
						switchToDefaultcontent();
						/*
						 * if(isDisplayed(rgSection,objectValue))
						 * clickUsingJavaScript(rgSection, objectValue);
						 */
						switchToDefaultcontent();
						switchToFrame("IfProducts");

						if (get("RG_Selection").contains("All"))
							report.updateMainReport("DisconnectType", "Full Disconnect");
						else
							report.updateMainReport("DisconnectType", "Partial Disconnect");
						report.updateMainReport("PropisitionCount", String.valueOf(pegaTiles.size()));

						// OnProfile
						int tileNum = 0;
						if (selectPackage.contains("1"))
							tileNum = 1;
						if (selectPackage.contains("2"))
							tileNum = 2;
						if (selectPackage.contains("3"))
							tileNum = 3;

						System.out.println("Test");
						String PartialDisconnect = get("PartialDisconnect");
						switchToDefaultcontent();

						if (fd.equalsIgnoreCase("yes")) {
							Thread.sleep(1000);
							for (int i = 0; i < PrepositionTiles.size(); i++) {
								System.out.println(PrepositionTiles.get(i).getText());
								clickUsingJavaScript(PrepositionTiles.get(i), objectValue);
								Thread.sleep(300);
								if (isDisplayed(Rejectbutton, objectValue, 20)) {
									clickUsingJavaScript(Rejectbutton, objectValue);
								}
								Thread.sleep(200);
								if (isDisplayed(Radioobutton, objectValue, 20)) {
									clickUsingJavaScript(Radioobutton, objectValue);
								}
								if (isDisplayed(ctnbutton, objectValue, 20)) {
									clickUsingJavaScript(ctnbutton, objectValue);
								}
							}
							clickUsingJavaScript(RGQA, objectValue);
							Thread.sleep(300);
							SimplexRGPage rg = new SimplexRGPage(driver, objectValue, report, data);
							rg.initialize(driver, objectValue, report, data).dynamicRGSelection();
							Thread.sleep(1500);
							Partialdisconnectreason();

						}
						if (PartialDisconnect.equalsIgnoreCase("yes")) {

							for (int i = 0; i < PrepositionTiles.size(); i++) {
								System.out.println(PrepositionTiles.get(i).getText());
								clickUsingJavaScript(PrepositionTiles.get(i), objectValue);
								Thread.sleep(300);
								if (isDisplayed(Rejectbutton, objectValue, 20)) {
									clickUsingJavaScript(Rejectbutton, objectValue);
								}
								Thread.sleep(200);
								if (isDisplayed(Radioobutton, objectValue, 20)) {
									clickUsingJavaScript(Radioobutton, objectValue);
								}
								if (isDisplayed(ctnbutton, objectValue, 20)) {
									clickUsingJavaScript(ctnbutton, objectValue);
								}
							}

							if (isDisplayed(RGQA, objectValue, 20)) {
								clickUsingJavaScript(RGQA, objectValue);
								Thread.sleep(300);
								SimplexRGPage rg = new SimplexRGPage(driver, objectValue, report, data);
								rg.initialize(driver, objectValue, report, data).dynamicRGSelection();
								Thread.sleep(1500);
								Partialdisconnectreason();
								// Disconnect();
								Thread.sleep(1500);
								if (isDisplayed(voiceoptions, objectValue, 5)) {

									pageScroll(voiceoptions, getUrl, true);
									report.reportPass("Check whether Please Review is dispalyed",
											"Check whether Please Review is dispalyed", "Please Review is displayed");
									clickUsingJavaScript(voiceoptions, objectValue);
									waitForLoader();
									waitForLoader();

								}

							}

							/*
							 * if(isDisplayed(Addtocartbutton, objectValue,
							 * 20)){ clickUsingJavaScript(Addtocartbutton,
							 * objectValue); }
							 */

						}

						// Selecting Tile
						System.out.println("Selecting Tile1");
						/*
						 * if (!getAttribute(pegaRecommendation, objectValue,
						 * "class").contains("open")){
						 * clickUsingJavaScript(pegaRecommendation,
						 * objectValue);}
						 */
						if (tileNum <= count) {

							if (isDisplayed(pegaTiles.get(tileNum - 1), objectValue)) {
								temp = pegaTiles.get(tileNum - 1).getText();
								report.updateMainReport("MO_Tile_Details", temp);
								tileNo = tileNum;
								tile_text = temp;
								clickUsingJavaScript(pegaTiles.get(tileNum - 1), objectValue);
							}
						}

						else {
							temp = pegaTiles.get(count - 1).getText();
							report.updateMainReport("MO_Tile_Details", temp);
							tileNo = count;
							tile_text = temp;
							clickUsingJavaScript(pegaTiles.get(count - 1), objectValue);
						}
						waitForLoader();
						waitForLoader();
						if (isDisplayed(btnAddtoCart1, objectValue, 10)) {
							clickUsingJavaScript(btnAddtoCart1, objectValue);
							waitForLoader();
							clickUsingJavaScript(pegaRecommendation1, objectValue);
						}

						// PegaBP=pegaBundlePrice.getText();
						/*
						 * if(temp.contains("Renew")||temp.contains("Rightsize")
						 * ){ if(temp.contains("Renew"))
						 * report.updateMainReport("PropositionSelected","Renew"
						 * ); else
						 * report.updateMainReport("PropositionSelected",
						 * "Rightsize");
						 */
						Thread.sleep(10000);
						switchToDefaultcontent();
						switchToFrame("IfProducts");
						waitForElementDisplay(pegaGetTotals, objectValue, 30);
						if (isDisplayed(pegaGetTotals)) {
							System.out.println("pegaGetTotals is displayed");
							if (tile_text.contains(pegaBundlePrice.getText())) {
								String pegaBundle = pegaBundlePrice.getText();
								// String pega_Total=pegaBundlePrice.getText();
								clickUsingJavaScript(pegaGetTotals, objectValue);

								waitForLoader();
								report.reportPass("GetTotals of Tile", "GetTotal should be displayed",
										"Get Total should be displayed");
								String pega_Total = pegaBundlePrice.getText().substring(1, 7).trim();
								String pega_Optix_total = pegaOptixTotal.getText().substring(1, 7).trim();
								String pegaBP = BPWithDisc.getText().replace("$", "").trim();
								String pegaOptixBP = pegaBP.substring(pegaBP.indexOf("-") + 1).replace(")", "").trim();
								pegaBP = pegaBP.substring(0, pegaBP.indexOf("(")).trim();
								put("PegaTile_Totals", pega_Total);
								put("PegaTile_BundlePrice", pegaBP);
								put("PegaTile_Optix_Totals", pega_Optix_total);
								put("PegaTile_Optix_BundlePrice", pegaOptixBP);
								if (get("TestCase_Name").contains("Standalone")) {
									put("PegaTile_EquipmentPrice",
											/* equipmentprice.getText() */"0.00");
									put("PegaTile_Optix_EquipmentPrice", "0.00");
								} else {
									String equipPrice = equipmentprice.getText().replace("$", "").trim();
									String pegaOptixEP = equipPrice.substring(equipPrice.indexOf("-") + 1).trim();
									equipPrice = equipPrice.substring(0, equipPrice.indexOf("(")).replace(")", "")
											.trim();
									put("PegaTile_EquipmentPrice", equipPrice);
									put("PegaTile_Optix_EquipmentPrice", pegaOptixEP);
								}
								put("PegaTile_Taxes", taxes.getText());
								System.out.println(pegaBundleOffers.getText());
								put("Pega_Offers", pegaBundleOffers.getText());

								report.updateMainReport("NumberOfTiles", String.valueOf(count));
								// report.updateMainReport("TileSelected",String.valueOf(tileNo));
								report.updateMainReport("MO_Tile_Offers", pegaBundleOffers.getText());
								report.updateMainReport("MO_Tile_Totals", pega_Total);
								report.updateMainReport("MO_Tile_BundlePrice", pegaBP);
								report.updateMainReport("MO_Pega_Bundle", pegaBundle);
								report.updateMainReport("MO_Tile_Taxes", taxes.getText());
								report.updateMainReport("MO_Tile_Optix_Totals", pega_Optix_total);
								report.updateMainReport("MO_Tile_Optix_BundlePrice", pegaOptixBP);

								if (get("TestCase_Name").contains("Standalone")) {
									report.updateMainReport("MO_Tile_EquipmentPrice",
											/* equipmentprice.getText() */"0.00");
									report.updateMainReport("MO_Tile_Optix_EquipmentPrice", "0.00");
								} else {
									String equipPrice = equipmentprice.getText().replace("$", "").trim();
									String pegaOptixEP = equipPrice.substring(equipPrice.indexOf("-") + 1)
											.replace(")", "").trim();
									equipPrice = equipPrice.substring(0, equipPrice.indexOf("(")).trim();

									report.updateMainReport("MO_Tile_EquipmentPrice", equipPrice);

									report.updateMainReport("MO_Tile_Optix_EquipmentPrice", pegaOptixEP);
								}

								// System.out.println(pega_Total+"\t"+BPWithDisc.getText()+"\t"+equipmentprice.getText()+"\t"+taxes.getText());
							}
						}
						waitForLoader();
						waitForLoader();

						waitForLoader();
						String pegaOffers = get("Pega_Offers").toString();
						// Onprofile and Disconnect Details and number of
						// Propositiions
						String onProfile = ExistingData.getText() + " " + ExistingTV.getText() + " "
								+ ExistingVoice.getText();
						System.out.println("Onprofile");
						report.updateMainReport("OnProfile", onProfile);
						// bundlePriceProduct
						waitForLoader();
						// Agreement Section
						if (!getAttribute(expandContract, objectValue, "class").contains("open")) {
							pageScroll(expandContract, objectValue, true);
							clickUsingJavaScript(expandContract, objectValue);
						}
						if (isDisplayed(AgreementActiveTile, objectValue)) {
							if (get("FlowType").equalsIgnoreCase("Change")) {
								clickUsingJavaScript(ActiveTile_Details, objectValue);
							}
							String pegaOfflist = get("Pega_Offers").toString();
							String[] pegaoff = pegaOfflist.split("\\n");
							System.out.println(pegaoff[1] + "\n\n\n\n" + pegaOfflist);
							Boolean offer = false;
							{
								for (String pega : pegaoff) {
									System.out.println(pega);
									if ((!pega.contains("year")) && (!pega.contains("M2M"))) {
										for (WebElement off : OfferPopupDetails) {
											if (off.getText().contains(pega)) {
												System.out.println(off.getText() + " is present ");
												offer = true;
												report.reportPass(
														"Offer " + pega + " should present in agreement Section",
														"Offer should present", pega + " Offer is present");
											} else if (!offer)
												offer = false;
										}
									}
								} // close
								clickUsingJavaScript(DetailsClose, objectValue);
							}
						}

						// MRDVR Service Selection
						if (get("Pega_Offers").contains("Multi-Room DVR Service")) {
							String SelectedEquip = null;
							if (!getAttribute(expandEquipmentsAccessoriesRibbon, objectValue, "class")
									.contains("open")) {
								pageScroll(expandEquipmentsAccessoriesRibbon, objectValue, true);
								clickUsingJavaScript(expandEquipmentsAccessoriesRibbon, objectValue);
							}
							if (isDisplayed(selectedEqpText, "", 3)) {
								SelectedEquip = getTextFromElement(selectedEqpText, objectValue);
								String strRouterOptions = get("RouterOptions").trim();
								System.out.println(SelectedEquip);
								if (SelectedEquip.contains("DVR") && SelectedEquip.contains("Router")) {
									System.out.println("Router Already Selected");
								} else if (SelectedEquip.contains("DVR") && (!SelectedEquip.contains("Router"))) {
									// RouterOptions
									clickUsingJavaScript(lnkRouterOptions, strRouterOptions);
									report.reportPass("To select RouterOptions ",
											strRouterOptions + "should be available as RouterOptions and be selectable",
											strRouterOptions + " RouterOptions is selected");
								}
							}

						}
						// Premium Channels Selection
						if (pegaOffers.contains("Showtime") || pegaOffers.contains("HBO")
								|| pegaOffers.contains("Epix")) {
							String offerChannel = "";
							String premiumChannels = get("PremiumChannels").trim();
							String channelType = get("ChannelType").trim();
							String SelectedPremiums = "";
							if (pegaOffers.contains("Showtime")) {
								offerChannel = "Showtime";
							} else if (pegaOffers.contains("HBO")) {
								offerChannel = "HBO";
							} else if (pegaOffers.contains("Epix")) {
								offerChannel = "Epix";
							}
							if (isDisplayed(Selected_Premium, "", 0)) {
								SelectedPremiums = getTextFromElement(Selected_Premium, objectValue);
								System.out.println(SelectedPremiums);
								if (SelectedPremiums.contains(offerChannel)) {
									System.out.println("Premium Channels Already selected");
								} else {
									pageScroll(premiumChannelToSelect, offerChannel, true);
									clickUsingJavaScript(premiumChannelToSelect, offerChannel);
									report.reportPass(
											"Simplex Page  ordering - Verify able to check premium channel:"
													+ offerChannel,
											"Should be able to check premium channel",
											"Able to check premium channel:" + offerChannel);
								}

							}

						}
						waitForLoader();
						// clickUsingJavaScript(GetTotals, objectValue);
						waitForLoader();
						System.out.println(NewMonthlyCharges.getText() + "\t" + ProductBundlePrice.getText() + "\t"
								+ EquipExtrasPrice.getText() + "\t" + TaxAmount.getText());
						report.updateMainReport("MO_GetTotals", NewMonthlyCharges.getText());
						report.updateMainReport("MO_Product_BundlePrice", ProductBundlePrice.getText());
						report.updateMainReport("MO_EquipmentPrice", EquipExtrasPrice.getText());
						report.updateMainReport("MO_Total_Taxes", TaxAmount.getText());
						put("MO_GetTotals", NewMonthlyCharges.getText());
						put("MO_Product_BundlePrice", ProductBundlePrice.getText());
						put("MO_EquipmentPrice", EquipExtrasPrice.getText());
						put("MO_Total_Taxes", TaxAmount.getText());
						bundlePriceProduct = ProductBundlePrice.getText();
						System.out.println("PegaBP" + PegaBP + "ProductBundlePrice" + bundlePriceProduct);

						// }
					}
				}

				switchToDefaultcontent();
				switchToFrame("IfProducts");
				if (isDisplayed(pegaRecommendation, objectValue, 20)) {
					if ((!selectPackage.isEmpty()) && (!selectPackage.equalsIgnoreCase("No"))) {
						/*
						 * switchToDefaultcontent();
						 * switchToFrame("IfProducts");
						 */

						// Expand recommendation tab in product and services
						// page
						/*
						 * if (!getAttribute(pegaRecommendation, objectValue,
						 * "class").contains("open")) {
						 * pageScroll(pegaRecommendation, objectValue, true);
						 * clickUsingJavaScript(pegaRecommendation,
						 * objectValue);}
						 */

						int t = 1, count = pegaTiles.size(), tileNo = 0;
						System.out.println(pegaTiles.size());
						String[] TempTileOffer = new String[pegaTiles.size()];
						try {
							if (pegaRecommendation.getText().contains("No Compass recommendation")) {
								report.reportFail("Offers Display in Tiles", "Compass Displayed or not in Product page",
										"Compass is not displayed in Product page");
								report.updateMainReport("PropositionSelected", "No Compass Recommendations Found");
							}

						} catch (Exception exe) {
							if (!isUserDefinedException(exe)) {
								report.reportFail(strDescription + getUrl, strExpected, strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								captureErrorMsg("Failed in Internet section.");
							}
							throw exe;

						}
						// Start Big Rule B.31
						// Validate the Duplicates Offer TIle present in Tiles
						for (int i = 0; i < pegaTiles.size(); i++) {

							tile_text = getTextFromElement(pegaTiles.get(i), objectValue);
							TempTileOffer[i] = tile_text;
							/*
							 * if(i==0)proposition1=tileTitle.get(i).getText();
							 * if(i==1)proposition2=tileTitle.get(i).getText();
							 * if(i==2)proposition3=tileTitle.get(i).getText();
							 */

							waitForLoader();
						}
						/*
						 * System.out.println("Prop: "
						 * +proposition1+"\t"+proposition2+"\t"+proposition3);
						 */
						Boolean Dup = ToFindDuplicates(TempTileOffer, pegaTiles.size());
						if (Dup)
							report.reportFail("Offers Display in Tiles", "Offers not be getting repeated in Tiles",
									"Offers are getting repeated in Tiles");
						else
							report.reportPass("Offers Display in Tiles", "Offers not be getting repeated in Tiles",
									"Offers are not getting repeated in Tiles");
						// End Big Rule B.31
						// Start Big Rule B.22
						if ((Dup) && (pegaTiles.size() == 3)) {
							if (proposition1 == proposition2) {
								report.reportPass("Offers Display in Tiles", "Offers not be getting repeated in Tiles",
										"Offers are not getting repeated in Tiles");
							} else
								report.reportFail("Offers Display in Tiles", "Offers not be getting repeated in Tiles",
										"Offers are getting repeated in Tiles");

						}

						// End Big Rule B.22
						switchToDefaultcontent();
						if (isDisplayed(rgSection, objectValue))
							clickUsingJavaScript(rgSection, objectValue);
						switchToDefaultcontent();
						switchToFrame("IfProducts");

						if (get("RG_Selection").contains("All"))
							report.updateMainReport("DisconnectType", "Full Disconnect");
						else
							report.updateMainReport("DisconnectType", "Partial Disconnect");
						report.updateMainReport("PropisitionCount", String.valueOf(pegaTiles.size()));

						// OnProfile
						int tileNum = 0;
						if (selectPackage.contains("1"))
							tileNum = 1;
						if (selectPackage.contains("2"))
							tileNum = 2;
						if (selectPackage.contains("3"))
							tileNum = 3;

						System.out.println("Test");
						String PartialDisconnect = get("PartialDisconnect");
						switchToDefaultcontent();
						if (PartialDisconnect.equalsIgnoreCase("yes")) {
							clickUsingJavaScript(Firsttile, objectValue);

							if (isDisplayed(Rejectbutton, objectValue, 20)) {
								clickUsingJavaScript(Rejectbutton, objectValue);
							}

							if (isDisplayed(Radioobutton, objectValue, 20)) {
								clickUsingJavaScript(Radioobutton, objectValue);
							}
							if (isDisplayed(ctnbutton, objectValue, 20)) {
								clickUsingJavaScript(ctnbutton, objectValue);
							}

							if (isDisplayed(Tile2, objectValue, 20)) {
								clickUsingJavaScript(Tile2, objectValue);
							}
							/*
							 * if(isDisplayed(Addtocartbutton, objectValue,
							 * 20)){ clickUsingJavaScript(Addtocartbutton,
							 * objectValue); }
							 */

						}

						// Selecting Tile
						System.out.println("Selecting Tile1");
						/*
						 * if (!getAttribute(pegaRecommendation, objectValue,
						 * "class").contains("open")){
						 * clickUsingJavaScript(pegaRecommendation,
						 * objectValue);}
						 */
						if (tileNum <= count) {
							switchToDefaultcontent();
							switchToFrame("IfProducts");
							if (isDisplayed(pegaTiles.get(tileNum - 1), objectValue)) {
								temp = pegaTiles.get(tileNum - 1).getText();
								report.updateMainReport("MO_Tile_Details", temp);
								tileNo = tileNum;
								tile_text = temp;
								clickUsingJavaScript(pegaTiles.get(tileNum - 1), objectValue);
							}
						}

						else {
							temp = pegaTiles.get(count - 1).getText();
							report.updateMainReport("MO_Tile_Details", temp);
							tileNo = count;
							tile_text = temp;
							clickUsingJavaScript(pegaTiles.get(count - 1), objectValue);
						}
						waitForLoader();
						waitForLoader();
						switchToDefaultcontent();
						switchToFrame("IfProducts");
						if (isDisplayed(btnAddtoCart, objectValue, 10)) {
							clickUsingJavaScript(btnAddtoCart, objectValue);
							waitForLoader();
							clickUsingJavaScript(pegaRecommendation1, objectValue);
						}

						// PegaBP=pegaBundlePrice.getText();
						/*
						 * if(temp.contains("Renew")||temp.contains("Rightsize")
						 * ){ if(temp.contains("Renew"))
						 * report.updateMainReport("PropositionSelected","Renew"
						 * ); else
						 * report.updateMainReport("PropositionSelected",
						 * "Rightsize");
						 */
						Thread.sleep(10000);
						switchToDefaultcontent();
						switchToFrame("IfProducts");
						waitForElementDisplay(pegaGetTotals, objectValue, 30);
						if (isDisplayed(pegaGetTotals)) {
							System.out.println("pegaGetTotals is displayed");
							if (tile_text.contains(pegaBundlePrice.getText())) {
								String pegaBundle = pegaBundlePrice.getText();
								// String pega_Total=pegaBundlePrice.getText();
								clickUsingJavaScript(pegaGetTotals, objectValue);

								waitForLoader();
								report.reportPass("GetTotals of Tile", "GetTotal should be displayed",
										"Get Total should be displayed");
								String pega_Total = pegaBundlePrice.getText().substring(1, 7).trim();
								String pega_Optix_total = pegaOptixTotal.getText().substring(1, 7).trim();
								String pegaBP = BPWithDisc.getText().replace("$", "").trim();
								String pegaOptixBP = pegaBP.substring(pegaBP.indexOf("-") + 1).replace(")", "").trim();
								pegaBP = pegaBP.substring(0, pegaBP.indexOf("(")).trim();
								put("PegaTile_Totals", pega_Total);
								put("PegaTile_BundlePrice", pegaBP);
								put("PegaTile_Optix_Totals", pega_Optix_total);
								put("PegaTile_Optix_BundlePrice", pegaOptixBP);
								if (get("TestCase_Name").contains("Standalone")) {
									put("PegaTile_EquipmentPrice",
											/* equipmentprice.getText() */"0.00");
									put("PegaTile_Optix_EquipmentPrice", "0.00");
								} else {
									String equipPrice = equipmentprice.getText().replace("$", "").trim();
									String pegaOptixEP = equipPrice.substring(equipPrice.indexOf("-") + 1).trim();
									equipPrice = equipPrice.substring(0, equipPrice.indexOf("(")).replace(")", "")
											.trim();
									put("PegaTile_EquipmentPrice", equipPrice);
									put("PegaTile_Optix_EquipmentPrice", pegaOptixEP);
								}
								put("PegaTile_Taxes", taxes.getText());
								System.out.println(pegaBundleOffers.getText());
								put("Pega_Offers", pegaBundleOffers.getText());

								report.updateMainReport("NumberOfTiles", String.valueOf(count));
								// report.updateMainReport("TileSelected",String.valueOf(tileNo));
								report.updateMainReport("MO_Tile_Offers", pegaBundleOffers.getText());
								report.updateMainReport("MO_Tile_Totals", pega_Total);
								report.updateMainReport("MO_Tile_BundlePrice", pegaBP);
								report.updateMainReport("MO_Pega_Bundle", pegaBundle);
								report.updateMainReport("MO_Tile_Taxes", taxes.getText());
								report.updateMainReport("MO_Tile_Optix_Totals", pega_Optix_total);
								report.updateMainReport("MO_Tile_Optix_BundlePrice", pegaOptixBP);

								if (get("TestCase_Name").contains("Standalone")) {
									report.updateMainReport("MO_Tile_EquipmentPrice",
											/* equipmentprice.getText() */"0.00");
									report.updateMainReport("MO_Tile_Optix_EquipmentPrice", "0.00");
								} else {
									String equipPrice = equipmentprice.getText().replace("$", "").trim();
									String pegaOptixEP = equipPrice.substring(equipPrice.indexOf("-") + 1)
											.replace(")", "").trim();
									equipPrice = equipPrice.substring(0, equipPrice.indexOf("(")).trim();

									report.updateMainReport("MO_Tile_EquipmentPrice", equipPrice);

									report.updateMainReport("MO_Tile_Optix_EquipmentPrice", pegaOptixEP);
								}

								// System.out.println(pega_Total+"\t"+BPWithDisc.getText()+"\t"+equipmentprice.getText()+"\t"+taxes.getText());
							}
						}
						waitForLoader();
						waitForLoader();

						waitForLoader();
						String pegaOffers = get("Pega_Offers").toString();
						// Onprofile and Disconnect Details and number of
						// Propositiions
						String onProfile = ExistingData.getText() + " " + ExistingTV.getText() + " "
								+ ExistingVoice.getText();
						System.out.println("Onprofile");
						report.updateMainReport("OnProfile", onProfile);
						// bundlePriceProduct
						waitForLoader();
						// Agreement Section
						if (!getAttribute(expandContract, objectValue, "class").contains("open")) {
							pageScroll(expandContract, objectValue, true);
							clickUsingJavaScript(expandContract, objectValue);
						}
						if (isDisplayed(AgreementActiveTile, objectValue)) {
							if (get("FlowType").equalsIgnoreCase("Change")) {
								clickUsingJavaScript(ActiveTile_Details, objectValue);
							}
							String pegaOfflist = get("Pega_Offers").toString();
							String[] pegaoff = pegaOfflist.split("\\n");
							System.out.println(pegaoff[1] + "\n\n\n\n" + pegaOfflist);
							Boolean offer = false;
							{
								for (String pega : pegaoff) {
									System.out.println(pega);
									if ((!pega.contains("year")) && (!pega.contains("M2M"))) {
										for (WebElement off : OfferPopupDetails) {
											if (off.getText().contains(pega)) {
												System.out.println(off.getText() + " is present ");
												offer = true;
												report.reportPass(
														"Offer " + pega + " should present in agreement Section",
														"Offer should present", pega + " Offer is present");
											} else if (!offer)
												offer = false;
										}
									}
								} // close
								clickUsingJavaScript(DetailsClose, objectValue);
							}
						}

						// MRDVR Service Selection
						if (get("Pega_Offers").contains("Multi-Room DVR Service")) {
							String SelectedEquip = null;
							if (!getAttribute(expandEquipmentsAccessoriesRibbon, objectValue, "class")
									.contains("open")) {
								pageScroll(expandEquipmentsAccessoriesRibbon, objectValue, true);
								clickUsingJavaScript(expandEquipmentsAccessoriesRibbon, objectValue);
							}
							if (isDisplayed(selectedEqpText, "", 3)) {
								SelectedEquip = getTextFromElement(selectedEqpText, objectValue);
								String strRouterOptions = get("RouterOptions").trim();
								System.out.println(SelectedEquip);
								if (SelectedEquip.contains("DVR") && SelectedEquip.contains("Router")) {
									System.out.println("Router Already Selected");
								} else if (SelectedEquip.contains("DVR") && (!SelectedEquip.contains("Router"))) {
									// RouterOptions
									clickUsingJavaScript(lnkRouterOptions, strRouterOptions);
									report.reportPass("To select RouterOptions ",
											strRouterOptions + "should be available as RouterOptions and be selectable",
											strRouterOptions + " RouterOptions is selected");
								}
							}

						}
						// Premium Channels Selection
						if (pegaOffers.contains("Showtime") || pegaOffers.contains("HBO")
								|| pegaOffers.contains("Epix")) {
							String offerChannel = "";
							String premiumChannels = get("PremiumChannels").trim();
							String channelType = get("ChannelType").trim();
							String SelectedPremiums = "";
							if (pegaOffers.contains("Showtime")) {
								offerChannel = "Showtime";
							} else if (pegaOffers.contains("HBO")) {
								offerChannel = "HBO";
							} else if (pegaOffers.contains("Epix")) {
								offerChannel = "Epix";
							}
							if (isDisplayed(Selected_Premium, "", 0)) {
								SelectedPremiums = getTextFromElement(Selected_Premium, objectValue);
								System.out.println(SelectedPremiums);
								if (SelectedPremiums.contains(offerChannel)) {
									System.out.println("Premium Channels Already selected");
								} else {
									pageScroll(premiumChannelToSelect, offerChannel, true);
									clickUsingJavaScript(premiumChannelToSelect, offerChannel);
									report.reportPass(
											"Simplex Page  ordering - Verify able to check premium channel:"
													+ offerChannel,
											"Should be able to check premium channel",
											"Able to check premium channel:" + offerChannel);
								}

							}

						}
						waitForLoader();
						// clickUsingJavaScript(GetTotals, objectValue);
						waitForLoader();
						System.out.println(NewMonthlyCharges.getText() + "\t" + ProductBundlePrice.getText() + "\t"
								+ EquipExtrasPrice.getText() + "\t" + TaxAmount.getText());
						report.updateMainReport("MO_GetTotals", NewMonthlyCharges.getText());
						report.updateMainReport("MO_Product_BundlePrice", ProductBundlePrice.getText());
						report.updateMainReport("MO_EquipmentPrice", EquipExtrasPrice.getText());
						report.updateMainReport("MO_Total_Taxes", TaxAmount.getText());
						put("MO_GetTotals", NewMonthlyCharges.getText());
						put("MO_Product_BundlePrice", ProductBundlePrice.getText());
						put("MO_EquipmentPrice", EquipExtrasPrice.getText());
						put("MO_Total_Taxes", TaxAmount.getText());
						bundlePriceProduct = ProductBundlePrice.getText();
						System.out.println("PegaBP" + PegaBP + "ProductBundlePrice" + bundlePriceProduct);

						// }
					}
				}

			} catch (Exception exe) {
				/*
				 * if (!isUserDefinedException(exe)) {
				 * report.reportFail(strDescription + getUrl, strExpected,
				 * strFailed); report.updateMainReport("ErrorMessage",
				 * strFailed); captureErrorMsg("Failed in Internet section."); }
				 * throw exe;
				 */
			}
		} else {
			// Onprofile
			String onProfile = ExistingData.getText() + ":" + ExistingTV.getText() + ":" + ExistingVoice.getText();
			System.out.println("Onprofile");
			report.updateMainReport("OnProfile", onProfile);

			try {
				dashboardService d = new dashboardService();
				Map<String, String> result = d
						.myOffersTileDetails(getUrl.substring(getUrl.indexOf("SIT"), getUrl.indexOf("&FlowType")), env);
				for (String key : result.keySet()) {
					report.updateMainReport(key, result.get(key).toString());
				}
			} catch (Exception exe) {
			}
		}
	}

	public void validateExchangeOptionsInCheckout() throws Exception {
		// Exchange Options : Added By Naresh,Madipelly
		if (!get("MoreOffers").isEmpty()) {
			if (isDisplayed(getRouterPriceInCheckout, "", 3)) {
				String RouterPriceInCheckOutPage = getTextFromElement(getRouterPriceInCheckout, "");
				System.out.println("Router Price in Checkout Page is : " + RouterPriceInCheckOutPage);

				// String
				// RouterPriceInOpOPage=getTextFromElement(getRouterPriceFromPorductPage,
				// get("RouterOptions"));
				// System.out.println("Router Price in OPO Page :
				// "+RouterPriceInOpOPage);

				// RouterPriceInCheckOutPage="-"+RouterPriceInCheckOutPage;
				if (RouterPriceInCheckOutPage.equals("Fee Waived")) {
					report.reportPass("Verify Router  fee waived or not", "Router fee should be waived",
							"Router fee waived");
				} else {
					report.reportFail("Verify Router  fee waived or not", "Router fee should be waived",
							"Router fee not waived");
				}

				CList<Element> TVEquipmentFees = getElementList(getTVEquipmentFeeWaived, objectValue);

				for (Element TVEquFee : TVEquipmentFees) {
					String TVFee = getTextFromElement(TVEquFee, objectValue);
					if (TVFee.equalsIgnoreCase("Fee Waived")) {
						report.reportPass("Verify TV Equipment  fee waived or not", "TV Equipment fee should be waived",
								"TV Eqipment fee waived");
						continue;
					} else {
						report.reportFail("Verify TV Equipment  fee waived or not", "TV Equipment fee should be waived",
								"TV Equipment fee not waived");
						break;
					}
				}

			}

			if (isDisplayed(TVFeeWaivedInReviewpage, "", 3)) {
				String FeeWaivedInReviewPage = getTextFromElement(TVFeeWaivedInReviewpage, objectValue);
				System.out.println(FeeWaivedInReviewPage);
				if (FeeWaivedInReviewPage.equals("Fee Waived")) {
					report.reportPass("Verify TV Equipment  fee waived or not", "TV Equipment fee should be waived",
							"TV Eqipment fee waived");
				} else {
					report.reportFail("Verify TV Equipment  fee waived or not", "TV Equipment fee should be waived",
							"TV Equipment fee not waived");
				}
			}
		}
	}

	/**
	 * @Description: reviewOrderOfferValidation is used to validate offer
	 *               summary section of review order
	 * @author: Mithra G
	 * @return:No Return Type
	 * @exception: Throws
	 *                 Exception
	 * @ModifiedBy:
	 * @ModifiedDate:
	 * @Comments: Added for new FCP update
	 */
	public void reviewOrderOfferValidation() throws Exception, UserDefinedException {

		System.out.println("->Review Order Offer Validation");

		waitForLoader();
		try {
			// Switching to frame
			switchToDefaultcontent();
			switchToFrame("IfProducts");
			waitForLoader();

			// Clicking expand offer summary
			WebElement offer_summaryexpand = driver
					.findElement(By.xpath("//span[text()='Offer Summary']/parent::li[@aria-expanded='true']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", offer_summaryexpand);
			waitForLoader();
			// Router offer validation
			// Getting router offer validation from validation sheet
			if (get("$12-Router Discounts").equalsIgnoreCase("Yes")) {
				System.out.println(get("$12-Router Discounts"));
				// Getting router offer validation description and price from
				// validation input sheet
				String routerOfferDescription = OfferDataExtraction.offerinfo.get("$12-Router Discounts")
						.get("Review order Description").toString();

				String routerOfferPrice = OfferDataExtraction.offerinfo.get("$12-Router Discounts")
						.get("Review order Offer amount").toString();
				System.out.println(routerOfferDescription);
				System.out.println(routerOfferPrice);
				// Validating the presence of router offer in review order page
				// if we have non empty values from input sheet

				try {
					if (!routerOfferDescription.isEmpty() || routerOfferPrice.isEmpty()) {

						/*
						 * WebElement routerofferdesc = driver.findElement(
						 * By.xpath(
						 * "//div[contains(text(),'New')]/following-sibling::div/child::div[contains(text(),'"
						 * + routerOfferDescription +
						 * "')]/../following-sibling::div[contains(text(),'" +
						 * routerOfferPrice + "')]"));
						 */
						if (isDisplayed(driver.findElement(By.xpath("//div[contains(text(),'" + routerOfferDescription
								+ "')]/../following-sibling::div[contains(text(),'" + routerOfferPrice + "')]")))) {
							pageScroll(driver.findElement(By.xpath("//div[contains(text(),'" + routerOfferDescription
									+ "')]/../following-sibling::div[contains(text(),'" + routerOfferPrice + "')]")));
							// System.out.println(routerofferdesc);
							report.reportPass("Router Offer validation",
									"Router offer " + routerOfferDescription + " shoule be present",
									"Router offer " + routerOfferDescription + " is present");
						} else
							report.reportFail("Router Offer validation",
									"Router offer " + routerOfferDescription + " shoule be present",
									"Router offer " + routerOfferDescription + " is not present");
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e);
					// throw e;
				}
			}

			// DVR offer validation
			// $12 DVR discounts
			// Getting DVR offer validation from validation sheet

			if (get("$12 DVR discounts").equalsIgnoreCase("Yes")) {
				System.out.println(get("$12 DVR discounts"));
				// Getting DVR offer validation description and price from
				// validation input sheet
				String dvrOfferDescription = OfferDataExtraction.offerinfo.get("$12 DVR discounts")
						.get("Review order Description").toString();

				String dvrOfferPrice = OfferDataExtraction.offerinfo.get("$12 DVR discounts")
						.get("Review order Offer amount").toString();
				System.out.println(dvrOfferDescription);
				System.out.println(dvrOfferPrice);
				// Validating the presence of DVR offer in review order page if
				// we have non empty values from input sheet
				try {
					if (!dvrOfferDescription.isEmpty() || dvrOfferPrice.isEmpty()) {
						WebElement DVRofferdesc = driver
								.findElement(By.xpath("//div[contains(text(),'" + dvrOfferDescription
										+ "')]/../following-sibling::div[contains(text(),'" + dvrOfferPrice + "')]"));
						if (isDisplayed(DVRofferdesc)) {
							pageScroll(DVRofferdesc);
							report.reportPass("DVR Offer validation",
									"DVR offer " + dvrOfferDescription + " shoule be present",
									"DVR offer " + dvrOfferDescription + " is present");
						} else
							report.reportFail("DVR Offer validation",
									"DVR offer " + dvrOfferDescription + " shoule be present",
									"DVR offer " + dvrOfferDescription + " is not present");
					}
				}

				catch (Exception e) {
					e.printStackTrace();
					System.out.println(e);
					// throw e;
				}
			}
			// STB offer validation
			// Getting STB offer validation from validation sheet

			if (get("$12 STB discounts").equalsIgnoreCase("Yes")) {
				System.out.println(get("$12 STB discounts"));
				// Getting STB offer validation description and price from
				// validation input sheet
				String stbOfferDescription = OfferDataExtraction.offerinfo.get("$12 STB discounts")
						.get("Review order Description").toString();

				String stbOfferPrice = OfferDataExtraction.offerinfo.get("$12 STB discounts")
						.get("Review order Offer amount").toString();
				System.out.println(stbOfferDescription);
				System.out.println(stbOfferPrice);
				// Validating the presence of STB offer in review order page if
				// we have non empty values from input sheet
				try {
					if (!stbOfferDescription.isEmpty() || stbOfferPrice.isEmpty()) {
						WebElement STBofferdesc = driver
								.findElement(By.xpath("//div[contains(text(),'" + stbOfferDescription
										+ "')]/../following-sibling::div[contains(text(),'" + stbOfferPrice + "')]"));
						if (isDisplayed(STBofferdesc)) {
							pageScroll(STBofferdesc);
							report.reportPass("STB Offer validation",
									"STB offer " + stbOfferDescription + " shoule be present",
									"STB offer " + stbOfferDescription + " is present");
						} else
							report.reportFail("STB Offer validation",
									"STB offer " + stbOfferDescription + " shoule be present",
									"STB offer " + stbOfferDescription + " is not present");
					}
				}

				catch (Exception e) {
					e.printStackTrace();
					System.out.println(e);
					// throw e;
				}
			}
			// $50 reward card offer validation
			// Getting $50 reward card offer validation from validation sheet

			if (get("$50 Reward card").equalsIgnoreCase("Yes")) {
				System.out.println(get("$50 Reward card"));
				// Getting $50 reward card offer validation description and
				// price from validation input sheet

				String prepaid50RewardCardOfferDescription = OfferDataExtraction.offerinfo.get("$50 Reward card")
						.get("Review order Description").toString();

				String prepaid50RewardCardOfferPrice = OfferDataExtraction.offerinfo.get("$50 Reward card")
						.get("Review order Offer amount").toString();
				System.out.println(prepaid50RewardCardOfferDescription);
				System.out.println(prepaid50RewardCardOfferPrice);
				// Validating the presence of $50 reward card offer in review
				// order page if we have non empty values from input sheet
				try {
					if (!prepaid50RewardCardOfferDescription.isEmpty() || prepaid50RewardCardOfferPrice.isEmpty()) {
						WebElement Reward50Cardofferdesc = driver
								.findElement(By.xpath("//div[contains(text(),'" + prepaid50RewardCardOfferDescription
										+ "')]/../following-sibling::div[contains(text(),'"
										+ prepaid50RewardCardOfferPrice + "')]"));
						if (isDisplayed(Reward50Cardofferdesc)) {
							pageScroll(Reward50Cardofferdesc);
							report.reportPass("50 Reward card Offer validation",
									"50 Reward card offer " + prepaid50RewardCardOfferDescription
											+ " shoule be present",
									"50 Reward card offer " + prepaid50RewardCardOfferDescription + " is present");
						} else
							report.reportFail("50 Reward card Offer validation",
									"50 Reward card offer " + prepaid50RewardCardOfferDescription
											+ " shoule be present",
									"50 Reward card offer " + prepaid50RewardCardOfferDescription + " is not present");
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e);
					// throw e;
				}
			}
			// $100 reward card offer validation
			// Getting $100 reward card offer validation from validation sheet

			if (get("$100 Reward card").equalsIgnoreCase("Yes")) {
				System.out.println(get("$100 Reward card"));
				// Getting $100 reward card offer validation description and
				// price from validation input sheet

				String prepaid100RewardCardOfferDescription = OfferDataExtraction.offerinfo.get("$100 Reward card")
						.get("Review order Description").toString();

				String prepaid100RewardCardOfferPrice = OfferDataExtraction.offerinfo.get("$100 Reward card")
						.get("Review order Offer amount").toString();
				System.out.println(prepaid100RewardCardOfferDescription);
				System.out.println(prepaid100RewardCardOfferPrice);
				// Validating the presence of $100 reward card offer in review
				// order page if we have non empty values from input sheet
				try {
					if (!prepaid100RewardCardOfferDescription.isEmpty() || prepaid100RewardCardOfferPrice.isEmpty()) {
						/*
						 * WebElement Reward100Cardofferdesc =
						 * driver.findElement( By.xpath(
						 * "//div[contains(text(),'New')]/following-sibling::div/child::div[contains(text(),'"
						 * + prepaid100RewardCardOfferDescription +
						 * "')]/../following-sibling::div[contains(text(),'" +
						 * prepaid100RewardCardOfferPrice + "')]"));
						 */
						if (isDisplayed(driver
								.findElement(By.xpath("//div[contains(text(),'" + prepaid100RewardCardOfferDescription
										+ "')]/../following-sibling::div[contains(text(),'"
										+ prepaid100RewardCardOfferPrice + "')]")))) {
							// pageScroll(Reward100Cardofferdesc);
							report.reportPass("100 Reward card Offer validation",
									"100 Reward card offer " + prepaid100RewardCardOfferDescription
											+ " shoule be present",
									"100 Reward card offer " + prepaid100RewardCardOfferDescription + " is present");
						} else
							report.reportFail("100 Reward card Offer validation",
									"100 Reward card offer " + prepaid100RewardCardOfferDescription
											+ " shoule be present",
									"100 Reward card offer " + prepaid100RewardCardOfferDescription
											+ " is not present");
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e);
					// throw e;
				}
			}
			// Auto pay offer validation
			// Getting Auto pay offer validation from validation sheet

			if (get("$10 Auto-Pay Discount").equalsIgnoreCase("Yes")) {
				System.out.println(get("$10 Auto-Pay Discount"));
				// Getting Auto - Pay offer validation description and price
				// from validation input sheet

				String autoPayOfferDescription = OfferDataExtraction.offerinfo.get("$10 Auto-Pay Discount")
						.get("Review order Description").toString();

				String autoPayOfferPrice = OfferDataExtraction.offerinfo.get("$10 Auto-Pay Discount")
						.get("Review order Offer amount").toString();
				System.out.println(autoPayOfferDescription);
				System.out.println(autoPayOfferPrice);
				// Validating the presence of Auto pay offer in review order
				// page if we have non empty values from input sheet
				try {
					if (!autoPayOfferDescription.isEmpty() || autoPayOfferPrice.isEmpty()) {
						/*
						 * WebElement autoPayofferdesc = driver.findElement(
						 * By.xpath(
						 * "//div[contains(text(),'New')]/following-sibling::div/child::div[contains(text(),'"
						 * + autoPayOfferDescription +
						 * "')]/../following-sibling::div[contains(text(),'" +
						 * autoPayOfferPrice + "')]"));
						 */
						if (isDisplayed(driver.findElement(By.xpath("//div[contains(text(),'" + autoPayOfferDescription
								+ "')]/../following-sibling::div[contains(text(),'" + autoPayOfferPrice + "')]")))) {
							pageScroll(driver.findElement(By.xpath("//div[contains(text(),'" + autoPayOfferDescription
									+ "')]/../following-sibling::div[contains(text(),'" + autoPayOfferPrice + "')]")));
							report.reportPass("Auto-Pay Discount Offer validation",
									"Auto-Pay Discount offer " + autoPayOfferDescription + " shoule be present",
									"Auto-Pay Discount offer " + autoPayOfferDescription + " is present");
						} else
							report.reportFail("Auto-Pay Discount Offer validation",
									"Auto-Pay Discount offer " + autoPayOfferDescription + " shoule be present",
									"Auto-Pay Discount offer " + autoPayOfferDescription + " is not present");
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e);
					// throw e;
				}
			}
			// Zero rated lead offer validation
			// Getting Auto pay offer validation from validation sheet

			if (get("Zero rated Lead offer").equalsIgnoreCase("Yes")) {
				System.out.println(get("Zero rated Lead offer"));
				// Getting Auto - Pay offer validation description and price
				// from validation input sheet

				String zeroRatedOfferDescription = OfferDataExtraction.offerinfo.get("Zero rated Lead offer")
						.get("Review order Description").toString();

				String zeroRatedOfferPrice = OfferDataExtraction.offerinfo.get("Zero rated Lead offer")
						.get("Review order Offer amount").toString();
				System.out.println(zeroRatedOfferDescription);
				System.out.println(zeroRatedOfferPrice);
				// Validating the presence of Auto pay offer in review order
				// page if we have non empty values from input sheet
				try {
					if (!zeroRatedOfferDescription.isEmpty() || zeroRatedOfferPrice.isEmpty()) {
						/*
						 * WebElement autoPayofferdesc = driver.findElement(
						 * By.xpath(
						 * "//div[contains(text(),'New')]/following-sibling::div/child::div[contains(text(),'"
						 * + autoPayOfferDescription +
						 * "')]/../following-sibling::div[contains(text(),'" +
						 * autoPayOfferPrice + "')]"));
						 */
						if (isDisplayed(driver.findElement(By.xpath("//div[contains(text(),'"
								+ zeroRatedOfferDescription + "')]/../following-sibling::div[contains(text(),'"
								+ zeroRatedOfferPrice + "')]")))) {
							pageScroll(driver.findElement(By.xpath("//div[contains(text(),'" + zeroRatedOfferDescription
									+ "')]/../following-sibling::div[contains(text(),'" + zeroRatedOfferPrice
									+ "')]")));
							report.reportPass("Auto-Pay Discount Offer validation",
									"Auto-Pay Discount offer " + zeroRatedOfferDescription + " shoule be present",
									"Auto-Pay Discount offer " + zeroRatedOfferDescription + " is present");
						} else
							report.reportFail("Auto-Pay Discount Offer validation",
									"Auto-Pay Discount offer " + zeroRatedOfferDescription + " shoule be present",
									"Auto-Pay Discount offer " + zeroRatedOfferDescription + " is not present");
					}
				}

				catch (Exception e) {
					e.printStackTrace();
					System.out.println(e);
					// throw e;
				}

			}
		}

		catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
			// throw e;
		}

	}

	public void offerTileValidation() throws JSONException, IOException, Exception {

		try {

			switchToDefaultcontent();

			switchToFrame("IfProducts");

			// Expand Contract
			if (!getAttribute(expandContract, objectValue, "class").contains("open")) {
				pageScroll(expandContract, objectValue, true);
				clickUsingJavaScript(expandContract, objectValue);

				waitForLoader();
				waitForLoader();
				waitForLoader();
				pageScroll(selectedofferViewDetail, objectValue, true);

				clickUsingJavaScript(selectedofferViewDetail, objectValue);

				waitForLoader();
				report.reportPass("To View Agreement & Offers Section", "Display Agreement & Offers Section",
						"Agreement & Offers Section should be displayed");
			}
			for (String offername : OfferDataExtraction.offerinfo.keySet())

			{
				String Expected_offer = OfferDataExtraction.offerinfo.get(offername).get("OPO Offer Description")
						.toString();

				if (get(offername).equalsIgnoreCase("Yes")) {

					try {
						if (isDisplayed(offeronDisplay_OfferDetailPopUp, Expected_offer)) {

							pageScroll(offeronDisplay_OfferDetailPopUp, Expected_offer, true);

							report.reportPass("validate " + Expected_offer, Expected_offer + " should be displayed",
									"offer is displayed");
							System.out.println(Expected_offer + " is displayed as expected");

						} else {
							report.reportFail("validate " + Expected_offer, Expected_offer + " should be displayed",
									"offer is not displayed");

							System.out.println(Expected_offer + " is not displayed though expected");

						}
					} catch (Exception ex) {
						report.reportFail("validate " + Expected_offer, Expected_offer + " should be displayed",
								"offer is not displayed");
						System.out.println(Expected_offer + " is not displayed though expected");

					}

				} else if (get(offername).equalsIgnoreCase("No")) {

					try {
						if (!isDisplayed(offeronDisplay_OfferDetailPopUp, Expected_offer)) {

							report.reportPass("validate " + Expected_offer, Expected_offer + " should not be displayed",
									"offer is not displayed");
							System.out.println(Expected_offer + " is not displayed as expected");

						} else {

							pageScroll(offeronDisplay_OfferDetailPopUp, Expected_offer, true);
							report.reportFail("validate " + Expected_offer, Expected_offer + " should not be displayed",
									"offer is displayed");
							System.out.println(Expected_offer + " is displayed though unexpected");

						}
					} catch (Exception ex) {
						report.reportPass("validate " + Expected_offer, Expected_offer + " should not be displayed",
								"offer is not displayed");
						System.out.println(Expected_offer + " is not displayed as expected");

					}

				}
			}
			clickUsingJavaScript(DetailsClose, objectValue);
			// Expand Contract
			if (getAttribute(expandContract, objectValue, "class").contains("open")) {
				pageScroll(expandContract, objectValue, true);
				clickUsingJavaScript(expandContract, objectValue);
				waitForLoader();
			}

		} catch (Exception ex) {
			System.out.println(ex.getMessage() + ex.getCause());
			ex.printStackTrace();
		}

	}

	
}
