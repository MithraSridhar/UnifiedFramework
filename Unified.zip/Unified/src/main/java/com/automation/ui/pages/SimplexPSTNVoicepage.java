package com.automation.ui.pages;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_PSTNVoice_PageObjects;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * SimplexProductAndServicesPage class represents the Product & Services and
 * interact with the Page.
 * 
 */
public class SimplexPSTNVoicepage extends Simplex_PSTNVoice_PageObjects {

    String objectValue = "";
    static boolean windows = InitiateDriver.windows;
    int iterator = 0;
    String testId;
    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

    String description = "", expected = "", actual = "", failure = "", getUrl = "";
    By by;

    /**
     * SimplexProductServicesPage constructor invokes the super class
     * constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     */
    public SimplexPSTNVoicepage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, windows, report, data);
	this.testId = testId;
    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     */
    public static SimplexPSTNVoicepage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexPSTNVoicepage.class, testId, report, data);
    }

    public void start() throws Exception {

	setIterator();
	if ((get("FlowType").contains("Install") || get("FlowType").contains("Change")|| get("FlowType").contains("Move"))&& get("Application").equalsIgnoreCase("CoA")) {

	   LECPageNavigation();
	} 
	else if((get("FlowType").contains("Install") || get("FlowType").contains("Change"))&& get("Application").equalsIgnoreCase("C2G")){
		selectLecVoice();
	}
	else if((get("StackDisconnectOption").contains("Move") || get("FlowType").contains("Stack"))&& get("Application").equalsIgnoreCase("C2G")){
		selectLecVoice();
	}
	//navigateTo();
	
    }
    
    
    public void navigateTo() throws Exception, UserDefinedException {

    	// clickUsingJavaScript on left panel for ProductPage
    	try {
    		int i = TestIterator.getIterator(testId);
    		TestIterator.setIterator(testId, ++i);
    		//LECClickSaveAndContinue();
    		}catch (Exception e) {
    	
    		e.printStackTrace();
    		throw new UserDefinedException("PSTN Button didn't click");
    	    }
    	}
    
    /**
     * @Info To Negotiate LEC page
     * @param FirstName
     * @param LastName
     * @param Additional
     *            Lines
     * @throws Exception
     * @Modified by Sourish
     * @Modified by Poovaraj
     * @LastUpdated 13/03/2017
     */
    public void LECPageNavigation() throws Exception 
    {
	
    long timeNow = System.currentTimeMillis();
	System.out.println("->LECPageNavigation");
	String strDescription = "", strExpected = "", strActual = "", strFailed = "", FIRSTNAME = "", LASTNAME = "", AdditionalLines = "";
	try {
   		
		//waitForLoader();	
		String FlowType = get("FlowType").toString();
	    String Application = get("Application").toString();
	    String Standalone = get("PSTN_Voice_Type").toString();
	    String changetype=get("ChangeType").toString();
	    
	    //Updated by Poovaraj on 06 Mar 2017
	    //if (FlowType.equalsIgnoreCase("Install") && Application.equalsIgnoreCase("COA") && Standalone.equalsIgnoreCase("Voice"))
	    if ((FlowType.equalsIgnoreCase("Install")||FlowType.equalsIgnoreCase("Change")||FlowType.equalsIgnoreCase("Move")) && Application.equalsIgnoreCase("COA") && Standalone.contains("Voice"))
	    {
	    	if(!changetype.contains("Ownership")){	
		FIRSTNAME = get("FirstName");
		LASTNAME = get("LastName");
		AdditionalLines = get("pstnAdditionalLines");
		strDescription = "Negotiate LEC Page";
		strExpected = "Verify that LEC information is able to provide ";
		strActual = "LEC page is negotiated successfully";
		strFailed = "LEC page details are not getting updated successfully";
		getUrl = ", URL Launched --> " + returnURL();

		switchToDefaultcontent();
		switchToFrame("IfProducts");
		
		//Updated by poovaraj on 07-Mar-2017
		String baseWindow = driver.getWindowHandle();		
		
		 
	     //Updated by poovaraj on 09-Mar-2017		 
		 switchToWindowWithURL("LineAndTN");
	   //  maximizeBrowserWindow();
	     
		// Negotiating Lines & TN assignment Section
		// Entering number of New lines		
		if (!AdditionalLines.isEmpty()) 
		{
			
			if((!AdditionalLines.equals("0") && (!AdditionalLines.isEmpty())) && (isDisplayed(LinesAndTNEdit, baseWindow, 3))){
				clickUsingJavaScript(LinesAndTNEdit, objectValue);
				waitForLoader();
				if(isDisplayed(termsok)){
					clickUsingJavaScript(termsok, objectValue);
				}
				waitForLoader();
				waitForLoader();
				}
			
			if(isDisplayed(ExistingBTN) && AdditionalLines.equals("0") && FlowType.equalsIgnoreCase("Change"))
			{
				waitForLoader();
			    //System.out.println(ExistingBTN.getText());
			    report.reportPass("Validate that Existing BTN is there or not", "Existing BTN should be there",
				    "Existing BTN is there");
				
			}
			else
			{
		    if (isDisplayed(NoOfLines)) 
		    {
		    	mouseOver(NoOfLines);		    	
		    	clearText(NoOfLines, "");
		    	setText(NoOfLines, "", AdditionalLines);
		    	report.reportPass("Enter Number of New Lines?" + AdditionalLines, "Verify is the number of New Lines entered", "No Of Lines are entered successfully");
		    }

		    Thread.sleep(4000);
		    // Clicking on Getlines
		    if (isDisplayed(BtnGetLines)) {
			mouseOver(BtnGetLines);
			clickUsingJavaScript(BtnGetLines, "");
			Alert alert = driver.switchTo().alert();
		     alert.accept();
			report.reportPass("Verify Getlines/Tn's button is clicked in Lines and Tn Assignment section", "Verify is Getlines/Tn's button is clicked in Lines and Tn Assignment section",
				"Getlines/Tn's button is clicked in Lines and Tn Assignment section");

		    }
		   }
		}

		// Clicking on OK button in LEC page under TN Assignment Summary
		// section in LEC page
		try {
			waitForLoader();
		    // waitForElementDisplay(BtnLinesOk,"", 5);
			if(isDisplayed(BtnLinesOk, ""))
			{
		    mouseOver(BtnLinesOk);
		    clickUsingJavaScript(BtnLinesOk, "");// Click is not working
		    System.out.println("BtnLinesOK under TNAssignment section has been clicked");
		    report.reportPass("Clikcing on OK buttn under Lines and Assignment Section", "Verify Ok button is clicked in Lines and Tn Assignment section",
			    "OK button is clicked in Lines and Tn Assignment section");
			}

		} catch (Exception e)
		{	
			strFailed = "Failed to click on OK button due to Object attribute is not availabe";
			getUrl = ", URL Launched --> " + returnURL();
		    report.reportFail("Clikcing on OK buttn under Lines and Assignment Section" + getUrl, "Verify Ok button is clicked in Lines and Tn Assignment section",
			    "Failed to click on OK button due to Object attribute is not availabe");						    				    
		    report.updateMainReport("comments", strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		    logger.debug(strFailed);
		    captureErrorMsg(strFailed);
		    throw new UserDefinedException(strFailed);

		}

		// Spinner processing
		//waitForLoader();
		pause();

		int j = 3;
		int y = Integer.parseInt(AdditionalLines);
		
		List<WebElement> Linecheck = driver.findElements(by.xpath("//input[@type='checkbox']"));
		Linecheck.get(2).click();
		for (int i = 0; i <= y; i++) {

		    Linecheck.get(i + 2).click();
		    // click on GetDetailes Lines
		    isDisplayed(GetDetailsforLines);
		    mouseOver(GetDetailsforLines);
		    clickUsingJavaScript(GetDetailsforLines, "");
		    waitForLoader();
		    waitForLoader();
		    Thread.sleep(2000);
		   if(i==0 && y>0){
		   
		    if(!get("TPV").isEmpty()){
		    	
		    	 mouseOver(Long_Distance_Carrier);
                 selectDropDownUsingVisibleText(Long_Distance_Carrier, "", get("TPV"));
                 System.out.println("LONG DISTANCE plan Selected.");
                 waitForLoader();
                 waitForLoader();
                 // Click on Apply under Calling Plan and Carrier Info                
                 mouseOver(ApplyCallingPlan);
                 clickUsingJavaScript(ApplyCallingPlan, "");
                 System.out.println("Apply button is clicked under Calling Plans and Carrier Info section");
                 report.reportPass("Clicking on apply button", "Verify that Apply button is clicked", "Apply button is clicked under Calling Paln and CArrier Info section successfully");
                 //waitForLoader();
                 waitForLoader();
                 pause();
		    }
		   }
		   else{
		   
		    
		    // Negotiating Plan and Features Section	    
		    //********************************************************************************************			
			// Updated by Poovaraj on 13-Mar-2017
			//********************************************************************************************
		       
					LECPlanFeatures(FIRSTNAME, LASTNAME);
			  
		    
		    
		    waitForLoader();
		   }
		    if (i != y) {
			Linecheck = driver.findElements(by.xpath("//input[@type='checkbox']"));
			Linecheck.get(i + 2).click();
		    }
		}

		// Spinner processing
		//waitForLoader();		
		pause();
		if(isDisplayed(InterceptsOk, baseWindow, 5))
		{
		mouseOver(InterceptsOk);
		clickUsingJavaScript(InterceptsOk, "");
		report.reportPass("Validate that Intercepts OK Button clicked or not", "Intercepts OK Button should be clicked", "Intercepts OK Button is clicked");
		waitForLoader();
		waitForLoader();
		}
		// Clicking on OK in NRC section
		try
		{
			LECNRCOK();
			
		}catch(Exception e)
		{
			 	report.reportFail("Click on Save and Continue Button", "Window should be closed after click on save and continue button","Window is NOT closed after click on save and continue button");				    
			    strFailed = "Window is NOT closed after click on save and continue button";				    
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    logger.debug(strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);
		}

		// Spinner processing
		//waitForLoader();		
		pause();
		
		// timelapsed - console
		System.out.println(System.currentTimeMillis() - timeNow + " Milliseconds");

		// Clicking on Save and Continue in LEC page
		LECClickSaveAndContinue();	
		pause();
	    	}
	    	else{
	    	// timelapsed - console
			System.out.println(System.currentTimeMillis() - timeNow + " Milliseconds");

			// Clicking on Save and Continue in LEC page
			LECClickSaveAndContinue();	
			pause();
	    	}
		//Updated by poovaraj on 07-Mar-2017
		//driver.switchTo().window(baseWindow);		
		
		// clickUsingJavaScript(VoiceOptionsBar, objectValue);
		report.reportPass(strDescription + getUrl, strExpected, strActual);		
		
		
	    }

	} catch (Exception exe) 
	{
	   /* exe.printStackTrace();
	    getUrl = ", URL Launched --> " + returnURL();
	    report.reportFail("strDescription" + getUrl, strExpected, strFailed);
	    throw exe;*/
		
		strFailed = "LEC details is NOT selected";
	    report.reportFail("Select LEC Details", "LEC details should be selected", strFailed);
	    report.updateMainReport("comments", strFailed);
	    report.updateMainReport("ErrorMessage", strFailed);
	    logger.debug(strFailed);
	    captureErrorMsg(strFailed);
	    throw new UserDefinedException(strFailed);
	}  	    		
	
    }

    /**
     * @Info To Negotiate Plan adn Features under LEC page
     * @param FirstName
     * @param LastName
     * @throws Exception
     * @Modified by Poovaraj
     * @LastUpdated 03/13/2017
     */
    public void AddingLECPlanDetails(int intNoOfLine) throws Exception
    {
       
       String FIRSTNAME = "Passlow";
       String LASTNAME = "Customer";
       
       String strDescription = "", strExpected = "", strActual = "", strFailed = "";
              try 
              {
                 // strDescription = "Negotiate Plan and Features under LEC Page";
                  strExpected = "Verify that Plan and features options are getting selected ";
                  strActual = "Plan and features options are getting selected successfully";
                  strFailed = "Plan and Features options are not being selected,since it is getting failed";
                  getUrl = ", URL Launched --> " + returnURL();
       
                  // Negotiating Calling Plans and Carrier Info Section in LEC page
                  try 
                  {  
                    String LecVoicePackage = get("PSTNVoicePackage").trim();
              	    String VerizoncallingService = get("PSTNVerizonCallingService").trim();
                  	
              	  if((!LecVoicePackage.contains("None")) && (!LecVoicePackage.isEmpty()))
      	 	      {
      	 	    	pageScroll(Lecvoicepackage, "", true);
      	 	    	selectDropDownUsingValue(Lecvoicepackage, "", LecVoicePackage);
      	 	    	waitForPageToLoad(driver);
      	 	    	waitForLoader();
      	 	    	if((LecVoicePackage.contains("PGO8R")) ||(LecVoicePackage.contains("PGO6R")))
                      {
                      if(isDisplayed(Domestic_LD_Plan))
                      {
  	                  mouseOver(Domestic_LD_Plan);
  	                  selectDropDownUsingValue(Domestic_LD_Plan, "", "O5V2X");
  	                  System.out.println("Domestic LD Plan has been selected from dropdown");
  	                  waitForLoader();
                        waitForLoader();
                        waitForLoader();
                      }
                      }
      	 	       }
      	    	 
          	    	
          	 	   if(LecVoicePackage.contains("None"))
          	 	    {
          	 		  if(isDisplayed(Moreoptions))
          		    	{
          		    		pageScroll(Moreoptions, "", true);
          		    		clickUsingJavaScript(Moreoptions, "");
          		    		waitForLoader();
          		    		waitForLoader();
          		    		report.reportPass("Clicking on More options button", "More options button should be clicked", "More options button is clicked under Calling Paln and CArrier Info section successfully");
          		    	}
          	 		  
          	 		  if(isDisplayed(VerizonCallingPackage))
          	 		  {
          	 			    pageScroll(VerizonCallingPackage, "", true);
          		 	    	selectDropDownUsingValue(VerizonCallingPackage, "", LecVoicePackage);
          		 	    	waitForLoader();
          		 	    	waitForLoader();
          		 	    	report.reportPass("Selecting Verizon Calling Package from dropdown", "Verizon Calling Package should be selected from dropdown", "Verizon Calling Package is selecting from dropdown");
          	 		  }
          	 		 WebElement drop_down = driver.findElement(By.xpath("//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_dropdownCallingService']"));
          		 	 Select verizoncallingservice = new Select(drop_down);
          		 	 List<WebElement> options = verizoncallingservice.getOptions();
          	 		  if(isDisplayed(drop_down))
          	 		  {
            	 			   try
            	 			   {
            	 				   int flag=0;
            	 				   breakLoop :
            	 				  for (int i=0;i<options.size();i++)
            	 				  {
            	 					  if(options.get(i).getText().contains(VerizoncallingService)) 
            	 					  {
            	 						  verizoncallingservice.selectByValue(VerizoncallingService);	
            	 						  flag=1;
            	 						  waitForLoader();
            	 						break breakLoop;
            	 					  }
            	 					 
            	 				  }
            	 			   if(flag==0){
            	 			   	 verizoncallingservice.selectByValue("1FR");	
          					 waitForLoader();
            	 			   }
          					 
          					 
            	 	 			 waitForLoader();
            			 	     waitForLoader();
            	 				 report.reportPass("Selecting Verizon Calling Service from dropdown", "Verizon Calling Service should be selected from dropdown", "Verizon Calling Service is selecting from dropdown");
            	 				
            	 				if(isDisplayed(Domestic_LD_Plan))
            	 		    	{
            	 		    		mouseOver(Domestic_LD_Plan);
            	 		    		selectDropDownUsingValue(Domestic_LD_Plan, "", "O5V2X");
            	 		    		System.out.println("Domestic LD Plan has been selected from dropdown");
            	 		    		waitForLoader();
            	 		    	    waitForLoader();
            	 		    	    waitForLoader();
            	 		    	}
            	 				 if(isDisplayed(DrpIEPlan))
            	 			    {
            	 			    mouseOver(DrpIEPlan);
            	 			    selectDropDownUsingValue(DrpIEPlan, "", "NICP");
            	 				System.out.println("International Plan has been selected from dropdown");
            	 				waitForSpinnerLoad();
            	 				Thread.sleep(500);
            	 			    }
            	 				
            	 				 if(isDisplayed(ApplytoSelectedLine))
            	 		    	{
            	 		    		pageScroll(ApplytoSelectedLine, "", true);
            	 		    		clickUsingJavaScript(ApplytoSelectedLine, "");
            	 		    		waitForLoader();
            	 		    		report.reportPass("Verify Apply to Selected Line button is clicked or not", "Apply to Selected Line Button should be Clicked", "Apply to Selected Line Button is Clicking");
            	 		    		waitForLoader();
            	 		    	}
            	 		    	if(isDisplayed(OkButton))
            	 		    	{
            	 		    		pageScroll(OkButton, "", true);
            	 		    		clickUsingJavaScript(OkButton, "");
            	 		    		waitForLoader();
            	 		    		report.reportPass("Verify Ok button is clicked or not", "OK Button should be Clicked", "Ok Button is Clicking");
            	 		    		waitForLoader();
            	 		    		waitForLoader();
            	 		    	} 
            	 				 
            	 			   }
            	 			   catch(Exception e)
            	 			   {
            	 				  e.printStackTrace(); 
            	 				  report.reportFail("Selecting Verizon Calling Service from dropdown", "Verizon Calling Service should be selected from dropdown", "Verizon Calling Service is not selected from dropdown");
            	 			   }
            	 		  }
          	 		  
          	 	    }
                     
                     // selecting LONG DISTANCE Plan   
                	  String VoiceValue = get("VoiceValue").trim();
                  	
                  	if(VoiceValue.contains("Regional"))
                  	{
                  		   mouseOver(Long_Distance_Carrier);
                           selectDropDownUsingVisibleText(Long_Distance_Carrier, "", "VERIZON LONG DISTANCE (BA) 6963");
                           System.out.println("LONG DISTANCE plan Selected.");
                           pause();
                     
                     // selecting Domestic LD Plan     
                                   
                           mouseOver(Domestic_LD_Plan);
                           selectDropDownUsingVisibleText(Domestic_LD_Plan, "", "ONEAN TalkTime 30 $11.99 $11.99");
                           System.out.println("Domestic LD plan Selected.");
                           pause();
                  	}
                         // selecting International Plan             
                           mouseOver(DrpIEPlan);
                           selectDropDownUsingVisibleText(DrpIEPlan, "", "NICP No International Calling Plan $0 $0");
                           System.out.println("International Plan has been selected from dropdown");
                           
                           waitForLoader();
                           // Click on Apply under Calling Plan and Carrier Info                
                           mouseOver(ApplyCallingPlan);
                           clickUsingJavaScript(ApplyCallingPlan, "");
                           System.out.println("Apply button is clicked under Calling Plans and Carrier Info section");
                           report.reportPass("Clicking on apply button", "Verify that Apply button is clicked", "Apply button is clicked under Calling Paln and CArrier Info section successfully");
                           //waitForLoader();
                           waitForLoader();
       
                  } catch (Exception e) 
                  {
                           getUrl = ", URL Launched --> " + returnURL();
                           report.reportFail("Clicking on apply button" + getUrl, "Verify that Apply button is clicked", "Failed to click th eapply button due to object not in ready state");                            
                           report.reportFail("Select Plan and Features Options.", "Plan and Features options should be selected", strFailed);
                           report.updateMainReport("comments", strFailed);
                           report.updateMainReport("ErrorMessage", strFailed);
                           logger.debug(strFailed);
                           captureErrorMsg(strFailed);
                           throw new UserDefinedException(strFailed);
                           
                  }
       }catch(Exception e)
              {                                         
                     report.reportFail("Select Plan and Features Options.", "Plan and Features options should be selected", strFailed);
                     report.updateMainReport("comments", strFailed);
                     report.updateMainReport("ErrorMessage", strFailed);
                     logger.debug(strFailed);
                     captureErrorMsg(strFailed);
                     throw new UserDefinedException(strFailed);         
              }                    
              
              try
              {
                  // Clicking on Check box Maintenance Plan
                  // waitForElementDisplay(ChkBoxUnderFeatures, "Maintenance
                  // Plan", 2);
                  mouseOver(ChkBoxUnderFeatures, "Maintenance Plan");
                  clickUsingJavaScript(ChkBoxUnderFeatures, "Maintenance Plan");
                  System.out.println("MAINTENANCE PLANSETUP is checked");
                  report.reportPass("Selecting Maintenance check box", "Verify that Maintenance check box is selected", "Maintanence chec box is checked successfully");

                  // Spinner processing
                  waitForSpinnerLoad();
                  Thread.sleep(1000);
                  if (!isDisplayed(Maintenance_Plan_Window)) {
                      click(setup_Maintenance_Plan);
                  }
                  waitForSpinnerLoad();
                  Thread.sleep(1000);
                  // Selecting WMR Maintenance Yes Plan

                  String lecMaintenancePlan = get("PSTNMaintenancePlan").trim();

                  if (lecMaintenancePlan.contains("WMR") || lecMaintenancePlan.contains("NMC")||lecMaintenancePlan.contains("MNTPB")||lecMaintenancePlan.contains("SEQ1X") ||lecMaintenancePlan.contains("OWM")) {
                      mouseOver(Inside_Wire_Maintainance, lecMaintenancePlan);
                      clickUsingJavaScript(Inside_Wire_Maintainance, lecMaintenancePlan);
                      click(Inside_Wire_Maintainance, lecMaintenancePlan);
                      System.out.println("WMR inside wire Maintenance Plan is selected");
                      report.reportPass("Selecting" +"lecMaintenancePlan"+" inside wire Maintenance Plan", "Verify that " +"lecMaintenancePlan"+"inside wire Maintenance Plan is selected",
                            "" +"lecMaintenancePlan"+" inside wire Maintenance Plan chec box is checked successfully");
                  } 
                  // Spinner processing
                  waitForSpinnerLoad();
                  Thread.sleep(1000);

                  // Clicking on OK/Apply to the selected lines under Maintenance
                  // Plan set up frame
                  // waitForElementDisplay(MaintenanceOK, "", 2);
                  mouseOver(MaintenanceOK);
                  clickUsingJavaScript(MaintenanceOK, "");
                  System.out.println("OK/Apply to the selected lines button is clicked");
                  report.reportPass("Clicking the OK button under Maintenance plan set up", "Verify that OK button is getting clicked under the Maintenance Plan set up frame",
                        "Ok is clicked successfully");

               }catch(Exception e)
              {                    
                 report.reportFail("Select Maintenance Plan", "Maintenance Plan should be selected", "Maintenance Plan is NOT selected successfully");
                 report.reportFail("Select Plan and Features Options.", "Plan and Features options should be selected", strFailed);
                 report.updateMainReport("comments", strFailed);
                 report.updateMainReport("ErrorMessage", strFailed);
                 logger.debug(strFailed);
                 captureErrorMsg(strFailed);
                 throw new UserDefinedException(strFailed); 
              }      
              
           
              try
              {
                     //Select Voice Back Up Plan
                     if (isDisplayed(lnkVoiceBackUpSetUp,objectValue,10))
                     {
                           mouseOver(lnkVoiceBackUpSetUp);
                           clickUsingJavaScript(lnkVoiceBackUpSetUp, "");
                           waitForLoader();
                           
                           //Select No Maintenace Options                  
                           waitForElementDisplay(lstVoiceBackUpSetUpOptions, objectValue,  15);
                           mouseOver(lstVoiceBackUpSetUpOptions);                 
                           //Dynamically changing every time
                           //selectDropDownUsingVisibleText(lstVoiceBackUpSetUpOptions, objectValue, "FEKZG  Customer Declined Voice Backup Power Reserve (after addressing any questions)  $0.00");
                           click(lstVoiceBackUpSetUpOptions);
                           System.out.print(lstVoiceBackUpSetUpOptions.getText());
                           waitForLoader();
                           
                           waitForElementDisplay(btnVoiceBackUpOK, objectValue,  15);
                           mouseOver(btnVoiceBackUpOK);
                           mouseclick(btnVoiceBackUpOK,objectValue);
                           //clickUsingJavaScript(btnVoiceBackUpOK, "");
                           waitForLoader();                  
                           pause();
                           
                           report.reportPass("Select Voice Back Up Plan", "Voice Back Up Plan should be selected", "Voice Back Up Plan is selected successfully");
                     }
                     
              }catch(Exception e)
              {
                     report.reportFail("Select Voice Back Up Plan", "Voice Back Up Plan should be selected", "Voice Back Up Plan is NOT selected");
                     report.reportFail("Select Plan and Features Options.", "Plan and Features options should be selected", strFailed);
                     report.updateMainReport("comments", strFailed);
                     report.updateMainReport("ErrorMessage", strFailed);
                     logger.debug(strFailed);
                     captureErrorMsg(strFailed);
                     throw new UserDefinedException(strFailed);
              }             
              
              try
              {
                  // Clicking on Jacks
                  // waitForElementDisplay(ChkBoxUnderFeatures, "Jacks", 2);
                  mouseOver(ChkBoxUnderFeatures, "Jacks");
                  clickUsingJavaScript(ChkBoxUnderFeatures, "Jacks");
                  System.out.println("JACKS check box is checked");
                  report.reportPass("Checking the JACKS check box", "Verify that JACKS is checked", "JACKS is checked successfully");

                  // Spinner processing
                  waitForSpinnerLoad();
                  

                  if (!isDisplayed(Jacks_Window)) {
                        
                      click(setup_Jacks);

                  }
                  waitForSpinnerLoad();
                  
                  // Selecting Jacks

                  String Jacktype = get("PSTNVoiceJack").trim();

                  if (Jacktype.contains("Primary")) {
                      mouseOver(Jacks_Type);
                      clickUsingJavaScript(Jacks_Type, Jacktype);
                      click(ADDLinkJack);
                      waitForSpinnerLoad();
                      Thread.sleep(1000);
                      System.out.println("Primary Jack is selected in Jacks/Fixed Fee Setup");
                      report.reportPass("Selecting Jacks/Fixed Fee Setup", "Verify that able to select Primary Jack in Jacks/Fixed Fee setup", "Primary Jack is selected successfully");
                  } else if (Jacktype.contains("Additional")) {
                      mouseOver(Jacks_Type);
                      clickUsingJavaScript(Jacks_Type, Jacktype);
                      click(ADDLinkJack);
                      waitForSpinnerLoad();
                      Thread.sleep(1000);
                      System.out.println("Additional Jack is selected in Jacks/Fixed Fee Setup");
                      report.reportPass("Selecting Jacks/Fixed Fee Setup", "Verify that able to select Additional Jack in Jacks/Fixed Fee setup", "Additional Jack is selected successfully");
                  }
                  // Selecting No Jacks
                  else {
                      mouseOver(ChkbxLECNoJacks);
                      clickUsingJavaScript(ChkbxLECNoJacks, "");
                      System.out.println("NO JACKS is selected in Jacks/Fixed Fee Setup");
                      report.reportPass("Selecting Jacks/Fixed Fee Setup", "Verify that able to select NO JACKS in Jacks/Fixed Fee setup", "NO JACKS is selected successfully");
                  }

                  // Spinner processing
                  waitForSpinnerLoad();
                  Thread.sleep(1000);

                  // Clicking on OK in Jacks setup
                  // waitForElementDisplay(NoJackOK, " ", 2);
                  mouseOver(BtnLECJackOk);
                  clickUsingJavaScript(BtnLECJackOk, " ");
                  System.out.println("OK button is clicked in Jacks/Fixed Fee Setup");
                  report.reportPass("Clicking the OK button under Jacks/Fixed Fee Setup", "Verify that OK button is getting clicked under Jacks/Fixed Fee Setup frame", "Ok is clicked successfully");

               }catch(Exception e)
              {
                     report.reportFail("Select Jack Optin", "Jack Option should be selected", "Jack Option is NOT selected");                
                     report.reportFail("Select Plan and Features Options.", "Plan and Features options should be selected", strFailed);
                     report.updateMainReport("comments", strFailed);
                     report.updateMainReport("ErrorMessage", strFailed);
                     logger.debug(strFailed);
                     captureErrorMsg(strFailed);
                     throw new UserDefinedException(strFailed);
              }
             
                //Click On Apply Button
              waitForElementDisplay(btnLECFeaturesApply, objectValue,  15);
              mouseOver(btnLECFeaturesApply);
              mouseclick(btnLECFeaturesApply,objectValue);
              //clickUsingJavaScript(btnLECFeaturesApply, "");
              //waitForLoader();   
              pause();
              
           // Handling of Directory Listing
           try 
           {
                     // Clicking on Edit link
                     // waitForElementDisplay(DLEdit, "", 2);
        	   		 waitForElementDisplay(DLEdit, objectValue,  15);
                     mouseOver(DLEdit);
                     clickUsingJavaScript(DLEdit, "");// click not working
                     System.out.println("EDIT link is clicked");
                     report.reportPass("Clicking on EDIT under Directory Listing", "Verify that EDIT is getting clicked", "EDIT is getting clicked successfully");
       
                     // Spinner processing
                     //waitForLoader();   
                     pause();
                     
                     // Entering First Name            
                     mouseOver(DLLastName);
                     clearText(DLLastName, objectValue);
                     setText(DLLastName, "", LASTNAME);
                     System.out.println("Last Name" + LASTNAME + "is entered successfully");
                     report.reportPass("Entering LAST NAME", "Verify that able to LAST NAME in Directory Listing", "LAST NAME is entered successfully");
       
                     // Spinner processing
                     waitForLoader();     
       
                     // Entering Last Name             
                     mouseOver(DLFirstName);
                     clearText(DLFirstName, objectValue);
                     setText(DLFirstName, "", FIRSTNAME);
                     System.out.println("FIRSTNAME" + FIRSTNAME + "is entered successfully");
                     report.reportPass("Entering FIRST NAME", "Verify that able to FIRST NAME in Directory Listing", "FIRST NAME is entered successfully");
       
                     // Spinner processing
                     waitForLoader();     
       
                     // Entering OK button in Directory Listing
                     // waitForElementDisplay(DLOK, "", 2);
                     mouseOver(DLOK);
                     clickUsingJavaScript(DLOK, "");// click not working
                     System.out.println("OK is getting clicked");
                     report.reportPass("Clicking OK button in Directory Listing", "Verify tha the OK button i sgetting clicked", "OK button is getting clicked successfully");
       
                     // Spinner processing
                     //waitForLoader();   
                     pause();
                     
                     // Clicking on OK in Package, Plan and features
                     // waitForElementDisplay(PlanFeaturesOK, "", 2);
                     mouseOver(PlanFeaturesOK);
                     clickUsingJavaScript(PlanFeaturesOK, "");// click not working
                     System.out.println("OK is clicked");
                     report.reportPass("Clicking on OK button under Plan and features", "Verify that OK is getting clicked", "OK is getting clicked successfully");
                     //waitForLoader();   
                     pause();

           } catch (Exception e)
           {
              getUrl = ", URL Launched --> " + returnURL();
              report.reportFail("Negotiating Directory Listing " + getUrl, "Verify that Directory Listing section is negotiating sucessfully", "Failed to do the Action");
              report.reportFail("Select Plan and Features Options.", "Plan and Features options should be selected", strFailed);
                     report.updateMainReport("comments", strFailed);
                     report.updateMainReport("ErrorMessage", strFailed);
                     logger.debug(strFailed);
                     captureErrorMsg(strFailed);
                     throw new UserDefinedException(strFailed);
           }    
    }  

    /**
     * @Info To click on SaveAndContinue under LEC page
     * @Modified by Sourish
     * @Modified by Poovaraj
     * @LastUpdated 03/13/2017
     */

    public void LECClickSaveAndContinue() throws Exception 
    {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";

	try {
	    strDescription = "Click on SAVEANDCONTINUE under LEC page";
	    strExpected = "Verify that SAVEANDCONTINUE button is getting clicked in LEC page";
	    strActual = "SAVEANDCONTINUE Ok button is getting clicked successfully";
	    strFailed = "SAVEANDCONTINUE is not getting clicked,since it is getting failed";
	    getUrl = ", URL Launched --> " + returnURL();

	    // waitForElementDisplay(LECSaveAndContinue, "", 2);
	    mouseOver(LECSaveAndContinue);
	    clickUsingJavaScript(LECSaveAndContinue, "");// click not working
	    System.out.println("SAVEANDCONTINUE is getting clicked");
	    report.reportPass(strDescription + getUrl, strExpected, strActual);
	    
	} catch (Exception e) 
	{
	/*    getUrl = ", URL Launched --> " + returnURL();
	    report.reportFail(strDescription + getUrl, strExpected, strFailed);
	    report.updateMainReport("ErrorMessage", strFailed);*/	
	    report.reportFail("Click on SAVE AND CONTINUE button", "SAVE AND CONTINUE button should be clicked", strFailed);
	    report.updateMainReport("comments", strFailed);
	    report.updateMainReport("ErrorMessage", strFailed);
	    logger.debug(strFailed);
	    captureErrorMsg(strFailed);
	    throw new UserDefinedException(strFailed);
	}
    }

    /**
     * @Info To click on NRCOk under LEC page
     * @Modified by Sourish
     * @LastUpdated 02/02/2017
     */
    public void LECNRCOK() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";

	try {
	    strDescription = "Click on NRC OK under LEC page";
	    strExpected = "Verify that OK button is getting clicked in LEC page under NRC";
	    strActual = "NRC Ok button is getting clicked successfully";
	    strFailed = "NRC ok is not getting clicked,since it is getting failed";
	    getUrl = ", URL Launched --> " + returnURL();
	    // Clicking on OK under NRC section
	    // waitForElementDisplay(NRCOK, "", 2);
		//LECNRCOK
		
		
		if(isDisplayed(NRCOK))
	   {
	    mouseOver(NRCOK);
	    clickUsingJavaScript(NRCOK, "");// click not working
	    System.out.println("OK is getting clicked");
	    report.reportPass(strDescription + getUrl, strExpected, strActual);
	   }
	   
	   
	} catch (Exception e) 
	{
		/*    getUrl = ", URL Launched --> " + returnURL();
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);*/
			
		strFailed = "NCR button is not clicked";
	    report.reportFail("Click on NCR button", "NCR button should be clicked", strFailed);
	    report.updateMainReport("comments", strFailed);
	    report.updateMainReport("ErrorMessage", strFailed);
	    logger.debug(strFailed);
	    captureErrorMsg(strFailed);
	    throw new UserDefinedException(strFailed);
	}
    }

    /**
     * @Info To handle of Spinner Load
     * @Modified by Sourish
     * @LastUpdated 02/02/2017
     */

    public void waitForSpinnerLoad() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	try {
	    strDescription = "Wait for Spinner to load completly";
	    strExpected = "Wait till Spinner to load";
	    strActual = "Spinner is getting loaded successfully";
	    strFailed = "Spinner is not getting loaded completly,since it is getting failed";
	    getUrl = ", URL Launched --> " + returnURL();

	    WebDriverWait wait = new WebDriverWait(driver, 60);
	    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[contains(text(),'Please wait while we process your request...')]")));
	    System.out.println("Waited successfully for the Spinner page to load");
	    report.reportPass(strDescription + getUrl, strExpected, strActual);
	} catch (Exception e) {
	    getUrl = ", URL Launched --> " + returnURL();
	    report.reportFail(strDescription + getUrl, strExpected, strFailed);
	    report.updateMainReport("ErrorMessage", strFailed);
	}

    }

    /**
     * @Info To Negotiate Plan adn Features under LEC page
     * @param FirstName
     * @param LastName
     * @throws Exception
     * @Modified by Sourish
     * @LastUpdated 02/02/2017
     */
    public void LECPlanFeatures(String FIRSTNAME, String LASTNAME) throws Exception {

        String strDescription = "", strExpected = "", strActual = "", strFailed = "";
        try {
            strDescription = "Negotiate Plan and Features under LEC Page";
            strExpected = "Verify that Plan and features options are getting selected ";
            strActual = "Plan and features options are getting selected successfully";
            strFailed = "Plan and Features options are not being selected,since it is getting failed";
            getUrl = ", URL Launched --> " + returnURL();

            // Negotiating Calling Plans and Carrier Info Section in LEC page
            try {
            	String LecVoicePackage = get("PSTNVoicePackage").trim();
        	    String VerizoncallingService = get("PSTNVerizonCallingService").trim();
            	
            	if((!LecVoicePackage.contains("None")) && (!LecVoicePackage.isEmpty()))
    	 	    {
    	 	    	pageScroll(Lecvoicepackage, "", true);
    	 	    	selectDropDownUsingValue(Lecvoicepackage, "", LecVoicePackage);
    	 	    	waitForPageToLoad(driver);
    	 	    	waitForLoader();
    	 	    	if((LecVoicePackage.contains("PGO8R")) ||(LecVoicePackage.contains("PGO6R")))
                    {
                    if(isDisplayed(Domestic_LD_Plan))
                    {
	                  mouseOver(Domestic_LD_Plan);
	                  selectDropDownUsingValue(Domestic_LD_Plan, "", "O5V2X");
	                  System.out.println("Domestic LD Plan has been selected from dropdown");
	                  waitForLoader();
                      waitForLoader();
                      waitForLoader();
                    }
                    }
    	 	    }
    	    	
    	 	   if(LecVoicePackage.contains("None"))
    	 	    {
    	 		  if(isDisplayed(Moreoptions))
    		    	{
    		    		pageScroll(Moreoptions, "", true);
    		    		clickUsingJavaScript(Moreoptions, "");
    		    		waitForLoader();
    		    		waitForLoader();
    		    		report.reportPass("Clicking on More options button", "More options button should be clicked", "More options button is clicked under Calling Paln and CArrier Info section successfully");
    		    	}
    	 		  
    	 		  if(isDisplayed(VerizonCallingPackage))
    	 		  {
    	 			    pageScroll(VerizonCallingPackage, "", true);
    		 	    	selectDropDownUsingValue(VerizonCallingPackage, "", LecVoicePackage);
    		 	    	waitForLoader();
    		 	    	waitForLoader();
    		 	    	report.reportPass("Selecting Verizon Calling Package from dropdown", "Verizon Calling Package should be selected from dropdown", "Verizon Calling Package is selecting from dropdown");
    	 		  }
    	 		 WebElement drop_down = driver.findElement(By.xpath("//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_dropdownCallingService']"));
    		 	 Select verizoncallingservice = new Select(drop_down);
    		 	 List<WebElement> options = verizoncallingservice.getOptions();
    	 		  if(isDisplayed(drop_down))
    	 		  {
      	 			   try
      	 			   {
      	 				   int flag=0;
      	 				   breakLoop :
      	 				  for (int i=0;i<options.size();i++)
      	 				  {
      	 					  if(options.get(i).getText().contains(VerizoncallingService)) 
      	 					  {
      	 						  verizoncallingservice.selectByValue(VerizoncallingService);	
      	 						  flag=1;
      	 						  waitForLoader();
      	 						break breakLoop;
      	 					  }
      	 					 
      	 				  }
      	 			   if(flag==0){
      	 			   	 verizoncallingservice.selectByValue("1FR");	
    					 waitForLoader();
      	 			   }
    					 
    					 
      	 	 			 waitForLoader();
      			 	     waitForLoader();
      	 				 report.reportPass("Selecting Verizon Calling Service from dropdown", "Verizon Calling Service should be selected from dropdown", "Verizon Calling Service is selecting from dropdown");
      	 				
      	 				if(isDisplayed(Domestic_LD_Plan))
      	 		    	{
      	 					String DomesticLDPlan = get("Domestic_LD_Plan").trim();
      	 					mouseOver(Domestic_LD_Plan);
      	 		    		selectDropDownUsingValue(Domestic_LD_Plan, "", DomesticLDPlan);
      	 		    		System.out.println("Domestic LD Plan has been selected from dropdown");
      	 		    		waitForLoader();
      	 		    	    waitForLoader();
      	 		    	    waitForLoader();
      	 		    	}
      	 				 if(isDisplayed(DrpIEPlan))
      	 			    {
      	 					String InternationalPlan = get("LEC_InternationalPlan").trim(); 
	      	 			    mouseOver(DrpIEPlan);
	      	 			    selectDropDownUsingValue(DrpIEPlan, "", InternationalPlan);
	      	 				System.out.println("International Plan has been selected from dropdown");
	      	 				waitForSpinnerLoad();
	      	 				Thread.sleep(500);
      	 			    }
      	 				
      	 				 if(isDisplayed(ApplytoSelectedLine))
      	 		    	{
      	 		    		pageScroll(ApplytoSelectedLine, "", true);
      	 		    		clickUsingJavaScript(ApplytoSelectedLine, "");
      	 		    		waitForLoader();
      	 		    		report.reportPass("Verify Apply to Selected Line button is clicked or not", "Apply to Selected Line Button should be Clicked", "Apply to Selected Line Button is Clicking");
      	 		    		waitForLoader();
      	 		    	}
      	 		    	if(isDisplayed(OkButton))
      	 		    	{
      	 		    		pageScroll(OkButton, "", true);
      	 		    		clickUsingJavaScript(OkButton, "");
      	 		    		waitForLoader();
      	 		    		report.reportPass("Verify Ok button is clicked or not", "OK Button should be Clicked", "Ok Button is Clicking");
      	 		    		waitForLoader();
      	 		    		waitForLoader();
      	 		    	} 
      	 				 
      	 			   }
      	 			   catch(Exception e)
      	 			   {
      	 				  e.printStackTrace(); 
      	 				  report.reportFail("Selecting Verizon Calling Service from dropdown", "Verizon Calling Service should be selected from dropdown", "Verizon Calling Service is not selected from dropdown");
      	 			   }
      	 		  }
    	 		  
    	 	    }
            	String VoiceValue = get("VoiceValue").trim();
            	
            	if(VoiceValue.contains("Regional"))
            	{
            	 mouseOver(Long_Distance_Carrier);
                 selectDropDownUsingVisibleText(Long_Distance_Carrier, "", "VERIZON LONG DISTANCE (BA) 6963");
                 System.out.println("LONG DISTANCE plan Selected.");
                 pause();
           
           // selecting Domestic LD Plan     
                         
                 mouseOver(Domestic_LD_Plan);
                // selectDropDownUsingVisibleText(Domestic_LD_Plan, "", "ONEAN TalkTime 30 $11.99 $11.99");
                 selectDropDownUsingValue(Domestic_LD_Plan, "", get("Domestic_LD_Plan").trim());
                 System.out.println("Domestic LD plan Selected.");
            	}
            	else{
            		if(!get("Long_Distance_Carrier").isEmpty()){
            			 mouseOver(Long_Distance_Carrier);
                         selectDropDownUsingVisibleText(Long_Distance_Carrier, "", get("Long_Distance_Carrier"));
                         System.out.println("LONG DISTANCE plan Selected.");
                         pause();
                	}
                   if(!get("Domestic_LD_Plan").isEmpty()){
            			
                	   	String DomesticLDPlan = get("Domestic_LD_Plan").trim().toUpperCase();
 	 					mouseOver(Domestic_LD_Plan); 	 					
 	 		    		selectDropDownUsingValue(Domestic_LD_Plan, "", DomesticLDPlan);
                        System.out.println("Domestic LD plan Selected.");
                       pause();
            		}
            		
            		
            	}
                 
               // selecting International Plan
               // waitForElementDisplay(DrpIEPlan, "", 2);
            	
               String InternationalPlan = get("LEC_InternationalPlan").trim().toUpperCase();
               if(!InternationalPlan.isEmpty()){
               mouseOver(DrpIEPlan);
               selectDropDownUsingValue(DrpIEPlan, "", InternationalPlan);
               System.out.println("International Plan has been selected from dropdown"); 
               waitForLoader();
               waitForLoader();
               waitForLoader();
               }
               // Click on Apply under Calling Plan and Carrier Info
               // waitForElementDisplay(ApplyCallingPlan, "", 2);
               pause();
               mouseOver(ApplyCallingPlan);
               clickUsingJavaScript(ApplyCallingPlan, "");
               System.out.println("Apply button is clicked under Calling Plans and Carrier Info section");
               report.reportPass("Clicking on apply button", "Verify that Apply button is clicked", "Apply button is clicked under Calling Paln and CArrier Info section successfully");
               waitForLoader();
               
            } catch (Exception e) {
               getUrl = ", URL Launched --> " + returnURL();
               report.reportFail("Clicking on apply button" + getUrl, "Verify that Apply button is clicked", "Failed to click the apply button due to object not in ready state");
               report.updateMainReport("ErrorMessage", "Failed to click the apply button due to object not in ready state");
            }

            // Spinner processing
            waitForSpinnerLoad();
            Thread.sleep(1000);
            
            

            // Negotiating Features Section in LEC page

     /*       if(!isSelected(ChkBoxUnderFeatures, "Maintenance Plan")){
            
            try {
                      // Clicking on Check box Maintenance Plan
                      // waitForElementDisplay(ChkBoxUnderFeatures, "Maintenance
                      // Plan", 2);
                      mouseOver(ChkBoxUnderFeatures, "Maintenance Plan");
                      clickUsingJavaScript(ChkBoxUnderFeatures, "Maintenance Plan");
                      System.out.println("MAINTENANCE PLANSETUP is checked");
                      report.reportPass("Selecting Maintenance check box", "Verify that Maintenance check box is selected", "Maintanence chec box is checked successfully");

                      // Spinner processing
                      waitForSpinnerLoad();
                      Thread.sleep(1000);
                      if (!isDisplayed(Maintenance_Plan_Window)) {
                          click(setup_Maintenance_Plan);
                      }
                      waitForSpinnerLoad();
                      Thread.sleep(1000);
                      // Selecting WMR Maintenance Yes Plan

                      String lecMaintenancePlan = get("PSTNMaintenancePlan").trim();

                      if (lecMaintenancePlan.contains("WMR") || lecMaintenancePlan.contains("NMC")||lecMaintenancePlan.contains("MNTPB")||lecMaintenancePlan.contains("SEQ1X") || lecMaintenancePlan.contains("OWM")) {
                    	  if(!isSelected(Inside_Wire_Maintainance, lecMaintenancePlan))
                          {
                    	  mouseOver(Inside_Wire_Maintainance, lecMaintenancePlan);
                          clickUsingJavaScript(Inside_Wire_Maintainance, lecMaintenancePlan);
                          click(Inside_Wire_Maintainance, lecMaintenancePlan);
                          }
                          System.out.println("WMR inside wire Maintenance Plan is selected");
                          report.reportPass("Selecting" +"lecMaintenancePlan"+" inside wire Maintenance Plan", "Verify that " +"lecMaintenancePlan"+"inside wire Maintenance Plan is selected",
                                "" +"lecMaintenancePlan"+" inside wire Maintenance Plan chec box is checked successfully");
                          
                      } 
                      // Spinner processing
                      waitForSpinnerLoad();
                      Thread.sleep(1000);

                      // Clicking on OK/Apply to the selected lines under Maintenance
                      // Plan set up frame
                      // waitForElementDisplay(MaintenanceOK, "", 2);
                      mouseOver(MaintenanceOK);
                      clickUsingJavaScript(MaintenanceOK, "");
                      System.out.println("OK/Apply to the selected lines button is clicked");
                      report.reportPass("Clicking the OK button under Maintenance plan set up", "Verify that OK button is getting clicked under the Maintenance Plan set up frame",
                            "Ok is clicked successfully");

                   
            }catch (Exception e) {
                      getUrl = ", URL Launched --> " + returnURL();
                      report.reportFail("Negotiating Maintenance Plane set up" + getUrl, "Verify that Maintenance Plan set up is negotiating sucessfully", "Failed to do the Action");
                      report.updateMainReport("ErrorMessage", "Failed to do the Action");
                   }
            }

            // Spinner processing
            waitForSpinnerLoad();
            Thread.sleep(1000);
            */

            // Handling of Voice Backup Power
        /*    try {
               // Clicking on Voice Backup Power
               // waitForElementDisplay(ChkBoxUnderFeatures, "Voice Backup",
               // 2);
               
            // *********
               mouseOver(ChkBoxUnderFeatures, "Voice Backup");
               clickUsingJavaScript(ChkBoxUnderFeatures, "Voice Backup");
               System.out.println("VOICE BACKUP POWER check box is checked");
               report.reportPass("Checking the VOICE BACKUP POWER check box", "Verify that VOICE BACKUP POWER is checked", "VOICE BACKUP POWER is checked successfully");

               // Spinner processing
               waitForSpinnerLoad();
               Thread.sleep(1000);

               // Selecting Voice Power Backup Setup
               // waitForElementDisplay(NoCharge, "FEKZQ", 2);
               mouseOver(NoCharge, "FEKZQ");
               click(NoCharge, "FEKZQ");// Not working
               System.out.println("FREE STANDARD SHIPPING is selected in Voice BAckup Power Setup");
               report.reportPass("Selecting Voice BAckup Power Setup", "Verify that able to select the Voice Backup Power setup", "Voice Backup Power Setup is selected successfully");

               // Spinner processing
               waitForSpinnerLoad();
               Thread.sleep(1000);

               // Clicking on OK in Voice Backup Power Fee setup
               // waitForElementDisplay(VoiceBkppowerOK, " ", 2);
               mouseOver(VoiceBkppowerOK);
               clickUsingJavaScript(VoiceBkppowerOK, " ");
               System.out.println("OK button is clicked in Voice BAckup Power setup");
               report.reportPass("Clicking the OK button under Voice BAckup Power set up", "Verify that OK button is getting clicked under Voice backup Power set up frame",
                      "OK is clicked successfully");

            } catch (Exception e) {
               getUrl = ", URL Launched --> " + returnURL();
               report.reportFail("Negotiating Voice Backup Power set up" + getUrl, "Verify that Voice Backup Power set up is negotiating sucessfully", "Failed to do the Action");

            }

            // Spinner processing
            waitForSpinnerLoad();
            Thread.sleep(1000);  */

            // Handling of Jacks
            if(!isSelected(ChkBoxUnderFeatures, "Jacks")){
            try {
                      // Clicking on Jacks
                      // waitForElementDisplay(ChkBoxUnderFeatures, "Jacks", 2);
                      mouseOver(ChkBoxUnderFeatures, "Jacks");
                      clickUsingJavaScript(ChkBoxUnderFeatures, "Jacks");
                      System.out.println("JACKS check box is checked");
                      report.reportPass("Checking the JACKS check box", "Verify that JACKS is checked", "JACKS is checked successfully");

                      // Spinner processing
                      waitForSpinnerLoad();
                      

                      if (!isDisplayed(Jacks_Window)) {
                            
                          click(setup_Jacks);

                      }
                      waitForSpinnerLoad();
                      
                      // Selecting Jacks

                      String Jacktype = get("PSTNVoiceJack").trim();

                      if (Jacktype.contains("Primary")) {
                          mouseOver(Jacks_Type);
                          clickUsingJavaScript(Jacks_Type, Jacktype);
                          click(ADDLinkJack);
                          waitForSpinnerLoad();
                          Thread.sleep(1000);
                          System.out.println("Primary Jack is selected in Jacks/Fixed Fee Setup");
                          report.reportPass("Selecting Jacks/Fixed Fee Setup", "Verify that able to select Primary Jack in Jacks/Fixed Fee setup", "Primary Jack is selected successfully");
                      } else if (Jacktype.contains("Additional")) {
                          mouseOver(Jacks_Type);
                          clickUsingJavaScript(Jacks_Type, Jacktype);
                          click(ADDLinkJack);
                          waitForSpinnerLoad();
                          Thread.sleep(1000);
                          System.out.println("Additional Jack is selected in Jacks/Fixed Fee Setup");
                          report.reportPass("Selecting Jacks/Fixed Fee Setup", "Verify that able to select Additional Jack in Jacks/Fixed Fee setup", "Additional Jack is selected successfully");
                      }
                      // Selecting No Jacks
                      else {
                          mouseOver(ChkbxLECNoJacks);
                          clickUsingJavaScript(ChkbxLECNoJacks, "");
                          System.out.println("NO JACKS is selected in Jacks/Fixed Fee Setup");
                          report.reportPass("Selecting Jacks/Fixed Fee Setup", "Verify that able to select NO JACKS in Jacks/Fixed Fee setup", "NO JACKS is selected successfully");
                      }

                      // Spinner processing
                      waitForSpinnerLoad();
                      Thread.sleep(1000);

                      // Clicking on OK in Jacks setup
                      // waitForElementDisplay(NoJackOK, " ", 2);
                      mouseOver(BtnLECJackOk);
                      clickUsingJavaScript(BtnLECJackOk, " ");
                      System.out.println("OK button is clicked in Jacks/Fixed Fee Setup");
                      report.reportPass("Clicking the OK button under Jacks/Fixed Fee Setup", "Verify that OK button is getting clicked under Jacks/Fixed Fee Setup frame", "Ok is clicked successfully");

                   } catch (Exception e) {
                      getUrl = ", URL Launched --> " + returnURL();
                      report.reportFail("Negotiating Jacks/Fixed Fee Setup" + getUrl, "Verify that Jacks/Fixed Fee Setup is negotiating sucessfully", "Failed to do the Action");
                      report.updateMainReport("ErrorMessage", "Failed to do the Action");

                   }
            }

            // Spinner processing
            waitForSpinnerLoad();
            Thread.sleep(1000);
            String featureproducts = get("FeatureProducts").trim();
   	
            if(!featureproducts.isEmpty()){
                try {
                	
                	 if(featureproducts.contains(";"))
                     {
                     	String[] Productslist = featureproducts.split(";");
                     	for(String Pdslist : Productslist)
                     	{
	                     	mouseOver(lnkAllProducts, "");
	                        clickUsingJavaScript(lnkAllProducts, "");
	                        System.out.println("All Products link is Clicked");
	                        report.reportPass("Verify All Products link is clicking or not", "All Products link should be clicked", "All Products lick is clicking");
	
	                        // Spinner processing
	                        waitForSpinnerLoad();
	                        waitForLoader();
	                        if(isDisplayed(TxtBoxUsoc))
	                        {
	                      	  mouseOver(TxtBoxUsoc, "");
	                      	  clearText(TxtBoxUsoc, "");
	                      	  setText(TxtBoxUsoc, "", Pdslist);
	                      	  waitForLoader();
	                      	  clickUsingJavaScript(UscoSearchButton, "");
	                      	  waitForLoader();
	                      	  mouseOver(UsocCheckBox, Pdslist);
	                      	  clickUsingJavaScript(UsocCheckBox, Pdslist);
	                      	  mouseOver(UsocApplyButton); 
	                      	  clickUsingJavaScript(UsocApplyButton, "");
	                      	  waitForLoader();
	                      	  if(isDisplayed(UsocApplyButton))
	                      	  {
	                      		clickUsingJavaScript(UsocApplyButton, "");
	                      	  }
	                      	  waitForLoader();
	                      	  
	                      	  if(isDisplayed(ErrorMessage))
	                      	  {
		                      	  if(ErrorMessage.getText().contains("You have entered a product that is not available"))
		                          {
		                      		System.out.println("Feature Products not Selected "+ErrorMessage.getText());
			                        report.reportPass("Verify All Feature Products Selected or not", "All Feature Products should not be selected", "Feature Products not Selected" +ErrorMessage.getText()); 
			                        clickUsingJavaScript(UsocCloseButton, "");
		                          }
	                      	  }
	                      	  else
	                      	  {
	                      		System.out.println("Feature Products Selected "+Pdslist);
		                        report.reportPass("Verify All Feature Products Selected or not", "All Feature Products should be selected", "Feature Products Selected" +Pdslist); 
	                      	  }
	                      	  
	                          if(isDisplayed(AdditionalProductsHeader))
	                          {
	                        	  if(isDisplayed(RequiredProductGroup))
	                        	  {
	                        		  int count = RequiredProductGroups.size();
	                        		  
	                        		  for(int i=0; i<count;i++)	                        	 	                        			  
	                        		  {
	                        			  String j = String.valueOf(i);
	                        			  if(!isSelected(RequiredFID, j))
	                        			  {
	                        				  waitForLoader();	
	                        				  clickUsingJavaScript(RequiredFID, j);
	                        			  }
	                        		  }
	                        		  
	                        		  if(isDisplayed(ProductNWTFeatures))
	                        		  {
		                        		  mouseOver(ProductNWTFeatures);
		                        		  clickUsingJavaScript(ProductNWTFeatures, "");
	                        		  }
	                        		  else if(isDisplayed(FIDCOMM))
	                        		  {
	                        			  mouseOver(FIDCOMM);
	                        			  selectDropDownUsingIndex(FIDCOMM, "", 0);
	                        		  }
	                        	  
	                        	  }
	                        	  waitForLoader();
	                        	  WebElement FIDSOK = driver.findElement(By.xpath("//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_lnkAdditionalProductOk']"));
	                        	  FIDSOK.click();
                        		  waitForLoader();
	                        	  
	                        	 
                        		  
	                        	  
	                          }
	                          
	                        }
                     	
                     	}
                     }
                	 else
                	 {
                		 // Clicking on All Products link
                          mouseOver(lnkAllProducts, "");
                          clickUsingJavaScript(lnkAllProducts, "");
                          System.out.println("All Products link is Clicked");
                          report.reportPass("Verify All Products link is clicking or not", "All Products link should be clicked", "All Products lick is clicking");

                          // Spinner processing
                          waitForSpinnerLoad();
                          waitForLoader();
                          if(isDisplayed(TxtBoxUsoc))
                          {
                        	  mouseOver(TxtBoxUsoc, "");
                        	  setText(TxtBoxUsoc, "", featureproducts);
                        	  waitForLoader();
                        	  clickUsingJavaScript(UscoSearchButton, "");
                        	  waitForLoader();
                        	  mouseOver(UsocCheckBox, featureproducts);
                        	  clickUsingJavaScript(UsocCheckBox, featureproducts);
                        	  mouseOver(UsocApplyButton); 
                        	  clickUsingJavaScript(UsocApplyButton, "");
                        	  waitForLoader();
                        	  waitForLoader();
                        	  if(isDisplayed(UsocApplyButton))
	                      	  {
	                      		clickUsingJavaScript(UsocApplyButton, "");
	                      	  }
	                      	  waitForLoader();
	                      	  
	                      	  if(isDisplayed(ErrorMessage))
	                      	  {
		                      	  if(ErrorMessage.getText().contains("You have entered a product that is not available"))
		                          {
		                      		System.out.println("Feature Products not Selected "+ErrorMessage.getText());
			                        report.reportPass("Verify All Feature Products Selected or not", "All Feature Products should not be selected", "Feature Products not Selected" +ErrorMessage.getText()); 
			                        clickUsingJavaScript(UsocCloseButton, "");
		                          }
	                      	  }
	                      	  else
	                      	  {
	                        	  System.out.println("Feature Products Selected "+featureproducts);
	  	                          report.reportPass("Verify All Feature Products Selected or not", "All Feature Products should be selected", "Feature Products Selected" +featureproducts);
	                      	  }
	                      	  if(isDisplayed(AdditionalProductsHeader))
		                          {
		                        	  if(isDisplayed(RequiredProductGroup))
		                        	  {
		                        		  int count = RequiredProductGroups.size();
		                        		  
		                        		  for(int i=0; i<count;i++)	                        	 	                        			  
		                        		  {
		                        			  String j = String.valueOf(i);
		                        			  if(!isSelected(RequiredFID, j))
		                        			  {
		                        				  waitForLoader();	
		                        				  clickUsingJavaScript(RequiredFID, j);
		                        			  }
		                        		  }
		                        		  
		                        		  if(isDisplayed(ProductNWTFeatures))
		                        		  {
			                        		  mouseOver(ProductNWTFeatures);
			                        		  clickUsingJavaScript(ProductNWTFeatures, "");
		                        		  }
		                        		  else if(isDisplayed(FIDCOMM))
		                        		  {
		                        			  mouseOver(FIDCOMM);
		                        			  selectDropDownUsingIndex(FIDCOMM, "", 0);
		                        		  }
		                        	  
		                        	  }
		                        	  waitForLoader();
		                        	  WebElement FIDSOK = driver.findElement(By.xpath("//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_lnkAdditionalProductOk']"));
		                        	  FIDSOK.click();
	                        		  waitForLoader();
		                        	  
		                          }
                          }
                        
                         
                	 }                           
		                	 mouseOver(ProductsApplyButton, "");
		                     clickUsingJavaScript(ProductsApplyButton, "");
		                     waitForLoader();
		                     waitForLoader();
		                     
		                     if(isDisplayed(NPDWallJack, "", 5))
		                     {
		                    	 WebElement ele=driver.findElement(By.xpath("//*[contains(@id , 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAccountProfileSection_AccountTreeViewt')]//span[contains(text(), 'RJ11W')]"));
		                    	 Actions act=new Actions(driver);
		                    	 act.moveToElement(ele);
		                    	 act.contextClick(ele).build().perform();	
		                    	 WebElement elementOpen = driver.findElement(By.xpath("//*[@id = 'productMenuforQuantifyUSOC']//a[contains(text(), 'Review Setup')]")); 
		                    	 elementOpen.click();
		                    	 waitForLoader();
		                    	 waitForLoader();
		                    	 if(isDisplayed(BtnOptionalFIDs))
		                    	 {
		                    		 mouseOver(BtnOptionalFIDs);
		                    		 clickUsingJavaScript(BtnOptionalFIDs, "");
		                    	 }
		                    	 
		                    	 //clickUsingJavaScript(FixedFee, "");
		                    	 String PSTNAdditionalFIDS = get("PSTN_AdditionalFIDS").trim();
			                     
			                     if(!PSTNAdditionalFIDS.isEmpty())
			                     {
			                     mouseOver(OptionalFIDS, PSTNAdditionalFIDS);
			                     clickUsingJavaScript(OptionalFIDS, PSTNAdditionalFIDS);
			                     }
		                    	 Thread.sleep(2000);
		                    	 clickUsingJavaScript(FIDSOK, "");
		                    	 waitForLoader();
		                    	 waitForLoader();
		                     }
                     
                       } catch (Exception e) {
                          getUrl = ", URL Launched --> " + returnURL();
                          report.reportFail("Negotiating Jacks/Fixed Fee Setup" + getUrl, "Verify that Jacks/Fixed Fee Setup is negotiating sucessfully", "Failed to do the Action");
                          report.updateMainReport("ErrorMessage", "Failed to do the Action");

                       }
                }
            
            
         // Clicking on apply in Package, Plan and features
                     // waitForElementDisplay(PlanFeaturesOK, "", 2);
                     //mouseOver(ApplyFeaturePlan);
              //     clickUsingJavaScript(ApplyFeaturePlan, "");// click not working
        //           System.out.println("Apply is clicked");
        //           report.reportPass("Clicking on Apply button under Plan and features", "Verify that Apply is getting clicked", "Apply is getting clicked successfully");


            // Handling of Directory Listing
        /*    try {
               // Clicking on Edit link
               // waitForElementDisplay(DLEdit, "", 2);
               mouseOver(DLEdit);
               clickUsingJavaScript(DLEdit, "");// click not working
               System.out.println("EDIT link is clicked");
               report.reportPass("Clicking on EDIT under Directory Listing", "Verify that EDIT is getting clicked", "EDIT is getting clicked successfully");

               // Spinner processing
               waitForSpinnerLoad();
               Thread.sleep(1000);

               // Entering First Name
               // waitForElementDisplay(DLLastName, "", 2);
               mouseOver(DLLastName);
               setText(DLLastName, "", LASTNAME);
               System.out.println("Last Name" + LASTNAME + "is entered successfully");
               report.reportPass("Entering LAST NAME", "Verify that able to LAST NAME in Directory Listing", "LAST NAME is entered successfully");

               // Spinner processing
               waitForSpinnerLoad();
               Thread.sleep(1000);

               // Entering Last Name
               // waitForElementDisplay(DLFirstName, "", 2);
               mouseOver(DLFirstName);
               setText(DLFirstName, "", FIRSTNAME);
               System.out.println("FIRSTNAME" + FIRSTNAME + "is entered successfully");
               report.reportPass("Entering FIRST NAME", "Verify that able to FIRST NAME in Directory Listing", "FIRST NAME is entered successfully");

               // Spinner processing
               waitForSpinnerLoad();
               Thread.sleep(1000);

               // Entering OK button in Directory Listing
               // waitForElementDisplay(DLOK, "", 2);
               mouseOver(DLOK);
               clickUsingJavaScript(DLOK, "");// click not working
               System.out.println("OK is getting clicked");
               report.reportPass("Clicking OK button in Directory Listing", "Verify tha the OK button i sgetting clicked", "OK button is getting clicked successfully");

               // Spinner processing
               waitForSpinnerLoad();
               Thread.sleep(1000);  */

               // Clicking on OK in Package, Plan and features
               // waitForElementDisplay(PlanFeaturesOK, "", 2);
            try
            {
            	
	            mouseOver(DLEdit);
	    		clickUsingJavaScript(DLEdit, "");// click not working
	    		System.out.println("EDIT link is clicked");
	    		report.reportPass("Clicking on EDIT under Directory Listing", "Verify that EDIT is getting clicked", "EDIT is getting clicked successfully");
	
	    		// Spinner processing
	    		waitForSpinnerLoad();
	    		Thread.sleep(1000);
	            
	            String PSTNListingPlan  = get("PSTNListingPlan").trim();
	    		
	    		if(!PSTNListingPlan.isEmpty())
	    		{
	    			if(isDisplayed(PublicationStatus))
	    			{
	    				if(PSTNListingPlan.contains("NPU"))
	    				{
	    					mouseOver(PublicationStatus);
	    					Thread.sleep(1000);
	    					selectDropDownUsingValue(PublicationStatus, "", "NON_PUBLISHED");
	    					report.reportPass("Selecting NON_PUBLISHED under Directory Listing", "Verify that NON_PUBLISHED should be selected under Directory Listing", "NON_PUBLISHED under Directory Listing selected Successfully");
	    				}
	    				else if(PSTNListingPlan.contains("NLT"))
	    				{
	    					mouseOver(PublicationStatus);
	    					Thread.sleep(1000);
	    					selectDropDownUsingValue(PublicationStatus, "", "DIR_ASSIST_ONLY");
	    					report.reportPass("Selecting DIR_ASSIST_ONLY under Directory Listing", "Verify that DIR_ASSIST_ONLY should be selected under Directory Listing", "DIR_ASSIST_ONLY under Directory Listing selected Successfully");
	    				}
	    				waitForSpinnerLoad();
	    				Thread.sleep(2000);
	    			}
	    			
	    			

	    		}	
	    	 String FirstName  = "Passlow";
	   	     String LastName  = "Customer";
	   	     
	   	     if(isDisplayed(DLLastName))
	   	     {
	   	     mouseOver(DLLastName);
	   	     clearText(DLLastName, strFailed);
	   	     setText(DLLastName, "", LastName);
	   	     System.out.println("Last Name" + LastName + "is entered successfully");
	   	     report.reportPass("Entering LAST NAME", "Verify that able to LAST NAME in Directory Listing", "LAST NAME is entered successfully");
	   	     }
	   	     // Spinner processing
	   	     waitForSpinnerLoad();
	   	     Thread.sleep(1000);

	   	     // Entering Last Name
	   	     
	   	     if(isDisplayed(DLFirstName))
	   	     {
	   	     mouseOver(DLFirstName);
	   	     clearText(DLFirstName, strFailed);
	   	     setText(DLFirstName, "", FirstName);
	   	     System.out.println("FIRSTNAME" + FirstName + "is entered successfully");
	   	     report.reportPass("Entering FIRST NAME", "Verify that able to FIRST NAME in Directory Listing", "FIRST NAME is entered successfully");
	   	     waitForLoader();
	   	     }
	   	     mouseOver(DLOK);
	        clickUsingJavaScript(DLOK, "");// click not working
	        System.out.println("OK is getting clicked");
	        report.reportPass("Clicking OK button in Directory Listing", "Verify tha the OK button i sgetting clicked", "OK button is getting clicked successfully");

	   	     // Spinner processing
	   	     waitForSpinnerLoad();
	   	     Thread.sleep(1000);
            }
            catch(Exception E)
            {
            	E.printStackTrace();
            }
            
               waitForLoader();	
               mouseOver(PlanFeaturesOK);
               clickUsingJavaScript(PlanFeaturesOK, "");// click not working
               System.out.println("OK is clicked");
               report.reportPass("Clicking on OK button under Plan and features", "Verify that OK is getting clicked", "OK is getting clicked successfully");

          /*  } catch (Exception e) {
               getUrl = ", URL Launched --> " + returnURL();
               report.reportFail("Negotiating Directory Listing " + getUrl, "Verify that Directory Listing section is negotiating sucessfully", "Failed to do the Action");

            }*/
            report.reportPass(strDescription + getUrl, strExpected, strActual);
        } catch (Exception e) {
            report.reportPass(strDescription + getUrl, strExpected, strFailed);
        }
        
        
      
     }
    
    /**
     * @Description: selectLecVoice is used to add or update line in Lec voice
     *               option
     * @param: VoicePlan,AddLecLine,ChangeVoiceJack
     *             and Standalone are used to update line in Lec Voice section
     * @author: Mounika, Padmini
     * @return:No Return Type
     * @exception: Throws
     *                 Exception
     * @ModifiedBy:
     * @ModifiedDate:
     * @Comments:
     */


    public void selectLecVoice() throws Exception, UserDefinedException {

        System.out.println("->Lec Section");
        String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
        strDescription = "To negotiate Lec Section in C2G";
        strExpected = "Negotiate Lec Section";
        strFailed = "Failed in Lec Section";
        strActual = "Negotiated Lec Section";
        getUrl = ", URL Launched --> " + returnURL();

        int addLineTabCount=0;
        try {

            String PSTNMaintenancePlan = get("PSTNMaintenancePlan");
            String AddLecLine = get("pstnAdditionalLines");
            String PSTNVoiceJack = get("PSTNVoiceJack");
            String PSTN_Voice_Type = get("PSTN_Voice_Type");
            String CreditFirstName = get("FName");
            String CreditLastName = get("LName");
            
            switchToDefaultcontent();
           // switchToFrame("IfProducts");

            waitForLoader();
            waitForLoader();
            waitForLoader();

            // click add new line

            addLineTabCount = NoOfAddlineTab.size();
            System.out.println("No Of  Addline Tab is:" + addLineTabCount);
            
                      
            try {
            	
            	if (!AddLecLine.isEmpty()) {
        			int addlineCount = Integer.parseInt(AddLecLine);

        			System.out.println("addlineCount value is:" + addlineCount);
        			for ( int i = 0; i < addlineCount; i++) {
        				
        			
        				
         			    if (isDisplayed(BtnLECAddNewLine, objectValue)) {
         			    	
       				    if((!isDisplayed(lecPageDisplay, "", 20))){
                      	  pageScroll(BtnLECAddNewLine, objectValue, true);
                          clickUsingJavaScript(BtnLECAddNewLine, objectValue);
                          waitForLoader();
                          waitForLoader();
                          waitForLoader();
                          waitForLoader();
                          waitForElementDisplay(lecPageDisplay, "", pageTimeoutInSeconds);
                         
                          report.reportPass("Click on Add Line in LEC", "Add new Line should be clicked.", "Clicked on Add new Line in LEC window");
                          addLineTabCount++;
         				}
       				    else if(!isDisplayed(lecPageDisplay, "", pageTimeoutInSeconds) && (i>=addLineTabCount)){
                     	  pageScroll(BtnLECAddNewLine, objectValue, true);
                         clickUsingJavaScript(BtnLECAddNewLine, objectValue);
                         waitForLoader();
                         waitForLoader();
                         waitForLoader();
                         waitForLoader();
                         waitForLoader();
                         waitForElementDisplay(lecPageDisplay, "", pageTimeoutInSeconds);
                        
                         report.reportPass("Click on Add Line  in LEC", "Add new Line should be clicked.", "Clicked on Add new Line in LEC window");
                         addLineTabCount++;
        				}
       				   
       				  
                          waitForLoader();
                          waitForLoader();

                          waitForElementDisplay(lecPageDisplay, "", pageTimeoutInSeconds);
                          // Maintenance Flow
                          
                          switchToDefaultcontent();
                          //switchToFrame("IfProducts");
                          //switchToFrame("PopupIFrame");
                          
                          if (isDisplayed(chkDisclosure, objectValue)) {
                          	pageScroll(chkDisclosure, objectValue, true);
                          	 clickUsingJavaScript(chkDisclosure, objectValue);
                          	 report.reportPass("Click on Disclosure Checkbox in Lec Window", "Disclosure Checkbox should be clicked in Lec Window", "Disclosure Checkbox is clicked in Lec Window");
                          	 waitForLoader();
                             waitForLoader();
                          
                          }

                          try{
                        	 // switchToDefaultcontent();
                        	  if(isDisplayed(VoiceMailLink, "", 4))
                        	  clickUsingJavaScript(VoiceMailLink, objectValue);
                              waitForLoader();
                              waitForLoader();
                              waitForLoader();
                             
                             // switchToDefaultcontent();
                              driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                              if(isDisplayed(ChkbxVoiceMail, "",5)){
                                  pageScroll(ChkbxVoiceMail, PSTNMaintenancePlan, true);
                                  click(ChkbxVoiceMail, PSTNMaintenancePlan);
                                  report.reportPass("Click on Voice Mail in LEC", "Voice Mail should be clicked", "Mainatinance Plan is clicked");
                                    }
                              switchToDefaultcontent();
                              driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                              clickUsingJavaScript(ChkbxVoiceMailOK, objectValue);
                              waitForLoader();
                              waitForLoader();
                              waitForLoader();
                              waitForLoader();
                   
                   		  
                          }
                          catch (Exception e) {
                              strFailed = "Failed in LEC Window, Voice Mail is not negotiated";
                              logger.error(strFailed, e);
                              report.reportFail("Failed in LEC Window", "Voice Mail should be negotiated", strFailed);
                              report.updateMainReport("comments", strFailed);
                              report.updateMainReport("ErrorMessage", strFailed);
                              captureErrorMsg(strFailed);
                              throw new UserDefinedException(strFailed);
                            }
                       /*
                          try {
                            if (isDisplayed(LinkLECMaintenanceDetails, objectValue)) {
                                clickUsingJavaScript(LinkLECMaintenanceDetails, objectValue);
                                waitForLoader();
                                waitForLoader();
                                waitForLoader();
                                waitForLoader();
                            }

                            driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                            // switchToFrame(jackVoiceFrame);

                            System.out.println("Switched to frame");

                                  if(isDisplayed(ChkbxLECNoMaintainance, "",5)){
                                pageScroll(ChkbxLECNoMaintainance, PSTNMaintenancePlan, true);
                                clickUsingJavaScript(ChkbxLECNoMaintainance, PSTNMaintenancePlan);
                                report.reportPass("Click on No Mainatinance Plan in LEC", "No Mainatinance Plan should be clicked", "No Mainatinance Plan is clicked");
                                  }
                                  else{
                                  	 pageScroll(ChkbxLECMaintainanceplan, PSTNMaintenancePlan, true);
                                       click(ChkbxLECMaintainanceplan, PSTNMaintenancePlan);
                                       report.reportPass("Click on Mainatinance Plan in LEC", "Mainatinance Plan should be clicked", "Mainatinance Plan is clicked");
                                        //clickUsingJavaScript(ChkbxLECMaintainanceplan, objectValue);
                                  
                                  }
                                waitForLoader();
                                waitForLoader();
                               waitForLoader();

                              
                            
                            switchToDefaultcontent();
                           // switchToFrame("IfProducts");
                           // switchToFrame("PopupIFrame");
                            driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

                            if (isDisplayed(linkOkMaintainanceGN, objectValue)) {
                          	  pageScroll(linkOkMaintainanceGN, objectValue, true);
                                clickUsingJavaScript(linkOkMaintainanceGN, objectValue);
                                report.reportPass("Click on Ok in Mainatinance Plan in LEC", "Ok in Mainatinance Plan should be clicked", "Ok in Mainatinance Plan is clicked");
                                waitForLoader();
                            }

                          } catch (Exception e) {
                            strFailed = "Failed in LEC Window, Maintainance Plan is not negotiated";
                            logger.error(strFailed, e);
                            report.reportFail("Failed in LEC Window", "Maintainance Plan should be negotiated", strFailed);
                            report.updateMainReport("comments", strFailed);
                            report.updateMainReport("ErrorMessage", strFailed);
                            captureErrorMsg(strFailed);
                            throw new UserDefinedException(strFailed);
                          }
                          */

                          System.out.println("Switched to frame");
                          waitForLoader();
                          waitForLoader();
                          waitForLoader();
                          waitForLoader();
                          waitForLoader();
                          waitForLoader();
                          pause();

                          switchToDefaultcontent();
                         // switchToFrame("IfProducts");
                          //switchToFrame("PopupIFrame");

                   

                              // Jack Flow

                              try {

                                switchToDefaultcontent();
                                //switchToFrame("IfProducts");
                                //switchToFrame("PopupIFrame");

                                if (isDisplayed(jackVoiceLink, PSTNVoiceJack)) {
                              	  pageScroll(jackVoiceLink, PSTNVoiceJack, true);
                                    clickUsingJavaScript(jackVoiceLink, PSTNVoiceJack);
                                    report.reportPass("Click on Jack Voice Link", "Jack Voice Link should be clicked", "Jack Voice Link is clicked");
                                    waitForLoader();
                                    waitForLoader();
                                    waitForLoader();
                                    // pause();

                              
                                    driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                                  
                                    // switchToFrame(jackVoiceFrame);

                                    System.out.println("Switched to frame");

                                    // update jack
                                    if (isDisplayed(ChkbxLECNoJacks, PSTNVoiceJack)) {

                                      if (!PSTNVoiceJack.isEmpty()) {

                                          System.out.println("ChangeVoiceJack count:" + valuesForVoiceJack.size());
                                          for (WebElement el : valuesForVoiceJack) {
                                            System.out.println("Value for Jack text:" + el.getText());

                                            for (WebElement el1 : chkBoxesForVoiceJack) {
                                                if (el.getText().contains(PSTNVoiceJack.trim())) {
                                                  ((JavascriptExecutor) driver).executeScript("arguments[0].click();", el1);
                                                  waitForLoader();
                                                  waitForLoader();
                                                  waitForLoader();

                                                  break;
                                                }
                                            }
                                          }
                                          pageScroll(ADDLinkJack, objectValue, true);
                                          clickUsingJavaScript(ADDLinkJack, objectValue);
                                          waitForLoader();
                                          waitForLoader();
                                          waitForLoader();
                                      

                                      } else {
                                          // no Jacks needed clicked
                                      	 pageScroll(ChkbxLECNoJacks, PSTNVoiceJack, true);
                                          clickUsingJavaScript(ChkbxLECNoJacks, PSTNVoiceJack);
                                         // report.reportPass("Click on No Jack in Jack Section", "No Jack in Jack Section should be clicked", "No Jack in Jack Section is clicked");
                                          waitForLoader();
                                          waitForLoader();
                                         

                                      }

                                    }
                                    // Link Ok
                                    switchToDefaultcontent();
                                   // switchToFrame("IfProducts");
                                   // switchToFrame("PopupIFrame");
                                    driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                                    if (isDisplayed(BtnLECJackOk, objectValue)) {
                                        // Clicking on OK for jacks
                                    	  pageScroll(BtnLECJackOk, objectValue, true);
                                        clickUsingJavaScript(BtnLECJackOk, objectValue);
                                        report.reportPass("Click on Ok in Jack Section", "Ok in Jack Section should be clicked", "Ok in Jack Section is clicked");
                                        waitForLoader();
                                        waitForLoader();
                                        waitForLoader();
                                     

                                      }


                                } else {

                                } 
                                
                                switchToDefaultcontent();
                                // switchToFrame("IfProducts");
                                // switchToFrame("PopupIFrame");
                                // driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                                 if(isDisplayed(btnDirectoryListing, objectValue)){
                                	 clickUsingJavaScript(btnDirectoryListing, objectValue);
                                	 waitForLoader(); 
                                	 waitForLoader(); 
                                	 
                                	 waitForLoader(); 
                                	// switchToFrame("IfProducts");
                                     // switchToFrame("PopupIFrame");
                                 	 switchToDefaultcontent();
                                 	driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                                 	
                                 	pageScroll(firstname, objectValue, true);
                                     clearText(firstname, objectValue);
                                     setText(firstname, objectValue, CreditFirstName);
                                     clearText(lastname, objectValue);
                                     setText(lastname, objectValue, CreditLastName);
                                     report.reportPass("Click on Ok in Jack Section", "Ok in Jack Section should be clicked", "Ok in Jack Section is clicked");
                                     waitForLoader(); 
                                     switchToDefaultcontent();
                                 	driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                                     pageScroll(applyDL, objectValue,true);
                                     clickUsingJavaScript(applyDL, objectValue);
                                     waitForLoader(); 
                                     waitForLoader(); 
                                     waitForLoader();
                                     switchToDefaultcontent();
                                     // switchToFrame("IfProducts");
                                     // switchToFrame("PopupIFrame");
                                      driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

                                     pageScroll(OkbuttonDL, objectValue, true);
                                     clickUsingJavaScript(OkbuttonDL, objectValue);
                                     waitForLoader(); 
                                     waitForLoader(); 
                                     waitForLoader(); 
                                     waitForLoader(); 
                                 	
                                 }
                              
                              } catch (Exception e) {
                                strFailed = "Failed in LEC Window, Voice Jack is not negotiated";
                                logger.error(strFailed, e);
                                report.reportFail("Failed in LEC Window", "Voice Jack should be negotiated", strFailed);
                                report.updateMainReport("comments", strFailed);
                                report.updateMainReport("ErrorMessage", strFailed);
                                captureErrorMsg(strFailed);
                                throw new UserDefinedException(strFailed);
                              }


                            }
            				}
        			
        			if (addlineCount == 0){
         				
        				
         			    if (isDisplayed(BtnLECAddNewLine, objectValue)) {
         			    	
        				    if((!isDisplayed(lecPageDisplay, "", 20))){
                      	  pageScroll(BtnLECAddNewLine, objectValue, true);
                          clickUsingJavaScript(BtnLECAddNewLine, objectValue);
                          waitForLoader();
                          waitForLoader();
                          waitForLoader();
                          waitForLoader();
                          waitForElementDisplay(lecPageDisplay, "", pageTimeoutInSeconds);
                         
                          report.reportPass("Click on Add Line in LEC", "Add new Line should be clicked.", "Clicked on Add new Line in LEC window");
                          addLineTabCount++;
         				}
        				    else if(!isDisplayed(lecPageDisplay, "", pageTimeoutInSeconds) ){
                     	  pageScroll(BtnLECAddNewLine, objectValue, true);
                         clickUsingJavaScript(BtnLECAddNewLine, objectValue);
                         waitForLoader();
                         waitForLoader();
                         waitForLoader();
                         waitForLoader();
                         waitForLoader();
                         waitForElementDisplay(lecPageDisplay, "", pageTimeoutInSeconds);
                        
                         report.reportPass("Click on Add Line  in LEC", "Add new Line should be clicked.", "Clicked on Add new Line in LEC window");
                         addLineTabCount++;
        				}
        				   
        				  
                          waitForLoader();
                          waitForLoader();

                          waitForElementDisplay(lecPageDisplay, "", pageTimeoutInSeconds);
                          // Maintenance Flow
                          
                          switchToDefaultcontent();
                          //switchToFrame("IfProducts");
                          //switchToFrame("PopupIFrame");
                          
                          if (isDisplayed(chkDisclosure, objectValue)) {
                          	pageScroll(chkDisclosure, objectValue, true);
                          	 clickUsingJavaScript(chkDisclosure, objectValue);
                          	 report.reportPass("Click on Disclosure Checkbox in Lec Window", "Disclosure Checkbox should be clicked in Lec Window", "Disclosure Checkbox is clicked in Lec Window");
                          	 waitForLoader();
                             waitForLoader();
                          
                          }

                          try{
                        	 // switchToDefaultcontent();
                        	  if(isDisplayed(VoiceMailLink, "", 4))
                        	  clickUsingJavaScript(VoiceMailLink, objectValue);
                              waitForLoader();
                              waitForLoader();
                              waitForLoader();
                             
                             // switchToDefaultcontent();
                              driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                              if(isDisplayed(ChkbxVoiceMail, "",5)){
                                  pageScroll(ChkbxVoiceMail, PSTNMaintenancePlan, true);
                                  click(ChkbxVoiceMail, PSTNMaintenancePlan);
                                  report.reportPass("Click on Voice Mail in LEC", "Voice Mail should be clicked", "Mainatinance Plan is clicked");
                                    }
                              switchToDefaultcontent();
                              driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                              clickUsingJavaScript(ChkbxVoiceMailOK, objectValue);
                              waitForLoader();
                              waitForLoader();
                              waitForLoader();
                              waitForLoader();
                   
                   		  
                          }
                          catch (Exception e) {
                              strFailed = "Failed in LEC Window, Voice Mail is not negotiated";
                              logger.error(strFailed, e);
                              report.reportFail("Failed in LEC Window", "Voice Mail should be negotiated", strFailed);
                              report.updateMainReport("comments", strFailed);
                              report.updateMainReport("ErrorMessage", strFailed);
                              captureErrorMsg(strFailed);
                              throw new UserDefinedException(strFailed);
                            }
                            /*
                          try {
                            if (isDisplayed(LinkLECMaintenanceDetails, objectValue)) {
                                clickUsingJavaScript(LinkLECMaintenanceDetails, objectValue);
                                waitForLoader();
                                waitForLoader();
                                waitForLoader();
                                waitForLoader();
                            }

                            driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                            // switchToFrame(jackVoiceFrame);

                            System.out.println("Switched to frame");

                                  if(isDisplayed(ChkbxLECNoMaintainance, "",5)){
                                pageScroll(ChkbxLECNoMaintainance, PSTNMaintenancePlan, true);
                                clickUsingJavaScript(ChkbxLECNoMaintainance, PSTNMaintenancePlan);
                                report.reportPass("Click on No Mainatinance Plan in LEC", "No Mainatinance Plan should be clicked", "No Mainatinance Plan is clicked");
                                  }
                                  else{
                                  	 pageScroll(ChkbxLECMaintainanceplan, PSTNMaintenancePlan, true);
                                       click(ChkbxLECMaintainanceplan, PSTNMaintenancePlan);
                                       report.reportPass("Click on Mainatinance Plan in LEC", "Mainatinance Plan should be clicked", "Mainatinance Plan is clicked");
                                        //clickUsingJavaScript(ChkbxLECMaintainanceplan, objectValue);
                                  
                                  }
                                waitForLoader();
                                waitForLoader();
                               waitForLoader();

                              
                            
                            switchToDefaultcontent();
                           // switchToFrame("IfProducts");
                           // switchToFrame("PopupIFrame");
                            driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

                            if (isDisplayed(linkOkMaintainanceGN, objectValue)) {
                          	  pageScroll(linkOkMaintainanceGN, objectValue, true);
                                clickUsingJavaScript(linkOkMaintainanceGN, objectValue);
                                report.reportPass("Click on Ok in Mainatinance Plan in LEC", "Ok in Mainatinance Plan should be clicked", "Ok in Mainatinance Plan is clicked");
                                waitForLoader();
                            }

                          } catch (Exception e) {
                            strFailed = "Failed in LEC Window, Maintainance Plan is not negotiated";
                            logger.error(strFailed, e);
                            report.reportFail("Failed in LEC Window", "Maintainance Plan should be negotiated", strFailed);
                            report.updateMainReport("comments", strFailed);
                            report.updateMainReport("ErrorMessage", strFailed);
                            captureErrorMsg(strFailed);
                            throw new UserDefinedException(strFailed);
                          }
                          */

                          System.out.println("Switched to frame");
                          waitForLoader();
                          waitForLoader();
                          waitForLoader();
                          waitForLoader();
                          waitForLoader();
                          waitForLoader();
                          pause();

                          switchToDefaultcontent();
                         // switchToFrame("IfProducts");
                          //switchToFrame("PopupIFrame");

                   

                              // Jack Flow

                              try {

                                switchToDefaultcontent();
                                //switchToFrame("IfProducts");
                                //switchToFrame("PopupIFrame");

                                if (isDisplayed(jackVoiceLink, PSTNVoiceJack)) {
                              	  pageScroll(jackVoiceLink, PSTNVoiceJack, true);
                                    clickUsingJavaScript(jackVoiceLink, PSTNVoiceJack);
                                    report.reportPass("Click on Jack Voice Link", "Jack Voice Link should be clicked", "Jack Voice Link is clicked");
                                    waitForLoader();
                                    waitForLoader();
                                    waitForLoader();
                                    // pause();

                              
                                    driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                                  
                                    // switchToFrame(jackVoiceFrame);

                                    System.out.println("Switched to frame");

                                    // update jack
                                    if (isDisplayed(ChkbxLECNoJacks, PSTNVoiceJack)) {

                                      if (!PSTNVoiceJack.isEmpty()) {

                                          System.out.println("ChangeVoiceJack count:" + valuesForVoiceJack.size());
                                          for (WebElement el : valuesForVoiceJack) {
                                            System.out.println("Value for Jack text:" + el.getText());

                                            for (WebElement el1 : chkBoxesForVoiceJack) {
                                                if (el.getText().contains(PSTNVoiceJack.trim())) {
                                                  ((JavascriptExecutor) driver).executeScript("arguments[0].click();", el1);
                                                  waitForLoader();
                                                  waitForLoader();
                                                  waitForLoader();

                                                  break;
                                                }
                                            }
                                          }
                                          pageScroll(ADDLinkJack, objectValue, true);
                                          clickUsingJavaScript(ADDLinkJack, objectValue);
                                          waitForLoader();
                                          waitForLoader();
                                          waitForLoader();
                                      

                                      } else {
                                          // no Jacks needed clicked
                                      	 pageScroll(ChkbxLECNoJacks, PSTNVoiceJack, true);
                                          clickUsingJavaScript(ChkbxLECNoJacks, PSTNVoiceJack);
                                         // report.reportPass("Click on No Jack in Jack Section", "No Jack in Jack Section should be clicked", "No Jack in Jack Section is clicked");
                                          waitForLoader();
                                          waitForLoader();
                                         

                                      }

                                    }
                                    // Link Ok
                                    switchToDefaultcontent();
                                   // switchToFrame("IfProducts");
                                   // switchToFrame("PopupIFrame");
                                    driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                                    if (isDisplayed(BtnLECJackOk, objectValue)) {
                                        // Clicking on OK for jacks
                                    	  pageScroll(BtnLECJackOk, objectValue, true);
                                        clickUsingJavaScript(BtnLECJackOk, objectValue);
                                        report.reportPass("Click on Ok in Jack Section", "Ok in Jack Section should be clicked", "Ok in Jack Section is clicked");
                                        waitForLoader();
                                        waitForLoader();
                                        waitForLoader();
                                     

                                      }


                                } else {

                                } 
                                
                                switchToDefaultcontent();
                                // switchToFrame("IfProducts");
                                // switchToFrame("PopupIFrame");
                                // driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                                 if(isDisplayed(btnDirectoryListing, objectValue)){
                                	 clickUsingJavaScript(btnDirectoryListing, objectValue);
                                	 waitForLoader(); 
                                	 waitForLoader(); 
                                	 
                                	 waitForLoader(); 
                                	// switchToFrame("IfProducts");
                                     // switchToFrame("PopupIFrame");
                                 	 switchToDefaultcontent();
                                 	driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                                 	
                                 	pageScroll(firstname, objectValue, true);
                                     clearText(firstname, objectValue);
                                     setText(firstname, objectValue, CreditFirstName);
                                     clearText(lastname, objectValue);
                                     setText(lastname, objectValue, CreditLastName);
                                     report.reportPass("Click on Ok in Jack Section", "Ok in Jack Section should be clicked", "Ok in Jack Section is clicked");
                                     waitForLoader(); 
                                     switchToDefaultcontent();
                                 	driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
                                     pageScroll(applyDL, objectValue,true);
                                     clickUsingJavaScript(applyDL, objectValue);
                                     waitForLoader(); 
                                     waitForLoader(); 
                                     waitForLoader();
                                     switchToDefaultcontent();
                                     // switchToFrame("IfProducts");
                                     // switchToFrame("PopupIFrame");
                                      driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));

                                     pageScroll(OkbuttonDL, objectValue, true);
                                     clickUsingJavaScript(OkbuttonDL, objectValue);
                                     waitForLoader(); 
                                     waitForLoader(); 
                                     waitForLoader(); 
                                     waitForLoader(); 
                                 	
                                 }
                                 
                               //Intercept
         						try{
         							waitForLoader();
         							waitForLoader();
         							waitForLoader();
         							if (isDisplayed(linkIntercept, objectValue)) {
         								// pageScroll(jackVoiceLink, objectValue, true);
         								clickUsingJavaScript(linkIntercept, objectValue);
         								report.reportPass("Click on linkIntercept edit ", "linkIntercept edit should be clicked", "linkIntercept edit is clicked");
         								waitForLoader();
         								waitForLoader();
         								waitForLoader();
         								// pause();

         								switchToDefaultcontent();
         								switchToFrame("IfProducts");
         								switchToFrame("PopupIFrame");
         								driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));	
         								clickUsingJavaScript(linkInterceptSelectAll, objectValue);
         								waitForLoader();
         								waitForLoader();
         								waitForLoader();                            

         								switchToDefaultcontent();
         								switchToFrame("IfProducts");
         								switchToFrame("PopupIFrame");
         								driver.switchTo().frame(driver.findElement(By.xpath("//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")));
         								clickUsingJavaScript(linkInterceptok, objectValue);
         								waitForLoader();
         								waitForLoader();
         								waitForLoader();                              

         								pause();



         							}
         						} catch (Exception e) {
        							strFailed = "Failed in LEC Window, . Intercept is not negotiated";
        							logger.error(strFailed, e);
        							report.reportFail("Failed in LEC Window", ". Intercept should be negotiated", strFailed);
        							report.updateMainReport("comments", strFailed);
        							report.updateMainReport("ErrorMessage", strFailed);
        							captureErrorMsg(strFailed);
        							throw new UserDefinedException(strFailed);
        						}
         						
                              
                              } catch (Exception e) {
                                strFailed = "Failed in LEC Window, Voice Jack is not negotiated";
                                logger.error(strFailed, e);
                                report.reportFail("Failed in LEC Window", "Voice Jack should be negotiated", strFailed);
                                report.updateMainReport("comments", strFailed);
                                report.updateMainReport("ErrorMessage", strFailed);
                                captureErrorMsg(strFailed);
                                throw new UserDefinedException(strFailed);
                              }


                            }
            				
         				
         				
                				
                			}
        			
            			    }
            			

            		           		

            } catch (Exception e) {
            	if (!isUserDefinedException(e)) {
        			report.reportFail(strDescription + getUrl, strExpected, strFailed);
        			report.updateMainReport("ErrorMessage", strFailed);
        			captureErrorMsg("Failed in Lec section.");
        		    }
        		    throw e;
        }
            

           
            // Clicking on Save and Continue

            switchToDefaultcontent();
            //switchToFrame("IfProducts");
            //switchToFrame("PopupIFrame");
            

            if (isDisplayed(BtnLECSaveAndCont, objectValue)) {
            	//pageScroll(BtnLECSaveAndCont, objectValue, true);
              clickUsingJavaScript(BtnLECSaveAndCont, objectValue);
              report.reportPass("Click on Save And Continue in Lec Window", "Save And Continue in Lec Window should be clicked", "Save And Continue in Lec Window is clicked");
            waitForLoader();
          

            }
        
             
              waitForLoader();
              waitForLoader();

              waitForLoader();
              waitForLoader();
              pause();
              pause();
              
              if(isDisplayed(ADDLinkJack, "", 7)){
            	  clickUsingJavaScript(BtnLECSaveAndCont, objectValue);
                  report.reportPass("Click on Save And Continue in Lec Window", "Save And Continue in Lec Window should be clicked", "Save And Continue in Lec Window is clicked");
                waitForLoader();
                
                waitForLoader();
                waitForLoader();

                waitForLoader();
                waitForLoader();
                pause();
                pause();
              }

        } catch (Exception e) {
        	 if (!isUserDefinedException(e)) {
        			report.reportFail(strDescription + getUrl, strExpected, strFailed);
        			report.updateMainReport("ErrorMessage", strFailed);
        			captureErrorMsg("Failed in Lec section.");
        		    }
        		    throw e;
        }
      }
    
    


   
}
