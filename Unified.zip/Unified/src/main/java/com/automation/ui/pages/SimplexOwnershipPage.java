package com.automation.ui.pages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_BillingInfo_PageObjects;
import com.automation.pageobjects.Simplex_Ownership_PageObjects;
import com.automation.support.Element;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * SimplexBillingInfoPage class represents the Billing Info Page and interact
 * with the Page
 * 
 */
//@SuppressWarnings("unused")
public class SimplexOwnershipPage extends Simplex_Ownership_PageObjects {


    String objectValue = "";
    static boolean windows = InitiateDriver.windows;
 
    String testId;
    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);
    String description = "", expected = "", actual = "", failure = "",getUrl="";
    By by;

    /**
     * SimplexBillingInfoPage constructor invokes the super class constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     */
    @SuppressWarnings("unchecked")
    public SimplexOwnershipPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, windows, report, data);
    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     */
    public static SimplexOwnershipPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexOwnershipPage.class, testId, report, data);
    }

    /**
     * Navigation start for Simplex Billing info Page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void start() throws Exception {

	setIterator();
	System.out.println("Ownership page...");

	if(!get("OwnershipPage").equalsIgnoreCase("")){
	changeOwnership();
	}


    }

    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void navigateTo() throws Exception {
    	// To increment the navigation iteration
    	int i = TestIterator.getIterator(testId);
    	TestIterator.setIterator(testId, ++i);
    }
    

	
    protected void changeOwnership() throws Exception {

    	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
    	try {
    	    // set the Iterator to latest excel count

    	    // Give Customer Billing info
    	    strDescription = "Entering customer Billing info details";
    	    strExpected = "Giving customer Billing info in details";
    	    strActual = "Giving Customer Billing details in Billing Info Page was successful";
    	    strFailed = "Giving Customer Billing details in Billing Info Page was not successful";
    	    getUrl = ", URL Launched --> " + returnURL();
                 
    	  waitForLoader();
    	  waitForLoader();
    	  switchToDefaultcontent();
    	  
    	  
    	  switchToFrame("IfProducts");
    	  
    	  waitForElementDisplay(rbtnIncomingOutgoingCustomer, objectValue, 30);
    	  clickUsingJavaScript(rbtnIncomingOutgoingCustomer, objectValue);
    	  
    	  report.reportPass("Click Incoming and Outgoing Radio Button in Ownership Page", "Click Incoming and Outgoing Radio Button in Ownership Page if Exists", "Clicking Incoming and Outgoing Radio Button");
    	  waitForLoader();
    	setText(txtOutgoingcallingparty, objectValue, "Test1");
    	report.reportPass("Enter Outgoing Calling Party in Ownership Page", "Enter Outgoing Calling Party in Ownership Page if Exists", "Entered Outgoing Calling Party in Ownership Page: Test1");
    	setText(txtIncomingcallingparty, objectValue, "Test2");
    	report.reportPass("Enter Incoming Calling Party in Ownership Page", "Enter Incoming Calling Party in Ownership Page if Exists", "Entered Incoming Calling Party in Ownership Page: Test2");
    	clickUsingJavaScript(btnContinue, objectValue);
    	report.reportPass("Click Continue Button in Ownership Page", "Click Continue Button in Ownership Page if Exists", "Click Continue Button in Ownership Page");
    	waitForLoader();
    	pageScroll(rbtnYes);
    	clickUsingJavaScript(rbtnYes, objectValue);
    	report.reportPass("Click Agreement in Ownership Page", "Click Agreement as Yes in Ownership Page if Exists", "Clicked Agreement as Yes in Ownership Page");
    	waitForLoader();
    	//Enter Valid ATN
		  
		   clearText(enterATN, objectValue); 
		   setText(enterATN, strActual, "813-966-5237");
		  
		 //Enter Valid MTN
		   
		   WebElement e=driver.findElement(By.xpath("//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$CustomerContactInformation$txtMobileNumber']"));
	       e.clear();
	    	setText(enterMTN, strActual, "813-966-5252");
		 
		   
		   
		 //Enter Valid Email
		   
		   clearText(enterEmail, objectValue);
		   setText(enterEmail, strActual, "polagoni.mounika@one.verizon.com");
		   report.reportPass("Validate Contact Info Details in Ownership Page", "Validate Contact Info Details if Exists in Ownership Page", "Validated Contact Info Details in Ownership Page");
    	pageScroll(btnSaveAndContinue);
    	clickUsingJavaScript(btnSaveAndContinue, objectValue);
    	waitForLoader();
    	waitForLoader();
      switchToDefaultcontent();
    	switchToFrame("IfProducts");
      
    	  if(isDisplayed(btnPostalAddress, strFailed, 8)){
    		pageScroll(btnPostalAddress,objectValue,true);
        	clickUsingJavaScript(btnPostalAddress, objectValue);
        }
    	else if(isDisplayed(btnUseSameAddress)){
    	pageScroll(btnUseSameAddress);
    	clickUsingJavaScript(btnUseSameAddress, objectValue);
    	}
    	waitForLoader();
    	waitForLoader();
	    waitForLoader();
	    waitForLoader();
	    waitForLoader();
    	
    	}
    	catch(Exception exe){
    		
    	}
    }
}