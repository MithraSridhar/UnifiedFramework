package com.automation.ui.pages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_OrderSummary_PageObjects;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;

/**
 * SimplexOrderSummaryPage class represents the Order Summary Info Page and
 * interact with the Page
 * 
 */
public class SimplexOrderSummaryPage extends Simplex_OrderSummary_PageObjects {

	String objectValue = "";
	static boolean windows = InitiateDriver.windows;
	String description = "", expected = "", actual = "", failure = "", getUrl;
	By by;
	int iterator = 0;
	String testId;
	Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

	/**
	 * SimplexOrderSummaryPage constructor invokes the super class constructor.
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            repesents the testcase id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	@SuppressWarnings("unchecked")
	public SimplexOrderSummaryPage(WebDriver driver, String testId,
			ReportStatus report, HashMap<String, String> data) throws Exception {
		super(driver, windows, report, data);
		this.testId = testId;
	}

	/**
	 * initialize method used to initialize the page elements for this page and
	 * returns current Page
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            repesents the testcase id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @return returns current page class
	 */
	public static SimplexOrderSummaryPage initialize(WebDriver driver,
			String testId, ReportStatus report, HashMap<String, String> data) {
		return ElementFactory.initElements(driver,
				SimplexOrderSummaryPage.class, testId, report, data);
	}

	/**
	 * Navigation start for Simplex Order Summary Page
	 * 
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public void start() throws Exception {

		setOrderSummaryInfo();
	}

	/**
	 * Navigation to this page
	 * 
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public void navigateTo() throws Exception 
	{
		//To increment the navigation iteration
		int i = TestIterator.getIterator(testId);
		TestIterator.setIterator(testId, ++i);
	}

	/**
	 * setOrderSummaryInfo method for providing the Customer's Order Summary
	 * information in Order Summary Info Page
	 * 
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	protected void setOrderSummaryInfo() throws Exception {
		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		try {
			// Give Customer Summary info
			strDescription = "Entering customer OrderSummary info details";
			strExpected = "Giving customer Order Summary info in details";
			strActual = "Giving Customer Order Summary details in Order Summary Info Page was successful";
			strFailed = "Giving Customer Order Summary details in Order Summary Info Page was not successful";
			getUrl = ", URL Launched --> " + returnURL();

			String notes = get("Notes");
			// Switch to default content
			switchToDefaultcontent();

			// Retrieve Master Order Number
			System.out.println(getTextFromElement(lblMon, strFailed));

			// Click the Closing notes label
			clickUsingJavaScript(lblClosingnotes, strFailed);

			setText(txtClosingnotes, objectValue, notes);
			// Element_validation(txtClosingnotes, objectValue,
			// "Simplex Calling From Page", "CallBack No is Entered", false,
			// "");

			// Click outside on Label to update the value in text box
			clickUsingJavaScript(lblClosingnotessmall, strFailed);

			// Click the save and close button
			clickUsingJavaScript(btnSaveAndClose, strFailed);

			report.reportPass(strDescription + getUrl, strExpected, strActual);
		} catch (Exception exe) {
			exe.printStackTrace();
			report.reportFail(strDescription + getUrl, strExpected, strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			throw exe;
		}

	}

}
