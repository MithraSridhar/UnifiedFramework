package com.automation.ui.pages;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_PSTNInternetHSI_PageObjects;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * SimplexProductAndServicesPage class represents the Product & Services and
 * interact with the Page.
 * 
 */
public class SimplexPSTNInternetHSIPage extends Simplex_PSTNInternetHSI_PageObjects {

    String objectValue = "";
    static boolean windows = InitiateDriver.windows;
    int iterator = 0;
    String testId;
    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

    String description = "", expected = "", actual = "", failure = "", getUrl = "";
    By by;

    /**
     * SimplexProductServicesPage constructor invokes the super class
     * constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     */
    public SimplexPSTNInternetHSIPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, windows, report, data);
	this.testId = testId;
    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     */
    public static SimplexPSTNInternetHSIPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexPSTNInternetHSIPage.class, testId, report, data);
    }

    public void start() throws Exception {

	setIterator();
	
	if(!get("PSTN_SaveAndCont").isEmpty()){
		if (isDisplayed(btnSaveAndContinueButton,objectValue,5))
	    {
		    mouseOver(btnSaveAndContinueButton);
		    clickUsingJavaScript(btnSaveAndContinueButton, objectValue);
		    pause();
		    waitForLoader();
		    report.reportPass("Click on Save and Continue Button", "Save and Continue Button should be clicked", "Save and Continue Button is clicked");
	    }
		if (isDisplayed(btnsaveContinue,objectValue,5))
	    {
		    mouseOver(btnsaveContinue);
		    clickUsingJavaScript(btnsaveContinue, objectValue);
		    pause();
		    waitForLoader();
		    report.reportPass("Click on Save and Continue Button", "Save and Continue Button should be clicked", "Save and Continue Button is clicked");
	    }
    
	}
	else{
		if (isDisplayed(refundablecheck,objectValue,1))
			{
		clickUsingJavaScript(refundablecheck, objectValue);			
		 report.reportPass("Click on Refundable deposit check box", "Refundable deposit check box should be checked", "Refundable deposit check box is clicked");
		 waitForLoader();
		 waitForLoader();
		}
	selectInternetHSI();
	}
	
    }
    
    
    public void navigateTo() throws Exception, UserDefinedException {

    	// clickUsingJavaScript on left panel for ProductPage
    	try {
    		int i = TestIterator.getIterator(testId);
    		TestIterator.setIterator(testId, ++i);
    		mouseOver(btnBBEsaveandContinue);
    		clickUsingJavaScript(btnBBEsaveandContinue, objectValue);
    		}catch (Exception e) {
    	
    		e.printStackTrace();
    		throw new UserDefinedException("PSTN Button didn't click");
    	    }
    	}
    
    /**
     * @Info Adding Internet Page  
     * @throws Exception
     * @Modified by Poovaraj
     * @LastUpdated 03/13/2017
     */
    public void selectInternetHSI() throws Exception 
    {
    	
    	String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl, VoiceValue = "" ;
    	strDescription = "Validation of Select PSTN InternetHSI";
    	String Modem = get("PSTN_Modem").toString();
    	strExpected = "Verify that PSTN InternetHSI information is able to provide";
    	strActual = "PSTN InternetHSI page is negotiated successfully";
    	strFailed = "PSTN InternetHSI page details are not getting updated successfully";
    	getUrl = ", URL Launched --> " + returnURL();
    	
    	  String Streaming = get("PSTN_Streaming").trim();
    	  String FlowType = get("FlowType").trim();
    	  String VASProduct = get("PSTN_VASProduct").trim();
    	
    	//waitForLoader();
    	//pause();
    	try{
    		
    		if (isDisplayed(ChangePackage))
    		{
    			clickUsingJavaScript(ChangePackage,objectValue);
    			waitForLoader();
    			pause();
    		}
    		if((!Streaming.isEmpty() && FlowType.equalsIgnoreCase("Change")) || (!FlowType.equalsIgnoreCase("Change"))){
    		/*clickUsingJavaScript(modemNo, Modem);
		    clickUsingJavaScript(modemSelect, objectValue);*/   
		    if(get("CreditFirstName").toLowerCase().equalsIgnoreCase("passhigh"))
		    {
		    	WebElement chsihkbox = driver.findElement(By.id("ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_chkHSIDeposit"));
		    	if(isDisplayed(chsihkbox)){
		    	chsihkbox.click();
		    	}
		    }
		    if(get("PSTN_Speed").equalsIgnoreCase("CheckSpeeds")){
			    switchToWindowWithURL("HSI");
			    waitForLoader();
			    waitForLoader();
			    clickUsingJavaScript(checkSpeeds, objectValue);
			  waitForLoader();
			  waitForLoader();
			    	if(isDisplayed(SelectedHSILine,objectValue,3))
				    {
				    	mouseOver(SelectedHSILine, "");
				    	click(SelectedHSILine, "");
				    	waitForPageToLoad(driver);
				    	waitForLoader();
				    	report.reportPass("Click on Selected Existing HSI Line", "Existing HSI Line should be clicked", "Existing HSI Line is clicked");
				    }
			    }
		    else if (isDisplayed(lstHSIType,objectValue,2)&&(get("PSTN_HSI_Type").trim().equalsIgnoreCase("StandAlone")))
    	    {
			    selectDropDownUsingVisibleText(lstHSIType, objectValue, get("PSTN_HSI_Type").trim());
			    report.reportPass("Select HSI Type", "HSI Type should be selected", "HSI Type is selected");
			    waitForLoader();
			    		    
			    mouseOver(rdoLineSelection);
			    clickUsingJavaScript(rdoLineSelection, objectValue);
			    report.reportPass("Select TN Line", "TN Line should be selected", "TN Line is selected");		    
			    
			    selectDropDownUsingVisibleText(lstIPAddressType, objectValue, get("PSTN_IP_Address_Type").trim());
			    report.reportPass("Select IP Address Type", "IP Address Type should be selected", "IP Address Type  is selected");		    
			    
			    selectDropDownUsingVisibleText(lstTerm, objectValue, get("PSTN_Term").trim());
			    report.reportPass("Select Term", "Term should be selected", "Term is selected");
			    //waitForLoader();
			    pause();
			    
			    selectDropDownUsingVisibleText(lstPacakge, objectValue, get("PSTN_Package").trim());	
			    report.reportPass("Select Package", "Package should be selected", "Package is selected");
			    waitForLoader();
			    
			    mouseOver(rdoBBEOptions);
			    clickUsingJavaScript(rdoBBEOptions, objectValue);
			    report.reportPass("Select BBE&E Options", "BBE&E option should be selected", "BBE&E option is selected");		    
			    
			    mouseOver(btnAddHSIPackage);
			    clickUsingJavaScript(btnAddHSIPackage, objectValue);
			    report.reportPass("Click on Add HSI Package to Selected Line button", "Add HSI Package to Selected Line button should be clicked", "Add HSI Package to Selected Line button is clicked");
    	    }
		    //waitForLoader();
		    else if(get("PSTN_HSI_Type").trim().equalsIgnoreCase("Bundle"))
		    {
		    	pause();
		    	waitForLoader();
		    	
		     if(isDisplayed(HSIBTN))
		     {
		     pageScroll(HSIBTN);
		     clickUsingJavaScript(HSIBTN, "");
		     waitForLoader();
		     waitForLoader();
		     }
		    }



            String ordertype = get("StackDisconnectOption").trim();
            String changetype = get("ChangeType").trim();
            if(ordertype.equalsIgnoreCase("ChangeExistingDryLoopService") || changetype.equalsIgnoreCase("HSI - Add UNEP/TDRL"))
    	    {
    	    switchToDefaultcontent();
	    	switchToFrame("IfProducts");
	
	    	//Updated by poovaraj on 07-Mar-2017
	    	String baseWindow = driver.getWindowHandle(); 
	
	
	    	     //Updated by poovaraj on 09-Mar-2017 
	    	switchToWindowWithURL("HSI");
    	   //  maximizeBrowserWindow();
    	     
    	     waitForLoader();
    	     
    	     switchToDefaultcontent();


    	     if(isDisplayed(SelectedHSILine))
    	    {
    	     mouseOver(SelectedHSILine, "");
    	     click(SelectedHSILine, "");
    	     waitForPageToLoad(driver);
    	     waitForLoader();
    	     report.reportPass("Click on Selected Existing HSI Line", "Existing HSI Line should be clicked", "Existing HSI Line is clicked");
    	    }
    	    }
            if(changetype.equalsIgnoreCase("StackAddCPE"))
    	    {
    	     
    	     switchToDefaultcontent();
    	switchToFrame("IfProducts");

    	//Updated by poovaraj on 07-Mar-2017
    	String baseWindow = driver.getWindowHandle(); 


    	     //Updated by poovaraj on 09-Mar-2017 
    	switchToWindowWithURL("HSI");
    	    // maximizeBrowserWindow();
    	     
    	     waitForLoader();
    	     
    	     switchToDefaultcontent();
    	     
    	     String CPEEquipment = get("CPEEquipment").trim();
    	     
    	     
    	     
    	     if(isDisplayed(BtnAddEquipment))
    	     {
    	     pageScroll(BtnAddEquipment);
    	     report.reportPass("Click on Btn Add Equipment", "Btn Add Equipment should be clicked", "Btn Add Equipment is clicked");
    	     clickUsingJavaScript(BtnAddEquipment, "");
    	     waitForLoader();
    	     waitForLoader();
    	     }
    	     
    	     switchToDefaultcontent();
    	     switchToFrame("extifrmpop");
    	     
    	     if(isDisplayed(AddCPEDropDown))
    	     {
    	     pageScroll(AddCPEDropDown);
    	     report.reportPass("Selct Equipment option from CPE DropDown", "Equipment option should be selected from CPE DropDown ", "Equipment option selected from CPE DropDown");
    	     selectDropDownUsingVisibleText(AddCPEDropDown, "", CPEEquipment);
    	     waitForLoader();
    	     waitForLoader();
    	     report.reportPass("Selct Equipment option from CPE DropDown", "Equipment option should be selected from CPE DropDown ", "Equipment option selected from CPE DropDown");
    	     }
    	     switchToDefaultcontent();
    	     switchToFrame("extifrmpop");
    	     if(isDisplayed(BTNOK))
    	     {
    	     
    	     pageScroll(BTNOK);
    	     click(BTNOK);
    	     waitForPageToLoad(driver);
    	     waitForLoader();
    	     waitForLoader();
    	     
    	     }
    	     
    	     
    	    }
			//Anu Dhiman 04/20
            if(changetype.equalsIgnoreCase("HSI - Add Technician Visit")){
            	System.out.println("AddTechButton Button is available");
            	
            	waitForLoader();
            	waitForLoader();
            	try{
            	String PSTNTruckRoll = get("PSTN_TruckRoll").trim();
            	
            	switchToWindowWithURL("HSI");
            	            	 
            	 if(isDisplayed(AddTechButton, "", 5)){  
          			clickUsingJavaScript(AddTechButton, objectValue);
          			System.out.println("Add tech Visit Button is clicked");
          			report.reportPass("Click Add Technician Visit Button", "Add Technician Visit Button should be clicked", "Clicking Add Technician Visit Button");
          			waitForLoader();
          			}
         	     
         	     if(PSTNTruckRoll.equalsIgnoreCase("CONSUMER DSL - STANDALONE TRUCKROLL"))
         	     { 
         	    	switchToFrame("extifrmpop");
         	    	
         	    if(isDisplayed(TruckRollDropdown1))
         	     {
         	    	 selectDropDownUsingVisibleText(TruckRollDropdown1, objectValue, PSTNTruckRoll.trim());         	  
         	    
         	    System.out.println("Dropdown value is selected");
         	     report.reportPass("Selct Equipment option from CPE DropDown", "Equipment option should be selected from CPE DropDown ", "Equipment option selected from CPE DropDown");
         	    switchToDefaultcontent();
         	    
         	   switchToFrame("extifrmpop");
         	   if(isDisplayed(BTNOK)){
         	     //clickUsingJavaScript(BTNOK, objectValue);
         		 click(BTNOK);
         	      waitForLoader();
         	   }
         	     
         	     }  
         	
      	     }
         	     
         	 switchToDefaultcontent();
         	 
         	 if(isDisplayed(TechInstall, "", 5))
         	 {
         		
         		clickUsingJavaScript(TechInstall, "");
         		waitForLoader();
         		report.reportPass("Selct Equipment option from CPE DropDown", "Equipment option should be selected from CPE DropDown ", "Equipment option selected from CPE DropDown");
         		
         		 
         	 }
         	     
         	/* switchToDefaultcontent();
         	 clickUsingJavaScript(BTNOK, objectValue);
         	 System.out.println("Save and Continue on HSI Internet page"); */
        	 
            }
         	    catch(Exception exe)
		    	{
		    		exe.printStackTrace();
		    	}
            }

if(changetype.equalsIgnoreCase("StackAddTruckroll"))
	    {
	     
	     switchToDefaultcontent();
	switchToFrame("IfProducts");

	//Updated by poovaraj on 07-Mar-2017
	String baseWindow = driver.getWindowHandle(); 


	     //Updated by poovaraj on 09-Mar-2017 
	switchToWindowWithURL("HSI");
	   //  maximizeBrowserWindow();
	     
	     waitForLoader();
	     
	     switchToDefaultcontent();
	     
	     String PSTNTruckRoll = get("PSTN_TruckRoll").trim();
	     
	     
	     
	     if(isDisplayed(BtnAddTech))
	     {
	     pageScroll(BtnAddTech);
	     report.reportPass("Click on Btn Add Equipment", "Btn Add Equipment should be clicked", "Btn Add Equipment is clicked");
	     clickUsingJavaScript(BtnAddTech, "");
	     waitForLoader();
	     waitForLoader();
	     }
	     
	     switchToDefaultcontent();
	     switchToFrame("extifrmpop");
	     
	     if(isDisplayed(DropdwnStandaoleCPE))
	     {
	     pageScroll(DropdwnStandaoleCPE);
	     report.reportPass("Selct Equipment option from CPE DropDown", "Equipment option should be selected from CPE DropDown ", "Equipment option selected from CPE DropDown");
	     selectDropDownUsingVisibleText(DropdwnStandaoleCPE, "", "CONSUMER DSL - STANDALONE TRUCKROLL");
	     waitForLoader();
	     waitForLoader();
	     report.reportPass("Selct Equipment option from CPE DropDown", "Equipment option should be selected from CPE DropDown ", "Equipment option selected from CPE DropDown");
	     }
	     switchToDefaultcontent();
	     switchToFrame("extifrmpop");
	     if(isDisplayed(BTNOK))
	     {
	     
	     pageScroll(BTNOK);
	     click(BTNOK);
	     waitForPageToLoad(driver);
	     waitForLoader();
	     waitForLoader();
	     
	     }
	     
	     switchToDefaultcontent();
	     
	     if(PSTNTruckRoll.equalsIgnoreCase("Free Full Service Truckroll"))
	     { 


	    if(isDisplayed(TruckRollProduct, "0"))
	     {
	     pageScroll(TruckRollProduct, "0", true);
	     clickUsingJavaScript(TruckRollProduct, "0");
	     report.reportPass("Selct Equipment option from CPE DropDown", "Equipment option should be selected from CPE DropDown ", "Equipment option selected from CPE DropDown");
	     waitForLoader();
	     
	     }
	     }
	     else
	     {
	     if(isDisplayed(TruckRollProduct, "1"))
	     {
	     pageScroll(TruckRollProduct, "1", true);
	     clickUsingJavaScript(TruckRollProduct, "1");
	     report.reportPass("Selct Equipment option from CPE DropDown", "Equipment option should be selected from CPE DropDown ", "Equipment option selected from CPE DropDown");
	     waitForLoader();
	     
	     }
	     }
	     
	     if(isDisplayed(TechInstall,"3"))
	     {
	     pageScroll(TechInstall, "1", true);
	     clickUsingJavaScript(TechInstall, "1");
	     report.reportPass("Selct Tech Install Radion Button", "Tech Install Option Should be Selected ", "Tech Install Option Selected.");
	     waitForLoader();
	     }
	     
	     
	     } 

    	    //For HBONOW
		    if(Streaming.contains("HBO"))
		    {
		    	if(isDisplayed(HBONOW, ""))
		    	{
		    		//mouseOver(HBONOW);
		    		clickUsingJavaScript(HBONOW, objectValue);
		    		waitForLoader();
		    	}
		    }
		   		    
		    
		    if(isDisplayed(rdoModemYes, Modem))
		    {
		    mouseOver(rdoModemYes);
		    clickUsingJavaScript(rdoModemYes, objectValue);
		    waitForLoader();
		    }
		   
		    if(isDisplayed(rdoHSILine, objectValue,2)){
		    mouseOver(rdoHSILine);
		    clickUsingJavaScript(rdoHSILine, objectValue);
		    waitForLoader();
		 
		    }
		    if(isDisplayed(rdoHSILineC2G, objectValue,2)){
		        mouseOver(rdoHSILineC2G);
			    clickUsingJavaScript(rdoHSILineC2G, objectValue);
			    waitForLoader();
		    }
		    
		    if(isDisplayed(InstallationType) && FlowType.equalsIgnoreCase("Install"))
			   {
				   	mouseOver(InstallationType);
				    clickUsingJavaScript(InstallationType, objectValue);
				    pause();
				    waitForLoader();
				    waitForLoader();
				    report.reportPass("Click on Installation Type Radio Button", "Installation Type Radio Button should be clicked", "Installation Type Radio Button is clicked"); 
			   }
              if(isDisplayed(TechInstall, objectValue,2)){
		        pageScroll(TechInstall, changetype, true);
			    clickUsingJavaScript(TechInstall, objectValue);
			    waitForLoader();
		    }
		   
		    if (isDisplayed(btnSaveAndContinueButton,objectValue,2))
		    {
			    mouseOver(btnSaveAndContinueButton);
			    clickUsingJavaScript(btnSaveAndContinueButton, objectValue);
			    pause();
			    waitForLoader();
			    waitForLoader();
			    report.reportPass("Click on Save and Continue Button", "Save and Continue Button should be clicked", "Save and Continue Button is clicked");
		    }
		    if(get("ChangeType").equalsIgnoreCase("ChangeHSIPackage")){
			    switchToWindowWithURL("LCWD2D");
				 clickUsingJavaScript(LecSaveAndCont, objectValue);
				 report.reportPass("Check whether Save And Continue is clicked in LEC Page", "Verify whether Save And Continue is clicked in LEC Page", "Save And Continue is clicked in LEC Page");
				 waitForLoader();
			     waitForLoader();
					
			    }
		    
		    //BBB&E Page
		    if((!isDisplayed(BBEProduct, VASProduct)) && get("Application").equalsIgnoreCase("CoA"))
		    {
		      mouseOver(BBETAB);
		      clickUsingJavaScript(BBETAB, "");
		      waitForLoader();
		      waitForLoader();
		    }
		    if((!isDisplayed(BBEProduct, VASProduct)) && (get("Application").equalsIgnoreCase("C2G")))
		    {
		      mouseOver(BBETABC2G);
		      clickUsingJavaScript(BBETABC2G, "");
		      waitForLoader();
		      waitForLoader();
		    }
		    if(isDisplayed(BBEProduct, VASProduct)){
		    if(VASProduct.isEmpty())
		    {
		    	if(isDisplayed(NOBBEProduct, VASProduct, 2)){
			    	//mouseOver(NOBBEProduct, "");
					clickUsingJavaScript(NOBBEProduct, "");
			    	}
			    	else{
			    		clickUsingJavaScript(NOBBEProduct2, "");
			    	}
				waitForLoader();
		    }
		    else
		    {
		    	mouseOver(BBEProduct, VASProduct);
		    	clickUsingJavaScript(BBEProduct, VASProduct);
		    	waitForLoader();
		    }
		    }
		    if (isDisplayed(btnBBESaveAndContinue,objectValue,2))
		    {
			    mouseOver(btnBBESaveAndContinue);
			    clickUsingJavaScript(btnBBESaveAndContinue, objectValue);
			    pause();
			    waitForLoader();
			    report.reportPass("Click on Save and Continue Button", "Save and Continue Button should be clicked", "Save and Continue Button is clicked");
		    }
		    
    		}  
    	}catch(Exception exe)
    	{
    		exe.printStackTrace();
    	    report.reportFail(strDescription + getUrl, strExpected, strFailed + exe.getCause());
    	    report.updateMainReport("ErrorMessage", strFailed);
    	    throw new UserDefinedException("Failed in Voice Plan ");
    	}
    }	
    
    }

