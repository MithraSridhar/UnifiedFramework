package com.automation.ui.pages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_EquipmentReturn_PageObjects;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;
import com.automation.pageobjects.CommonOR;

/**
 * SimplexDueDatePage class represents the DueDate Info Page and interact with the Page
 * @author Rajagopal
 *
 */
public class SimplexEquipmentReturnPage extends Simplex_EquipmentReturn_PageObjects {

	String objectValue = "";
	static boolean windows = InitiateDriver.windows;
	String description = "", expected = "", actual = "", failure = "", getUrl;
	By by;
	int iterator = 0;
	String testId;

	Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

	/**
	 * SimplexDueDatePage constructor invokes the super class constructor.
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            repesents the testcase id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	@SuppressWarnings("unchecked")
	public SimplexEquipmentReturnPage(WebDriver driver, String testId,
			ReportStatus report, HashMap<String, String> data) throws Exception {
		super(driver, windows, report, data);
		this.testId = testId;
	}

	/**
	 * initialize method used to initialize the page elements for this page and
	 * returns current Page
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            repesents the testcase id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @return returns current page class
	 */
	/**
	 * initialize method used to initialize the page elements for this page and returns current Page
	 * @param driver represents the instance of type WebDriver
	 * @param testId repesents the testcase id
	 * @param report represents the instance of Report Status class
	 * @return returns current page class
	 */
	public static SimplexEquipmentReturnPage initialize(WebDriver driver,
			String testId, ReportStatus report, HashMap<String, String> data) {
		return ElementFactory.initElements(driver, SimplexEquipmentReturnPage.class,
				testId, report, data);
	}


	/**
	 * Navigation start for Simplex Due Date Page
	 * 
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public void start() throws Exception {
		setIterator();

		System.out.println("In EquipmentReturn page:");
		
		verifyEquipmentReturn();
		
		selectEquipmentReturn();

	
	}
	
	 /**
     * Verifies EquipmentReturn  tab is opened or not, if not clicks on it
     * 
     * @author 
     * @throws Exception
     */
    public void verifyEquipmentReturn() throws Exception {

	try {
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");

	    if (isDisplayed(ShippingReturnTab, "", 1)) {
		System.out.println(ShippingReturnTab.getText());
		String classValue = getAttribute(ShippingReturnTab, "", "class");
		if (classValue != null && !classValue.contains("active")) {
		    clickUsingJavaScript(ShippingReturnTab, "");
		    waitForLoader();
		}
	    }

	} catch (Exception e) {
	    report.reportFail("Verify ShippingReturnTab.", "ShippingReturnTab should be displayed.", "ShippingReturnTab is not available");
	    report.updateMainReport("ErrorMessage", "ShippingReturnTab is not available");
	    throw e;
	}

    }

	/**
	 * Navigation to this page
	 * 
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public void navigateTo() throws Exception 
	{
		//To increment the navigation iteration
		int i = TestIterator.getIterator(testId);
		TestIterator.setIterator(testId, ++i);
		//clickUsingJavaScript(dataEquipmentTab, objectValue);
	}

	/**
	 * setDueDateInfo method for providing the Customer's DueDate information in
	 * DueDate Info Page
	 * 
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	/**
	 * 
	 * setEquipmentReturn method for providing the Customer's Equipment Return information in
	 * EquipmentReturn Info Page	 
	 * @throws Exception
	 * @Author: Mounika, Padmini
	 *  throws exception of type Exception
	 */


	public void selectEquipmentReturn() throws Exception, UserDefinedException{
		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		try {
			
			
			try{
				
				
		
				//	if(!get("ReturnType").toLowerCase().contains("skip")&&!get("ReturnType").isEmpty()){
				if(isDisplayed(ShippingReturnTab, strFailed, 10)){
				
						// Give Customer Billing info
						strDescription = "Selecting the Equipemnt return in checkout page";
						strExpected = "Equipment return should be selected sucessfully";
						strActual = "Equipment return was selected sucessfully";
						strFailed = "Equipment return selection was not successful at checkout page";
						getUrl = ", URL Launched --> " + returnURL();

						waitForLoader();
						waitForLoader();
						waitForLoader();
						report.reportPass("Shipping Return Tab should be displayed" + getUrl, "Shipping Return Tab should be displayed", "Shipping Return Tab is dispalyed in checkout page");
						switchToDefaultcontent();
						//Switch Frame
						switchToFrame("IfProducts");


						String return_Type=get("ReturnType");
						String equipmentreturn=get("Equipmentreturn");

						//Getting the text of Equipment return

						//String eqp=getTextFromElement(EquipReturnHeaderText, objectValue);
						String eqp = EquipReturnHeaderText.getText();
						System.out.println(eqp);





						// Select return type

						if(!return_Type.isEmpty())
						{
							try{

								if(isDisplayed(DrpdwnreasonReturnType, eqp, 5)){
								selectDropDownUsingVisibleText(DrpdwnreasonReturnType, objectValue, return_Type);
								}


							}
							catch(Exception exe){
								throw exe;
							}
						}	

						if(equipmentreturn.equals("DropOff"))
						{

							boolean dropoffoption_present = false;
							if (isDisplayed(rdDropOff)) {
								pageScroll(rdDropOff, "", true);

								clickUsingJavaScript(rdDropOff, objectValue);
								report.reportPass("select Equipment drop off option ",
										"Equipment drop off should be selected", "Equipment drop off option is selected");
								dropoffoption_present = true;
							} else if (isDisplayed(rdDropOffC2G)) {
								clickUsingJavaScript(rdDropOffC2G, objectValue);
								report.reportPass("select Equipment drop off option ",
										"Equipment drop off should be selected", "Equipment drop off option is selected");
								dropoffoption_present = true;

							} else {
								report.reportFail("select Equipment drop off option ",
										"Equipment drop off should be selected",
										"Equipment drop off option is not selected");

							}

							if (dropoffoption_present) {

								if (isDisplayed(DropOff_EmailSearch_txtbox)) {

									pageScroll(DropOff_EmailSearch_btn, "", true);
									clearText(DropOff_EmailSearch_txtbox, "");
									setText(DropOff_EmailSearch_txtbox, "", get("Email"));
									report.reportPass("Enter customer email address to send store locations",
											"customer email address should be entered", "customer email address is entered Successfully!");								
									click(DropOff_EmailSearch_btn);
									waitForLoader();
									if (isDisplayed(DropOff_Email_success_msg,"",10)) {
										report.reportPass("send store locations to customer email address",
												"Store locations should be sent Successfully", "Email Sent Successfully!");

									} else {

										report.reportFail("send store locations to customer email address",
												"Store locations should be sent Successfully",
												"Email is not Sent Successfully!");
									}
								}
								else{
									
									report.reportFail("verify option to send store location",
											"option to send store location should be available",
											"option to send store location is not available");
								}
							}

						}
						else if(equipmentreturn.equals("Current"))
						{
							if(isDisplayed(rdCurrentAddress))
							{
							clickUsingJavaScript(rdCurrentAddress, objectValue);
							}

						}			
						else if(equipmentreturn.equals("Service"))
						{
							if(isDisplayed(rdNewServiceAddress))
							{
							clickUsingJavaScript(rdNewServiceAddress, objectValue);
							}

						}
						else if(equipmentreturn.equals("Billing"))
						{
							if(isDisplayed(rdBillingAddress))
							{
							clickUsingJavaScript(rdBillingAddress, objectValue);
							}

						}

						waitForLoader();
						waitForLoader();
			            waitForLoader();

						//Clicking on Save And Continue button
						clickUsingJavaScript(EquipSaveNdContinue, objectValue);
			              waitForLoader();
			              waitForLoader();
			              if(isDisplayed(rdbtnSuggestedAddress, strFailed, 5)){
			            	  clickUsingJavaScript(rdbtnSuggestedAddress, objectValue);
			            	  report.reportPass("Click Suggested Address Radio button if available" + getUrl, "Suggested Address Radio button should be clicked", "Suggested Address Radio button is clicked");
			            	  waitForLoader();
			            	  clickUsingJavaScript(EquipSaveNdContinue, objectValue);
			                  waitForLoader();
			                  waitForLoader();
			                  waitForLoader();
			                  waitForLoader();
			              }
							pause();
							report.reportPass(strDescription + getUrl, strExpected, strActual);
						
					//}	 

				
			}
			}
			catch (Exception exe) {
				System.out.println("Equipement return tab is not present in this flow");

			}
			
			
		} catch (Exception exe) {
			exe.printStackTrace();
			report.reportFail(strDescription + getUrl, strExpected, strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			throw new   UserDefinedException("Failed in Equipment Return Page");
		}

	}
	
	


}
