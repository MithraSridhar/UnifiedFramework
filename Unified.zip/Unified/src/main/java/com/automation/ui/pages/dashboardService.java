package com.automation.ui.pages;

import io.restassured.path.xml.element.NodeChildren;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.MediaType;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import static io.restassured.path.xml.XmlPath.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map; 

import com.automation.ui.pages.logId;

public class dashboardService {
	public static String profileResponse ="";
	public static String vzProfile ="";

	public Map<String, String> myOffersTileDetails(String cogSession,String env) throws ParseException, IOException
	{
		// TODO Auto-generated method stub
		Client client;
		String vzProfile_SERVICE_URL = "http://itotaas.ebiz.verizon.com:8080/ValidationMicroservices-v1.0/getvzfullprofile";
		String getProfileRestURL ="http://optixnte12.ebiz.verizon.com/SimplexMS/web/OrderingGateWaySvc/api/Ordering/GetProfileDisplay";
		client = ClientBuilder.newClient();

		String logInfo = new logId().getLogInfo(cogSession);
		String logID = getLogId(logInfo,"LogId", "CRMM-Bundle-Request");
		String tableSource = getLogId(logInfo,"TableSource", "CRMM-Bundle-Request");
		//System.out.println("RG-Request LogID:"+logID);

	    Responses res = new Responses();
	    String request = res.getResponse1(cogSession, logID, tableSource);
/*	    logID = getLogId(logInfo,"LogId", "GetProfileDisplay-Request & Response");
	    if(!logID.equals(""))
	    {
			tableSource = getLogId(logInfo,"TableSource", "GetProfileDisplay-Request & Response");
			System.out.println("GetProfileDisplay-Request & Response:"+logID);
	
			profileResponse = res.getResponse1(cogSession, logID, tableSource);;
	    }
	    else
	    {
	    	String getProfileRequestXML = "{\"HeaderInfo\":{\"SessionId\":\""+cogSession.trim()+"\",\"TransactionId\":\"SIT-a8e4da1b-dc07-4bf2-b19d-b54234e8cd52\",\"SenderApiName\":\"GetProfileDisplay\",\"UserSessionId\":\"dad2e891-ba96-418c-abd1-5de18beaa611\"},\"isVBMOPOFlow\":\"N\",\"isBGRequest\":true}";
	    	profileResponse=new logId().sendPOST(getProfileRestURL, getProfileRequestXML);
	    }
	    if(profileResponse.contains("Response:"))
			profileResponse = profileResponse.substring(profileResponse.indexOf("Response:")+9,profileResponse.indexOf("\"}"));
		profileResponse = profileResponse.replace("\\\"", "\"").replace("<\\/", "</");

	    System.out.println(profileResponse);
	    Map<String, String> existingProd =	existingProds(request,profileResponse);
	    System.out.println(existingProd);*/
	    
		logID = getLogId(logInfo,"LogId", "CRMM-Bundle-Response-MYOFFERS");
	    tableSource = getLogId(logInfo,"TableSource", "CRMM-Bundle-Response-MYOFFERS");

	    String response = res.getResponse1(cogSession, logID, tableSource);;
	
	    logID = getLogId(logInfo,"LogId", "CRMM-Bundle-Response-Formatted");
	    tableSource = getLogId(logInfo,"TableSource", "CRMM-Bundle-Response-Formatted");

	    String crmmResponse = res.getResponse1(cogSession, logID, tableSource);;
		crmmResponse=crmmResponse.substring(crmmResponse.indexOf("<CRMMQualificationResponse"),crmmResponse.indexOf("\"}")).replace("\\", "");
		
/*		String vision = with(profileResponse).getString("'**'.findAll { it.name() == 'TvAccountNumber' }").replace("0001", "");
		String state = with(profileResponse).getString("'**'.findAll { it.name() == 'State' }[1]");

		vzProfile = client
	 	         .target(vzProfile_SERVICE_URL).queryParam("visionId", vision)
	 	         .queryParam("state", state).queryParam("env", env).request(MediaType.APPLICATION_JSON)
	 	         .get(String.class);
		System.out.println(vzProfile);
		
		vzProfile=vzProfile.substring(vzProfile.indexOf("<getVZFullProfileResponse"),vzProfile.indexOf("getVZFullProfileResponse>")).replace("\\", "")+"getVZFullProfileResponse>";*/

		
		ArrayList<Map<String, ArrayList<Map<String, String>>>> lists=processResp(response, crmmResponse);
	    //System.out.println(lists);
	    
		Map<String, String> result=myoffersTilesInfo(lists);
		if(lists.get(0).size()==0)
			result.put("NoCompassReason",noPropReason(response));
		
		
		return result;
	    
	}


	public Map<String, String> bigRuleResults(String cogSession,String env) throws ParseException
	{
		// TODO Auto-generated method stub
		Client client;
		String vzProfile_SERVICE_URL = "http://itotaas.ebiz.verizon.com:8080/ValidationMicroservices-v1.0/getvzfullprofile";
		client = ClientBuilder.newClient();
		//
		/*String logInfo = client
	 	         .target(REST_LOGINFO_URL).queryParam("cogsession", cogSession)
	 	         .request(MediaType.APPLICATION_JSON).get(String.class);*/
		String logInfo = new logId().getLogInfo(cogSession);
		String logID = getLogId(logInfo,"LogId", "RG-Request");
		String tableSource = getLogId(logInfo,"TableSource", "RG-Request");
		//System.out.println("RG-Request LogID:"+logID);
	    /*String request = client
	 	         .target(REST_SERVICE_URL).queryParam("cogsession", cogSession)
	 	         .queryParam("logID", logID).queryParam("LogType", tableSource).request(MediaType.APPLICATION_JSON)
	 	         .get(String.class);*/

	    Responses res = new Responses();
	    String request = res.getResponse1(cogSession, logID, tableSource);
	    logID = getLogId(logInfo,"LogId", "GetProfileDisplay-Request & Response");
		tableSource = getLogId(logInfo,"TableSource", "GetProfileDisplay-Request & Response");
		//System.out.println("GetProfileDisplay-Request & Response:"+logID);
	    /*profileResponse = client
	 	         .target(REST_SERVICE_URL).queryParam("cogsession", cogSession)
	 	         .queryParam("logID", logID).queryParam("LogType", tableSource).request(MediaType.APPLICATION_JSON)
	 	         .get(String.class);*/
		profileResponse = res.getResponse1(cogSession, logID, tableSource);;
	    if(profileResponse.contains("Response:"))
			profileResponse = profileResponse.substring(profileResponse.indexOf("Response:")+9,profileResponse.indexOf("\"}"));
		profileResponse = profileResponse.replace("\\\"", "\"").replace("<\\/", "</");

/*	    String profileResponse = client.target(vzProfileServiceURL)
	    		 .queryParam("visionId", "4516611410001").queryParam("state", "MA").queryParam("env", "NTE1").request(MediaType.APPLICATION_JSON)
	 	         .get(String.class);*/
	    //System.out.println(profileResponse);
	    Map<String, String> existingProd =	existingProds(request,profileResponse);
	    //System.out.println(existingProd);
	    
		logID = getLogId(logInfo,"LogId", "RG-Response");
	    tableSource = getLogId(logInfo,"TableSource", "RG-Response");
		/*String response = client
	         .target(REST_SERVICE_URL).queryParam("cogsession", cogSession)
	         .queryParam("logID", logID).queryParam("LogType", tableSource).request(MediaType.APPLICATION_JSON)
	         .get(String.class);	*/ 
	    String response = res.getResponse1(cogSession, logID, tableSource);;
	    		
		logID = getLogId(logInfo,"LogId", "CRMM-Bundle-Response");
	    tableSource = getLogId(logInfo,"TableSource", "CRMM-Bundle-Response");
		/*crmmResponse = client
	         .target(REST_SERVICE_URL).queryParam("cogsession", cogSession)
	         .queryParam("logID", logID).queryParam("LogType", tableSource).request(MediaType.APPLICATION_JSON)
	         .get(String.class);	 */
	    String crmmResponse = res.getResponse1(cogSession, logID, tableSource);;
		crmmResponse=crmmResponse.substring(crmmResponse.indexOf("<CRMMQualificationResponse"),crmmResponse.indexOf("\"}")).replace("\\", "");
		
		String vision = with(profileResponse).getString("'**'.findAll { it.name() == 'TvAccountNumber' }").replace("0001", "");
		String state = with(profileResponse).getString("'**'.findAll { it.name() == 'State' }[1]");

		vzProfile = client
	 	         .target(vzProfile_SERVICE_URL).queryParam("visionId", vision)
	 	         .queryParam("state", state).queryParam("env", env).request(MediaType.APPLICATION_JSON)
	 	         .get(String.class);
		//System.out.println(vzProfile);
		
		vzProfile=vzProfile.substring(vzProfile.indexOf("<getVZFullProfileResponse"),vzProfile.indexOf("getVZFullProfileResponse>")).replace("\\", "")+"getVZFullProfileResponse>";

		ArrayList<Map<String, ArrayList<Map<String, String>>>> lists=processResp(response, crmmResponse);
	    //System.out.println(lists);
	    
	    
	    Map<String, String> rulesResult = bigRulesValidation(lists, existingProd, crmmResponse);

	    return rulesResult;
	}

	public HashMap<String, HashMap<String,String>> validateMRCProducts() throws ParserConfigurationException, SAXException, IOException, XPathExpressionException 
	{
		HashMap<String, HashMap<String,String>> serviceMrcProducts=new HashMap<String, HashMap<String,String>>();
		System.out.println(profileResponse);
		if(profileResponse!=null && !("").equals(profileResponse))
		{
			InputStream inputStream = new ByteArrayInputStream(profileResponse.getBytes(Charset.forName("UTF-8")));
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputStream);
			doc.getDocumentElement().normalize();
			XPath xPath = XPathFactory.newInstance().newXPath();
			String expression = "//ExistingServices/ExistingService";
			NodeList nodeList = (NodeList) xPath.compile(expression).evaluate(doc, XPathConstants.NODESET);
			
			if(nodeList!=null&&nodeList.getLength()>0){
				for (int i = 0; i < nodeList.getLength(); i++) {
					Node nNode = nodeList.item(i);
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) nNode;
						if(eElement.getElementsByTagName("ServiceKeyWord").item(0)!=null){
							String serviceKeyWord = eElement.getElementsByTagName("ServiceKeyWord").item(0).getTextContent();
							//System.out.println(serviceKeyWord);
							HashMap<String,String> mrcProducts= new HashMap<String, String>();
							NodeList productsNodeList =eElement.getElementsByTagName("Products");
							if(serviceKeyWord.toLowerCase().contains("lec"))
								mrcProducts = lecproducts(vzProfile);
							if(!serviceKeyWord.toLowerCase().contains("bbe") && ! serviceKeyWord.toLowerCase().contains("lec") )
							if(productsNodeList!=null&&productsNodeList.getLength()>0){
								for (int j = 0; j < productsNodeList.getLength(); j++) {
									Node nProductNode = productsNodeList.item(j);
									if (nProductNode.getNodeType() == Node.ELEMENT_NODE) {
										Element eProductElement = (Element) nNode;
										NodeList existingProductsNodeList =eProductElement.getElementsByTagName("ExistingProducts");
										if(existingProductsNodeList!=null&&existingProductsNodeList.getLength()>0){
											for (int k = 0; k < existingProductsNodeList.getLength(); k++) {
												Node nExistingProductNode = existingProductsNodeList.item(k);
												if (nExistingProductNode.getNodeType() == Node.ELEMENT_NODE) {
													Element eExistingProductElement = (Element) nExistingProductNode;
													String usoc ="";
													String mrc = "";
													String desc = "";
													if(eExistingProductElement.getElementsByTagName("Usoc").item(0)!=null)
														usoc = eExistingProductElement.getElementsByTagName("Usoc").item(0).getTextContent();
													if(eExistingProductElement.getElementsByTagName("Mrc").item(0)!=null)
														mrc = eExistingProductElement.getElementsByTagName("Mrc").item(0).getTextContent();
													if(eExistingProductElement.getElementsByTagName("Description").item(0)!=null)
														desc = eExistingProductElement.getElementsByTagName("Description").item(0).getTextContent();
													
													//System.out.println(usoc+"-"+mrc);
													String productType = "";
													productType = with(vzProfile).getString("'**'.find { it.pcatId == '"+usoc.trim()+"'}.productType");
													if(mrc.equals(""))
														mrc = "$0.0";
													
													if( !(usoc.equals("") || productType.equalsIgnoreCase("FTTPD") || productType.equalsIgnoreCase("BASIC")|| productType.equalsIgnoreCase("FVPRIMARY") || productType.equalsIgnoreCase("DISCOUNT") || desc.contains("Regional Sports Network")))
															mrcProducts.put(usoc+":"+productType, mrc);
												}
											}
										}

									}
								}
							}
							if(!serviceKeyWord.toLowerCase().contains("bbe"))
								serviceMrcProducts.put(serviceKeyWord, mrcProducts);
						}
					}
				}
			}
			
		}
		return serviceMrcProducts;
		
	}
	
	
	private HashMap<String, String> lecproducts(String vzProfile2) {
		 HashMap<String, String> mrcProducts = new HashMap<String, String>();
		 try
		 {
			 if(vzProfile!=null && !("").equals(vzProfile) && vzProfile.contains("productinfolist"))
				{
				 NodeChildren productinfo = with(vzProfile).getNodeChildren("'**'.findAll { it.name() == 'productinfolist' }.productinfo");
				//System.out.println( productinfo.size());
		        for (io.restassured.path.xml.element.Node item : productinfo.nodeIterable()) {
		            final String usoc = item.getAttribute("usoc");
		            final String rc = item.getAttribute("rc").replace(" ", "");
		            if(!usoc.equalsIgnoreCase("PGO8F"))
		            	mrcProducts.put(usoc, rc);
		        }
				}
		 }catch(Exception ex){
			 ex.printStackTrace();
		 }
		 return mrcProducts;
	}

	@SuppressWarnings("unchecked")
	private static Map<String, String> bigRulesValidation(ArrayList<Map<String, ArrayList<Map<String, String>>>> lists, Map<String, String> existingProd, String crmmResponse) {
		
		Map<String, String> rulesResult =new LinkedHashMap<String,String>();
		Map<String, ArrayList<Map<String, String>>> rankCat = lists.get(0);
		HashMap<String,String> tileInfo =new LinkedHashMap<String,String>();
		Map<String, ArrayList<Map<String, String>>> bundleT=lists.get(1);
		HashMap<String,String> offerId =new LinkedHashMap<String,String>();
		Map<String, ArrayList<Map<String, String>>> pccatId=lists.get(2);
		ArrayList<Map<String,String>> linkedArrayList = null;
		ArrayList<Map<String,String>> offerIdArrayList = null;
		String[] bigRules={"B.1","B.2","B.3","B.5","B.14","B.15","B.20","B.21","B.22","B.23","B.24","B.25","B.27","B.28","B.30","B.31","B.32"};
		String propositionPrice ="";
		String result="";
		String tiles="";
		boolean rightSizeDispaly = false ;
		
			for(Map.Entry entry:rankCat.entrySet()){
				String key= (String) entry.getKey();
				tileInfo = (HashMap<String, String>) ((ArrayList) entry.getValue()).get(0);
				offerIdArrayList = pccatId.get(key);
				
				
				//rule 31
				if(linkedArrayList != null )
					if( bundleT .get(key).toString().equals(linkedArrayList.toString()) )
						rulesResult.put("B.31", "two same tiles presented");

				//rule 01,02 , 23,24,25
				rulesResult = bigRulesValidation(key, tileInfo, offerIdArrayList, existingProd, rulesResult);
				
				//rule 27 
				linkedArrayList = bundleT .get(key);
				result = bigRule27(tileInfo, linkedArrayList, existingProd);
				if(!("").equals(result))
				{
					rulesResult.put("B.27", result);
					rulesResult.put("B.26", result);
				}

				//	Rule 22 & Rule 20	    		  
				String val=tileInfo.get("category");	  
				if(val.contains("Me"))
					val = val.replace("Me", "").trim();
	    		  if(("").equals(tiles))
	    			  tiles+=val;
	    		  else
	    			  tiles+= ","+val;
				
				//rule 15
				if(existingProd.get("FlowType").equalsIgnoreCase("PartialDisconnect"))
				{
					if( tileInfo.get("category").equalsIgnoreCase("RightSize") )
					{
						rightSizeDispaly = true;
						if((existingProd.get("DataISOC") !=null || !("").equals(existingProd.get("DataISOC"))) &&(!bundleT.get(key).toString().contains("Data") && !existingProd.get("removedIntent").toString().contains("DATA")))
							result+= "Data,";
						if((existingProd.get("videoIsoc") !=null || !("").equals(existingProd.get("videoIsoc"))) &&(!bundleT.get(key).toString().contains("Video") && !existingProd.get("removedIntent").toString().contains("TV")))
							result+= "Video,";
						if((existingProd.get("voiceIsoc") !=null || !("").equals(existingProd.get("voiceIsoc"))) &&(!bundleT.get(key).toString().contains("Voice") && !existingProd.get("removedIntent").toString().contains("VOICE")))
							result+= "Voice,";

							
					}
				}
				else
					rightSizeDispaly = true;

				//rule 29
				if( tileInfo.get("category").equalsIgnoreCase("retain") )
				{
					String linkedList = bundleT.get(key).toString();
					String existingData = existingProd.get("DataISOC");
					String existingVideo = existingProd.get("videoIsoc");
					String existingVoice = existingProd.get("voiceIsoc");

					if(!(linkedList.contains(existingData) && linkedList.contains(existingVideo) && linkedList.contains(existingVoice)))
						rulesResult.put("B.28", "Not retained the current service package");
				}
				
				if(!existingProd.get("FlowType").equalsIgnoreCase("PartialDisconnect"))
				{
					if(!existingProd.toString().contains("OCO"))
					if(entry.getKey().equals("1"))
					{
						if(tileInfo.get("category").toString().equalsIgnoreCase("renew"))
							propositionPrice = tileInfo.get("propositionPrice").toString();
						else
							rulesResult.put("B.32", "Pega not offered 1st tile as Renew");
					}
					else
					{
						if(tileInfo.get("category").toString().equalsIgnoreCase("rightsize"))
						{
							if(!("").equals(propositionPrice))
							{
								Float diff = Float.valueOf(propositionPrice)-Float.valueOf(tileInfo.get("propositionPrice").toString());
								if(existingProd.get("term").equalsIgnoreCase("M2M") && !(diff < 30.00))
									rulesResult.put("B.32", " Price diff b/w Renew is greater than $30 for M2M Customer");
								else if(!(Float.valueOf(tileInfo.get("propositionPrice").toString()) < Float.valueOf(propositionPrice)))
									rulesResult.put("B.32", "RightSize price is greater than Renew tile Price");
	
							}
						}
					}
					//Rule B.21 
					String linkedList = bundleT.get(key).toString();
					if(existingProd.toString().contains("OCO"))
					if(entry.getKey().equals("1"))
					{
						if( ! tileInfo.get("category").toString().equalsIgnoreCase("renew") || linkedList.toString().contains("OCO"))
						{
							rulesResult.put("B.21", "Pega not offered 1st tile as Renew/ Legacy product offered in 1st tile");
							rulesResult.put("B.30", "Pega not offered 1st tile as Renew/ Legacy product offered in 1st tile");
						}
					}
					if(entry.getKey().equals("2") && !existingProd.get("FlowType").equalsIgnoreCase("PartialDisconnect"))
					{
						if(! tileInfo.get("category").toString().equalsIgnoreCase("renew") && !linkedList.toString().contains("OCO"))
							rulesResult.put("B.21", "Pega not offered 2nd tile as Renew/ Legacy product not offered in 2nd tile");

					}
				}
			}	
			

			//rule B.15
			if( ! rightSizeDispaly)
				rulesResult.put("B.15", "Rightsize is not recommended for PartialDisconnect");
			if(!("").equals(result) )
				rulesResult.put("B.15", result +"Product is removed where intent remove product(s) is "+existingProd.get("removedIntent").toString());
			
			//rule 22 and Rule 20
			//Days Calculation
			String startDate=existingProd.get("bundleStartDate");
			 long days=(long) 0.00F;
			if(startDate.length()>0){
				 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
				 LocalDate secondDate = LocalDate.parse(startDate, formatter);
				 days = ChronoUnit.DAYS.between(secondDate,LocalDate.now());
				}
			if(days > 365 & rankCat.size()>1){
				if(tiles.equalsIgnoreCase("Renew,RightSize,Retain")||tiles.contains("Renew,Renew,Retain")||tiles.contains("RightSize,RightSize,Retain")||tiles.contains("Renew,RightSize,RightSize")||tiles.contains("Renew,Renew,RightSize"))
					System.out.println("there are 3 types of tiles");
				else if(tiles.equalsIgnoreCase("Renew,Renew")||tiles.equalsIgnoreCase("Renew,RightSize")||tiles.equalsIgnoreCase("RightSize,RightSize")||tiles.contains("RightSize,Retain")||tiles.contains("Retain,RightSize")||tiles.contains("Retain,Renew"))
					System.out.println("there are only two types of tiles"); 
				else
				{
					rulesResult.put("B.22", "Ranking Order is not correct");
					rulesResult.put("B.20", "Ranking Order is not correct");
				}
			}
			else
			{
				if( ! tiles.toLowerCase().startsWith("rightsize"))
					rulesResult.put("B.20", "RightSzie is not presented first");
			}
			
			for(String rules:bigRules)
			{
				if(!rulesResult.containsKey(bigRules))
					rulesResult.put(rules, "PASS");
			}
			
		return rulesResult;

	}





	private static Map<String, String> existingProds(String request, String profileResp) throws ParseException {
		Map<String, String> profileInfo = new HashMap<String,String>();
		
		if(!("").equals(request) && request !=null && request.contains("<CRMMQualificationRequest"))
		{
			String pegaRequest=request.substring(request.indexOf("<CRMMQualificationRequest"),request.indexOf("\"}")).replace("\\", "");
			String marketingProfile = with(pegaRequest).get("'**'.findAll { it. name()== 'MarketingProfile' }");
			//profileResp += profileResponse.replace("\\", "").substring(profileResponse.indexOf("<serviceInfo>"),profileResponse.indexOf("</serviceInfo>"))+"</serviceInfo>";
			//profileResp += profileResponse.replace("\\", "").substring(profileResponse.indexOf("<MarketingProfile>"),profileResponse.indexOf("</MarketingProfile>"))+"</MarketingProfile></getVZFullProfileResponse>";

			String FlowType=with(pegaRequest).get("'**'.findAll { it.name() == 'RecommendationIntent' }.@RecommendationFlowType");
			profileInfo.put("FlowType", FlowType);

			
			//Data  
			if(with(pegaRequest).get("'**'.findAll { it.@productType == 'FTTPD' }.@id").toString().length() >2)
			{
				String dataIsoc =  with(pegaRequest).get("'**'.findAll { it.@productType == 'FTTPD' }.@id");
				String dataProd =  with(profileResp.trim()).get("'**'.findAll { it.Usoc == '"+dataIsoc+"' }.Description");
				profileInfo.put("DataISOC", dataIsoc);
				profileInfo.put("dataProd", dataProd);
			}else{
				profileInfo.put("DataISOC", "");
				profileInfo.put("dataProd", "");
			}

			//Video
			//System.out.println(with(pegaRequest).get("'**'.findAll { it.@productType == 'BASIC' }.@id").toString());
			if(with(pegaRequest).get("'**'.findAll { it.@productType == 'BASIC' }.@id").toString().length() >2)
			{
				String videoIsoc =  with(pegaRequest).get("'**'.find{ it.@productType == 'BASIC' }.@id");
				String videoprod =  with(pegaRequest).get("'**'.find{ it.@productType == 'BASIC' }.@productTypeValue");
				profileInfo.put("videoIsoc", videoIsoc);
				profileInfo.put("videoprod", videoprod);
			}else{
				profileInfo.put("videoIsoc", "");
				profileInfo.put("videoprod", "");
			}

			//Voice
			if(with(pegaRequest).get("'**'.findAll { it.@productType == 'FVPRIMARY' }.@id").toString().length() >2)
			{
				String voiceIsoc =  with(pegaRequest).get("'**'.findAll { it.@productType == 'FVPRIMARY' }.@id");
				String voiceProd =  with(pegaRequest).get("'**'.findAll { it.@productType == 'FVPRIMARY' }.@productName");
				profileInfo.put("voiceIsoc", voiceIsoc);
				profileInfo.put("voiceProd", voiceProd);
			}
			else if((pegaRequest).contains("<LECVoice")){
				if(with(pegaRequest).get("'**'.findAll { it.name() == 'LECVoice' }.LineList.Line.Bundle.@id").toString().length() >2){
					String voiceIsoc =  with(pegaRequest).get("'**'.findAll { it.name() == 'LECVoice' }.LineList.Line.Bundle.@id");
					String voiceProd =  "Verizon Freedom Essentials";
					profileInfo.put("voiceIsoc", voiceIsoc);
					profileInfo.put("voiceProd", voiceProd);
				}
			}else{
				profileInfo.put("voiceIsoc", "");
				profileInfo.put("voiceProd", "");
			}

			//Bundle
			if(with(pegaRequest).get("'**'.findAll { it.name() == 'BundleInfo' }.@bundleTypeCodeOnOrder").toString().length() >2)
			{
				String bundleTypeCode=with(pegaRequest).get("'**'.findAll { it.name() == 'BundleInfo' }.@bundleTypeCodeOnOrder");
				profileInfo.put("bundleTypeCode", bundleTypeCode);
			}else
				profileInfo.put("bundleTypeCode", "");
			

			//Term 
			String termprod ="";
			List<String> termIsoc =  with(pegaRequest).get("'**'.findAll { it.@productType=='BQTTERMTRK' }.@id");
			if(termIsoc.size() ==0)
				profileInfo.put("term", "M2M");
			else
				profileInfo.put("term", "TERM");
/*				for(String isoc:termIsoc){
					termprod += with(profileResp.trim()).get("'**'.findAll { it.Usoc == '"+isoc+"' }.Description")+",";
					profileInfo.put("term", termprod);
	
				}*/
			//LeadList
			String leadList=with(marketingProfile).get(("'**'.findAll { it.ParamName == 'PRSPECT_LEAD_LIST_ID' }.ParamValue"));
			profileInfo.put("leadList", leadList);
			
			//BundleeffectiveDate
				String contract=with(profileResp).get("'**'.findAll { it.name() == 'ContractPeriod' }").toString();
				profileInfo.put("bundleStartDate", contract.replace("[", "").substring(0,10));

			//removed intent
			if(!profileInfo.get("FlowType").toString().equalsIgnoreCase("FullDisconnect"))
			{
				String removedIntent = with(pegaRequest).get("'**'.findAll { it.name() == 'RecommendationIntent'}.@SERVICESDISCONNECT");
				profileInfo.put("removedIntent", removedIntent);
			}else{profileInfo.put("removedIntent", "");}
		}
		else
		{
			//System.out.println("empty request");
		}
		return profileInfo;
		
	}

	private static ArrayList<Map<String, ArrayList<Map<String, String>>>> processResp(String response, String crmmResponse) throws ParseException{
		// TODO Auto-generated method stub
		Map<String,ArrayList<Map<String,String>>> rankCat=new LinkedHashMap<String,ArrayList<Map<String,String>>>();
		Map<String,ArrayList<Map<String,String>>> bundleT=new LinkedHashMap<String,ArrayList<Map<String,String>>>();
		Map<String,ArrayList<Map<String,String>>> offerList=new LinkedHashMap<String,ArrayList<Map<String,String>>>();
		Map<String,ArrayList<Map<String,String>>> equipList=new LinkedHashMap<String,ArrayList<Map<String,String>>>();

	      JSONObject responseObj = (JSONObject) new JSONParser().parse(response);
	      JSONObject obj = (JSONObject) new JSONParser().parse((String) responseObj.get("Response"));
	      //System.out.println(obj);
	      JSONObject CRMMQualificationResponse = (JSONObject) obj.get("CRMMQualificationResponse");
	      if(!response.contains("noPropositionReason"))
	      if(CRMMQualificationResponse !=null)
	      {
		        JSONObject Response = (JSONObject) CRMMQualificationResponse.get("Response");
		        if(Response !=null )
		        {
		        	//System.out.println(Response);
				        JSONObject QualifiedSets = (JSONObject) Response.get("QualifiedSets");
				        if(QualifiedSets !=null)
				        {
					        JSONArray QualifiedSet = (JSONArray) QualifiedSets.get("QualifiedSet");
					        for(int i=0; i < QualifiedSet.size(); i++) {
					        
					              JSONObject QualifiedSetInnerObj = (JSONObject) QualifiedSet.get(i);
					              if(QualifiedSetInnerObj.get("qsType").toString().equalsIgnoreCase("Propositions"))
					              {
					            	  JSONObject propositions = (JSONObject) QualifiedSetInnerObj.get("Propositions");	
					            	  JSONArray proposition = (JSONArray) propositions.get("Proposition");	
					                  for(int j=0; j < proposition.size(); j++) {
					                	  //initialize array
					              		ArrayList<Map<String,String>> tileInfoArrayList=new ArrayList<Map<String,String>>();
					            		ArrayList<Map<String,String>> linkedArrayList=new ArrayList<Map<String,String>>();
					            		ArrayList<Map<String,String>> offerIdArrayList=new ArrayList<Map<String,String>>();
					            		ArrayList<Map<String,String>> equipArrayList=new ArrayList<Map<String,String>>();

					                	  JSONObject propositionInnerObj = (JSONObject) proposition.get(j);
					                	  String category = (String) propositionInnerObj.get("category");	
					                	  String rank = (String) propositionInnerObj.get("rank");	
					                	  String totalPrice = (String) propositionInnerObj.get("totalPrice");	
					                	  String propositionPrice = (String) propositionInnerObj.get("PropositionPrice");
					                	  
					              		HashMap<String,String> tileInfo =new HashMap<String,String>();
					                	 tileInfo.put("category",category);
					                	 tileInfo.put("TotalPrice", totalPrice);
					                	 tileInfo.put("propositionPrice",propositionPrice);
						                   JSONObject saProducts = (JSONObject) propositionInnerObj.get("StandaloneProducts"); 
						                   if(saProducts != null)
						                   {
						                   JSONArray saProd = (JSONArray) saProducts.get("StandaloneProduct");
							                   for(int k=0; k < saProd.size(); k++) {
							                	   JSONObject saProdInnerObj = (JSONObject) saProd.get(k);
							                	   String productType=(String)saProdInnerObj.get("productType");
							                	   if(productType.equalsIgnoreCase("FTTPD") || productType.equalsIgnoreCase("BASIC") || productType.equalsIgnoreCase("FVPRIMARY"))
							                	   {
							                			HashMap<String,String> linked =new LinkedHashMap<String,String>();
								                	   String pCatID=(String)saProdInnerObj.get("productId");
								                	   String serviceType=(String)saProdInnerObj.get("serviceType");
								                	   String productKeyword = (String) saProdInnerObj.get("productKeyword");
								                	   String netPrice = (String) saProdInnerObj.get("mrcRateValue");
	
								                	   linked.put("type", "SA");
								                	   linked.put("Product", pCatID);
								                	   linked.put("serviceType", serviceType);
									                   linked.put("netPrice", netPrice);
	
								                	   if(productKeyword.contains("2YEAR"))
										                   tileInfo.put("contractTerm", "24");
								                	   else
										                   tileInfo.put("contractTerm", "-1");
									                   linkedArrayList.add(linked);
							                	   }
							                	   else
							                	   {							                			
							                		   HashMap<String,String> linked =new LinkedHashMap<String,String>();
								                	   String pCatID=(String)saProdInnerObj.get("productId");
								                	   String serviceType=(String)saProdInnerObj.get("serviceType");
								                	   String netPrice = (String) saProdInnerObj.get("mrcRateValue");
								                	   String saProductType = (String) saProdInnerObj.get("productType");
								                	   String productTypeValue = (String) saProdInnerObj.get("productTypeValue");

								                	   linked.put("Product", pCatID);
								                	   linked.put("serviceType", serviceType);
									                   linked.put("netPrice", netPrice);
									                   linked.put("productType", saProductType);
									                   linked.put("productTypeValue", productTypeValue);

									                   equipArrayList.add(linked);
							                	   }
							                   }
						                   }
					                	   
						                   String bundleTypeCode="";
						                   JSONObject bundles = (JSONObject) propositionInnerObj.get("Bundles"); 
						                   if(bundles != null)
						                   {
						                   JSONArray bundle = (JSONArray) bundles.get("Bundle");
						                  for(int k=0; k < bundle.size(); k++) {
						                   JSONObject bundleInnerObj = (JSONObject) bundle.get(k);
						                   bundleTypeCode=(String)bundleInnerObj.get("typeCode");
						                   tileInfo.put("TypeCode", bundleTypeCode);
						                   JSONObject contract = (JSONObject) bundleInnerObj.get("ContractDetails");
						                  if (contract!=null)
						                  {
						                	  JSONArray contractDet = (JSONArray) contract.get("ContractItemDetail");
						                	  for(int m=0; m < contractDet.size(); m++) {
						                		  JSONObject contractInnerObj = (JSONObject) contractDet.get(m);
								                   String contractTerm=(String)contractInnerObj.get("contractTerm");
								                   tileInfo.put("contractTerm", contractTerm);
						                	  } 
						                  }
						                   tileInfoArrayList.add(tileInfo);
						                   rankCat.put(rank,tileInfoArrayList);
						                   JSONObject linkedProducts = (JSONObject) bundleInnerObj.get("LinkedProducts");
						                   if( linkedProducts != null)
						                   {
						                   JSONArray linkedProduct = (JSONArray) linkedProducts.get("LinkedProduct");
						                  
						                   for(int l=0; l<linkedProduct.size(); l++)
						                   {
						               		HashMap<String,String> linked =new LinkedHashMap<String,String>();
						                   JSONObject linkedProductInnerObject = (JSONObject) linkedProduct.get(l);
						                   String serviceType= (String)linkedProductInnerObject.get("serviceType");
						                   String productList= (String)linkedProductInnerObject.get("productIdList");					                   
						                   String productName= (String) linkedProductInnerObject.get("Name");
						                   String netPrice= (String) linkedProductInnerObject.get("netPrice");
	
					                	   linked.put("type", "Bundle");
						                   linked.put("Product",productList);
						                   linked.put("Name", productName);
						                   linked.put("serviceType", serviceType);
						                   linked.put("netPrice", netPrice);
	
						                   linkedArrayList.add(linked);
						                 					             
						                   }
						                   }
						                 
						                   }
						                   }
						                   
						                   //get price 
						                
						                   //get offers details
						                   JSONObject Offers = (JSONObject) propositionInnerObj.get("Offers");
					                       if(Offers != null)
							               {
							                   JSONArray product = (JSONArray)  Offers.get("Product");
							                 
							                  for(int k=0; k < product.size(); k++) {
							                   JSONObject productInnerObj = (JSONObject) product.get(k);
							                   String pcat=(String)productInnerObj.get("PCatID");
							                   String bsOfferCat=(String)productInnerObj.get("BSOfferCategory");
							                   String bsOffer=(String)productInnerObj.get("BSOfferId");
							                   String leadList=(String)productInnerObj.get("LeadListID");
							                   String bsPromoId=(String)productInnerObj.get("BSPromotionId");
							                   String prodDesc=(String)productInnerObj.get("productDescription");					                 
							                   String offerDesc=(String) productInnerObj.get("groupDescription");
							                   String vqePromotionId=(String) productInnerObj.get("vqePromotionId");
							                   String vqePromoGroupId=(String) productInnerObj.get("vqePromoGroupId");
							                   String price=(String) productInnerObj.get("price");
	
							           		   String leadOffer = with(crmmResponse).getString("'**'. findAll { it.@vqePromotionId == '"+vqePromotionId.trim()+"' }.@IsLeadOffer");
							           		   String applicableTerm = with(crmmResponse).getString("'**'. findAll { it.@vqePromotionId == '"+vqePromotionId.trim()+"' }.@applicableTerm");
		
							           			HashMap<String,String> offerId =new LinkedHashMap<String,String>();
		
							                   offerId.put("BSOfferCategory", bsOfferCat);
							                   offerId.put("BSOfferId",bsOffer);
							                   offerId.put("LeadListID", leadList);
							                   offerId.put("BSPromotionId",bsPromoId);
							                   offerId.put("productDescription", prodDesc);
							                   offerId.put("groupDescription",offerDesc);
							                   offerId.put("pcat",pcat);
							                   offerId.put("isLead",leadOffer);
							                   offerId.put("applicableTerm",applicableTerm);
							                   offerId.put("vqePromoGroupId",vqePromoGroupId);
							                   offerId.put("price",price);
	
							                   offerIdArrayList.add(offerId);
							                   
							                  }
							                }
	
							                   bundleT.put(rank,linkedArrayList);   
							                   offerList.put(rank,offerIdArrayList);
							                   equipList.put(rank, equipArrayList);
					                  }
					                  
					              }
					            
					        }
				        }
	
			        
		        }
	      }
		  else
		  {
				System.out.println("No Output from pega");
		  }
	      ArrayList<Map<String,ArrayList<Map<String,String>>>> lists = new ArrayList<Map<String,ArrayList<Map<String,String>>>>();
	      lists.add(rankCat);
	      lists.add(bundleT);
	      lists.add(offerList);
	      lists.add(equipList);
	      return lists;
	}

	public String noPropReason(String response) throws ParseException{

		String noPropositionReason ="";
		      JSONObject responseObj = (JSONObject) new JSONParser().parse(response);
		      JSONObject obj = (JSONObject) new JSONParser().parse((String) responseObj.get("Response"));
		      //System.out.println(obj);
		      JSONObject CRMMQualificationResponse = (JSONObject) obj.get("CRMMQualificationResponse");
		      if(CRMMQualificationResponse !=null)
		      {
			        JSONObject Response = (JSONObject) CRMMQualificationResponse.get("Response");
			        if(Response !=null )
			        {
			        	//System.out.println(Response);
				        JSONObject pegaContextList = (JSONObject) Response.get("PegaContextList");
			        	if(pegaContextList != null)
				        {
					        JSONArray pegaContext = (JSONArray) pegaContextList.get("PegaContext");
					        for(int i=0; i < pegaContext.size(); i++) {
				            	  JSONObject pegaContextInnerObject = (JSONObject) pegaContext.get(i);	 
				            	  noPropositionReason = (String) pegaContextInnerObject.get("noPropositionReason");
					        }
				        }
			        }
		      }
		      return noPropositionReason;
	}
	
	private static String getLogId(String result,String object, String service) throws ParseException
	{
		String logId="";
        JSONArray c = (JSONArray) new JSONParser().parse(result);
	    for (int i = 0; i < c.size(); i++) {
	        JSONObject obj1 = (JSONObject) c.get(i);
	        String shortMessage=(String) obj1.get("ShortMessage");
	        if(shortMessage.contains(service))
	        {
		        logId=(String) obj1.get(object);

	        }
	    }
        return logId;
	}
	
	private static String bigRule27(HashMap<String, String> tileInfo, ArrayList<Map<String, String>> linkedArrayList, Map<String, String> existingProd ) {
		
		String result ="";
		ArrayList<String> DownsizeTVList=new ArrayList<String>();
		DownsizeTVList.add("Ultimate");
		DownsizeTVList.add("Extreme");
		DownsizeTVList.add("Preferred");
		DownsizeTVList.add("Custom");
		DownsizeTVList.add("Local");

		ArrayList<String> Spanish=new ArrayList<String>();
		Spanish.add("Mundo Total");
		Spanish.add("Mundo");
		
		if(tileInfo.get("category").equals("Rightsize")){		
			for( Map<String, String> linkedProduct  : linkedArrayList)
			{
				if(linkedProduct.get("serviceType").equalsIgnoreCase("Video"))
				{
	
					String Tv=linkedProduct.get("Name").toString();	
					String existingTv=existingProd.get("videoprod");	
					if(Tv.toLowerCase().contains(existingTv.toLowerCase())){
						System.out.println("Same product expected");
					}else
					{
						for(int k=0;k<DownsizeTVList.size()-1;k++){
							if(existingTv.toLowerCase().contains(DownsizeTVList.get(k).toLowerCase())){
								if(Tv.contains(DownsizeTVList.get(k+1)))
									System.out.println("DownsizeTVList :"+DownsizeTVList.get(k+1)+" TV: "+Tv);
								else
									result += "Downsize tv is not correct.. ";
							}
						}
			
						for(int p=0;p<Spanish.size()-1;p++){
							if(existingTv.toLowerCase().contains(Spanish.get(p).toLowerCase())){
								if(Tv.contains(Spanish.get(p+1)))
									System.out.println("Spanish :"+Spanish.get(p+1)+" TV: "+Tv);
								else
									result += "Spanish Downsize tv is not correct.. ";
							}
					   }
					}
				}
	
			}
		}
		return result;
	}
	
	private static Map<String, String> bigRulesValidation(String key, HashMap<String, String> tileInfo, ArrayList<Map<String, String>> offerIdArrayList, Map<String, String> existingProd, Map<String, String> rulesResult) {
		int leadCount = 0; 
		String leadPromoGroupid="";
		String prvLeadPromoGroupid="";

		boolean leadListCheck = false ;
		String result23 = "";
		String result02 ="";
		String term = tileInfo.get("contractTerm").toString();
		String existingLeadList = existingProd.get("leadList") .toString(); 
		for(Map<String, String> offerId: offerIdArrayList)
		{
			if(offerId.get("isLead").equalsIgnoreCase("Yes"))
			{
				leadPromoGroupid = offerId.get("vqePromoGroupId").toString();
				if(!("").equals(leadPromoGroupid) && ! leadPromoGroupid.equals(prvLeadPromoGroupid))
					leadCount ++ ;
				
				prvLeadPromoGroupid = leadPromoGroupid;

				if (!("").equals(offerId.get("LeadListID")))
						leadListCheck = true ;
				//Rule B.02
				if ( !term.equals(offerId.get("applicableTerm").toString()))
						result02 = "For "+term+" contract "+offerId.get("applicableTerm").toString()+" lead offer is applied";
				result02 = result02.replace("24", "2 Year").replace("-1", "M2M");
				
				//	B.24					
				if(tileInfo.get("category").toString().equalsIgnoreCase("renew"))
					if(!offerId.get("applicableTerm").toString().equals("24"))
						rulesResult.put("B.24", "For Renew Tile M2M Lead offer is presented");

					

			}		
		}
		
		//B.02 
		if(!("").equals(result02))
			rulesResult.put("B.02", result02);

		//B.01 & B.25
		if(leadCount >1)
		{
			rulesResult.put("B.01", "More than 1 Lead offer is presented...");
			rulesResult.put("B.25", "More than 1 Lead offer is presented...");
		}

		//rule B.23
		if(key.equals(1) && existingLeadList.contains("LC1000") && !leadListCheck)
			result23 += "LeadList Offer is not presented by Pega\n";
		else if(key.equals(1) && !existingLeadList.contains("LC1000") && leadListCheck)
			result23 += "LeadList Offer is presented by Pega where LeadList not set to the account\n";
		else if( !key.equals(1) && leadListCheck)
			result23 += "LeadList Offer is presented by Pega other than Tile 1\n";
	
		if(!("").equals(result23))
			rulesResult.put("B.23", result23);
		
		return rulesResult;
	}

	public HashMap<String, Float> calculateMrc(HashMap<String, HashMap<String, String>> serviceMrcProducts) {
		HashMap<String, Float> serviceMrcPrice=new HashMap<String, Float>();
		DecimalFormat decimalFormat = new DecimalFormat("#.##");
		float equipPrice = 0;
		for(String key:serviceMrcProducts.keySet())
		{
			if(!key.equalsIgnoreCase("BBE"))
			{
				float mrcPrice = 0;
				HashMap<String,String> mrcProdcuts = serviceMrcProducts.get(key);
				for(String mrckey: mrcProdcuts.keySet())
				{
					//System.out.println(key+":"+mrckey+":"+Float.valueOf(mrcProdcuts.get(mrckey).replace("$", "")));
					if(mrckey.toUpperCase().contains("VBUNDLE") || mrckey.toUpperCase().contains("VMRDVR") ||  mrckey.toUpperCase().contains("VFEATURE") || mrckey.toUpperCase().contains("VMOBILITY") || mrckey.toUpperCase().contains("VROOM") || mrckey.toUpperCase().contains("VCP") || mrckey.toUpperCase().contains("EQUIPPACKTV"))
						equipPrice += Float.valueOf(mrcProdcuts.get(mrckey).replace("$", ""));
					else
						mrcPrice+=Float.valueOf(mrcProdcuts.get(mrckey).replace("$", ""));
				}
				serviceMrcPrice.put(key, Float.valueOf(decimalFormat.format(mrcPrice)));
			}
			serviceMrcPrice.put("equip", Float.valueOf(decimalFormat.format(equipPrice)));
		}
		return serviceMrcPrice;
	}

	/*public HashMap<String, Float> compareTotalPricewithMrc(HashMap<String, Float> mrcPrices) {
		Map<String, ArrayList<Map<String, String>>> rankCat = lists.get(0);
		Map<String, ArrayList<Map<String, String>>> bundleT=lists.get(1);
		HashMap<String,String> tileInfo =new LinkedHashMap<String,String>();
		HashMap<String,String> offerId =new LinkedHashMap<String,String>();
		Map<String, ArrayList<Map<String, String>>> pccatId=lists.get(2);
		ArrayList<Map<String, String>> linkedArrayList = null;
		ArrayList<Map<String,String>> offerIdArrayList = null;
		DecimalFormat decimalFormat = new DecimalFormat("#.##");
		HashMap<String, Float> pricDiff = new HashMap<String, Float>();
		float diff=0;
		
		for(Map.Entry entry:rankCat.entrySet()){
			String key= (String) entry.getKey();
			tileInfo = (HashMap<String, String>) ((ArrayList) entry.getValue()).get(0);
			float totalPrice = Float.valueOf(tileInfo.get("TotalPrice"));
			//float totalMrcPrice = Float.valueOf(tileInfo.get("propositionPrice"));
			float totalMrcPrice = 0;
			linkedArrayList = bundleT .get(key);
			offerIdArrayList = pccatId.get(key);
			int data=0;int video =0; int voice = 0;
			for(Map<String, String> products:linkedArrayList)
			{
				if(products.get("serviceType").equals("Data"))
				{
					if (data ==0)
						totalMrcPrice += Float.valueOf(mrcPrices.get("Data"));
					data++;
				}
				else if(products.get("serviceType").equals("Video"))
				{
					if (video ==0)
						totalMrcPrice += Float.valueOf(mrcPrices.get("Video"));
					video ++;
				}
				else 
				{
					if(mrcPrices.containsKey("FDV")& (voice ==0))
						totalMrcPrice += Float.valueOf(mrcPrices.get("FDV"));
					else if(mrcPrices.containsKey("LEC")& (voice ==0))
						totalMrcPrice += Float.valueOf(mrcPrices.get("LEC"));
						
					voice++;
				}
				System.out.println(products.get("netPrice").toString());
				totalMrcPrice += Float.valueOf(products.get("netPrice").toString().replace("$", ""));
			}
			for(Map<String, String> offers:offerIdArrayList)
			{
				if(!offers.get("price").toString().contains(","))
					totalMrcPrice -= Float.valueOf(offers.get("price").toString().replace("$", ""));
				System.out.println(offers.get("price").toString());
			}

			totalMrcPrice += Float.valueOf(mrcPrices.get("equip"));
			
			if( totalMrcPrice != totalPrice)
					diff = totalPrice - totalMrcPrice;

			pricDiff.put(key, Float.valueOf(decimalFormat.format(diff))	);
		}
		return pricDiff;
		
	}
	*/

	public Map<String, String> myoffersTilesInfo(ArrayList<Map<String, ArrayList<Map<String, String>>>> lists) throws JSONException, IOException 
	{
			Map<String, ArrayList<Map<String, String>>> rankCat = lists.get(0);
			Map<String, ArrayList<Map<String, String>>> bundleT=lists.get(1);
			Map<String, ArrayList<Map<String, String>>> offersList=lists.get(2);
			Map<String, ArrayList<Map<String, String>>> equipList=lists.get(3);

			Map<String, String> result =new HashMap<String, String>();
			DecimalFormat decimalFormat = new DecimalFormat("#.##");

			String propPriceComp="";
			result.put("PropisitionCount",""+rankCat.size());
			for(Map.Entry entry:rankCat.entrySet()){
				String key= (String) entry.getKey();
				HashMap<String,String> tileInfo = (HashMap<String, String>) ((ArrayList) entry.getValue()).get(0);
				float propPrice = Float.valueOf(tileInfo.get("propositionPrice"));
				float offerPrice = 0;
				float bundlePrice = 0;
				ArrayList<Map<String, String>> linkedArrayList = bundleT .get(key);
				ArrayList<Map<String,String>> offerIdArrayList = offersList.get(key);
				ArrayList<Map<String,String>> equipArrayList = equipList.get(key);

				String bundleProducts="";
				String offers="";
				String equipments="";
				
				result.put("T"+key.trim()+"_Category",tileInfo.get("category"));
				result.put("T"+key.trim()+"_BundleType",tileInfo.get("TypeCode"));
				result.put("T"+key.trim()+"_TotalPrice",tileInfo.get("TotalPrice"));
				result.put("T"+key.trim()+"_PropositionPrice",tileInfo.get("propositionPrice"));
				for(Map<String, String> offer:offerIdArrayList)
				{
					if(!offer.get("price").toString().contains(","))
						offerPrice += Float.valueOf(offer.get("price").toString().replace("$", ""));
					offers +=offer.get("pcat").toString()+":"+offer.get("BSPromotionId").toString()+":"+offer.get("BSOfferId").toString()+":"+offer.get("productDescription").toString()+":"+ offer.get("LeadListID").toString()+":"+ offer.get("price").toString()+",";
		
				}
				for(Map<String, String> bundleProduct:linkedArrayList)
				{
					if(!bundleProduct.get("netPrice").toString().contains(","))
						bundlePrice += Float.valueOf(bundleProduct.get("netPrice").toString().replace("$", ""));
					bundleProducts +=bundleProduct.get("Product").toString()+":"+bundleProduct.get("Name").toString()+":"+ bundleProduct.get("netPrice").toString()+",";
				}
				for(Map<String, String> equipment:equipArrayList)
				{
					equipments +=equipment.get("Product").toString()+":"+equipment.get("serviceType").toString()+":"+ equipment.get("productType").toString();
					if(!equipment.get("productTypeValue").toString().contains("NA"))
						equipments += ":"+ equipment.get("productTypeValue").toString();
					if(!equipment.get("netPrice").toString().contains("NA"))
						equipments += ":"+ equipment.get("netPrice").toString();
					else
						equipments += ":$0.0";
					equipments+= ",";
				}
				if(!(propPrice == Float.valueOf(decimalFormat.format(bundlePrice - offerPrice))))
					propPriceComp += "Tile"+key+":Not Matching";
				
				result.put("T"+key.trim()+"_BundleProduct",bundleProducts);
				result.put("T"+key.trim()+"_Equipment",equipments);
				result.put("T"+key.trim()+"_Offers",offers);
			}	
			result.put("PropoPriceComp",propPriceComp);
		return result;
	}

}
