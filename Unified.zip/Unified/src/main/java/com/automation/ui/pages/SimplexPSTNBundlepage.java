package com.automation.ui.pages;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_PSTNBundle_PageObjects;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * SimplexProductAndServicesPage class represents the Product & Services and
 * interact with the Page.
 * 
 */
public class SimplexPSTNBundlepage extends Simplex_PSTNBundle_PageObjects {

    String objectValue = "";
    static boolean windows = InitiateDriver.windows;
    int iterator = 0;
    String testId;
    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

    String description = "", expected = "", actual = "", failure = "", getUrl = "";
    By by;

    /**
     * SimplexProductServicesPage constructor invokes the super class
     * constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     */
    public SimplexPSTNBundlepage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, windows, report, data);
	this.testId = testId;
    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     */
    public static SimplexPSTNBundlepage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexPSTNBundlepage.class, testId, report, data);
    }

    public void start() throws Exception {

	setIterator();
	if (get("FlowType").contains("Install") || get("FlowType").contains("Move")|| get("FlowType").contains("Change")) {

	    addBundle();
	} 
	
	if (get("StackDisconnectOption").contains("Move") || get("FlowType").contains("Stack") && get("Application").equalsIgnoreCase("C2G")) {

	    addBundle();
	} 
	//navigateTo();
	
    }
    
    
    public void navigateTo() throws Exception, UserDefinedException {

    	// clickUsingJavaScript on left panel for ProductPage
    	try {
    		int i = TestIterator.getIterator(testId);
    		TestIterator.setIterator(testId, ++i);
    		}catch (Exception e) {
    	
    		e.printStackTrace();
    		throw new UserDefinedException("PSTN Button didn't click");
    	    }
    	}
   
    /**
     * @Description: Select Bundle options
     * @author: Sourish
     * @return:No Return Type
     * @exception: Throws
     *                 Exception
     * @ModifiedBy:Poovaraj
     * @ModifiedDate:14 Mar 2017
     * @Comments:
     */
    
    public void addBundle() throws Exception, UserDefinedException 
    {
    	
    		getUrl = ", URL Launched --> " + returnURL();
    	    
    		pause();
    		//waitForLoader();
    		try 
    		{
    		
    			String VoiceValue = get("VoiceValue").trim();
    			String Internetspeed = get("InternetSpeed").trim();
    			if(get("Application").equalsIgnoreCase("COA")){
    			switchToWindowWithTitle("CoA: New Install");
    			}
    			else if(get("Application").equalsIgnoreCase("C2G")){
    				switchToWindowWithTitle("Co2G: New Install");
    			}
  	     
    			//Standlone Flow	
    			if (VoiceValue.contains("Voice Standalone"))
    			{ 	
    				if(isDisplayed(btnSkipBundle))
    		         {
    	             waitForElementDisplay(btnSkipBundle, objectValue, 15);
    		         clickUsingJavaScript(btnSkipBundle, objectValue);
    		         //waitForLoader();
    		         pause();
    		         report.reportPass("Click on Skip Bundle button" + getUrl, "Skip Bundle button should be clicked", "Skip Bundle button is clicked successfully");
    		         }
	    		
    			}
    			else
    			{
	   	     		//upadted by poovaraj on 14 Mar 2017
	   	     		if(VoiceValue.contains("Freedom"))
	   	     		{
	   	     			
	   	     		try{
	   	     		clickUsingJavaScript(freedomEssentialchkbx, VoiceValue);
   	     			waitForLoader();
   	     			
			   	     		}
			   	     	catch(Exception e)
			   			{
			   	     	String strFailed = "Voice Value "+VoiceValue+ " is not available in Bundle Page";
			    		  report.reportFail("Verify whether Voice Value is clicked", "Verify whether Voice Value is clicked", strFailed);		
			    		report.updateMainReport("comments", strFailed);
			    		report.updateMainReport("ErrorMessage", strFailed);
			    		logger.error(strFailed);
			    		captureErrorMsg(strFailed);
			    		throw new UserDefinedException(strFailed);	
				        }
	   	     		}
	   	     		
	   	     		else 
	   	     		{
	   	     			clickUsingJavaScript(chkRegionalEssentialchkbx, VoiceValue);
	   	     		}
		   	     	if(!Internetspeed.isEmpty())
			        {
		   	     		try{
			        clickUsingJavaScript(internetspeedchkbx, Internetspeed);
		   	     		}
		   	     	catch(Exception e)
		   			{
		   	     	String strFailed = "Internet Speed "+Internetspeed+ " is not available in Bundle Page";
		    		  report.reportFail("Verify whether Internet Speed is clicked", "Verify whether Internet Speed is clicked", strFailed);		
		    		report.updateMainReport("comments", strFailed);
		    		report.updateMainReport("ErrorMessage", strFailed);
		    		logger.error(strFailed);
		    		captureErrorMsg(strFailed);
		    		throw new UserDefinedException(strFailed);	
			        }
			        }
			        else
			        {
			        clickUsingJavaScript(internetspeedallchkbx, objectValue);
			        }
	    		    
	    		  
	    		    clickUsingJavaScript(btnDispbundnOffrs, objectValue);
	    		    waitForLoader();
	    		   
	    		    if(get("Application").equalsIgnoreCase("C2G")){
	    		    	  clickUsingJavaScript(radbtnCoreBundle, objectValue);
	  	    		       waitForLoader();
	  	    		       
	  	    		     clickUsingJavaScript(radbtnCoreBundleLabel, objectValue);
	  	    		       waitForLoader();
	    		    }
	    		    else{
	    		    	 clickUsingJavaScript(radbtnNoContract, objectValue);
	 	    		     waitForLoader();
	    		    }
	    		    
	    		    waitForElementDisplay(btnBundle, objectValue, 15);
	    		    clickUsingJavaScript(btnBundle, objectValue);
	    		  //waitForLoader();
	    		    pause();	    		    
	    		    report.reportPass("Click on Bundle button" + getUrl, "Bundle button should be clicked", "Bundle button is clicked successfully");
    			}
    		}catch (Exception exe)
    		{
    			exe.printStackTrace();
    		    getUrl = ", URL Launched --> " + returnURL();
    		    report.reportFail("Click on Bundle / Skip Button button" + getUrl, "Bundle / Skip Bundle button should be clicked", "Bundle / Skip Bundle button is NOT clicked");
    		    report.updateMainReport("ErrorMessage",  "Bundle / Skip Bundle button is NOT clicked");
    		    throw exe;
        	}    	
    }    
   
}
    
    
    