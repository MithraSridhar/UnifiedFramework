package com.automation.ui.pages;

import java.util.Base64;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_CollectDeposit_PageObjects;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * SimplexDueDatePage class represents the DueDate Info Page and interact with
 * the Page
 * 
 */
public class SimplexCollectDepositPage extends Simplex_CollectDeposit_PageObjects {

    String objectValue = "";
    static boolean windows = InitiateDriver.windows;
    String description = "", expected = "", actual = "", failure = "", getUrl;
    By by;
    String testId;

    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

    /**
     * SimplexDueDatePage constructor invokes the super class constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     *             
     */
    @SuppressWarnings("unchecked")
    public SimplexCollectDepositPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, windows, report, data);
	this.testId = testId;
    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     */
    public static SimplexCollectDepositPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexCollectDepositPage.class, testId, report, data);
    }

    /**
     * Navigation start for Simplex Due Date Page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void start() throws Exception {
    	System.out.println("Collect Deposit Page..");

	setIterator();

	if (get("Application").equalsIgnoreCase("COA") && ( get("FlowType").equalsIgnoreCase("install") || get("FlowType").equalsIgnoreCase("Change"))) {

	    processCollectDeposit();
	} else {
		//For C2G
	    selectcollectDeposit();
	}

    }

    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void navigateTo() throws Exception {

	// To increment the navigation iteration
	int i = TestIterator.getIterator(testId);
	TestIterator.setIterator(testId, ++i);
	// clickUsingJavaScript(dueDateTab, objectValue);
    }

    //For C2G
    public void selectcollectDeposit() throws Exception, UserDefinedException {

    	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
    	try {
    	    // Give Customer Collect Deposit info
    	    strDescription = "Entering customer collectDeposit info details";
    	    strExpected = "Giving customer collectDeposit info in details";
    	    strActual = "Giving Customer collectDeposit details in collectDeposit Info Page was successful";
    	    strFailed = "Giving Customer collectDeposit details in collectDeposit Info Page was not successful";
    	    getUrl = ", URL Launched --> " + returnURL();

    	    
    	    
    	    switchToDefaultcontent();
    	    switchToFrame("IfProducts");
    	    

    	    String CCCardNum = get("CCCardNum").trim();
    	    String CreditCardConfirmNum = get("CreditCardConfirmNum").trim();
    	    String CVV = get("CVV").trim();
    	    String CancelOrderDeposit = get("CancelOrderDeposit").trim();
    	    String cardexpirymonth = get("ExpMonth").trim();
    	    String cardexpiryyear = get("ExpYear").trim();
    	    
    	    String s = "";
    	   
    	    if (isDisplayed(collectDepositTab, "", 3)) {
    		s = getTextFromElement(collectDepositTab, objectValue);
    	    }

    	    System.out.println(s);

    	    if (!CancelOrderDeposit.equalsIgnoreCase("Yes") && s.contains("Collect Deposit")) {
    	    		
    	    	if (isDisplayed(DepositConfirm))
    	    	{
    	    		clickUsingJavaScript(DepositConfirm,objectValue);
    	    		waitForLoader();
    	    		  switchToDefaultcontent();
    	      	    switchToFrame("IfProducts");
    	          //   clickUsingJavaScript(chxconfirm, objectValue);
    	              waitForElementDisplay(btnSaveContinue, "", 15);
    	              clickUsingJavaScript(btnSaveContinue,objectValue);
    	              waitForLoader();
    	              waitForLoader();
    	              waitForLoader();
    	              waitForLoader();
    	              waitForLoader();
    	              pause();
    	              
    	           //   btnSaveContinue.sendKeys(Keys.ENTER);
    	              waitForPageToLoad(driver);
    	              waitForLoader();
    	    		
    	    	}
    	    	else
    	    	{	
    	    	clickUsingJavaScript(collectDepositBtn, objectValue);
    			waitForPageToLoad(driver);
    			if (isDisplayed(OkPopup, "", 3)) {
                    pageScroll(OkPopup, s, true);
                    report.reportPass("Click Ok popup if is displayed", "Ok Popup is clicked", "Ok Popup is clicked");
    				clickUsingJavaScript(OkPopup, objectValue);
    			    }
    		
    			if (isDisplayed(vepsUserID, "", 3)) {

    				enterVepsCredentials();
    			    }
    		

    		switchToFrame("ifrmVPESContent");
    		
    		selectDropDownUsingVisibleText(CreditCardType, objectValue, "AMEX");
            Actions action = new Actions(driver);
            action.moveToElement(driver.findElement(By.xpath("//input[@id='txtPObpInfocovNumber']"))).click().build().perform();
            CreditCardNum.clear();
            action.sendKeys(CCCardNum).perform();
            
            Actions action4 = new Actions(driver);
            action.moveToElement(driver.findElement(By.xpath("//input[@id='txtPObpInfocovCCNumber']"))).click().build().perform();
            CreditCardConNum.clear();
            action4.sendKeys(CreditCardConfirmNum).perform();
            
            report.reportPass("Enter card details.", "Card details should be entered.", "Entered card Details");

            // Enter the Security Code
            
            Actions action1 = new Actions(driver);
            action1.moveToElement(driver.findElement(By.xpath("//input[@id='txtPObpInfocovSecurityCode']"))).click().build().perform();
            CCSecurityCode.clear();
            action1.sendKeys(CVV).perform();
            
            selectDropDownUsingVisibleText(expmonth, objectValue, cardexpirymonth);
            
            Thread.sleep(2000);
            
            selectDropDownUsingVisibleText(expyear, objectValue, cardexpiryyear);

            
            Thread.sleep(1000);
            
            Actions action2 = new Actions(driver);
            action2.moveToElement(driver.findElement(By.xpath("//input[@id='btnPObpInfocovReview']"))).click().build().perform();
            waitForLoader();
          	 waitForLoader();
    	    //}
    	    
    	    switchToDefaultcontent();
    	    switchToFrame("IfProducts");
           clickUsingJavaScript(chxconfirm, objectValue);
            waitForElementDisplay(btnSaveContinue, "", 15);
            btnSaveContinue.sendKeys(Keys.ENTER);
            waitForPageToLoad(driver);
            waitForLoader();
    	    	}
    	    }
       

         report.reportPass(strDescription + getUrl, strExpected, strActual);
         
         switchToDefaultcontent();
         switchToFrame("IfProducts");



         if (CancelOrderDeposit.equalsIgnoreCase("Yes") && s.contains("Collect Deposit")) {

     		clickUsingJavaScript(btnCancelOrder, objectValue);
     		 report.reportPass("Click Cancel Order button", "Cancel Order button should be clicked.", "Clicked Cancel Order button");
     		waitForLoader();
     		waitForLoader();
    		waitForLoader();
    		waitForLoader();
    		report.reportPass(strDescription + getUrl, strExpected, strActual);
    		switchToFrame("PopupIFrame");

         //  clickUsingJavaScript(confirmCancel, objectValue);
  		
     		//report.reportPass("Click Confirm  Cancel Order Popup button", "Confirm  Cancel Order Popup should be clicked.", "Clicked Confirm  Cancel Order Popup");
     			
   	    }
     	   

    	} catch (Exception exe) {
    	    exe.printStackTrace();
    	    report.reportFail(strDescription + getUrl, strExpected, strFailed + exe.getCause());
    	    report.updateMainReport("ErrorMessage", strFailed);
    	    throw new UserDefinedException("Failed in Collect Deposit Page");
    	}

        }


    /***
     * Used for install -- high risk customer.
     * 
     * @throws Exception
     * @throws UserDefinedException
     */

    public void processCollectDeposit() throws Exception, UserDefinedException {

        String strDescription = "", strExpected = "", strActual = "", strFailed = "";
        try {
            // Give Customer Collect Deposit info
            strDescription = "Entering customer collectDeposit info details.";
            strExpected = "Giving customer collectDeposit info in details";
            strActual = "Giving Customer collectDeposit details in collectDeposit Info Page was successful";
            strFailed = "Giving Customer collectDeposit details in collectDeposit Info Page was not successful.";
            getUrl = ", URL Launched --> " + returnURL();

            switchToDefaultcontent();
            switchToFrame("IfProducts");

            String CCCardNum = get("CCCardNum").trim();
          
            String CVV = get("CVV").trim();
            
            String cardexpirymonth = get("ExpMonth").trim();
            
            String cardexpiryyear = get("ExpYear").trim();
        
            String s = "";

            if (isDisplayed(collectDepositTab, "", 0)) {
               s = getTextFromElement(collectDepositTab, objectValue);
            }

            System.out.println(s);

            if (!get("CCCardNum").isEmpty() && s.contains("Collect Deposit")) {

               if (isDisplayed(vepsConfirm, "", 0)) {
                   if (!isSelected(vepsConfirm, ""))
                      clickUsingJavaScript(vepsConfirm, "");
               }
               clickUsingJavaScript(collectDepositBtn, objectValue);
               waitForPageToLoad(driver);

               
               boolean isCardPageDisplayed = tryForCardPage(5);
               if (!isCardPageDisplayed && isDisplayed(vepsUserID)) {

                   throw new UserDefinedException("ERROR: VEPS page is not displayed.. exiting test run...");
               } else {

               }
               switchToDefaultcontent();
               switchToFrame("IfProducts");
               switchToFrame("ifrmVPESContent");
               
              Actions action = new Actions(driver);
               action.moveToElement(driver.findElement(By.xpath("//*[@id = 'pwdCC']"))).click().build().perform();
               cardNo.clear();
               
               action.sendKeys(CCCardNum).perform();
               
               System.out.println();
               // Enter the card number
               
        /*     setText(cardNo, objectValue, CCCardNum);   */
                      
               report.reportPass("Enter card details", "Card details should be entered.", "Entered card: "+CCCardNum);

               // Enter the Security Code
               
               Actions action1 = new Actions(driver);
               action1.moveToElement(driver.findElement(By.xpath("//*[@id = 'txtCVV2']"))).click().build().perform();
               cvv2No.clear();
               action1.sendKeys(CVV).perform();
               System.out.println();

        /*     setText(cvv2No, objectValue, CVV);*/
               
               report.reportPass("Enter CVV details.", "CVV should be entered.", "Entered CVV: "+CVV);

               selectDropDownUsingVisibleText(expiryMonth, "", cardexpirymonth);
               
               Thread.sleep(1000);
               
               selectDropDownUsingVisibleText(expiryYear, "", cardexpiryyear);
                            
               //waitForLoader();
               // clicking on proceed deposit button.
               // clickUsingJavaScript(proceedButton, objectValue);
               //proceedButton.sendKeys(Keys.ENTER);
               
               Actions action2 = new Actions(driver);
               action2.moveToElement(driver.findElement(By.xpath("//*[@id = 'btnProcess']"))).click().build().perform();
               
               try {
                   Thread.sleep(2000);
                   driver.switchTo().alert().accept();
                   Thread.sleep(3000);

               } catch (Exception e) {

               }
               waitForElementDisplay(saveAndContinue, "", 50);
               saveAndContinue.sendKeys(Keys.ENTER);
               try {
                   Thread.sleep(2000);
                   driver.switchTo().alert().accept();
                   Thread.sleep(3000);
               } catch (Exception e) {

               }
               waitForPageToLoad(driver);
               waitForLoader();

            }

            report.reportPass(strDescription + getUrl, strExpected, strActual);
            
            switchToDefaultcontent();
            switchToFrame("IfProducts");

        } catch (Exception exe) {
            exe.printStackTrace();
            report.reportFail(strDescription + getUrl, strExpected, strFailed + exe.getCause());
            report.updateMainReport("ErrorMessage", strFailed);
            throw exe;
        }

     }


    public boolean tryForCardPage(int maxTrials) throws Exception {
    	

	for (int i = 1; i <= maxTrials; i++) {
	    waitForLoader();
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    switchToFrame("ifrmVPESContent");
	    if (isDisplayed(cardNo, "", 0)) {

		return true;
	    }
	    if (isDisplayed(vepsUserID, "", 0)) {

		enterVepsCredentials();
	    } else {

		switchToDefaultcontent();
		switchToFrame("IfProducts");
		msgLinkClickHere.sendKeys(Keys.ENTER);
		try {
		    Thread.sleep(2000);
		    driver.switchTo().alert().accept();
		    Thread.sleep(3000);
		    waitForLoader();
		} catch (Exception e) {

		}
		switchToDefaultcontent();
		switchToFrame("IfProducts");
		waitForPageToLoad(driver);
		if (isDisplayed(vepsConfirm, "", 0)) {
		    if (!isSelected(vepsConfirm, ""))
			clickUsingJavaScript(vepsConfirm, "");
		}

		switchToDefaultcontent();
		switchToFrame("IfProducts");
		collectDepositBtn.sendKeys(Keys.ENTER);
		waitForPageToLoad(driver);

		if (isDisplayed(vepsConfirm, "", 0)) {
		    if (!isSelected(vepsConfirm, ""))
			clickUsingJavaScript(vepsConfirm, "");
		}

	    }

	}
	waitForLoader();
	switchToDefaultcontent();
	switchToFrame("IfProducts");
	switchToFrame("ifrmVPESContent");
	if (isDisplayed(cardNo, "", 3)) {

	    return true;
	} else {
	    return false;
	}

    }

    public void enterVepsCredentials() throws Exception {
    	String psw = get("Password").trim();
    	byte[] decryptedPasswordBytes = Base64.getDecoder().decode(psw);
        String decryptedPassword = new String(decryptedPasswordBytes); 
	setText(vepsUserID, "", get("VepsUserID").trim());
	setText(vepsPwd, "", decryptedPassword);
	report.reportPass("Entere veps credentials.", "Veps credentials should be entered.", "Entered veps credentials.");
	clickUsingJavaScript(vepsLoginBtn, "");

	waitForPageToLoad(driver);
	switchToDefaultcontent();
	switchToFrame("IfProducts");
	switchToFrame("ifrmVPESContent");
    }

}
