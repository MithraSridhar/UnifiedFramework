package com.automation.ui.pages;

import java.util.Base64;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_Login_PageObjects;
import com.automation.support.CustomElementLocator;
import com.automation.support.ElementFactory;
import com.automation.test.order.SimplexCOAInstallDynamic;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * SimplexLoginPage class represents the Login Page and interact with the Page.
 * 
 */
public class SimplexLoginPage extends Simplex_Login_PageObjects {

	String objectValue = "";
	static boolean windows = InitiateDriver.windows;
	int iterator = 0;
	String testId;
	Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

	/**
	 * SimplexLoginPage constructor invokes the super class constructor.
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            represents the test case id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public SimplexLoginPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
		super(driver, windows, report, data);
		this.testId = testId;
	}

	/**
	 * initialize method used to initialize the page elements for this page and
	 * returns current Page
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            repesents the testcase id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @return returns current page class
	 */
	public static SimplexLoginPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

		return ElementFactory.initElements(driver, SimplexLoginPage.class, testId, report, data);
	}

	String description = "", expected = "", actual = "", failure = "", getUrl;
	By by;

	/**
	 * Navigation start for simplex login page
	 * 
	 * @param Url
	 *            represents the page url to be open
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public void start() throws Exception {

		setIterator();

		if(get("GUI_Validations").toString().contains("AccountRetreival")){
			launchWebSite(get("SimplexURL"));
			}else{
			launchWebSite(get("URL"));
			}

	}

	/**
	 * Navigation to this page
	 * 
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public void navigateTo() throws Exception 
	{
		//To increment the navigation iteration
		int i = TestIterator.getIterator(testId);
		TestIterator.setIterator(testId, ++i);

	}

	/**
	 * launchWebSite method used to open the given url
	 * 
	 * @param Url
	 *            represents the page url to be open
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public void launchWebSite(String Url) throws Exception, UserDefinedException {
		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		try {
			
			System.out.println(get("$12-Router Discounts"));

			
			
			//System.out.println(SimplexCOAInstallDynamic.offerinfo.get("$100 Reward card").get("Cart order Description"));

			openWebsite(Url);
			description = "Launching the WebSite";
			expected = "Website to get successfully loaded";
			actual = "Website is successfully loaded";
			getUrl = ", URL Launched --> " + returnURL();
			

			report.reportPass(description + getUrl, expected, actual);
			if(isDisplayed(siteCannotbeReached, strFailed, 2)){
				String err=getTextFromElement(siteCannotbeReached, strFailed);
				System.out.println(err);
				strFailed = "Getting error instaed of login page: "+err;
			    report.reportFail("Login should be Successfull", "Login should be Successfull", strFailed);
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    logger.error(strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);
			}
			if(!get("Username").trim().isEmpty()){
						login(get("Username").trim(), get("Password").trim());
			}
			else{
				strFailed = "Username and password are not Provided in the Run Manager";
			    report.reportFail("Login should be Successfull", "Login should be Successfull", "Login is not successfull as Username & Password are not Provided in the RunManager");
			    report.updateMainReport("comments", "Username and password are not Provided in the Run Manager");
			    report.updateMainReport("ErrorMessage", "Username and password are not Provided in the Run Manager");
			    logger.error(strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);
			}
		} catch (Exception exe) {
			
			exe.printStackTrace();
		    if (!isUserDefinedException(exe)) {
		    	report.reportFail(description + getUrl, expected, "Unable to launch the Browser : " + get("Browser"));
			report.updateMainReport("ErrorMessage", "Unable to launch the Browser : " + get("Browser"));
			captureErrorMsg("Failed in Login page");
		    }

		    throw exe;
		}

	}

	/**
	 * login method is used for login to the Simplex Login Page.
	 * 
	 * @param username
	 *            represents the user login id
	 * @param password
	 *            represents the user login pwd
	 * @throws Exception
	 *             throws exception of type Exception
	 * @author Shiva
	 */
	public void login(String username, String password) throws Exception, UserDefinedException {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "";

		strDescription = "Trying to login to the Page.";
		strExpected = "Login should be successful.";
		strActual = "User is successfully logged in";
		strFailed = "Login is not Successfull";
		getUrl = ", URL Launched --> " + returnURL();
		String encryptpwd= get("Password").toString();
		waitForLoader();
		
		try {

			byte[] decryptedPasswordBytes = Base64.getDecoder().decode(encryptpwd);
	        String decryptedPassword = new String(decryptedPasswordBytes); 
	        
			if (isDisplayed(userID,"",30)) { // For SSO Application.

				setText(userID, "", username);
				report.reportPass("Verizon sign page -- User name", "Enter user name: " + username, "User name is entered.");
				
				//Password encryption
				
                
				setText(password2, "", decryptedPassword);
				report.reportPass("Verizon sign page-- password", "Enter password", "Password entered.");

				if(isDisplayed(logIn, decryptedPassword, 1)){
				clickUsingJavaScript(logIn, "");
				report.reportPass("Verizon sign page-- sign in button.", "Click on sign in button.", "Clicked on sign in button.");
				}

				waitForLoader();
				if(isDisplayed(errorMsg, decryptedPassword, 3)){
					strFailed = "Login is not successfull due to invalid Credentials";
				    report.reportFail("Login should be Successfull", "Login should be Successfull", "Login is not successfull due to invalid Credentials");
				    report.updateMainReport("comments", "Login is not successfull due to invalid Credentials");
				    report.updateMainReport("ErrorMessage", "Login is not successfull due to invalid Credentials");
				    logger.error(strFailed);
				    captureErrorMsg(strFailed);
				    throw new UserDefinedException(strFailed);
				}
				else if(isDisplayed(clearCacheMsg, decryptedPassword, 15)){
					clickUsingJavaScript(clearCacheMsg, "");
					report.reportPass("Click Clear Cache Link if displayed", "Click Clear Cache Link if displayed", "Clear Cache Link is Clicked");	
					if (isDisplayed(userID,"",30)) { // For SSO Application.

						setText(userID, "", username);
						report.reportPass("Verizon sign page -- User name", "Enter user name: " + username, "User name is entered.");
						
						//Password encryption
						
		                
						setText(password2, "", decryptedPassword);
						report.reportPass("Verizon sign page-- password", "Enter password", "Password entered.");

						if(isDisplayed(logIn, decryptedPassword, 1)){
						clickUsingJavaScript(logIn, "");
						report.reportPass("Verizon sign page-- sign in button.", "Click on sign in button.", "Clicked on sign in button.");
						}

					}
				}

			} else { // For old LOgin


				 setText(ebizuserID, "", username);
				 report.reportPass("Verizon sign page -- User name", "Enter user name: " + username, "User name is entered.");
				 
				 
				 setText(ebizpassword, "", decryptedPassword);
				 report.reportPass("Verizon sign page-- password", "Enter password", "Password entered.");
				
				 clickUsingJavaScript(ebizlogIn, "");
				 report.reportPass("Verizon sign page-- sign in button.", "Click on sign in button.", "Clicked on sign in button.");

				 waitForLoader();
				 if(isDisplayed(errorMsg, decryptedPassword, 3)){
						strFailed = "Login is not successfull due to invalid Credentials";
					    report.reportFail("Login should be Successfull", "Login should be Successfull", "Login is not successfull due to invalid Credentials");
					    report.updateMainReport("comments", "Login is not successfull due to invalid Credentials");
					    report.updateMainReport("ErrorMessage", "Login is not successfull due to invalid Credentials");
					    logger.error(strFailed);
					    captureErrorMsg(strFailed);
					    throw new UserDefinedException(strFailed);
					}
					else if(isDisplayed(clearCacheMsg, decryptedPassword, 15)){
						clickUsingJavaScript(clearCacheMsg, "");
						report.reportPass("Click Clear Cache Link if displayed", "Click Clear Cache Link if displayed", "Clear Cache Link is Clicked");	
					}
			}

		} catch (Exception exe) {
			exe.printStackTrace();
		    if (!isUserDefinedException(exe)) {
		    	report.reportFail(description + getUrl, expected, "Unable to launch the Browser : " + get("Browser"));
			report.updateMainReport("ErrorMessage", "Unable to launch the Browser : " + get("Browser"));
			captureErrorMsg("Failed in Login page");
		    }

		    throw exe;
		}
		report.reportPass(strDescription + getUrl, strExpected, strActual);


	}

}
