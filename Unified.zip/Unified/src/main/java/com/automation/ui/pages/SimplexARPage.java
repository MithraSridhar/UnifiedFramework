package com.automation.ui.pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_CallingFrom_PageObjects;
import com.automation.pageobjects.Simplex_AR_PageObjects;
import com.automation.support.Element;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

public class SimplexARPage extends Simplex_AR_PageObjects {

	String objectValue = "";

	static boolean windows = InitiateDriver.windows;
	
	

	String description = "", expected = "", actual = "", failure = "", getUrl;
	By by;
	String testId;
	Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

	/**
	 * SimplexCallingFromPage constructor invokes the super class constructor.
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            Represents the test case id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public SimplexARPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
		super(driver, windows, report, data);
		this.testId = testId;
	}

	/**
	 * initialize method used to initialize the page elements for this page and
	 * returns current Page
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            repesents the testcase id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @return returns current page class
	 */
	public static SimplexARPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

		return ElementFactory.initElements(driver, SimplexARPage.class, testId, report, data);
	}

	/**
	 * Navigation start for Calling From Page
	 * 
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public void start() throws Exception {

		setIterator();

		System.out.println("AR page..");
		if (get("ARvalidation").toString().equalsIgnoreCase("Yes")) {
			setAccountRetrievedValidationNewUI();
		}

	}

	/**
	 * Navigation to this page
	 * 
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public void navigateTo() throws Exception {
		//To increment the navigation iteration
		int i = TestIterator.getIterator(testId);
		TestIterator.setIterator(testId, ++i);
		
	}

	
	
	public void setAccountRetrievedValidationNewUI() throws Exception {

		String BillType="";
		
		
		
		
		
		
		 
		try {

			getUrl = ", URL Launched --> " + returnURL();
			BillType=get("BillType");
			
			// **********************************************Header
			waitForLoader();
			pause();
			
			//Click on Drop down option
			clickUsingJavaScript(DrpdwnMoreopt, objectValue);
			
			
			report.reportPass("Check whether More dropdown clicked", "Should click on More dropdown", "Clicked on More dropdown");
			
			waitForLoader();
			/*waitForLoader();
			
			//Click on Quick links
			//driver.findElement(By.xpath("//a[@class='text-normal ng-scope active-other']")).click();
			//click(lnkquick, objectValue);
			mouseOver(lnkquick, objectValue);
			waitForElementDisplay(lnkquick, objectValue, 60);
			Thread.sleep(1000);
			mouseOver(lnkquick, objectValue);
			Thread.sleep(1000);
			
			//Most Used
			
			if(getAttribute(tabMostused, objectValue, "aria-selected", 30).contains("true"));
			{
				mouseOver(tabMostused);
				report.reportPass("Check whether switched to Mostused Tab", "Should switch to Mostused Tab", "Switched to Mostused tab");
			}
			
			String morelnks = get("MoreLinks");
			String lnks[] = morelnks.split(";");
			
			for(int i=0;i<lnks.length;i++)
			{
				System.out.println(lnks[i]);
				String menuname = lnks[i];
				System.out.println(menuname);
				click(mlnks, menuname);
				
				report.reportPass("Click on a: "+lnks[i], "Should click on: "+lnks[i], "Clicked on a link: "+lnks[i]);
		
				for(String wind : driver.getWindowHandles())
				{
					driver.switchTo().window(wind);
				}
				report.reportPass("Check wheher window is loaded :"+lnks[i], "Should load the window: "+lnks[i], "Window is loaded: "+lnks[i]);
				driver.close();
				
				switchToWindowWithTitle("Optix A/C No: 552-165-853-0001");
				
			}	
			//closing the qicklinks
			
			//Ticket Entry
				
				if(!getAttribute(tabfrequentused, objectValue, "aria-selected", 30).contains("true"));
				{
						waitForElementDisplay(tabfrequentused, objectValue, 30);
						//mouseOver(tabfrequentused);
						mouseclick(tabfrequentused, objectValue);
						report.reportPass("Check whether switched to Mostused Tab", "Should switch to Mostused Tab", "Switched to Mostused tab");
					
					String frkmorelnks = get("TicketEntry");
					String tlnks[] = frkmorelnks.split(";");
								for(int j=0;j<tlnks.length;j++)
								{
									System.out.println(tlnks[j]);
									String Frkmenuname = tlnks[j];
									System.out.println(Frkmenuname);
									click(mlnks, Frkmenuname);
									report.reportPass("Click on a: "+tlnks[j], "Should click on: "+tlnks[j], "Clicked on a link: "+tlnks[j]);
							
											for(String wind : driver.getWindowHandles())
											{
												driver.switchTo().window(wind);
											}
									if (isDisplayed(mlogbook, Frkmenuname, 10))
									{
										clickUsingJavaScript(mlogbookpopup, objectValue);
										switchToWindowWithTitle("Optix A/C No: 552-165-853-0001");
										driver.findElement(By.xpath("//li[@data-moreoption-hover='quickLinks']")).click();
										mouseOver(lnkquick, objectValue);
										waitForElementDisplay(tabfrequentused, objectValue, 30);
										mouseclick(tabfrequentused, objectValue);
										
									}
									report.reportPass("Check wheher window is loaded :"+tlnks[j], "Should load the window: "+tlnks[j], "Window is loaded: "+tlnks[j]);
									driver.close();
									switchToWindowWithTitle("Optix A/C No: 552-165-853-0001");
							}
			}
		
				*/
		/*	//To click on Open how to link
			
				
				for(String wind : driver.getWindowHandles())
				{
					driver.switchTo().window(wind);
				}
				report.reportPass("Check wheher window is loaded :", "Should load the window: ", "Window is loaded: ");
				driver.close();*/
		
				
				
			if(BillType.equalsIgnoreCase("FinalBill")){
				
				try{
				if(FinalAccountindicator.isDisplayed()){
				
					report.reportPass("Check whether final account marker displayed", "final account marker should be displayed", "final account marker is displayed ");
				}
				else{
					
					report.reportFail("Check whether final account marker displayed", "final account marker should be displayed", "final account marker is not displayed ");

				}
				}
				catch(Exception ex){
					report.reportFail("Check whether final account marker displayed", "final account marker should be displayed", "final account marker is not displayed ");

					
				}
			}
			else if(BillType.equalsIgnoreCase("LiveBill")){
				try{
				if(FinalAccountindicator.isDisplayed()){
					
					report.reportFail("Check whether final account marker is not displayed", "final account marker should not be displayed", "final account marker is displayed ");

				}
				else{
					
					report.reportPass("Check whether final account marker is not displayed", "final account marker should not be displayed", "final account marker is not displayed ");

				}
				}
				catch(Exception ex){
					
					report.reportPass("Check whether final account marker is not displayed", "final account marker should not be displayed", "final account marker is not displayed ");

				}
				
				
				
			}
			
			
			//*****Calling Party
			try {
				String StringlabelHeaderCallingParty = labelHeaderCallingPartyNew.getAttribute("value");
				report.reportPass("Verify Calling Party Name", "Calling Party Name should be displayed", "Calling Party Name is "+StringlabelHeaderCallingParty);

			} catch (Exception e) {
				report.reportFail("Verify Calling Party Name", "Calling Party Name should be displayed", "Calling Party Name is not displayed");
				throw new UserDefinedException("Calling Party Name is not displayed");
			}	
			

			if(!BillType.equalsIgnoreCase("FinalBill")){
			try{
			String AccountRetrieval_StringlabelHeaderCustomerName = labelHeaderCustomerNameNew.getAttribute("textContent").trim();
			report.reportPass("Verify Customer Name is loaded", "Customer Name should be loaded", "Customer is -"+AccountRetrieval_StringlabelHeaderCustomerName);
			}
			catch(Exception ex){
			report.reportFail("Verify Customer Name is loaded", "Customer Name should be loaded", "Customer Name is not loaded");
			throw new UserDefinedException("Customer Name is not loaded");
			}
			
			
			try{
			String StringlabelHeaderEmail = labelHeaderEmailNew.getAttribute("innerText");
			report.reportPass("Verify Customer E-mail address is loaded", "Customer E-mail address  should be loaded", "Customer e-mail is -"+StringlabelHeaderEmail);
			}
			catch(Exception ex){
			report.reportFail("Verify Customer E-mail address is loaded", "Customer E-mail address  should be loaded", "Customer e-mail is not loaded ");
			}
			
			
			//Verify Customer Correspondence details
	
			try 
			{
				String StringlabelHeaderAddressLine = labelHeaderAddressLine1New.getAttribute("textContent") + " " + labelHeaderAddressLine2New.getAttribute("textContent");
				report.reportPass("Verify Address","Address should be displayed","Customer Address is "+StringlabelHeaderAddressLine);
				
			} catch (Exception e) 
			{
				report.reportFail("Verify Address","Address should be displayed","Customer Address is not loaded");
				throw new UserDefinedException("Customer Address is not loaded");

			}	
			}
			//Verify Account detail
				//Verify BTN
				try{
					String SimplexBTN = getAttribute(CustomerDetails, "BTN", "innerText").replace("Edit", "").trim();
					report.reportPass("Verify BTN","BTN Should be loaded","BTN is "+SimplexBTN);

					
				}catch(Exception e){
					report.reportFail("Verify BTN","BTN Should be loaded","BTN  is not loaded");
				}
				
				try{
	//Verify Acct
	if(isDisplayed(CustomerDetails, "Acct", 1)){
	String SimplexAcct = getAttribute(CustomerDetails, "Acct", "innerText").replace("-", "");
	report.reportPass("Verify Acccount Number","Acccount Number Should be loaded","Acccount Number is "+SimplexAcct);
	}
	else{
	String SimplexAcct = getAttribute(CustomerDetails, "PCAN", "innerText").replace("-", "");
	report.reportPass("Verify PCAN Number","PCAN Number Should be loaded","PCAN Number is "+SimplexAcct);
	} 


	}catch(Exception e){
	report.reportFail("Verify Acccount Number","Acccount Number Should be loaded","Acccount Number is not loaded");
	if(!BillType.equalsIgnoreCase("FinalBill")){
	throw new UserDefinedException("Acccount Number is not loaded");
	}
	}
				
				
				
				try{
					//Verify Mobile number
					String SimplexMobile = getAttribute(CustomerDetails, "Mobile", "innerText").replace("-", "");
					report.reportPass("Verify Mobile Number","Mobile Number Should be loaded","Mobile Number is "+SimplexMobile);

				}catch(Exception e){
					report.reportFail("Verify Mobile Number","Mobile Number Should be loaded","Mobile Number is not loaded");

				}
				
				try{
					//Verify LOB
					String SimplexLOB = getAttribute(CustomerDetails, "LOB", "innerText");
					report.reportPass("Verify LOB","LOB Should be loaded","LOB is "+SimplexLOB);

				}catch(Exception e){
					report.reportFail("Verify LOB","LOB Should be loaded","LOB is not loaded");
					if(!BillType.equalsIgnoreCase("FinalBill")){
					throw new UserDefinedException("LOB is not loaded");
					}
					
				}
				
				try{
					//Verify SafeGaurd
					String SimplexSafeGaurd = getAttribute(SafeGaurdLabel, objectValue, "innerText").trim();
					report.reportPass("Verify SafeGaurd Flag ","SafeGaurd flag should be loaded", "SafeGaurd flags is "+SimplexSafeGaurd);

					
					
				}catch(Exception e){		
					report.reportFail("Verify SafeGaurd Flag ","SafeGaurd flag should be loaded", "SafeGaurd flags is not loaded");
					throw new UserDefinedException("SafeGaurd flags is not loaded");

				}
			
		
			if(!BillType.equalsIgnoreCase("FinalBill")){
				
			//*****Bundle Type
			try {
				String StringlabelHeaderBundleType = BundleType_Header.getAttribute("innerText").trim();
				report.reportPass("Verify Bundle Type", "Bundle Type Should be displayed", "Bundle Type is "+StringlabelHeaderBundleType);
				
			} catch (Exception e) {
				report.reportFail("Verify Bundle Type", "Bundle Type Should be displayed", "Bundle Type is not loaded" );
				throw new UserDefinedException( "Bundle Type is not loaded" );

			}
			
			//*****Individual Services
			try {
				String StringService = "";
				  HashSet<String> availableService=new HashSet<String>();  
					String AllavailableService = "";

				for(Element service : ExistingServices_List){
					
					if(service.getAttribute("title").contains("BBE")){ StringService = "BBE"; }
					else if(service.getAttribute("title").contains("FDV")){ StringService = "FiOS Digital Voice"; }
					else{ StringService = service.getAttribute("title").toString().trim(); }
				
					availableService.add(StringService);
					
				}
				
				
				for(String service : availableService){

					AllavailableService=AllavailableService+service+",";
				}
				
				
				report.reportPass("Verify Existing Services", "Existing Services should be displayed", "Existing Services are "+AllavailableService);

				
			} catch (Exception e) {
				report.reportFail("Verify Existing Services", "Existing Services should be displayed", "Existing Services is not loaded");

			}
			
			//Verify Contract Term
			VerifyContractLoyaltyYears();
			}
		
	
			String ParentWindow = null;
			
			//*****Chat window
			
			// For temporary Purpose
			//verifyChat();			
			
			//***** Support Info
			verifySupportInfo();
			
			//***** CALL NOTES
			try {
				String HeaderIconString = "Call notes";
				String TestString = "Test";
				String IconString = "More";
				
				/*clickUsingJavaScript(DrpdwnMoreopt, objectValue);
				//driver.findElement(by.xpath("//a[@data-moreoption-hover='quickLinks']")).click();
				System.out.println("test");
				mouseOver(lnkquick, objectValue);
				clickUsingJavaScript(lnkquick, objectValue);
				List<WebElement> ele = driver.findElements(by.xpath("//ul[@class='azlinks']"));
				System.out.println(ele.size());
				for(int i=0;i<ele.size();i++)
				{
					System.out.println(ele.get(i).getText());
					driver.findElement(by.xpath("//a[contains(text(),'Voice Calculator')]")).click();
					switchToWindowWithTitle("CoA: Voice Calculator");
					driver.close();
					switchToDefaultcontent();
			    	switchToFrame("IfProducts");
					
				}*/
				
				clickUsingJavaScript(clickCallNotes, HeaderIconString);
             waitForLoader();
              waitForLoader();
             pause();
				report.reportPass("Verify 'CALL NOTES' icon is available", "" , "As expected");
				setText(TextArea_CallNotesPopUp, objectValue, TestString);
				clickUsingJavaScript(CloseButton_CallNotesPopUp, objectValue);
				
				//Check if entered text is retained in Call notes
				try{
					clickUsingJavaScript(clickCallNotes, HeaderIconString);
                    waitForLoader();
              waitForLoader();
             pause();
					waitForLoader();
					String TextAreaReadCallNotesPopUp=TextAreaRead_CallNotesPopUp.getAttribute("value").trim();
					if(TextAreaReadCallNotesPopUp.trim().contains(TestString)){
						report.reportPass("Verify 'CALL NOTES' retains the entered text", "'CALL NOTES' should have the entered text-"+ TestString, "'CALL NOTES'  have the entered text-"+ TextAreaReadCallNotesPopUp);
					}else{
						report.reportPass("Verify 'CALL NOTES' retains the entered text", "'CALL NOTES' should have the entered text-"+ TestString, "'CALL NOTES'  have the entered text-"+ TextAreaReadCallNotesPopUp);
					}
					clickUsingJavaScript(CloseButton_CallNotesPopUp, objectValue);
				}catch(Exception e){
					clickUsingJavaScript(CloseButton_CallNotesPopUp, objectValue);
					report.reportFail("Verify 'CALL NOTES' retains the etered text", "" , "'CALL NOTES' is not loaded ");
				}
				
			} catch (Exception e) {
				report.reportFail("Verify 'CALL NOTES' ", "", "'CALL NOTES' is not loaded");
			}
			
			// Verify if Follow Ups is opening
			try {
				String HeaderIconString = "Follow ups";
				String TestString = "Test";
				clickUsingJavaScript(OpenFollowUpWindowNew, objectValue);
				waitForLoader();
				// Verify for new window content
				if (isDisplayed(Cancel_FollowUpWindowNew)) {
					report.reportPass("Verify 'Follow Ups' pop up loaded", "", "As expected");
				} else {
					report.reportFail("Verify 'Follow Ups' pop up loaded", "", "Not Loaded");
					report.updateMainReport("ErrorMessage",  "Not Loaded");
				}
				clickUsingJavaScript(Cancel_FollowUpWindowNew, objectValue);
			} catch (Exception e) {
				e.printStackTrace();
				report.reportFail("Verify 'Follow Ups' pop up Opens", "", "'Follow Ups' pop is not loaded");
				report.updateMainReport("ErrorMessage",  "'Follow Ups' pop is not loaded");
			}
			
	
			if(!BillType.equalsIgnoreCase("FinalBill")){
			
			//*****Sales opportunities
					
					try{
						
						List<WebElement> lst= driver.findElements(By.xpath("//div[@ng-if='!salesOpportunity.TitleValue']/child::span"));
	    				for (int i = 0; i < lst.size(); i++) {
	    					System.out.println(lst.size());
	    				    String list1 = lst.get(i).getText();
	    				    System.out.println(list1);
	    				    if (!list1.isEmpty()) {
	    				
	    				    	report.reportPass("Verify sales opportunities", "sales opportunities should be displayed", "sales opportunities displayed are "+list1);
	    				System.out.println(list1);
	    				}
	    				}
					}
					
						
	    				 catch (Exception e) {
								report.reportFail("Verify sales opportunities", "sales opportunities should be displayed", "sales opportunities is not loaded");
								throw new UserDefinedException("sales opportunities is not loaded");
						 }
							
					System.out.println(driver.getTitle());
					System.out.println(driver.getCurrentUrl());
					
					
					
					
					//if(isDisplayed(SalesOpportunitiesFlag, ParentWindow, 2)){
						
						clickUsingJavaScript(SalesOpportunitiesFlag, objectValue);
						
						
						switchToWindowWithURL("salesOpportunities");
						waitForLoader();
						pause();
						report.reportPass("Verify Sales Opportunities Link is Clicked", "Sales Opportunities Link Should be clicked", "Sales Opportunities Link is Clicked");
						if(isDisplayed(ConnectionsPage, objectValue, 15)){
							report.reportPass("Verify Whether Page is loaded on clicking Sales Opportunities Link", "Verify Whether Page is loaded on clicking Connections Link", "Sales Opportunities Page is loaded on clicking Sales Opportunities Link");
						}
						else{
							report.reportFail("Verify Whether Page is loaded on clicking Sales Opportunities Link", "Verify Whether Page is loaded on clicking Sales Opportunities Link", "Sales Opportunities Page is not loaded on clicking Sales Opportunities Link");
							
						}
						System.out.println(driver.getTitle());
					switchToWindowWithURL("FlowType=Change");
					//}
					
					if(isDisplayed(SnapshotIcon, objectValue, 2)){
	                	 clickUsingJavaScript(SnapshotIcon, objectValue);
	                	 report.reportPass("Click Snapshot Icon", "Verify able to click snapshot Icon", "Able to click snapshot Icon");
	                 }
			
			//*****Connections
			/*try {
				
				String StringConnectionsArea = Connections_Area.getAttribute("innerText").trim();
				report.reportPass("Verify Connections Area", "Connections Area should be loaded", "Connections Area is "+StringConnectionsArea);
				} 
			catch (Exception e)
			{
				report.reportFail("Verify Connections", "Connection detail should be loaded", "Connection detail not loaded");
			}
			
				try{
				String StringConnectionsTechInstall = Connections_TechnicianNeed.getAttribute("innerText").trim();
				report.reportPass("Verify ConnectionsTechInstall", "ConnectionsTechInstall should be loaded", "ConnectionsTechInstall is "+StringConnectionsTechInstall);
				}catch (Exception e) {
				}
				
				try{
				String StringConnectionsTechInstallCondition = Connections_TechnicianNeedCondition.getAttribute("innerText").trim();
				report.reportPass("Verify StringConnectionsTechInstallCondition", "StringConnectionsTechInstallCondition should be loaded", "StringConnectionsTechInstallCondition is "+StringConnectionsTechInstallCondition);
				}catch (Exception e) {
				}
				*/
               //  if(isDisplayed(ConnectionsFlag, ParentWindow, 2)){
					
					clickUsingJavaScript(ConnectionsFlag, objectValue);
					
					
					switchToWindowWithURL("connectionsView");
					waitForLoader();
					pause();
					report.reportPass("Verify Connections Link is Clicked", "Connections Link Should be clicked", "Connections Link is Clicked");
					if(isDisplayed(ConnectionsPage, objectValue, 15)){
						report.reportPass("Verify Whether Page is loaded on clicking Connections Link", "Verify Whether Page is loaded on clicking Connections Link", "Connections Page is loaded on clicking Connections Link");
					}
					else{
						report.reportFail("Verify Whether Page is loaded on clicking Connections Link", "Verify Whether Page is loaded on clicking Connections Link", "Connections Page is not loaded on clicking Connections Link");
						
					}
					
					switchToWindowWithURL("FlowType=Change");
					
			//	}
                 if(isDisplayed(SnapshotIcon, objectValue, 2)){
                	 clickUsingJavaScript(SnapshotIcon, objectValue);
                	 report.reportPass("Click Snapshot Icon", "Verify able to click snapshot Icon", "Able to click snapshot Icon");
                 }
               
			
			}
			
			} catch (Exception e) {
			e.printStackTrace();
			report.reportFail( "AR page is not negotiated successfully"+ getUrl,"" , "Negetiation failed due to "+e.toString() + e.getMessage());
			report.updateMainReport("ErrorMessage",  "Negetiation failed due to "+e.toString());
		    report.updateMainReport("comments", "Negetiation failed due to "+e.toString());

			throw e;
		}

	}
	
	
	
	
	public void VerifyContractLoyaltyYears() throws Exception  
	{
		boolean MTMCustomer=false;
		
		
		
		try{
			
			try{
			for(Element CustomerAgreementDetails: CustomerAgreementDetail){
				
				String contractinfo=getAttribute(CustomerAgreementDetails, "", "innerText");
				System.out.println(contractinfo);
				
				if(contractinfo.contains("Month to") || contractinfo.contains("MTM") ){
					
					MTMCustomer=true;
					break;
				}
				
			}
			}
			catch(Exception e){
				
			}
			
			
			System.out.println(MTMCustomer);
			
			
			if(MTMCustomer){
				
				report.reportPass("Verify Customer contract type","Customer should be either MTM/2 year Contract","Customer is MTM customer");

			}
			else {
				
				report.reportPass("Verify Customer contract type","Customer should be either MTM/2 year Contract","Customer is 2 year contracted customer");

			}
			
			//Verify Loyalty Term Duration
		/*	try{
				String SimplexLoyaltyDuration = getAttribute(LoyaltyYears, "", "innerText").replace("(", "").replace(")", "").trim().toString();
				report.reportPass("Verify Loyalty Duration","Loyalty Term Duration should be displayed","Loyalty Term Duration is "+SimplexLoyaltyDuration );

				}catch(Exception e){
					report.reportPass("Verify Loyalty Duration","Loyalty Term Duration should be displayed","Loyalty Term Duration is not displayed due to"+e.toString() );

			}
			*/
			if(!MTMCustomer){
			//Verify Contract
			try{
				String SimplexContract = getAttribute(ContractTerm, "", "innerText").replace("(", "").replace(")", "").trim().toString();
				report.reportPass("Verify Contract Duration","Contract Term Duration should be displayed","Contract Term Duration is "+SimplexContract );

				
			}catch(Exception e){

			}
			}
		}catch(Exception e){
		}
	}
	
	
	
	

	
	private void verifyChat() throws Exception{
		String ParentWindow = null;
		try{
			 clickUsingJavaScript(OpenChatWindowNew, objectValue);
			 pause();
			 pause();
			 pause();
			 ParentWindow = driver.getWindowHandle();
			 System.out.println(driver.getWindowHandles().size());
			 if(driver.getWindowHandles().size()>0){
				
				 for(String w: driver.getWindowHandles()){
					 driver.switchTo().window(w);
					 System.out.println(driver.getTitle());
					 String WindowTitle = driver.getTitle();
					 if(!WindowTitle.contains("Search Account") &&
					 !WindowTitle.contains("Rep Dashboard") &&
					 !WindowTitle.contains("Optix")
					 ){
						 break;
					 }
				 }
			 }
			 try{
				
				 driver.switchTo().frame(0);
				 switchToFrame("chat-window-1");
				 if(isDisplayed(Cancel_ChatWindow,"", 80)){
					 report.reportPass("Verify Chat Window", "Chat Window should be loaded",
					 "Chat Window is loaded");
					 clickUsingJavaScript(Cancel_ChatWindow,objectValue);

				 }else{
					 report.reportFail("Verify Chat Window loaded", "Chat Window should be loaded", "Chat window is not loaded");
				 }
				 driver.close();
				 driver.switchTo().window(ParentWindow);
			 }catch(Exception e){
				 driver.close();
				 driver.switchTo().window(ParentWindow);
			 }	
		}catch(Exception e){
		 report.reportFail("Verify Chat Window Opens", "Chat window is not loaded", "");
		 driver.close();
		 driver.switchTo().window(ParentWindow);
		 }
	}
	
	private void verifySupportInfo() throws Exception{
		try {
			System.out.println();
			String HeaderIconString = "support info";
			clickUsingJavaScript(HeaderIcon_Dynamic, HeaderIconString);
			report.reportPass("Verify 'SUPPORT INFO' icon", "'SUPPORT INFO' icon should be clickable" , "'SUPPORT INFO' icon is clicable and click operation performed");
			if(isDisplayed(SearchTextField_SupportInfoPopUp,objectValue,10)){
				report.reportPass("Verify 'SUPPORT INFO' Pop up", "'SUPPORT INFO' Pop up should be displayed" , "'SUPPORT INFO' Pop up is displayed");
				clickUsingJavaScript(CloseButton_SupportInfoPopUp, objectValue);

			}else{
				report.reportPass("Verify 'SUPPORT INFO' Pop up", "'SUPPORT INFO' Pop up should be displayed" , "'SUPPORT INFO' Pop up is not displayed");
			}
		} catch (Exception e) {
			report.reportFail("Verify 'SUPPORT Options'", "'SUPPORT INFO' icon should be clickable", "'SUPPORT INFO' Pop up is not displayed");
			throw new UserDefinedException("Unable to verify due to "+e.toString());
		}
	}
	
	
	
}
