package com.automation.ui.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.automation.pageobjects.CommonOR;
import com.automation.support.CustomElementLocator;
import com.automation.support.Element;
import com.automation.utilities.ReportStatus;
import com.google.common.base.Function;

public class CommonPage extends CommonOR {

    protected WebDriver driver;
    protected ReportStatus report;
    String testId;
    public static String totalOrderValueWithoutTax, totalOrderValueWithTax;
    String description = "", expected = "", actual = "", failure = "", getUrl;
    Boolean settext = true, list = false, skipfailure = false, mouseclick = false;
    public static HashMap<String, String> globalData = new HashMap<String, String>();
    By by;

    public CommonPage(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, data, report);
	this.driver = driver;
	this.report = report;
	this.testId = data.get("S_No");
	String timeout =get("PageTimeoutInSeconds").trim();
	if(!timeout.isEmpty()){
	    pageTimeoutInSeconds = Integer.parseInt(timeout);
	}
    }

    /**
     * This method will wait till the page Loader to be completed
     * 
     * @param elementValue
     *            represents the element value to identify the element loader
     * @throws InterruptedException
     * @author Shiva Kumar Simharaju
     */

    public synchronized void waitForLoader() throws InterruptedException {

	// int defaultTimeOut = CustomElementLocator.Time;
	try {
	    
	    String angularActive = "active";
	    String classAttribute = "class";
	    String styleAttribute = "style";
	
	    waitForPageToLoad(driver);
	    driver.switchTo().defaultContent();

	    waitForElement(pageOverlayWithoutModel, classAttribute, angularActive);
	    waitForElement(loaderPageOverlay, classAttribute, angularActive);
	    waitForElement(pageOverlayWithoutModel, classAttribute, angularActive);
	    waitForElement(loaderPageOverlay, classAttribute, angularActive);
	    waitForElement(loaderPageOverlay2, classAttribute, angularActive);
	    waitForElement(pleaseWaitLoader3, classAttribute, angularActive);

	    if (isDisplayed(IfProducts, "", 1)) {

		switchToFrame("IfProducts");
		waitForElement(loaderPageOverlay, classAttribute, angularActive);
		waitForElement(vzLoading, classAttribute, "vzloading");
		waitForElement(pleaseWaitLoader, styleAttribute, "block");
		waitForElement(pageLoading2, classAttribute, angularActive);
		waitForElement(pageLoading, classAttribute, angularActive);
		
		
	    }

	    if (isDisplayed(popupIframe, "", 1)) {
		switchToFrame("PopupIFrame");
		waitForElement(loaderPageOverlay, classAttribute, angularActive);
		waitForElement(pleaseWaitLoader2, styleAttribute, "block");
		waitForElement(pageLoading, classAttribute, angularActive);
	  
	    }

	} catch (Exception e) {

	} 
    }

    public synchronized void waitForElement(Element element, String attribuiteName, String waitForString) {

	int timeout = 240;
	try {

	    while (getAttribute(element, "", attribuiteName, 0).contains(waitForString)) {

		if (timeout < 1) {
		    break;
		}
		timeout--;
		Thread.sleep(500);

	    }

	} catch (Exception e) {

	}
    }

    /**
     * WebDriver waits till the full page load within 3 minutes.
     * 
     * @author Shiva Kumar Simharaju
     * @param driver
     * @return
     */
    public void waitForPageToLoad(WebDriver driver) {

	JavascriptExecutor js = (JavascriptExecutor) driver;
	long _timer = 0;
	final long _timeInSeconds = 240;

	while (true) {

	    try {

		if (js.executeScript("return document.readyState").toString().equals("complete")) {

		    break;
		}
		Thread.sleep(500);

	    } catch (Exception e) {
		break;

	    }

	    if (_timer >= _timeInSeconds) {

		System.out.println("Warning: Unable to load full page within " + _timeInSeconds + " seconds.");

		break;
	    }

	    _timer++;
	}

    }

    // ******************** GUI Validation
    // methods*************************************
    public boolean guiValidateVisibility(Element element, String pageName, String fieldName, String strActual, String strFailed) throws Exception {

	String strDescription = "Validate GUI of " + fieldName + " in " + pageName + " page.";
	String strExpected = "Validate " + fieldName;

	if (isDisplayed(element, "", 0)) {

	    if (getAttribute(element, "", "class").contains("active")) {

		report.reportPass(strDescription, strExpected, strActual);
		return true;

	    } else {

		report.reportFail(strDescription, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		return false;
	    }

	} else {

	    report.reportFail(strDescription, strExpected, element + " Element is not available or visible.");
	    report.updateMainReport("ErrorMessage", element + " Element is not available or visible.");
	    return false;

	}

    }

    public boolean guiValidateInVisibility(Element element, String pageName, String fieldName, String strActual, String strFailed) throws Exception {

	String strDescription = "Validate GUI of " + fieldName + " in " + pageName + " page.";
	String strExpected = "Validate " + fieldName;

	if (isDisplayed(element, "", 0)) {

	    if (!getAttribute(element, "", "class").contains("active")) {

		report.reportPass(strDescription, strExpected, strActual);
		return true;

	    } else {

		report.reportFail(strDescription, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		return false;
	    }

	} else {

	    report.reportFail(strDescription, strExpected, element + " Element is not available or visible.");
	    report.updateMainReport("ErrorMessage", element + " Element is not available or visible.");
	    return false;

	}

    }

    public boolean guiValidateAllowsOnlyAlphapet(Element element, String fieldName, String pageName, String inputText, boolean scenarioType) throws Exception {

	String strDescription = "Validate GUI of " + fieldName + " in " + pageName + " page.";
	String strExpected = "Validate " + fieldName;

	if (scenarioType) {

	    setText(element, "", inputText);
	    String insertedText = element.getAttribute("value");
	    if (insertedText.length() > 0 && !inputText.isEmpty()) {

		report.reportPass(strDescription, strExpected, fieldName + " accepting alphabets");
		return true;

	    } else {

		report.reportFail(strDescription, strExpected, fieldName + " not accepting alphabets.");
		report.updateMainReport("ErrorMessage", fieldName + " not accepting alphabets.");
		return false;
	    }

	} else {

	    setText(element, "", inputText);
	    String insertedText = element.getAttribute("value");
	    if (insertedText.length() == 0 && !inputText.isEmpty()) {

		report.reportPass(strDescription, strExpected, fieldName + " not accepting numeric values");
		return true;

	    } else {

		report.reportFail(strDescription, strExpected, fieldName + " accepting numeric values.");
		report.updateMainReport("ErrorMessage", fieldName + " accepting numeric values.");
		return false;
	    }

	}

    }

    public boolean guiValidateAllowsOnlyNumericDigits(Element element, String fieldName, String pageName, String inputText, boolean scenarioType) throws Exception {

	String strDescription = "Validate GUI of " + fieldName + " in " + pageName + " page.";
	String strExpected = "Validate " + fieldName;

	if (scenarioType) {

	    setText(element, "", inputText);
	    String insertedText = element.getAttribute("value");
	    if (insertedText.length() > 0 && !inputText.isEmpty()) {

		report.reportPass(strDescription, strExpected, fieldName + " accepting Numeric");
		return true;

	    } else {

		report.reportFail(strDescription, strExpected, fieldName + " not accepting Numeric.");
		report.updateMainReport("ErrorMessage", fieldName + " not accepting Numeric.");
		return false;
	    }

	} else {

	    setText(element, "", inputText);
	    String insertedText = element.getAttribute("value");
	    if (insertedText.length() == 0 && !inputText.isEmpty()) {

		report.reportPass(strDescription, strExpected, fieldName + " not accpeting Alphabets");
		return true;

	    } else {

		report.reportFail(strDescription, strExpected, fieldName + " accpeting Alphabets.");
		report.updateMainReport("ErrorMessage", fieldName + " accpeting Alphabets.");
		return false;
	    }

	}

    }

    public HashMap<String, String> dataMap = new HashMap<String, String>();


    /**
     * SwitchToWindow method can be used for switching to window based on Title
     * 
     * @param title
     *            represents name of the window
     * @author Shiva Kumar Simharaju
     * 
     */
    public boolean switchToWindowWithTitle(String title) {

	int timeOut = 5;
	while (true) {
	    try {
		if (driver.getWindowHandles().size() > 1) {
		    WebDriver nextWindow = null;
		    Set<String> windowIterator = driver.getWindowHandles();
		    System.out.println("No of windows :  " + windowIterator.size());

		    for (String s : windowIterator) {
			String windowHandle = s;
			System.out.println("Window Id = " + windowHandle);
			nextWindow = driver.switchTo().window(windowHandle);
			System.out.println("Window Title : " + nextWindow.getTitle());
			System.out.println("Window Url : " + nextWindow.getCurrentUrl());
			if (nextWindow.getTitle().contains(title)) {
			    System.out.println("Selected Window Title : " + nextWindow.getTitle());
			    return true;
			}

		    }

		}
		if (timeOut < 1) {
		    return false;
		}

		Thread.sleep(1000);

		timeOut--;
	    } catch (Exception e) {
		timeOut--;
		if (timeOut < 1) {
		    return false;
		}
	    }
	}
    }

    /**
     * SwitchToWindow method can be used for switching to window based on Title
     * 
     * @param title
     *            represents name of the window
     * 
     */
    public boolean switchToWindowWithURL2Param(String strURLContent, String strURLContentnot) {

    	int timeOut = 30;
    	
    	while (true) {
    	    try {
    		if (driver.getWindowHandles().size() > 1) {
    		    WebDriver nextWindow = null;
    		    Set<String> windowIterator = driver.getWindowHandles();
    		    System.out.println("No of windows :  " + windowIterator.size());

    		    for (String s : windowIterator) {
    			String windowHandle = s;
    			System.out.println("Window Id = " + windowHandle);
    			nextWindow = driver.switchTo().window(windowHandle);
    			System.out.println("Window Title : " + nextWindow.getTitle());
    			System.out.println("Window Url : " + nextWindow.getCurrentUrl());
    			if (nextWindow.getCurrentUrl().contains(strURLContent) && !nextWindow.getCurrentUrl().contains(strURLContentnot)) {
    			    System.out.println("Selected Window Title : " + nextWindow.getTitle());
    			    return true;
    			}

    		    }

    		    
    		}
    		if (timeOut < 1) {
    			return false;
    		}

    		Thread.sleep(1000);

    		timeOut--;
    	    } catch (Exception e) {
    		timeOut--;

    		if (timeOut < 1) {
    			return false;
    		}
    	    }
    	}
        }
    
    public boolean switchToWindowWithURL(String strURLContent) {

    	int timeOut = 30;
    	while (true) {
    	    try {
    		if (driver.getWindowHandles().size() > 1) {
    		    WebDriver nextWindow = null;
    		    Set<String> windowIterator = driver.getWindowHandles();
    		    System.out.println("No of windows :  " + windowIterator.size());

    		    for (String s : windowIterator) {
    			String windowHandle = s;
    			System.out.println("Window Id = " + windowHandle);
    			nextWindow = driver.switchTo().window(windowHandle);
    			System.out.println("Window Title : " + nextWindow.getTitle());
    			System.out.println("Window Url : " + nextWindow.getCurrentUrl());
    			if (nextWindow.getCurrentUrl().contains(strURLContent)) {
    			    System.out.println("Selected Window Title : " + nextWindow.getTitle());
    			    return true;
    			}

    		    }

    		    
    		}
    		if (timeOut < 1) {
    			return false;
    		}

    		Thread.sleep(1000);

    		timeOut--;
    	    } catch (Exception e) {
    		timeOut--;

    		if (timeOut < 1) {
    			return false;
    		}
    	    }
    	}
        }
    
    
    public boolean isUserDefinedException(Exception exe) {

	return exe.getClass().getName().contains("UserDefinedException");
    }

    public void captureErrorMsg(String customMessage) throws Exception {

	if (isDisplayed(noMatchFound, "", 0)) {
	    report.reportPass("Capture Error message.", "Error message should be captured.", "Error Message: " + getTextFromElement(noMatchFound, "").trim());
	    report.updateMainReport("comments", customMessage + " App Error Message: " + getTextFromElement(noMatchFound, "").trim());
	}

	if (isDisplayed(noAccountFound, "", 0)) {
	    report.reportPass("Capture Error message.", "Error message should be captured.", "Error Message: " + getTextFromElement(noAccountFound, "").trim());
	    report.updateMainReport("comments", customMessage + " App Error Message: " + getTextFromElement(noAccountFound, "").trim());
	}

	if (isDisplayed(requiredFieldsMissed, "", 0)) {
	    pageScroll(requiredFieldsMissed, "", true);
	    report.reportPass("Capture Error message.", "Error message should be captured.", "Error Message: " + getTextFromElement(requiredFieldsMissed, "").trim());
	    report.updateMainReport("comments", customMessage + " Error Message: " + getTextFromElement(requiredFieldsMissed, "").trim());
	}
	if (isDisplayed(prodPageCommonError, "", 0)) {
	    pageScroll(prodPageCommonError, "", true);
	    report.reportPass("Capture Error message.", "Error message should be captured.", "Error Message: " + getTextFromElement(prodPageCommonError, "").trim());
	    report.updateMainReport("comments", customMessage + " App Error Message: " + getTextFromElement(prodPageCommonError, "").trim());
	}

    }

    public boolean isNotDisplayed(By by, int Time) {

	boolean flag = false;

	try {

	    WebDriverWait wait = new WebDriverWait(driver, Time);

	    flag = wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
	    return flag;
	} catch (Exception e) {
	    return flag;
	}
    }
    
public synchronized   ArrayList<HashMap<String,String>> ReadExcelData(String FileName, String SheetName) throws  IOException, InterruptedException{
    	
    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MMMM-dd");
		ArrayList<HashMap<String,String>> excelDataArray = new ArrayList<HashMap<String,String>>();
		String FilePath = new File(System.getProperty("user.dir")).getAbsolutePath() + "\\Files\\"+FileName.trim();
		System.out.println(FilePath);
		FileInputStream inputStream = new FileInputStream(new File(FilePath));
		Workbook  workbook = new HSSFWorkbook(inputStream);
		Sheet firstSheet=workbook.getSheet(SheetName);
		//Sheet firstSheet = workbook.getSheetAt(0);
	    Iterator<Row> iterator = firstSheet.iterator();
	    int columnCount = firstSheet.getRow(firstSheet.getFirstRowNum()).getLastCellNum();
	    while (iterator.hasNext()) {
			
			Row row = iterator.next();
			HashMap<String, String> excelData = new HashMap<String, String>();
			for (int i=0; i<columnCount;i++){
			
				String cellValue = "";
				try{
					switch (row.getCell(i).getCellType()){
					case Cell.CELL_TYPE_STRING:
						cellValue = row.getCell(i).getStringCellValue();
						break;
					case Cell.CELL_TYPE_NUMERIC:
						if(DateUtil.isCellDateFormatted(row.getCell(i))){
							cellValue = String.valueOf(dateFormat.format(row.getCell(i).getDateCellValue()));
						} /*else {
							if(doubleFlag){
								DecimalFormat formate = new DecimalFormat("#.00");
								double value = row.getCell(i).getNumericCellValue();
								cellValue = String.valueOf(formate.format(value));
							}
							else
								cellValue = String.valueOf((int)row.getCell(i).getNumericCellValue());
							    //System.out.println(cellValue);
						}*/
						break;
					case Cell.CELL_TYPE_BLANK :
						cellValue = "";
						break;
					case Cell.CELL_TYPE_FORMULA:
						switch(row.getCell(i).getCachedFormulaResultType()) {
			            case Cell.CELL_TYPE_NUMERIC:
			            	if(DateUtil.isCellDateFormatted(row.getCell(i))){
			            		cellValue = String.valueOf(dateFormat.format(row.getCell(i).getDateCellValue()));
							} /*else {
				            	if(doubleFlag){
				            		DecimalFormat formate = new DecimalFormat("#.00");
				            		double value = row.getCell(i).getNumericCellValue();
				            		cellValue = String.valueOf(formate.format(value));
				            	}
								else
									cellValue = String.valueOf((int)row.getCell(i).getNumericCellValue());
				                break;
							}*/
			            case Cell.CELL_TYPE_STRING:
			            	cellValue = row.getCell(i).getStringCellValue();
			                break;
						}
					}
				} catch(NullPointerException e){
					cellValue = "";
				}
				String heading = firstSheet.getRow(0).getCell(i).toString();
				excelData.put(heading, cellValue);
				
			}
			
			if(row.getRowNum()!=0 && !excelData.isEmpty())
				excelDataArray.add(excelData);
			
		}

	return excelDataArray;
}


}
