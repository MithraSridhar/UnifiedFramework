package com.automation.ui.pages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_Change_SerivceAddress_PageObjects;
import com.automation.support.CustomElementLocator;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * SimplexLoginPage class represents the Login Page and interact with the Page.
 * 
 */
public class SimplexChangeServiceAddressPage extends Simplex_Change_SerivceAddress_PageObjects {

	String objectValue = "";
	static boolean windows = InitiateDriver.windows;
	int iterator = 0;
	String testId;
	Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

	/**
	 * SimplexLoginPage constructor invokes the super class constructor.
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            repesents the testcase id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public SimplexChangeServiceAddressPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
		super(driver, windows, report, data);
		this.testId = testId;
	}

	/**
	 * initialize method used to initialize the page elements for this page and
	 * returns current Page
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            repesents the testcase id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @return returns current page class
	 */
	public static SimplexChangeServiceAddressPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

		return ElementFactory.initElements(driver, SimplexChangeServiceAddressPage.class, testId, report, data);
	}

	String description = "", expected = "", actual = "", failure = "", getUrl;
	By by;

	/**
	 * Navigation start for simplex login page
	 * 
	 * @param Url
	 *            represents the page url to be open
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public void start() throws Exception {

		setIterator();

		if(get("ChangeType").equalsIgnoreCase("Correct Service Address")){
			
		//Change Service Address provided in Runmanager
		ChangeServiceAddress();
		
		ValidateAddressQualification();
		}
		
	}

	/**
	 * Navigation to this page
	 * 
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public void navigateTo() throws Exception 
	{
		//To increment the navigation iteration
		int i = TestIterator.getIterator(testId);
		TestIterator.setIterator(testId, ++i);

	}

	/**
	 * ChangeServiceAddress method is used for Changing service address.
	 *
	 * @throws Exception
	 *             throws exception of type Exception
	 * @author Praveen Buyankar
	 */
	public void ChangeServiceAddress() throws Exception, UserDefinedException {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		String Field = "";
		strDescription = "Setting new Service address ";
		strExpected = "New service address is entered";
		strActual = "New service address is entered successfuly";
		strFailed = "Unable to Enter new Service Address in field : ";
		getUrl = ", URL Launched --> " + returnURL();

		waitForLoader();

		try {
			String abc="137;;PARTRIDGE;Drive;;;;;;;WSWD;MA;02090";
			String[] address=abc.split(";");
			 
			if(address.length==13){
				//Set House number
				Field = "House Number";
				clearText(HouseNum_Txtbox, objectValue);
				if(!(address[0].isEmpty() || address[0].equals(""))){
					setText(HouseNum_Txtbox, objectValue, address[0]);
				}
				
				
				//Set Street Direction
				Field = "Street Direction";
				selectDropDownUsingIndex(StreetDirection_Drpdwn, objectValue, 0);
				if(!(address[1].isEmpty() || address[1].equals(""))){
					selectDropDownUsingVisibleText(StreetDirection_Drpdwn, objectValue, address[1]);
				}
				
				
				//Set Street Name
				Field = "Street Name";
				clearText(StreetNmae_Txtbox, objectValue);
				if(!(address[2].isEmpty() || address[2].equals(""))){
					setText(StreetNmae_Txtbox, objectValue, address[2]);
				}
				
				
				//Set Street Type
				Field = "Street Type";
				selectDropDownUsingIndex(StreetType_Drpdwn, objectValue, 0);
				if(!(address[3].isEmpty() || address[3].equals(""))){
					selectDropDownUsingVisibleText(StreetType_Drpdwn, objectValue, address[3]);
				}
				
				//Set Directional Suffix
				Field = "Directional Suffix";
				selectDropDownUsingIndex(DirectionalSuffix_Drpdwn, objectValue, 0);
				if(!(address[4].isEmpty() || address[4].equals(""))){
					selectDropDownUsingVisibleText(DirectionalSuffix_Drpdwn, objectValue, address[4]);
				}
				
				//Set Structure
				Field = "Structure";
				selectDropDownUsingIndex(Structure_Drpdwn, objectValue, 0);
				if(!(address[5].isEmpty() || address[5].equals(""))){
					selectDropDownUsingVisibleText(Structure_Drpdwn, objectValue, address[5]);
					clearText(Structure_Txtbox, objectValue);
				}
				
				
				if(!(address[6].isEmpty() || address[6].equals(""))){
				setText(Structure_Txtbox, objectValue, address[6]);
				}
				//Set Floor
				Field = "Floor";
				clearText(Floor_Txtbox, objectValue);
				if(!(address[7].isEmpty() || address[7].equals(""))){
					setText(Floor_Txtbox, objectValue, address[7]);
				}
				
				//Set Unit
				Field = "Unit";
				selectDropDownUsingIndex(Unit_Drpdwn, objectValue, 0);
				if(!(address[8].isEmpty() || address[8].equals(""))){
					selectDropDownUsingVisibleText(Unit_Drpdwn, objectValue, address[8]);
					clearText(Unit_Txtbox, objectValue);
				}
				
				
				if(!(address[9].isEmpty() || address[9].equals(""))){
					setText(Unit_Txtbox, objectValue, address[9]);
				}
				
				//Set City
				Field = "City";
				clearText(City_Txtbox, objectValue);
				if(!(address[10].isEmpty() || address[10].equals(""))){
					setText(City_Txtbox, objectValue, address[10]);
				}
				
				//Set State
				Field = "State";
				if(!(address[11].isEmpty() || address[11].equals(""))){
					selectDropDownUsingVisibleText(State_Drpdwn, objectValue, address[11]);
				}
				
				
				//Set ZipCode
				Field = "ZipCode";
				clearText(Zipcode_Txtbox, objectValue);
				if(!(address[12].isEmpty() || address[12].equals(""))){
					setText(Zipcode_Txtbox, objectValue, address[12]);
				}
				
				report.reportPass(strDescription + getUrl, strExpected, strActual);
				
			}	
			else{
				report.reportFail(strDescription + getUrl, "No of Fields for address colums should be 13", "No of Fields for address columns provided are only "+address.length);
			}

				waitForLoader();
				

		} catch (Exception exe) {
			exe.printStackTrace();
			report.reportFail(strDescription + getUrl, strExpected, strFailed + Field);
			report.updateMainReport("ErrorMessage", strFailed);
			throw exe;
		}
	}
	
	
	/**
	 * ValidateAddressQualification method is used for Changing service address.
	 *
	 * @throws Exception
	 *             throws exception of type Exception
	 * @author Praveen Buyankar
	 */
	public void ValidateAddressQualification() throws Exception, UserDefinedException {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		String Field = "";
		strDescription = "Validate Address Qualification";
		strExpected = "Validate Address Qualification";
		strActual = "Validated Address Qualification Successfully";
		strFailed = "Unable to Validate Address";
		getUrl = ", URL Launched --> " + returnURL();

		waitForLoader();

		try {
			
			//Click on Qualify Address Button
			switchToDefaultcontent();
			switchToFrame("IfProducts");
			clickUsingJavaScript(QualifyAddress_Button, objectValue);
			pause();
			waitForLoader();
			waitForLoader();
			waitForLoader();
			waitForLoader();
			waitForLoader();
			
			
			
			//Verify for any error messages after address qualification
			switchToDefaultcontent();
			switchToFrame("IfProducts");
			if(isDisplayed(Errorsection_Validation, objectValue,15)){
				String errormsg = getTextFromElement(Errorsection_Validation, objectValue);
				if(errormsg.contains("NTAS")){
					report.reportFail(strDescription + getUrl, "Address Entered should be validated", "Enterred Address is not available in NTAS");
					report.updateMainReport("ErrorMessage", strFailed);
					throw new UserDefinedException("Enterred Address is not available in NTAS");
					
				}else if(errormsg.contains("The Service Qualification results for the new address have changed")){
					report.reportFail(strDescription + getUrl, "Address Entered should be validated", "Enterred Address Doesnot match with the Existing services");
					report.updateMainReport("ErrorMessage", strFailed);
					throw new UserDefinedException("Enterred Address Doesnot match with the Existing services");
				}
			}
			
			//Click on Save and Continue
			clickUsingJavaScript(SaveandContinue_Button, objectValue);
			
			//Select New Roommate option if the account has pending accounts
			if(isDisplayed(Newroommate_Radiobtn, objectValue, 45)){
				clickUsingJavaScript(Newroommate_Radiobtn, objectValue);
			}

			

		} catch (Exception exe) {
			exe.printStackTrace();
			report.reportFail(strDescription + getUrl, strExpected, strFailed + Field);
			report.updateMainReport("ErrorMessage", strFailed);
			throw exe;
		}
		


	}

}
