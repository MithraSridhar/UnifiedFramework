package com.automation.ui.pages;

import java.util.HashMap;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_ContactInfo_PageObjects;
import com.automation.support.ElementFactory;
import com.automation.test.order.OfferDataExtraction;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * SimplexContactInfoPage class represents the Contact Info Page and interact
 * with the Page
 * 
 */
public class SimplexContactInfoPage extends Simplex_ContactInfo_PageObjects {

    String objectValue = "";
    static boolean windows = InitiateDriver.windows;
    String description = "", expected = "", actual = "", failure = "", getUrl;
    By by;
    String testId;

    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

    /**
     * SimplexContactInfoPage constructor invokes the super class constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            represents the test case id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     *             
     *             
     */
    public SimplexContactInfoPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, windows, report, data);
	this.testId = testId;
    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     */
    public static SimplexContactInfoPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexContactInfoPage.class, testId, report, data);
    }

    /**
     * Navigation start for Simplex Contact info Page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void start() throws Exception {

	setIterator();

	System.out.println("In contact info page:");
	//FCP update
	if (get("Project_ID").contains("FCP")) {
	validateOfferinViewDetail();
	}
	// To check contact info tab is opened or not.. if not click on it
	verifyContactInfoTab();
	if(get("SubFlowType").equalsIgnoreCase("TVStbpriceup") || get("SubFlowType").equalsIgnoreCase("HNP")|| get("SubFlowType").equalsIgnoreCase("AutoPayTracker") ){
	
	   ValidateViewDetails();
	}

	if (get("CCISaveAndContinue").equalsIgnoreCase("Continue")) {
	    setContactInfo();
	}

    }

    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void navigateTo() throws Exception {

	// To increment the navigation iteration
	int i = TestIterator.getIterator(testId);
	TestIterator.setIterator(testId, ++i);
	clickUsingJavaScript(contactInfoTab, objectValue);
    }

    /**
     * setContactInfo method for providing the Customer's Contact information in
     * Contact Info Page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    protected void setContactInfo() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	try {
	    // Give Customer Billing info
	    strDescription = "Entering customer Contact info details";
	    strExpected = "Giving customer Contact info in details";
	    strActual = "Giving Customer Contact details in Contact Info Page was successful";
	    strFailed = "Giving Customer Contact details in Contact Info Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();
	    int time = 60;

	    waitForLoader();
	    
	    String vasProduct = get("VASProduct").trim();

	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    
	    report.reportPass("Contact Info Page should be displayed", "Contact Info Page should be displayed", "Contact Info Page should is displayed");
	    // Added by Gopal 07/16/2018
	    
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    
	    if(isDisplayed(MasterOrderNumber) && get("Application").equalsIgnoreCase("COA"))
	    {
	    	    	
	    	pageScroll(MasterOrderNumber);
	    	clickUsingJavaScript(MasterOrderNumber, objectValue);
	    	waitForLoader();
	    	waitForLoader();
	    	waitForLoader();
	    	//waitForLoader();
	    	//waitForLoader();
	    	//waitForLoader();	
	    	//waitForLoader();
	    	//waitForLoader();
	    	if(isDisplayed(Viewdetailspopup))
	    	{
	    		String productsWindow = driver.getWindowHandle();
	       	    Set<String> allWindows = driver.getWindowHandles();  	    
	       	    System.out.println(driver.getTitle());
	           	waitForLoader();
	           	try{
	           	switchToDefaultcontent();
	           	 switchToFrame("IfProducts");
	           	 WebElement table=driver.findElement(By.id("ViewDetailsTbl"));
	           	 java.util.List<WebElement> rows=table.findElements(By.tagName("tr"));
	           	 
	           	 int count = TypesofProductsList.size();
	           	 
	           	 for(int i =0; i<count; i++)
	           	 {
	           		  String j = String.valueOf(i);
	           		  pageScroll(ProductDetails, j, true);
	           		  report.reportPass("Display Bundle Components in Checkout Page","Display Bundle Components in Checkout Page", "Bundle Components in Checkout Page are: ");
	           		  waitForPageToLoad(driver);
	           	 }
          	 
	           	 
	           	 //Prakash -- Validation of Suspended ISOC's - Begin
	           	 
	           	 WebElement table1=driver.findElement(By.id("ctl00_Panel20"));
    	    	 java.util.List<WebElement> rows1=table.findElements(By.tagName("tr"));
    	    	 
    	    	 String data1=rows.get(0).getText();
    	    	
    	    	 System.out.println("Row : " +rows.size());
    	    	 if (rows.size() > 0)
    	    	 {
    	    		 report.reportPass("Cart View Details", "There are " +rows.size()+ "product details displayed", "There are product details displayed");
    	    		 report.reportPass("Cart View Details", "The details displayed ", data1);
    	    	 }
    	    	// System.out.println("Row : " +data1);
    	    	 
    	    	 
    	    	 String[] words=data1.split("\\n");
	           	  int ctr1=0;
    	    	 for(String w:words){  
    	    		 System.out.println(w);
    	    		// waitForLoader();
    	    		 
    	    		 ctr1=ctr1+1;
    	    		if (w.contains("H9508"))
    	    		{    	
    	    			report.reportPass("Cart View Details", " Video Suspension Tracker H9508 displayed"," Video Suspension Tracker H9508 Displayed"); 
    	    		}
    	    		else if (w.contains("H9183"))
    	    		{    	
    	    			report.reportPass("Cart View Details", " Fios Data Suspension Tracker H9183  displayed"," Fios Data Suspension Tracker H9183  Displayed"); 
    	    		} 
    	    		else if (w.contains("H9162"))
    	    		{    	
    	    			report.reportPass("Cart View Details", " FDV Suspension Tracker H9162   displayed"," FDV Suspension Tracker H9162  Displayed"); 
    	    		}
    	    		 
    	    	 }
    	    	 
	           	 
	           	 /////Prakash -- Validation of Suspended ISOC's - End
	           	 if(isDisplayed(BBESection) && !vasProduct.isEmpty())
	           	 {
	           		 pageScroll(BBESection);
	           		 
	           		 if(vasProduct.contains(";")){
		           		  String[] vasProds = vasProduct.split(";");
		           		  System.out.println(vasProds);
		           		for (int i = 0; i < vasProds.length; i++){
		           			
		           		 int NoofBBEProd= NoOfBBEProducts.size();
		           		 for(int x =1; x<=NoofBBEProd; x++){
		           			  String y = String.valueOf(x);
			           		  String Productstatus = getAttribute(ProductStatus, y, "alt");
			              	  String ProductDesc = getTextFromElement(EachBBEProducts, y);
			              	  String ProductDesc1 = ProductDesc.split(" ")[0];
			              	  String ProductDesc2 = ProductDesc.replace(ProductDesc1, "");
			              	  String ProductDescFinal = ProductDesc2.split("\\(")[0].trim(); 
			              	  
			              	  System.out.println(vasProds[i]);
			           		  if(vasProds[i].toUpperCase().contains(":X") ){
							 
			           			  String BBEProduct = vasProds[i].split(":X")[0];
			           			
			           			  if(BBEProduct.equalsIgnoreCase(ProductDescFinal))
			           			  {
			           				  System.out.println("VAS Product is    :"+ProductDescFinal);
			           				  if(Productstatus.equalsIgnoreCase("Removed"))
			           				  {
			           					  System.out.println("VAS Product " +ProductDescFinal+"is  "+Productstatus);
			           					  report.reportPass("Validate Wether VAS Product is Removed or not in View Details Page", "VAS Product Should be Removed in View Details Page", "VAS Product is Removed in View Details Page: " +ProductDescFinal);
			           				  }
			           				 else
				           			  {
				           				  System.out.println("VAS Product is not Displayed " +ProductDescFinal);
				           				  report.reportFail("Validate Wether VAS Product is Removed or not in View Details Page", "VAS Product Should be Removed in View Details Page", "VAS Product is not Removed in View Details Page: " +ProductDescFinal);
				           			  }
			           			  }
			           			 
			           			  
			           		  } else
			           		  {
				           			if(vasProds[i].equalsIgnoreCase(ProductDescFinal))
				           			  {
				           				  System.out.println("VAS Product is " +ProductDescFinal);
				           				  if(Productstatus.equalsIgnoreCase("Added"))
				           				  {
				           					  System.out.println("VAS Product " +ProductDescFinal+" is  "+Productstatus);
				           					  report.reportPass("Validate Wether VAS Product is Added or not in View Details Page", "VAS Product Should be Added in View Details Page", "VAS Product is Added in View Details Page: " +ProductDescFinal);
				           				  }
				           				else
					           			  {
					           				  System.out.println("VAS Product is not Displayed " +ProductDescFinal);
					           				  report.reportFail("Validate Wether VAS Product is Added or not in View Details Page", "VAS Product Should be Added in View Details Page", "VAS Product is not Added in View Details Page: " +ProductDescFinal);
					           			  }
				           			  }
				           			  
				           		  }			              	  			              	  
			              	  
		           		 }
		           			
		           		}
		           		
	           		 } else {
	           		
	           			 int NoofBBEProd= NoOfBBEProducts.size();
		           		 for(int x =1; x<=NoofBBEProd; x++){
		           			  String y = String.valueOf(x);
			           		  String Productstatus = getAttribute(ProductStatus, y, "alt");
			              	  String ProductDesc = getTextFromElement(EachBBEProducts, y);
			              	  String ProductDesc1 = ProductDesc.split(" ")[0];
			              	  String ProductDesc2 = ProductDesc.replace(ProductDesc1, "");
			              	  String ProductDescFinal = ProductDesc2.split("\\(")[0].trim(); 
			              	  
			              	  System.out.println(vasProduct);
			           		  if(vasProduct.toUpperCase().contains(":X") ){
							 
			           			  String BBEProduct = vasProduct.split(":X")[0];
			           			
			           			  if(BBEProduct.equalsIgnoreCase(ProductDescFinal))
			           			  {
			           				  System.out.println("VAS Product is  :" +ProductDescFinal);
			           				  if(Productstatus.equalsIgnoreCase("Removed"))
			           				  {
			           					  System.out.println("VAS Product  "+ProductDescFinal+" is  "+Productstatus);
			           					  report.reportPass("Validate Wether VAS Product is Removed or not in View Details Page", "VAS Product Should be Removed in View Details Page", "VAS Product is Removed in View Details Page: " +ProductDescFinal);
			           				  }
			           				else
				           			  {
				           				  System.out.println("VAS Product is not Displayed " +ProductDescFinal);
				           				  report.reportFail("Validate Wether VAS Product is Removed or not in View Details Page", "VAS Product Should be Removed in View Details Page", "VAS Product is not Removed in View Details Page: " +ProductDescFinal);
				           			  }
			           			  }
			           			  
			           			  
			           		  } else
			           		  {
				           			if(vasProduct.equalsIgnoreCase(ProductDescFinal))
				           			  {
				           				  System.out.println("VAS Product is " +ProductDescFinal);
				           				  if(Productstatus.equalsIgnoreCase("Added"))
				           				  {
				           					  System.out.println("VAS Product  " +ProductDescFinal+" is  "+Productstatus);
				           					  report.reportPass("Validate Wether VAS Product is Added or not in View Details Page", "VAS Product Should be Added in View Details Page", "VAS Product is Added in View Details Page: " +ProductDescFinal);
				           				  }
				           				 else
					           			  {
					           				  System.out.println("VAS Product is not Displayed " +ProductDescFinal);
					           				  report.reportFail("Validate Wether VAS Product is Added or not in View Details Page", "VAS Product Should be Added in View Details Page", "VAS Product is not Added in View Details Page: " +ProductDescFinal);
					           			  }
					           		  }		
				           			  }
				           			 	              	  			              	  
			              	  
		           		 }	 
	           			 
	           		 }
	           	 }
	           	 
	           	 if(isDisplayed(BBESection) && get("ChangeType").equalsIgnoreCase("Disconnect"))
	           	 {	
           			 int NoofBBEProd= NoOfBBEProducts.size();
	           		 for(int x =1; x<=NoofBBEProd; x++){
	           			  String y = String.valueOf(x);
		           		  String Productstatus = getAttribute(ProductStatus, y, "alt");
		              	  String ProductDesc = getTextFromElement(EachBBEProducts, y);
		              	  String ProductDesc1 = ProductDesc.split(" ")[0];
		              	  String ProductDesc2 = ProductDesc.replace(ProductDesc1, "");
		              	  String ProductDescFinal = ProductDesc2.split("\\(")[0].trim(); 
		              	  		           			
		           			  if(!ProductDescFinal.isEmpty())
		           			  {
		           				  System.out.println("VAS Product is  :" +ProductDescFinal);
		           				  if(Productstatus.equalsIgnoreCase("Removed"))
		           				  {
		           					  System.out.println("VAS Product  "+ProductDescFinal+" is  "+Productstatus); 
		           					  report.reportPass("Validate Wether VAS Product is Removed or not in View Details Page", "VAS Product Should be Removed in View Details Page", "VAS Product is Removed in View Details Page: " +ProductDescFinal);
		           				  }
		           				else
			           			  {
			           				  System.out.println("VAS Product is not Displayed " +ProductDescFinal);
			           				  report.reportFail("Validate Wether VAS Product is Removed or not in View Details Page", "VAS Product Should be Removed in View Details Page", "VAS Product is not Removed in View Details Page: " +ProductDescFinal);
			           			  }
		           			  }
		           			  
		           			  
		           		  } 
			         
	           	 }
	           	 
	           	clickUsingJavaScript(CartViewDetails_Close, "");
	       	    } catch(Exception e) {
	       			report.reportFail("Cart View Details", "There are no product details  displayed", "There are no product details displayed");
	       		  }
	    	}
	    		
	    }
	    
	    
	    if(isDisplayed(lnkCloseMasterPopup))
	    {
	    	clickUsingJavaScript(CloseMark, "");
	    	waitForLoader();
	    }

	    switchToDefaultcontent();
	    switchToFrame("IfProducts");

	    if(isDisplayed(popupIframe, "", 1)){
    		switchToFrame("PopupIFrame");
    	}
	    
	    String atn = get("ATN").trim();
	    String mtn = get("MTN").trim();
	    String email = get("Email").trim();

	    // Capturing the MOn after Credit Fail

	  /*  if (get("GUI_Validations").equalsIgnoreCase("Yes")) {

		UIValidation_CaptureMON();
	    }
	    */

	 // Enter Valid MTN
	    if (!mtn.isEmpty()) {
	    	WebElement e=driver.findElement(By.xpath("//input[@alt='Mobile Number' or @id='txtMobileNumber']"));
	    	e.clear();
		    setText(enterMTN, strActual, mtn);
	    }
	    
	 // Enter Valid Email
	  
	    if (!email.isEmpty()) {
	    	WebElement em=driver.findElement(By.xpath("//input[@alt='Email'or @id='txtEmail']"));
	    	em.clear();
		//clearText(enterEmail, objectValue);
		setText(enterEmail, strActual, email);
		 waitForLoader();
		//-----------------------Digital Billing Update---------------------------------
				if((email.equals("none"))&&isDisplayed(DBNoEmailCheckBox,"",3)){
					clickUsingJavaScript(DBNoEmailCheckBox,objectValue);
				}

	    }
        waitForLoader();
  
	    // Enter Valid ATN
	    if (!atn.isEmpty() && isDisplayed(enterATN, "", 0)) {
		clearText(enterATN, objectValue);
		setText(enterATN, strActual, atn);
	    }

	   
	    if (isDisplayed(EmailUpdateNo, "", 3)) {
		clickUsingJavaScript(EmailUpdateNo, objectValue);
	    }

	    // Click On Same As Above CheckBox

	    if (isDisplayed(chkSameAsAbove, "", 3)) {
		clickUsingJavaScript(chkSameAsAbove, objectValue);
	    }

	    if (isDisplayed(rdBtnPrefContactN, "", 1)) {
		// Click On Preferred Method of contact
		clickUsingJavaScript(rdBtnPrefContactN, objectValue);
	    }

	    if (isDisplayed(streamingYes, "", 1)) {
		// Click On Preferred Method of contact
		clickUsingJavaScript(streamingYes, "");
	    }

	    if(isDisplayed(chkAsSameAbv, email)){
	    	clickUsingJavaScript(chkAsSameAbv, objectValue);
	    	
	    }
	   
	   
	    // Click On Save And Continue Button
	    clickUsingJavaScript(btnCCISave, objectValue);

	    Thread.sleep(2000);
	    //waitForPageToLoad(driver);
	  //-------------------------Digital Billing Update-----------------------
	    try{
	    	if(isDisplayed(DBDeclineMessage,"",5)){
	    		pageScroll(DBDeclineMessage);
	    		clickUsingJavaScript(DBDeclineMessageCheckbox, objectValue);	    		
	    		System.out.println("Digital billing decline message click box is clicked");
	    		pageScroll(btnCCISave);
	    		clickUsingJavaScript(btnCCISave, objectValue);
	    		
	    		report.reportPass("Digital Billing decline message Checkbox should be checked", "Digital Billing decline message Checkbox should be checked", "Digital Billing decline message Checkbox is diplayed and it is clicked"); 
		     }
	    	else{
	    		System.out.println("Digital billing decline message click box is not displayed , hence it is DB order");
	    		report.reportPass("Digital Billing decline message Checkbox should not be checked", "Digital Billing decline message Checkbox should not checked", "Digital Billing decline message Checkbox is not diplayed and it is  not clicked"); 
		     }
	    }
	    catch(Exception e){
			System.out.println("Digital billing decline message click box is not displayed , hence it is DB order");
			report.reportFail("Digital Billing decline message Checkbox should not be checked", "Digital Billing decline message Checkbox should not checked", "Digital Billing decline message Checkbox is not diplayed and it is  not clicked");
			} 



	    if(get("Application").equalsIgnoreCase("C2G")){
	    	if (isDisplayed(chkOverUseInd2, "", 2)) {

	    		// PageSync
	    		waitForElementDisplay(chkOverUseInd2, objectValue, time);

	    		// Click On Check Override CheckBox
	    		clickUsingJavaScript(chkOverUseInd2, objectValue);

	    		// Click On Save And Continue Button
	    		clickUsingJavaScript(btnCCISave, objectValue);
	    		report.reportPass("Click Save And Continue in Contact Info", "Save And Continue should be clicked in Contact Info", "Save And Continue is clicked in Contact Info");
	    	    }
	    	
	    }
	    else{
	    	
	    	if (isDisplayed(chkOverUseInd2, "", 2)) {

	    		// PageSync
	    		waitForElementDisplay(chkOverUseInd2, objectValue, time);

	    		// Click On Check Override CheckBox
	    		clickUsingJavaScript(chkOverUseInd2, objectValue);

	    		// Click On Save And Continue Button
	    		clickUsingJavaScript(btnCCISave, objectValue);
	    		report.reportPass("Click Save And Continue in Contact Info", "Save And Continue should be clicked in Contact Info", "Save And Continue is clicked in Contact Info");
	    	    }
	    	
	    	
	    	else if (isDisplayed(chkOverUseInd, "", 2)) {

		// PageSync
		waitForElementDisplay(chkOverUseInd, objectValue, time);

		// Click On Check Override CheckBox
		clickUsingJavaScript(chkOverUseInd, objectValue);
		 

		// Click On Save And Continue Button
		clickUsingJavaScript(btnCCISave, objectValue);
		report.reportPass("Click Save And Continue in Contact Info", "Save And Continue should be clicked in Contact Info", "Save And Continue is clicked in Contact Info");
		waitForLoader();
	    }
	    }
	    

	    if (!isNotDisplayed(activeContactInfoTab, 30)) {
	    	if(isDisplayed(errormsg, email, 0)){
		String error=getTextFromElement(errormsg, email);
		System.out.println(error);
		//------------------------Digital Billing Update---------------------------------
				try{
					Thread.sleep(2000);
					pageScroll(btnCCISave);
					Thread.sleep(2000);
					System.out.println("S&C button");
					//clickUsingJavaScript(btnCCISave, objectValue);
					btnCCISave.click();
					if (isDisplayed(chkOverUseInd, "", 2)) {
					waitForElementDisplay(chkOverUseInd, objectValue, time);
					Thread.sleep(5000);
					// Click On Check Override CheckBox
					pageScroll(chkOverUseInd);
					clickUsingJavaScript(chkOverUseInd, objectValue);
					 
					// Click On Save And Continue Button
					pageScroll(btnCCISave);
					clickUsingJavaScript(btnCCISave, objectValue);
					Thread.sleep(2000);
					pageScroll(DBDeclineMessageCheckbox);
					clickUsingJavaScript(DBDeclineMessageCheckbox, objectValue);
					Thread.sleep(2000);
					pageScroll(btnCCISave);
					System.out.println("S&C button");
					clickUsingJavaScript(btnCCISave, objectValue);}
					
					report.reportPass("Click Save And Continue in Contact Info", "Save And Continue should be clicked in Contact Info", "Save And Continue is clicked in Contact Info");
					waitForLoader();
					}
					catch(Exception e){
						System.out.println("Digital_billing_enrollment decline message is not displayed");
						report.reportFail("Digital Billing enrollment decline message should be  displayed: ", "Digital Billing enrollment decline message is not displayed: " , "Digital Billing decline message is not displayed ");
						} 			
					 /*strFailed = "Failed in Contact info page, Summary page was not displayed post clicking save and continue in contact info page.";
					  report.reportFail("Verify Contact info page not displayed", "Contact info page should not be displayed post clicking save and continue in contact info page.", strFailed);		
					report.updateMainReport("comments", "Error: "+error+ " is displayed in Contact Info Page");
					report.updateMainReport("ErrorMessage", error);
					logger.error(error);
					captureErrorMsg(error);
					throw new UserDefinedException(strFailed);	*/
			       }
	    	
	    	else{
		  strFailed = "Failed in Contact info page, Summary page was not displayed post clicking save and continue in contact info page.";
		  report.reportFail("Verify Contact info page not displayed", "Contact info page should not be displayed post clicking save and continue in contact info page.", strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);	
	    	}
		
	    } else {
		report.reportPass(strDescription + getUrl, strExpected, strActual);
	    }

	    waitForLoader();

	} catch (Exception exe) {
		if (!isUserDefinedException(exe)) {
	 		report.reportFail(strDescription + getUrl, strExpected, strFailed);
	 		report.updateMainReport("ErrorMessage", strFailed);
	 		captureErrorMsg(strFailed);
	 	    }
		 throw exe;
	}

    }
    /**
     * Verifies Contact info tab is opened or not, if not clicks on it
     * 
     * @author Shiva Kumar Simharaju
     * @throws Exception
     */
    public void verifyContactInfoTab() throws Exception {

	try {
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");

	    if (isDisplayed(contactInfoTab, "", 1)) {
		System.out.println(contactInfoTab.getText());
		String classValue = getAttribute(contactInfoTab, "", "class");
		if (classValue != null && !classValue.contains("active")) {
		    clickUsingJavaScript(contactInfoTab, "");
		    waitForLoader();
		}
	    }

	} catch (Exception e) {
	    report.reportFail("Verify contact info Tab.", "Contact info tab should be displayed.", "Contact info tab is not available");
	    report.updateMainReport("ErrorMessage", "Contact info tab is not available");
	    throw e;
	}

    }

    protected void UIValidation_CaptureMON() throws Exception {



	    try {
		switchToDefaultcontent();
		switchToFrame("IfProducts");
		if(get("Application").equalsIgnoreCase("COA"))
		{
		if (isDisplayed(contactInfoTab, "", 1)) {

		    System.out.println(contactInfoTab.getText());
		    getTextFromElement(MON_Label, objectValue);
		    waitForLoader();
		    getTextFromElement(Display_MON, objectValue);
		}
		}
		else{
			
		}
	    } catch (Exception exe) {
		exe.printStackTrace();
	    }
	}
    
    
    ////////////////////Vignesh//////////////////////
    public void ValidateViewDetails() throws Exception {

    	String strFailed = "";

    	waitForLoader();
    	waitForLoader();
    	switchToDefaultcontent();
    	// switchToFrame("IfProducts");

    	try {

    		if (get("Application").contains("C2G"))
    			clickUsingJavaScript(C2G_viewDetail_link, "");

    		if (get("Application").contains("COA"))
    			clickUsingJavaScript(MON_link, "");

    	} catch (Exception ex) {
    		ex.printStackTrace();
    	}

    	waitForLoader();
    	waitForLoader();
    	
    	//code to take screenshot
    	
    	try{
    		pageScroll(viewDetail_Screenshot.get(0), "", true);		
    		report.reportPass("View details-take screenshot","","screenshot taken");
    		if(viewDetail_Screenshot.size()>10){
    			
    			for(int i=0;i<viewDetail_Screenshot.size();i++){
    			
    			pageScroll(viewDetail_Screenshot.get(i), "", true);		
    			report.reportPass("View details-take screenshot","","screenshot taken");

    			i=i+9;
    			}
    		}
    		
    		pageScroll(viewDetail_Screenshot.get(viewDetail_Screenshot.size()-1), "", true);		
    		report.reportPass("View details-take screenshot","","screenshot taken");

    	
    	
    	}
    	catch(Exception ex){
    		
    	}

    	if (!get("NoOfTV_Price").isEmpty()) {

    		String newTVcount = get("NoOfTv").trim();
    		String Pricestructure = get("NoOfTV_Price").trim();
    		String PreExistingTVcount = "";

    		int TV = Integer.valueOf(newTVcount);
    		int newIsocseries = 0;
    		if (TV < 16) {
    			newIsocseries = 30 + TV - 1;
    		} else {
    			newIsocseries = 30 + TV;

    		}

    		String NewIsoc = "Q46" + newIsocseries;

    		int ExistingIsocseries = 0;

    		try {
    			PreExistingTVcount = get("PreExistingTVCount").trim();

    			int ExistingTV = Integer.valueOf(newTVcount);
    			if (ExistingTV < 16) {
    				ExistingIsocseries = 30 + ExistingTV - 1;
    			} else {
    				ExistingIsocseries = 30 + ExistingTV;

    			}
    		} catch (Exception ex) {
    		}

    		String ExistingIsoc = "Q46" + ExistingIsocseries;

    		if (get("FlowType").contains("Install")) {

    			String New_NoOfTV_Price = "";
    			if (Pricestructure.equalsIgnoreCase("New")) {

    				if (TV == 1) {

    					New_NoOfTV_Price = "$12";
    				} else if (TV == 2) {

    					New_NoOfTV_Price = "$24";
    				} else if (TV == 3) {

    					New_NoOfTV_Price = "$30";
    				} else if (TV == 4) {

    					New_NoOfTV_Price = "$36";
    				} else if (TV >= 5) {

    					New_NoOfTV_Price = "$42";
    				}
    			}

    			String Expectedaddition = NewIsoc + " Rent: " + newTVcount
    					+ " Set-Top Box (1 @ " + New_NoOfTV_Price + " = "
    					+ New_NoOfTV_Price + ".00)";
    			try {
    				WebElement ViewDetails_TVSTB_added = driver
    						.findElement(By
    								.xpath("//tbody[@id='dv_FiOS TV']//td/child::img[@alt='Added']/../following-sibling::td[contains(text(),'"
    										+ NewIsoc
    										+ "') and contains(text(),'"
    										+ newTVcount
    										+ "') and contains(text(),'Set-Top') and contains(text(),'"
    										+ New_NoOfTV_Price + "')]"));

    				if (ViewDetails_TVSTB_added.isDisplayed()) {
    					report.reportPass("Verify View details",
    							Expectedaddition
    									+ " should be added in view details",
    							Expectedaddition + " is added in view details");
    				} else {
    					report.reportFail("Verify View details",
    							Expectedaddition
    									+ " should be added in view details",
    							Expectedaddition
    									+ " is not added in view details");
    					strFailed = Expectedaddition
    							+ " is not added in view details";
    					throw new UserDefinedException(strFailed);
    				}
    			} catch (Exception ex) {
    				report.reportFail("Verify View details", Expectedaddition
    						+ " should be added in view details",
    						Expectedaddition + " is not added in view details");
    				strFailed = Expectedaddition
    						+ " is not added in view details";
    				throw new UserDefinedException(strFailed);

    			}
    		} else {

    			if (!PreExistingTVcount.isEmpty() && !newTVcount.isEmpty()) {

    				String New_NoOfTV_Price = "";
    				String Existing_NoOfTV_Price = "";
    				String Expectedremoval = "";
    				WebElement ViewDetails_TVSTB_removed = null;
    				if (!PreExistingTVcount.equalsIgnoreCase(newTVcount)) {

    					if (Pricestructure.equalsIgnoreCase("oldtoNew")) {

    						if (TV == 1) {

    							New_NoOfTV_Price = "$12";
    						} else if (TV == 2) {

    							New_NoOfTV_Price = "$24";
    						} else if (TV == 3) {

    							New_NoOfTV_Price = "$30";
    						} else if (TV == 4) {

    							New_NoOfTV_Price = "$36";
    						} else if (TV >= 5) {

    							New_NoOfTV_Price = "$42";
    						}

    						Expectedremoval = PreExistingTVcount
    								+ " Set-Top Box";

    						String Expectedaddition = NewIsoc + " Rent: "
    								+ newTVcount + " Set-Top Boxes (1 @ "
    								+ New_NoOfTV_Price + " = "
    								+ New_NoOfTV_Price + ".00)";
    						try {
    							WebElement ViewDetails_TVSTB_added = driver
    									.findElement(By
    											.xpath("//tbody[@id='dv_FiOS TV']//td/child::img[@alt='Added']/../following-sibling::td[contains(text(),'"
    													+ NewIsoc
    													+ "') and contains(text(),'"
    													+ newTVcount
    													+ "') and contains(text(),'Set-Top') and contains(text(),'"
    													+ New_NoOfTV_Price
    													+ "')]"));

    							if (ViewDetails_TVSTB_added.isDisplayed()) {

    								report.reportPass(
    										"Verify View details",
    										Expectedaddition
    												+ " should be added in view details",
    										Expectedaddition
    												+ " is added in view details");
    							} else {
    								report.reportFail(
    										"Verify View details",
    										Expectedaddition
    												+ " should be added in view details",
    										Expectedaddition
    												+ " is not added in view details");
    								strFailed = Expectedaddition
    										+ " is not added in view details";
    								throw new UserDefinedException(strFailed);
    							}
    						} catch (Exception ex) {
    							report.reportFail(
    									"Verify View details",
    									Expectedaddition
    											+ " should be added in view details",
    									Expectedaddition
    											+ " is not added in view details");
    							strFailed = Expectedaddition
    									+ " is not added in view details";
    							throw new UserDefinedException(strFailed);
    						}
    						try {
    							ViewDetails_TVSTB_removed = driver
    									.findElement(By
    											.xpath("//tbody[@id='dv_FiOS TV']//td/child::img[@alt='Removed']/../following-sibling::td[contains(text(),'"
    													+ PreExistingTVcount
    													+ "') and contains(text(),'Set-Top') ]"));

    							if (ViewDetails_TVSTB_removed.isDisplayed()) {

    								report.reportPass(
    										"Verify View details",
    										Expectedremoval
    												+ " should be removed from view details",
    										Expectedremoval
    												+ " is removed from view details");
    							} else {
    								report.reportFail(
    										"Verify View details",
    										Expectedremoval
    												+ " should be removed from view details",
    										Expectedremoval
    												+ " is not removed from view details");

    								strFailed = Expectedremoval
    										+ " is not removed from view details";
    								throw new UserDefinedException(strFailed);
    							}

    						} catch (Exception ex) {
    							report.reportFail(
    									"Verify View details",
    									Expectedremoval
    											+ " should be removed from view details",
    									Expectedremoval
    											+ " is not removed from view details");

    							strFailed = Expectedremoval
    									+ " is not removed from view details";
    							throw new UserDefinedException(strFailed);
    						}
    					} else if (Pricestructure.equalsIgnoreCase("NewtoNew")) {

    						if (Integer.valueOf(PreExistingTVcount) == 1) {

    							Existing_NoOfTV_Price = "$12";
    						} else if (Integer.valueOf(PreExistingTVcount) == 2) {

    							Existing_NoOfTV_Price = "$24";
    						} else if (Integer.valueOf(PreExistingTVcount) == 3) {

    							Existing_NoOfTV_Price = "$30";
    						} else if (Integer.valueOf(PreExistingTVcount) == 4) {

    							Existing_NoOfTV_Price = "$36";
    						} else if (Integer.valueOf(PreExistingTVcount) >= 5) {

    							Existing_NoOfTV_Price = "$42";
    						}

    						if (TV == 1) {

    							New_NoOfTV_Price = "$12";
    						} else if (TV == 2) {

    							New_NoOfTV_Price = "$24";
    						} else if (TV == 3) {

    							New_NoOfTV_Price = "$30";
    						} else if (TV == 4) {

    							New_NoOfTV_Price = "$36";
    						} else if (TV >= 5) {

    							New_NoOfTV_Price = "$42";
    						}

    						Expectedremoval = ExistingIsoc + " Rent: "
    								+ PreExistingTVcount
    								+ " Set-Top Boxes (1 @ "
    								+ Existing_NoOfTV_Price + " = "
    								+ Existing_NoOfTV_Price + ".00)";

    						String Expectedaddition = NewIsoc + " Rent: "
    								+ newTVcount + " Set-Top Boxes (1 @ "
    								+ New_NoOfTV_Price + " = "
    								+ New_NoOfTV_Price + ".00)";
    						try {
    							WebElement ViewDetails_TVSTB_added = driver
    									.findElement(By
    											.xpath("//tbody[@id='dv_FiOS TV']//td/child::img[@alt='Added']/../following-sibling::td[contains(text(),'"
    													+ NewIsoc
    													+ "') and contains(text(),'"
    													+ newTVcount
    													+ "') and contains(text(),'Set-Top') and contains(text(),'"
    													+ New_NoOfTV_Price
    													+ "')]"));

    							if (ViewDetails_TVSTB_added.isDisplayed()) {

    								report.reportPass(
    										"Verify View details",
    										Expectedaddition
    												+ " should be added in view details",
    										Expectedaddition
    												+ " is added in view details");
    							} else {
    								report.reportFail(
    										"Verify View details",
    										Expectedaddition
    												+ " should be added in view details",
    										Expectedaddition
    												+ " is not added in view details");
    								strFailed = Expectedaddition
    										+ " is not added in view details";
    								throw new UserDefinedException(strFailed);
    							}
    						} catch (Exception ex)

    						{
    							report.reportFail(
    									"Verify View details",
    									Expectedaddition
    											+ " should be added in view details",
    									Expectedaddition
    											+ " is not added in view details");
    							strFailed = Expectedaddition
    									+ " is not added in view details";
    							throw new UserDefinedException(strFailed);
    						}

    						try {
    							ViewDetails_TVSTB_removed = driver
    									.findElement(By
    											.xpath("//tbody[@id='dv_FiOS TV']//td/child::img[@alt='Removed']/../following-sibling::td[contains(text(),'"
    													+ ExistingIsoc
    													+ "') and contains(text(),'"
    													+ PreExistingTVcount
    													+ "') and contains(text(),'Set-Top') and contains(text(),'"
    													+ Existing_NoOfTV_Price
    													+ "')]"));

    							if (ViewDetails_TVSTB_removed.isDisplayed()) {

    								report.reportPass(
    										"Verify View details",
    										Expectedremoval
    												+ " should be removed from view details",
    										Expectedremoval
    												+ " is removed from view details");
    							} else {
    								report.reportFail(
    										"Verify View details",
    										Expectedremoval
    												+ " should be removed from view details",
    										Expectedremoval
    												+ " is not removed from view details");

    								strFailed = Expectedremoval
    										+ " is not removed from view details";
    								throw new UserDefinedException(strFailed);
    							}
    						} catch (Exception ex) {
    							report.reportFail(
    									"Verify View details",
    									Expectedremoval
    											+ " should be removed from view details",
    									Expectedremoval
    											+ " is not removed from view details");

    							strFailed = Expectedremoval
    									+ " is not removed from view details";
    							throw new UserDefinedException(strFailed);
    						}
    					}

    				} else {

    					String Expectedonprofile = "";
    					WebElement ViewDetails_TVSTB_onprofile = null;
    					if (Pricestructure.equalsIgnoreCase("old")) {

    						Expectedonprofile = PreExistingTVcount
    								+ "Set-Top Box";
    						try {
    							ViewDetails_TVSTB_onprofile = driver
    									.findElement(By
    											.xpath("//tbody[@id='dv_FiOS TV']//td/child::img[@alt='OnProfile']/../following-sibling::td[contains(text(),'"
    													+ PreExistingTVcount
    													+ "') and contains(text(),'Set-Top')]"));
    							if (ViewDetails_TVSTB_onprofile.isDisplayed()) {

    								report.reportPass(
    										"Verify View details",
    										Expectedonprofile
    												+ " should be on-profile in view details",
    										Expectedonprofile
    												+ " is on-profile in view details");
    							} else {
    								report.reportFail(
    										"Verify View details",
    										Expectedonprofile
    												+ " should be on-profile in view details",
    										Expectedonprofile
    												+ " is not on-profile in view details");
    								strFailed = Expectedonprofile
    										+ " is not on-profile in view details";
    								throw new UserDefinedException(strFailed);
    							}

    						} catch (Exception ex) {
    							report.reportFail(
    									"Verify View details",
    									Expectedonprofile
    											+ " should be on-profile in view details",
    									Expectedonprofile
    											+ " is not on-profile in view details");
    							strFailed = Expectedonprofile
    									+ " is not on-profile in view details";
    							throw new UserDefinedException(strFailed);

    						}
    					} else if (Pricestructure.equalsIgnoreCase("New")) {

    						if (Integer.valueOf(PreExistingTVcount) == 1) {

    							Existing_NoOfTV_Price = "$12";
    						} else if (Integer.valueOf(PreExistingTVcount) == 2) {

    							Existing_NoOfTV_Price = "$24";
    						} else if (Integer.valueOf(PreExistingTVcount) == 3) {

    							Existing_NoOfTV_Price = "$30";
    						} else if (Integer.valueOf(PreExistingTVcount) == 4) {

    							Existing_NoOfTV_Price = "$36";
    						} else if (Integer.valueOf(PreExistingTVcount) >= 5) {

    							Existing_NoOfTV_Price = "$42";
    						}

    						Expectedonprofile = ExistingIsoc + " Rent: "
    								+ PreExistingTVcount
    								+ " Set-Top Boxes (1 @ "
    								+ Existing_NoOfTV_Price + " = "
    								+ Existing_NoOfTV_Price + ".00)";
    						try {
    							ViewDetails_TVSTB_onprofile = driver
    									.findElement(By
    											.xpath("//tbody[@id='dv_FiOS TV']//td/child::img[@alt='OnProfile']/../following-sibling::td[contains(text(),'"
    													+ ExistingIsoc
    													+ "') and contains(text(),'"
    													+ PreExistingTVcount
    													+ "') and contains(text(),'Set-Top') and contains(text(),'"
    													+ Existing_NoOfTV_Price
    													+ "')]"));
    							if (ViewDetails_TVSTB_onprofile.isDisplayed()) {

    								report.reportPass(
    										"Verify View details",
    										Expectedonprofile
    												+ " should be on-profile in view details",
    										Expectedonprofile
    												+ " is on-profile in view details");
    							} else {
    								report.reportFail(
    										"Verify View details",
    										Expectedonprofile
    												+ " should be on-profile in view details",
    										Expectedonprofile
    												+ " is not on-profile in view details");
    								strFailed = Expectedonprofile
    										+ " is not on-profile in view details";
    								throw new UserDefinedException(strFailed);
    							}
    						} catch (Exception ex) {
    							report.reportFail(
    									"Verify View details",
    									Expectedonprofile
    											+ " should be on-profile in view details",
    									Expectedonprofile
    											+ " is not on-profile in view details");
    							strFailed = Expectedonprofile
    									+ " is not on-profile in view details";
    							throw new UserDefinedException(strFailed);
    						}
    					}

    				}

    			}

    		}
    	}

    	if (!get("HNP").isEmpty()) {

    		String HNP = get("HNP").trim();

    		if (HNP.equalsIgnoreCase("AutoAdded")) {
    			try {
    				if (isDisplayed(ViewDetails_BBE_added,"Home Network Protection")) {

    					report.reportPass(
    							"validate Home Network Protection in view detail",
    							"Home Network Protection should be added in view detail",
    							"Home Network Protection is added in view detail");

    				} else {

    					report.reportFail(
    							"validate Home Network Protection",
    							"Home Network Protection should be added in view detail",
    							"Home Network Protection is not added in view detail");
    					strFailed = "Home Network Protection is not added in view detail";
    					throw new UserDefinedException(strFailed);
    				}
    			} catch (Exception ex) {
    				report.reportFail(
    						"validate Home Network Protection",
    						"Home Network Protection should be added in view detail",
    						"Home Network Protection is not added in view detail");
    				strFailed = "Home Network Protection is not added in view detail";
    				throw new UserDefinedException(strFailed);
    			}

    		}

    		else if (HNP.equalsIgnoreCase("NotAutoAdded")) {
    			try {
    				if (!isDisplayed(ViewDetails_BBE_added,"Home Network Protection")) {

    					report.reportPass(
    							"validate Home Network Protection  in view detail",
    							"Home Network Protection should not be added  in view detail",
    							"Home Network Protection is not added  in view detail");

    				} else {

    					report.reportFail(
    							"validate Home Network Protection  in view detail",
    							"Home Network Protection should not be added  in view detail",
    							"Home Network Protection is added  in view detail");
    					strFailed = "Home Network Protection is added  in view detail";
    					throw new UserDefinedException(strFailed);
    				}
    			} catch (Exception ex) {
    				report.reportPass(
    						"validate Home Network Protection  in view detail",
    						"Home Network Protection should not be added  in view detail",
    						"Home Network Protection is not added  in view detail");

    			}

    		} else if (HNP.equalsIgnoreCase("blockdeletion")) {
    			try {
    				if (isDisplayed(ViewDetails_BBE_onprofile,"Home Network Protection")) {

    					report.reportPass(
    							"validate Home Network Protection",
    							"Home Network Protection should be on profile in view detail",
    							"Home Network Protection is on profile in view detail");

    				} else {

    					report.reportFail(
    							"validate Home Network Protection",
    							"Home Network Protection should be on profile in view detail",
    							"Home Network Protection is not on profile in view detail");
    					strFailed = "Home Network Protection is not on profile in view detail";
    					throw new UserDefinedException(strFailed);
    				}
    			} catch (Exception ex) {
    				report.reportFail(
    						"validate Home Network Protection",
    						"Home Network Protection should be on profile in view detail",
    						"Home Network Protection is not on profile in view detail");
    				strFailed = "Home Network Protection is not on profile in view detail";
    				throw new UserDefinedException(strFailed);
    			}
    		}

    	}
    		
    	
    	if(!get("ExchangeOptions").isEmpty())
    	{
    		validateVMSExchangeOptions();
    	}
    	if((!get("FlowType").equals("Install") && !get("ExchangeOptions").isEmpty()) || (!get("FlowType").equals("Move") && !get("ExchangeOptions").isEmpty()))
    	{
    		valdiateVMSExchangeForInstallFlow();
    	}

    	///Vignesh code
    	
    	if (get("SubFlowType").equalsIgnoreCase("AutoPayTracker")) {
			if (!isDisplayed(Auto_Pay_Video_Tracker) && !isDisplayed(Auto_Pay_Data_Tracker)) {

				report.reportPass("validate Auto pay trackers", "Auto pay trackers should not get added",
						"Auto pay trackers are not added");

			} else {
				report.reportFail("validate Auto pay trackers", "Auto pay trackers should not get added",
						"Auto pay trackers are added");
				throw new UserDefinedException("Auto pay trackers are added");
			}

		/*	if (get("Contract").trim().contains("AutoPayAccept")) {

				if (isDisplayed(Auto_Pay_Discount)) {

					report.reportPass("validate Auto pay Discount", "Auto pay Discount should get added",
							"Auto pay Discount is added");

				} else {
					report.reportFail("validate Auto pay Discount", "Auto pay Discount should get added",
							"Auto pay Discount not added");
					throw new UserDefinedException("Auto pay Discount not added even though accepted in OPO");
				}

			} else if (get("Contract").trim().contains("AutoPayDecline")) {

				if (isDisplayed(Auto_Pay_Discount)) {

					report.reportPass("validate Auto pay Discount", "Auto pay Discount should not get added",
							"Auto pay Discount not added");

				} else {
					report.reportFail("validate Auto pay Discount", "Auto pay Discount should not get added",
							"Auto pay Discount added");
					throw new UserDefinedException("Auto pay Discount added even though declined in OPO");
				}
			}*/

		}
    	
    	
    	clickUsingJavaScript(ViewDetails_Close, "");
    }
    
public void validateVMSExchangeOptions() throws Exception{
    	
    	if(!get("MoreOffers").isEmpty())
    	{
    		System.out.println("VIEW DETAILS ... EXCHANGE OPTIONS VALIDATION");
    		if(isDisplayed(viewDetails_Q2423Discount, objectValue, 3))
    		{
    			System.out.println("VIEW DETAILS ... EXCHANGE OPTIONS VALIDATION");
    			report.reportPass(
					"Validate Q2423 Router Waiver ",
					"Router price should be waived off",
					"Router price waived off");
    			
    		}
    		else
    		{
    			System.out.println("VIEW DETAILS ... EXCHANGE OPTIONS VALIDATION --- FAILED");
    			report.reportFail(
    					"Validate Q2423 Router Waiver ",
    					"Router price should be waived off",
    					"Router price is not waived off");
    			
    		}
    	}
    	
    	
    }
    public void valdiateVMSExchangeForInstallFlow() throws Exception{
    	
    	
    		System.out.println("VIEW DETAILS ... EXCHANGE OPTIONS VALIDATION for Install Flows");
    		if(isDisplayed(Q2388ISoc, objectValue, 3))
    		{
    			report.reportPass(
					"Validate Q2388 ISOC is added or not ",
					"Q2388 ISOC should be displayd",
					"Q2388 ISOC is displayed");
    			
    		}
    		else
    		{
    			report.reportFail(
    					"Validate Q2388 ISOC is added or not ",
    					"Q2388 ISOC should be displayd",
    					"Q2388 ISOC is not displayed");
    			
    		}
    		if(isDisplayed(Q2389ISoc, objectValue, 3))
    		{
    			report.reportPass(
					"Validate Q2389 ISOC is added or not ",
					"Q2389 ISOC should be displayd",
					"Q2389 ISOC is displayed");
    			
    		}
    		else
    		{
    			report.reportFail(
    					"Validate Q2389 ISOC is added or not ",
    					"Q2389 ISOC should be displayd",
    					"Q2389 ISOC is not displayed");
    			
    		}
    	
    }
    void validateOfferinViewDetail() throws Exception {
		String strFailed = "";
		try {
			waitForLoader();
			waitForLoader();
			switchToDefaultcontent();
			// switchToFrame("IfProducts");

			try {

				if (get("Application").contains("C2G"))
					clickUsingJavaScript(C2G_viewDetail_link, "");

				if (get("Application").contains("COA"))
					clickUsingJavaScript(MON_link, "");

			} catch (Exception ex) {
				ex.printStackTrace();
			}

			waitForLoader();
			waitForLoader();

			// code to take screenshot

			try {
				pageScroll(viewDetail_Screenshot.get(0), "", true);
				report.reportPass("View details-take screenshot", "", "screenshot taken");
				if (viewDetail_Screenshot.size() > 10) {

					for (int i = 0; i < viewDetail_Screenshot.size(); i++) {

						pageScroll(viewDetail_Screenshot.get(i), "", true);
						report.reportPass("View details-take screenshot", "", "screenshot taken");

						i = i + 9;
					}
				}

				pageScroll(viewDetail_Screenshot.get(viewDetail_Screenshot.size() - 1), "", true);
				report.reportPass("View details-take screenshot", "", "screenshot taken");

			} catch (Exception ex) {

			}
			try {
				System.out.println();
				for (String offername : OfferDataExtraction.offerinfo.keySet())

				{

					String Expected_offer = OfferDataExtraction.offerinfo.get(offername).get("Cart order Description")
							.toString();

					if (get(offername).equalsIgnoreCase("Yes")) {

						try {
							WebElement offerentry = driver.findElement(
									by.xpath("//child::img[@alt='Added']/../following-sibling::td[contains(text(),'"
											+ Expected_offer + "')]/../../.."));

							if (offerentry.isDisplayed()) {

								report.reportPass("validate " + Expected_offer, Expected_offer + " should be displayed",
										"offer is displayed");
								System.out.println(Expected_offer + " is displayed as expected");

							} else {

								report.reportFail("validate " + Expected_offer, Expected_offer + " should be displayed",
										"offer is not displayed");
								System.out.println(Expected_offer + " is not displayed though expected");

							}
						} catch (Exception ex) {
							report.reportFail("validate " + Expected_offer, Expected_offer + " should be displayed",
									"offer is not displayed");
							System.out.println(Expected_offer + " is not displayed though expected");

						}

					} else if (get(offername).equalsIgnoreCase("No")) {

						try {

							WebElement offerentry = driver.findElement(
									by.xpath("//child::img[@alt='Added']/../following-sibling::td[contains(text(),'"
											+ Expected_offer + "')]/../../.."));
							if (!offerentry.isDisplayed()) {

								report.reportPass("validate " + Expected_offer,
										Expected_offer + " should not be displayed", "offer is not displayed");
								System.out.println(Expected_offer + " is not displayed as expected");

							} else {
								report.reportFail("validate " + Expected_offer,
										Expected_offer + " should not be displayed", "offer is displayed");
								System.out.println(Expected_offer + " is displayed though unexpected");

							}
						} catch (Exception ex) {
							report.reportPass("validate " + Expected_offer, Expected_offer + " should not be displayed",
									"offer is not displayed");
							System.out.println(Expected_offer + " is not displayed as expected");

						}
					}
				}
			} catch (Exception ex) {

			}
			clickUsingJavaScript(ViewDetails_Close, "");

		}

		catch (Exception ex) {
			System.out.println(ex.getMessage() +ex.getCause());
			ex.printStackTrace();
		}
    }
    
}

    

