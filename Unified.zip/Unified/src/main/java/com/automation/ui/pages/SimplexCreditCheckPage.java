package com.automation.ui.pages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_CreditCheck_PageObjects;
import com.automation.support.Element;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * SimplexCreditCheckPage class represents the Credit Check Page and interact
 * with the Page
 * 
 */
public class SimplexCreditCheckPage extends Simplex_CreditCheck_PageObjects {

    String objectValue = "";
    static boolean windows = InitiateDriver.windows;
    String description = "", expected = "", actual = "", failure = "", getUrl;
    By by;
    String testId;

    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

    /**
     * SimplexCreditCheckPage constructor invokes the super class constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     */
    public SimplexCreditCheckPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, windows, report, data);
	this.testId = testId;
    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     */
    public static SimplexCreditCheckPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexCreditCheckPage.class, testId, report, data);
    }

    /**
     * Navigation start for Simplex Credit Check Page
     * 
     * @param Url
     *            represents the page url to be open
     * @throws Exception
     *             throws exception of type Exception
     */
    public void start() throws Exception {

	System.out.println("Credit check page..");
	setIterator();
	System.out.println("Iterator Value Is : =" + TestIterator.getIterator(testId));
	setCreditInfo();

    }

    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void navigateTo() throws Exception {

	// To increment the navigation iteration
	int i = TestIterator.getIterator(testId);
	TestIterator.setIterator(testId, ++i);
    }

    /**
     * setCreditInfo method for providing the Customer's Credit information in
     * Credit Check Page
     * 
     * @param strFirstName
     *            represents the First Name
     * 
     * @author Surya Teja Padala
     */
    protected void setCreditInfo() throws Exception {
String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	try {
	    // Give Customer Credit info
	    strDescription = "Entering customer credit info details";
	    strExpected = "Giving customer credit info in details";
	    strActual = "Giving Customer credit info in Credit Check Page was successful";
	    strFailed = "Giving Customer credit info in Credit Check Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();

	 /*   if (get("GUI_Validations").equalsIgnoreCase("Yes")) {

		UIValidation_Skip_creditvalidation();

	    }
	    */

	    // Sync Handle
	    waitForLoader();
	    waitForLoader();
	    // waitforSpinner("");
	    // Switch to firstFrame

	    switchToDefaultcontent();
	    switchToFrame("IfProducts");

	    switchToFrame("PopupIFrame");
	    
	    System.out.println();
	    waitForLoader();
	    waitForLoader();
	    if ( get("FlowType").equalsIgnoreCase("Install")) {	    	
	    	
	    	try{
	   	     waitForLoader();
	   	     if ( get("Application").equalsIgnoreCase("C2G")){
	   	    	 
	   	    	if(isDisplayed(c2ghsicreditchkBox)){
	   	     clickUsingJavaScript(c2ghsicreditchkBox, objectValue); 
	   	     }
	   	    	else{
	   	    		clickUsingJavaScript(c2gfdvcreditchkBox, objectValue);
	   	    	}
	   	    		}
	   	     
	   	     if (isDisplayed(creditcheckdisclaimer)){
	   	click(creditcheckdisclaimer, objectValue);
	   	report.reportPass("click on Disclaimercheckbox",
	   	"Disclaimercheckbox should be successfully clicked",
	   	"Disclaimercheckbox is clicked successfully");
	   	     }

	   	}
	    	
	    	catch(Exception ex){
	    		
	    	}
	    }

	    // waitForElementDisplay(rbtnCreditCheckNo, "", 20);
	    // Select No Option on Credit Bureau Check
	    clickUsingJavaScript(rbtnCreditCheckNo, objectValue);
	    report.reportPass(strDescription + getUrl, strExpected, strActual);

	    // wait for FirstName and DOB to display

	    // waitForElementDisplay(txtDOBYear, "Credit Card Details section is
	    // not completely loaded - DOB not loaded after " + time + "
	    // seconds", time);

	    // Enter FirstName
	    clearText(txtFirstName, objectValue);
	    setText(txtFirstName, objectValue, get("CreditFirstName").trim());

	    // Enter LastName
	    clearText(txtLastName, objectValue);
	    setText(txtLastName, objectValue, get("CreditLastName").trim());

	    // Enter SSN
	    setText(txtSSN, objectValue, get("CreditSSN").trim());

	    if ((get("Application").equalsIgnoreCase("C2G") || get("Application").equalsIgnoreCase("COA"))) {
		//if (get("Application").equalsIgnoreCase("C2G") && get("FlowType").equalsIgnoreCase("Install")) {
			setText(cnftxtSSN, objectValue, get("CreditSSN").trim());
	    }

	    // Select DOB Month
	    selectDropDownUsingVisibleText(lstDOBMonth, strActual, get("CreditDOM").trim());

	    // Select DOB Date
	    selectDropDownUsingVisibleText(lstDOBDate, strActual, get("CreditDOB").trim());

	    // Select DOB Year
	    setText(txtDOBYear, objectValue, get("CreditDOY").trim());
	    
	    report.reportPass(strDescription + getUrl, strExpected, strActual);

	    // Click On Verify Credit Button
	    // waitForElementDisplay(btnVerifyCredit, "Verify Credit Button not
	    // loaded after " + time + " seconds", time);
	    
	    if(isDisplayed(chkboxpricequote, objectValue,10)){
	    	   clickUsingJavaScript(chkboxpricequote, objectValue);
	    }
	    clickUsingJavaScript(btnVerifyCredit, objectValue);
	    
	    waitForLoader();
	    Thread.sleep(20000);
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    switchToFrame("PopupIFrame");
		
		if(isDisplayed(btncancel, objectValue,3)){
	    clickUsingJavaScript(btncancel, objectValue);
	    }
	    
	    if(isDisplayed(CreateNewAccount))
	    {
	    	
	    	try{
	     pageScroll(CreateNewAccount);
	     clickUsingJavaScript(CreateNewAccount, "");
	     waitForLoader();
	     waitForLoader();
	    	}
	    	catch(Exception exe){
	    	strFailed = "Create New & Seperate Account button is not working";
			report.reportFail("Verify Clicking Create New & Seperate Account button", "Verify Clicking Create New & Seperate Account button", strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);	
	    	}
	    }

	    switchToDefaultcontent();
	    // for Credit fail UI validation

	  /*  if (get("GUI_Validations").equalsIgnoreCase("Yes")) {

		UIValidation_CreditFail();

	    }
	    */

	    // Failed Credit check
	    // waitForLoader();
	    waitForLoader();
	    if (isDisplayed(lblVerifyCreditErrMsg, "", 1)) {
		     
		    if(lblVerifyCreditErrMsg.getText().contains("FAIL"))
		    {
		report.reportPass("Credit Check Info.", "Credit Check Info is failed.", "Credit Check Info is failed");
		report.updateMainReport("ErrorMessage", "Credit Check Info is failed");
		waitForLoader();
		clickUsingJavaScript(btnClose, objectValue);
		waitForLoader();
		    }
	    }
	    else if(isDisplayed(verifyCredit, strFailed, 10)){
	    	
	    	strFailed = "Failed in Verifying Credit Check Page";
			report.reportFail("Verify Credit Check page", "Verify Credit Check page", strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);	
	    }

	} catch (Exception exe) {
		if (!isUserDefinedException(exe)) {
	 		report.reportFail(strDescription + getUrl, strExpected, strFailed);
	 		report.updateMainReport("ErrorMessage", strFailed);
	 		captureErrorMsg(strFailed);
	 	    }
		 throw exe;  
	}

    }

    // for Cancel Credit Validation GUI Validation 03/20/2017

    protected void UIValidation_Skip_creditvalidation() throws Exception {

	if (get("Skip_Creditvalidation").equalsIgnoreCase("Yes")) {

	    String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	    String getUrl = "";

	    String pageName = "Credit Information";

	    try {

		strDescription = "Validate Cancel credit Button is displayed or not";
		strExpected = "Cancel Credit Button Should be Displayed";
		strActual = "Cancel Credit Button is displayed";
		strFailed = "Cancel Credit Button is not displayed.";
		getUrl = ", URL Launched --> " + returnURL();
		int time = 60;

		// Sync Handle
		// waitforSpinner("");
		// Switch to firstFrame

		switchToDefaultcontent();
		switchToFrame("IfProducts");

		// Switch to another frame
		switchToFrame("PopupIFrame");

		waitForElementDisplay(Btn_Cancel_Credit, "", 20);

		waitForLoader();

		if (isDisplayed(Btn_Cancel_Credit, "", 1)) {

		    waitForLoader();
		    clickUsingJavaScript(Btn_Cancel_Credit, objectValue);
		    waitForLoader();
		}

		clickUsingJavaScript(Cancel_Credit_Yes, objectValue);

		waitForPageToLoad(driver);

		switchToDefaultcontent();

	    } catch (Exception exe) {
		exe.printStackTrace();
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);

	    }

	}
    }

    // For Credit Fail Validations by Gopal 03/23/2017

    protected void UIValidation_CreditFail() throws Exception {

	if (get("Credit_Fail").equalsIgnoreCase("Yes")) {

	    try {
		waitForPageToLoad(driver);
		switchToDefaultcontent();
		switchToFrame("IfProducts");

		// Switch to another frame
		switchToFrame("PopupIFrame");

		waitForElementDisplay(Btn_Cancel_Credit, "", 20);

		waitForLoader();

		if (isDisplayed(Btn_Cancel_Credit, "", 1)) {

		    waitForLoader();
		    clickUsingJavaScript(Btn_Cancel_Credit, objectValue);
		    waitForLoader();
		}

		waitForPageToLoad(driver);

	    } catch (Exception exe) {
		exe.printStackTrace();
	    }

	}

    }

}
