package com.automation.ui.pages;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

@Path("getLogId")
public class logId {

	

	@GET
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
	public String getLogInfo(@DefaultValue("") @QueryParam("cogsession") String cogSessionId) {
		String result="No Response";

		try
		{
			   Calendar cal = Calendar.getInstance();
			   SimpleDateFormat dtf = new SimpleDateFormat("MM/dd/yyyy");

			   String toDate= dtf.format(cal.getTime());
			   cal.add(Calendar.DATE, -3);
			   String fromDate = dtf.format(cal.getTime());
			   
			   
				String post_params="{\"envName\":\"SITOPTIXALL\",\"componentID\":\"COA.All\",\"SessionID\":\""+cogSessionId+"\",\"transactionId\":null,\"StartTime\":\""+fromDate+"\",\"EndTime\":\""+toDate+"\"}";
				String logUrl="https://cofeedashboard.verizon.com/CAToolsSimplexSvc/log/get";
				result=new logId().sendPOST(logUrl,post_params);

				//System.out.println(response);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return result;	
		
	}
	
	public static void main(String[] args) throws IOException, ParseException {
		// TODO Auto-generated method stub
		String post_params="{\"envName\":\"SITOPTIXALL\",\"componentID\":\"COA.All\",\"SessionID\":\""+"SIT-1ff143bf-db3d-4e41-ad2c-47ce479d8e77"+"\",\"transactionId\":null,\"StartTime\":\"05/14/2018\",\"EndTime\":\"05/14/2018\"}";
		String logUrl="https://cofeedashboard.verizon.com/CAToolsSimplexSvc/log/get";
		String result=new logId().sendPOST(logUrl,post_params);
		String logId=getLogId(result,"CRMM -Bundle-RG-Response-RG");
	//	System.out.println("GET DONE-logId:"+logId);
		String post_params_response="{\"envName\":\"SITOPTIXALL\",\"SessionID\":\"SIT-1ff143bf-db3d-4e41-ad2c-47ce479d8e77\",\"LogType\":\"TLOGMESSAGE\",\"LogId\":\""+logId+"\"}";
		String logInfoUrl="https://cofeedashboard.verizon.com/CAToolsSimplexSvc/log/getLogInfo";
		String response=new logId().sendPOST(logInfoUrl,post_params_response);
		//System.out.println(response);

	}

	public static String sendPOST(String url,String post_params) throws IOException, ParseException {
		String result ="";
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setDoOutput(true);
		con.setDoInput(true);
		con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
		con.setRequestProperty("Accept", "application/json, text/plain, */*");
		con.setRequestMethod("POST");
		
		// For POST only - START
		OutputStream os = con.getOutputStream();
        os.write(post_params.getBytes("UTF-8"));
        os.close();
		// For POST only - END

		int responseCode = con.getResponseCode();
		
		if (responseCode == HttpURLConnection.HTTP_OK) { //success
            InputStream in = new BufferedInputStream(con.getInputStream());
            result = org.apache.commons.io.IOUtils.toString(in, "UTF-8");
            //JSONObject jsonObject = new JSONObject(result);
			in.close();
			// print result
			//System.out.println(jsonObject);
		}
		return result;

	}

	private static String getLogId(String result,String service) throws ParseException
	{
		String logId="";
        JSONArray c = (JSONArray) new JSONParser().parse(result);
	    for (int i = 0; i < c.size(); i++) {
	        JSONObject obj1 = (JSONObject) c.get(i);
	        String shortMessage=(String) obj1.get("ShortMessage");
	        if(shortMessage.contains(service))
	        {
		        logId=(String) obj1.get("LogId");

	        }
	    }
        return logId;
	}

}
