package com.automation.ui.pages;

import java.util.HashMap;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_Dashboard_PageObjects;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * SimplexDashboardPage class represents the Dashboard Page and interact with
 * the page.
 * 
 * 
 */
public class SimplexDashboardPage extends Simplex_Dashboard_PageObjects {

    public static final int timeOut = 0;
    String objectValue = "";
    int iterator = 0;
    static boolean windows = InitiateDriver.windows;
    String description = "", expected = "", actual = "", failure = "", getUrl;
    By by;
    String testId;
    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

    /**
     * SimplexDashboardPage constructor invokes the super class constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     */
    public SimplexDashboardPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, windows, report, data);
	this.testId = testId;
    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     */
    public static SimplexDashboardPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexDashboardPage.class, testId, report, data);
    }

    /**
     * Navigation start for dashboard page
     * 
     * @param Url
     *            represents the page url to be open
     * @throws Exception
     *             throws exception of type Exception
     */
    public void start() throws Exception {

	setIterator();
	if(get("Username").trim().isEmpty()){
		String strFailed = "Username and password are not Provided in the Run Manager";
		report.reportFail("Login should be Successfull", "Login should be Successfull", "Login is not successfull as Username & Password are not Provided in the RunManager");
		report.updateMainReport("comments", "Username and password are not Provided in the Run Manager");
		report.updateMainReport("ErrorMessage", "Username and password are not Provided in the Run Manager");
		logger.error(strFailed);
		captureErrorMsg(strFailed);
		throw new UserDefinedException(strFailed);
		}

	System.out.println("Dash board page...");
	// For COA install flows
	if (get("Application").equalsIgnoreCase("COA") && get("FlowType").equalsIgnoreCase("Install")) {

		 waitForLoader();
		 if (isDisplayed(OpenAccount,"",5)){
         try{
         waitForElementDisplay(OpenAccount, objectValue, pageTimeoutInSeconds);
			clickUsingJavaScript(OpenAccount, "");
			report.reportPass("Open account icon", "Click on open account icon", "Clicked on open account icon");
			waitForLoader();
			//clickCOANewInstallButton();
			clickCOANewInstallButtonUpdated();
			
         } catch (Exception e) {
         	
                   report.reportFail("Verify Whether open account icon is displayed", "open account icon is displayed", "open account icon is not displayed");
                   report.updateMainReport("comments", "open account icon is not displayed");
                   report.updateMainReport("ErrorMessage", "open account icon is not displayed");
                   logger.error("open account icon is not displayed");
                   captureErrorMsg("open account icon is not displayed");
                   throw new UserDefinedException("open account icon is not displayed");             
                   
                }
		 } else {
			 clickCOANewInstallButton();
		 }
		
	    

	    // For COA non install flows
	} else if (get("Application").equalsIgnoreCase("COA") && (!get("FlowType").equalsIgnoreCase("Install"))) {
		waitForLoader();
        
		if (isDisplayed(OpenAccount,"",5)){
        try{
        waitForElementDisplay(OpenAccount, objectValue, pageTimeoutInSeconds);
			clickUsingJavaScript(OpenAccount, "");
			report.reportPass("Open account icon", "Click on open account icon", "Clicked on open account icon");
			waitForLoader();
			 //clickSearchButton();
			clickCOANewInstallButtonUpdated();
        } catch (Exception e) {
        	
                  report.reportFail("Verify Whether open account icon is displayed", "open account icon is displayed", "open account icon is not displayed");
                  report.updateMainReport("comments", "open account icon is not displayed");
                  report.updateMainReport("ErrorMessage", "open account icon is not displayed");
                  logger.error("open account icon is not displayed");
                  captureErrorMsg("open account icon is not displayed");
                  throw new UserDefinedException("open account icon is not displayed");             
                  
               }
		} else {
			clickSearchButton();
		}

	    // For C2G flows
	} else if (get("Application").equalsIgnoreCase("C2G")) {

	    clickCompanyLocation();
	} else {
	    report.reportFail("Execute Test case", "Enter Application and flow type details in run manager sheet.", "Entered Applicatoin: " + get("Application") + " FlowType: " + get("FlowType"));
	    report.updateMainReport("ErrorMessage", "Entered Applicatoin: " + get("Application") + " FlowType: " + get("FlowType"));
	}

    }
    
    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void navigateTo() throws Exception {

	// To increment the navigation iteration
	int i = TestIterator.getIterator(testId);
	TestIterator.setIterator(testId, ++i);

    }


    /**
     * Clicks on COA New Install button.
     * 
     * @throws Exception
     */
    public void clickCOANewInstallButton() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	
	try {
	    // select card type
	    strDescription = "Validation of New Account button.";
	    strExpected = "New account button should be clicked and new window should be opened.";
	    strActual = "Clicked on new account button and opened new account window.";
	    strFailed = "Failed on clicking on new account button.";
	    getUrl = ", URL Launched --> " + returnURL();

	    waitForLoader();
	    try{
	    waitForElementDisplay(btnNewAccount, objectValue, 150);
	    }
	    catch (Exception exe) {
	    	strFailed = "Failed in Dashboard page, Dashboard Page not loaded even after 150 seconds after login Page";
			report.reportFail("Validation of Dashboard Page", "Dashboard Page should be loaded", strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);
		    }
	    waitForLoader();
	    clickUsingJavaScript(btnNewAccount, objectValue);
	    waitForLoader();
	    Thread.sleep(1000);
	    // Switch to newly opened window and maximize it
	    boolean newWindowOpened = switchToWindowWithTitle("Optix New Connect");
	    if (!newWindowOpened) {
		strFailed = "Failed in Dashboard page, new Account window not opened even after 30 seconds post clicking new account link.";
		report.reportFail("Validation of New Account button.", "New account button should be clicked and new window should be opened.", strFailed);
		report.updateMainReport("comments", strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		logger.error(strFailed);
		captureErrorMsg(strFailed);
		throw new UserDefinedException(strFailed);

	    }
	    //maximizeBrowserWindow();
	    report.reportPass(strDescription + getUrl, strExpected, strActual);
	} catch (Exception exe) {
	    if (!isUserDefinedException(exe)) {
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		captureErrorMsg("Failed in Internet section.");
	    }

	    throw exe;
	}

    }

    public void clickCOANewInstallButtonUpdated() throws Exception {

    	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
    	
    	try {
    	    // select card type
    	    strDescription = "Validation of New Account button.";
    	    strExpected = "New account button should be clicked and new window should be opened.";
    	    strActual = "Clicked on new account button and opened new account window.";
    	    strFailed = "Failed on clicking on new account button.";
    	    getUrl = ", URL Launched --> " + returnURL();

    	    waitForLoader();
    	    /*try{
    	    waitForElementDisplay(btnNewAccount, objectValue, 150);
    	    }
    	    catch (Exception exe) {
    	    	strFailed = "Failed in Dashboard page, Dashboard Page not loaded even after 150 seconds after login Page";
    			report.reportFail("Validation of Dashboard Page", "Dashboard Page should be loaded", strFailed);
    			report.updateMainReport("comments", strFailed);
    			report.updateMainReport("ErrorMessage", strFailed);
    			logger.error(strFailed);
    			captureErrorMsg(strFailed);
    			throw new UserDefinedException(strFailed);
    		    }
    	    waitForLoader();
    	    clickUsingJavaScript(btnNewAccount, objectValue);
    	    waitForLoader();
    	    Thread.sleep(1000);*/
    	    // Switch to newly opened window and maximize it
    	    boolean newWindowOpened = switchToWindowWithTitle("Optix Search Account");
    	    if (!newWindowOpened) {
    		strFailed = "Failed in Dashboard page, new Account window not opened even after 30 seconds post clicking new account link.";
    		report.reportFail("Validation of New Account button.", "New account button should be clicked and new window should be opened.", strFailed);
    		report.updateMainReport("comments", strFailed);
    		report.updateMainReport("ErrorMessage", strFailed);
    		logger.error(strFailed);
    		captureErrorMsg(strFailed);
    		throw new UserDefinedException(strFailed);

    	    }
    	    //maximizeBrowserWindow();
    	    report.reportPass(strDescription + getUrl, strExpected, strActual);
    	} catch (Exception exe) {
    	    if (!isUserDefinedException(exe)) {
    		report.reportFail(strDescription + getUrl, strExpected, strFailed);
    		report.updateMainReport("ErrorMessage", strFailed);
    		captureErrorMsg("Failed in opening account.");
    	    }

    	    throw exe;
    	}

        }

    public void clickSearchButton() throws Exception {

    	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
    	try {
    	    // select ordering type
    	    strDescription = "Validation of Account searh button.";
    	    strExpected = "Account search button should be clicked and new window should be opened.";
    	    strActual = "Clicked on Account search button and opened Account search window.";
    	    strFailed = "Unable to click on search button due to unavailability.";
    	   

    	    if(get("SafeGuardOption").equalsIgnoreCase("Yes"))
    	    {
    	     
    	     Set<String> allExistingWindows = driver.getWindowHandles();
    	     
    	     System.out.println(allExistingWindows.size());
    	     
    			    //String productsWindow = driver.getWindowHandle();
    			// Switching to BBE window
    			Set<String> allWindows = driver.getWindowHandles();
    		
    			for (String Child_Window : allWindows) {
    			System.out.println(Child_Window);
    		
    			    //if (!allExistingWindows.contains(Child_Window)) {
    			driver.switchTo().window(Child_Window);
    			waitForLoader();
    			waitForLoader();
    			break;
    			   // }

    	   }
    	    }
    	    getUrl = ", URL Launched --> " + returnURL();
    	    waitForLoader();

    	    switchToDefaultcontent();
    	    waitForLoader();
    	    try{
    	    waitForElementDisplay(btnSearch, objectValue, 150);
    	    }
    	    catch (Exception exe) {
    	    	strFailed = "Failed in Dashboard page, Dashboard Page not loaded even after 150 seconds after login Page";
    			report.reportFail("Validation of Dashboard Page", "Dashboard Page should be loaded", strFailed);
    			report.updateMainReport("comments", strFailed);
    			report.updateMainReport("ErrorMessage", strFailed);
    			logger.error(strFailed);
    			captureErrorMsg(strFailed);
    			throw new UserDefinedException(strFailed);
    		    }
    	    waitForLoader();
    	    clickUsingJavaScript(btnSearch, "");

    	    waitForLoader();
    	    boolean newWindowOpened=switchToWindowWithURL("newconnect");
    	    if (!newWindowOpened) {

    		strFailed = "Failed in Dashboard page, account search window not opened even after 30 seconds post clicking new search link.";
    		report.reportFail("Validation of account search button.", "Account search button should be clicked and new window should be opened.", strFailed);
    		report.updateMainReport("comments", strFailed);
    		report.updateMainReport("ErrorMessage", strFailed);
    		logger.error(strFailed);
    		captureErrorMsg(strFailed);
    		throw new UserDefinedException(strFailed);
    	    }

    	   // maximizeBrowserWindow();

    	    report.reportPass(strDescription + getUrl, strExpected, strActual);
    	} catch (Exception exe) {
    	    if (!isUserDefinedException(exe)) {
    		report.reportFail(strDescription + getUrl, strExpected, strFailed);
    		report.updateMainReport("ErrorMessage", strFailed);
    		captureErrorMsg("Failed in Internet section.");
    	    }


    	    throw exe;
    	}

        }

    /**
     * 
     * Optimized code and enhanced reporting functionality.
     * 
     * @LastModifiedBy -- Shiva Kumar Simharaju
     * @throws Exception
     * @throws UserDefinedException
     */

    public void clickCompanyLocation() throws Exception, UserDefinedException {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	
	try {
	    // select ordering type
	    strDescription = "Validation of company location";
	    strExpected = "Company location should be selected and new window should be opened.";
	    strActual = "Clicked and selected on company location and opened new window.";
	    strFailed = "Failed to select company location in dashboard.";
	    getUrl = ", URL Launched --> " + returnURL();
	    waitForLoader();
        waitForLoader();
	    waitForLoader();

	    String company = get("Company").trim();
	    String location = get("Location").trim();
	    
		// if((!company.isEmpty()) || (!location.isEmpty()) ){
	  
	    if(isDisplayed(DashBoardPopUpC2G, location, 30)){
	    waitForElementDisplay(btnCompanyLocation, objectValue, 100);
	    // Clicking CompanyLocation
	    clickUsingJavaScript(btnCompanyLocation, "");
	    report.reportPass("Dashboard page -- Company location Link.", "Click on company location.", "Clicked on company location.");
	    waitForLoader();

	    if (!company.isEmpty()) {
		// select Company
	    	try{
		selectDropDownUsingVisibleText(LstCompanyName, "", company);
	    	}
	    	catch (Exception exe){
	    	strFailed = "Required Company" +company+ "is not present";
		    report.reportFail("Company Should be Selected", "Company Should be Selected", strFailed);
		    report.updateMainReport("comments", strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		    logger.error(strFailed);
		    captureErrorMsg(strFailed);
		    throw new UserDefinedException(strFailed);
	    	}
	    }
	    if (!location.isEmpty()) {

		selectDropDownUsingVisibleText(LstLocationName, "", location);
	    }
	    click(companysection);
	    report.reportPass("Dashboard page -- select Company.", "Company location should be selected.", "Selected company location: " + company);
	    waitForLoader();
	    waitForLoader();

	    //Clicking Continue Button
	    clickUsingJavaScript(btnContinue, "");
	    report.reportPass("Dashboard page -- continue button.", "Click on continue button.", "Clicked on continue button.");
	    waitForLoader();
	    waitForLoader();
	    
	   }
	    waitForLoader();
	    waitForLoader();
	    waitForLoader();
	    waitForLoader();
	    //Switching the Window
	    boolean newWindowOpened = switchToWindowWithTitle("Optix Search Account");
	    if (!newWindowOpened) {
		
		strFailed = "Failed in Dashboard page, selected company but Account window not opened.";
		report.reportFail("Validation of Company selection", "Company should be selected and new window should be opened.", strFailed);
		report.updateMainReport("comments", strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		logger.error(strFailed);
		captureErrorMsg(strFailed);
		throw new UserDefinedException(strFailed);
	    }
	    //Maximizing Browser Window
	   //maximizeBrowserWindow();
	    waitForLoader();

	    report.reportPass(strDescription + getUrl, strExpected, strActual);
	  
	}catch (Exception exe){
	    if (!isUserDefinedException(exe)){
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		captureErrorMsg("Failed in Internet section.");
	    }

	    throw exe;
	}
	

    }

}
