package com.automation.ui.pages;

//import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
//import org.json.JSONException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_RG_PageObjects;
import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * **SImplexRGPage class represents the RG QAndA Page and interact with the Page.
 * 
 */
public class SimplexRGPage extends Simplex_RG_PageObjects {

    String objectValue = "";
    static boolean windows = InitiateDriver.windows;

    String testId;
    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);
    String strDescription = "", strExpected = "", strEpected = "", strActual = "", strFailed = "", getUrl;
    By by;
    

    
    /**
     * SimplexRGPage constructor invokes the super class constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     * 
     * 
     */
    @SuppressWarnings("unchecked")
    public SimplexRGPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, windows, report, data);
	this.testId = testId;
    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     */
    public static SimplexRGPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexRGPage.class, testId, report, data);
    }

    /**
     * Navigation start for simplex RGP page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void start() throws Exception {

	setIterator();
	System.out.println("RG page..");
	
	waitForLoader();
    switchToDefaultcontent();
	
	if(isDisplayed(MessageAlert1, "", 6))
	{
		clickUsingJavaScript(MessageAlert1, objectValue);
		waitForLoader();
	}
	
if (get("FlowType").contains("Install") && (!isDisplayed(RGQA, objectValue, pageTimeoutInSeconds))) {
		
		report.reportPass("RG Questionaire Should not be displayed", "RG Questionaire Should not be displayed", "RG Questionaire is not displayed");
	}

else
{
	/*
	if (get("GUI_Validations").equalsIgnoreCase("Yes") && get("Application").equalsIgnoreCase("COA")) {
	    UIValidation_Simplex_RG_Dashboard_Page();
	}
	else if (get("RG_GUI").equalsIgnoreCase("Yes") && get("Application").equalsIgnoreCase("C2G")) {
	    HeaderValidations();
	}
	*/

	if (get("FlowType").contains("Change")) { // Skiping RG page for
							  // change scnearios.

		if(get("SubFlowType").contains("EquipmentDropOffEmailcheckSnapShot")){
			//vignesh
			check_EquipmentDropOffEmail_SnapShot();
		}else{
			gotoProductpageForChange();
		}	   


	} else {
		if(get("RG_Selection").equalsIgnoreCase("OpenAccount")){
			
			OpenAccount();
			
		}

		else if (get("RG_Selection").equalsIgnoreCase("Dynamic")) {
	   
		dynamicRGSelection();

	    } else if (get("RG_Selection").equalsIgnoreCase("More")) {
			   
		 ValidateMoreOption();

	    } 
			else if ((get("FlowType").contains("Install")) && (get("ChangeType").contains("SmartCart"))) { //Anu
			   
			smartcartinstall();

		    }
		//Added by PRakash for Snowtickets link - --- 1/7/2019
			else if (get("RG_Selection").equalsIgnoreCase("OptixBotSearch")) {
				   
				OptixBotSearch();
				return;

			    } 
			
			else {
		selectRGQuestoins(get("RG_Selection"));
	    }
	    
	}
	}
    }

    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
	 
	  public void  smartcartinstall() throws Exception,UserDefinedException {
		  
		  String getUrl = "";
    	  String email = get("Email").trim();  
    	 

		    waitForLoader();
		    switchToDefaultcontent();
		    getUrl = ", URL Launched --> " + returnURL();
		
			try{
				//waitForElementDisplay(Smartcartpopup, "", pageTimeoutInSeconds);
				if(Smartcartpopup.isDisplayed()){		
	    		
	    		if (isDisplayed(smartemail))  //Anu
	    		{
	    			if (!email.isEmpty()) {
	    				setText(smartemail, "", email);	  	    				
	    				 report.reportPass("Enter Email address" , " Email address should be selected." ,  " Email address is selected");
	    				
	    		}	}
	    			pageScroll(smartResume);
	    			 clickUsingJavaScript(smartResume, objectValue);	
    				 System.out.println("SmartCart Resume is clicked");
					  report.reportPass("Click on Resume Button" , "Resume Button should be selected." ,  " Resume Button is selected");
    				 waitForLoader();	    			
	    			    	
		}
				else{
					 clickUsingJavaScript(Popupmessage, objectValue);
					 if (isDisplayed(smartemail))  //Anu
			    		{
			    			if (!email.isEmpty()) {
			    				setText(smartemail, "", email);	  	    				
			    				 report.reportPass("Enter Email address" , " Email address should be selected." ,  " Email address is selected");
			    				
			    		}	}
					 pageScroll(smartResume);
	    			 clickUsingJavaScript(smartResume, objectValue);	
    				 System.out.println("SmartCart Resume is clicked");
					  report.reportPass("Click on Resume Button" , "Resume Button should be selected." ,  " Resume Button is selected");
    				 waitForLoader();	
					
				}
				
				}
	  catch (Exception e) {

		    strFailed = "Failed in Smart cart Pop up page,Smart Cart pop up was not displayed even afters " + pageTimeoutInSeconds + "seconds.";
		   logger.error(strFailed);

		    report.updateMainReport("comments", strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		    captureErrorMsg(strFailed);

		    report.reportFail("Check display of Smart Cart Pop up", "Smart Cart Pop up should be loaded and displayed.", "Smart Cart Pop up was not loaded.");
		    throw new UserDefinedException(strFailed);
		}
			
    	
			}
			
    public void navigateTo() throws Exception {

	String cancelOrder = get("cancelOrder");

	// To increment the navigation iteration
	int i = TestIterator.getIterator(testId);
	TestIterator.setIterator(testId, ++i);
	
	waitForLoader();
	waitForLoader();
	switchToDefaultcontent();
	 
	 String windowTitle = driver.getTitle();
	 if(!windowTitle.contains("Optix") && get("FlowType").contains("Install"))
		 switchToWindowWithTitle("Optix New Connect");
	 
	 	waitForLoader();
		waitForLoader();
		switchToDefaultcontent();
	/*	 
	 
	 if( (get("Application").equalsIgnoreCase("C2G"))){
		 if(!getAttribute(btnSnapshot, "", "class").contains("active")){
			 clickUsingJavaScript(btnSnapshot, "");
		 }
		 
		 switchToDefaultcontent();
		 
		 if(getAttribute(btnHeaderArrow,"","class").contains("down-arrow")){
			 clickUsingJavaScript(btnHeaderArrow, "");
		 }
	 }
	 
	 waitForLoader();
	 switchToDefaultcontent();*/
	 
	 if(cancelOrder.isEmpty()){
	 
	 if(isDisplayed(btnRGQtn,"")){
		 
		clickUsingJavaScript(btnRGQtn, "");
	 }
	 
	 waitForLoader();
	 switchToDefaultcontent();
	 
	 for(Element editRGbtn: radEditRGQtn){
		 
		 clickUsingJavaScript(editRGbtn, "");
		 break;
	 }
	 }
	 
	 
	
	
    }

    /**
     * Selects RG questions based on your flow dynamically.
     * 
     * @author Shiva Kumar Simharju
     * @throws Exception
     */
    protected void dynamicRGSelection() throws Exception {

    	HashMap<String, String> installMatrix = new HashMap<String, String>();
    	HashMap<String, String> changeMatrix = new HashMap<String, String>();
    	HashMap<String, String> moveMatrix = new HashMap<String, String>();
    	HashMap<String, String> disconnectMatrix = new HashMap<String, String>();

    	// ****************Install matrix***************
    	
    	String pd = get("PartialDisconnect").trim();
    	String fd = get("FullDisconnect").trim();

    	installMatrix.put("Was this address previously served", "No;Traditional;Streaming;Gotta Have It All;EPIX;Assign New Telephone Number");
    	installMatrix.put("This location is HFWS", "New Resident Moving In;No;No;Negotiate Order;No;Streaming;Gotta Have It All;EPIX;Assign New Telephone Number");
    	installMatrix.put("According to our records, this address already has a pending New Install order",
    		"No;New Resident Moving In and Current Resident Moving Out;No;No;Accepts new number<OR>Negotiate Order;No;Streaming;Gotta Have It All;EPIX;Assign New Telephone Number");
    	installMatrix.put("How does the customer use the internet", "Streaming;Gotta Have It All;EPIX;Assign New Telephone Number");
    	installMatrix.put("Will you need voice service for your business", "Streaming;Gotta Have It All;EPIX;Assign New Telephone Number");
    	installMatrix.put("Will the customer accept a new TN", "Accepts new number");
    	installMatrix.put("What type of plan interests you?", "Traditional;Streaming;Assign New Telephone Number<OR>Gotta Have It All;EPIX;Assign New Telephone Number");
    	installMatrix.put("Discuss Internet", "Discuss Internet;Streaming;Assign New Telephone Number");
    	installMatrix.put("Does the customer want to update the pending order?", "No;No;Customer Does Not Want/Need Internet;Accepts New number");
    	installMatrix.put("Negotiate Order", "Negotiate Order;No<OR>Traditional;Streaming;Assign New Telephone Number<OR>Gotta Have It All;EPIX;Assign New Telephone Number");
    	installMatrix.put("Are you moving into the home?", "No;Discuss Internet;Negotiate Order;No;Streaming;Gotta Have It All;EPIX;Assign New Telephone Number");
    	installMatrix.put("Make the appropriate selection to ensure the order does not go into a Hold For Working Service status.", "New Resident Moving In;No;No;Traditional;Discuss Internet;Negotiate Order;No;Streaming;Gotta Have It All;EPIX;Gotta Have Sports;Assign New Telephone Number");
    	installMatrix.put("Does this order belong to the caller?", "No;New Resident Moving In;No;No;No;Discuss Internet;Negotiate Order;No;Streaming;Gotta Have It;EPIX;Gotta Have Sports;Assign New Telephone Number");
    	installMatrix.put("There is existing service at this location.", "New Resident Moving In;No;No;Negotiate Order;No;Streaming;Gotta Have It All;EPIX;Assign New Telephone Number");
    	
    	
    	// ****************Change matrix***************
    	changeMatrix.put("What is the reason for disconnect", "Answer Not Provided;Answer Not Provided;Process Disconnect;Continue With Disconnect;No<OR>Answer Not Provided;Answer Not Provided");
        changeMatrix.put("Select the cancel reason provided by the customer", "Answer Not Provided;Answer Not Provided");
    	changeMatrix.put("Does this order belong to the caller?", "No;New Resident Moving In And Current Resident Moving Out;No;No;Reissue Order;No;Streaming;Gotta Have It All;EPIX;Assign New Telephone Number");
        changeMatrix.put("Are you moving into the home?", "No;Reissue Order;Streaming;Gotta Have It All;EPIX;Assign New Telephone Number");
        if(!pd.isEmpty()){
        	changeMatrix.put("Select the services the customer would like to disconnect", "All Offers Reviewed, Process PARTIAL Disconnect;No;Disconnect Phone<OR>Disconnect BBE/E");
        }
        if(!fd.isEmpty()){
        	changeMatrix.put("Select the services the customer would like to disconnect", "All Offers Reviewed, Process FULL Disconnect;No;Disconnect Phone<OR>Disconnect BBE/E");
        }
        

    	// ****************Move matrix***************
    	moveMatrix.put("According to our records, this address already has a pending New Install order.", "No;New Resident Moving In;No;Reissue Order;Move All the Services As Is");
    	moveMatrix.put("This location is HFWS", "New Resident Moving In;No;Negotiate Order;No;Streaming;Gotta Have it All (Ultimate)  ;EPIX;Add Phone");
    	moveMatrix.put("This location is HFWS", "New Resident Moving In;No;Negotiate Order;No;Move All the Services As Is");
    	moveMatrix.put("This location is HFWS", "New Resident Moving In;No;Negotiate Order;No;Re Negotiate Services;Basic Internet and Email;Gotta Have it All (Ultimate);EPIX;Add Phone");
    	
    	moveMatrix.put("Next Action", "Negotiate Order;Move All the Services As Is");
    	
    	
    	moveMatrix.put("Next Action", "Negotiate Order;Re Negotiate Services;Add Internet;Basic Internet and Email;Gotta Have it All (Ultimate);EPIX;Add Phone");
    	moveMatrix.put("Next Action", "Negotiate Order;Re Negotiate Services;Add Internet;Basic Internet and Email;Does Not Want TV;Add Phone");
    	moveMatrix.put("Next Action", "Negotiate Order;Re Negotiate Services;Add Internet;Basic Internet and Email;Does Not Want TV;Does Not Want Phone");
    	moveMatrix.put("Next Action", "Negotiate Order;Re Negotiate Services;Does Not Want Internet;No Internet Access;Does Not Want TV;Does Not Want Phone");
    	moveMatrix.put("Next Action", "Negotiate Order;Re Negotiate Services;Does Not Want Internet;Competitor;Add Fios Internet;Basic Internet/E-mail;Does Not Want TV;Does Not Want Phone");
    	moveMatrix.put("We appreciate you being a LOYAL Verizon customer.", "No;Negotiate Services;Streaming;Gotta Have;EPIX;Does Not Want Phone");
    	
    	
    	// ****************Disconnect matrix***************
    	disconnectMatrix.put("", "");

    	waitForPageToLoad(driver);

    	String question = "";

    	if (get("FlowType").toLowerCase().contains("install")) {
    		
    		/*try{
    		String Runmanageraddress = get("Address") + get("Zipcode");
    		String Optixfirstaddress =address_FirsthalfatHeader.getText().toString();
    		String Optixsecondaddress=address_SecondhalfatHeader.getText().toString();
    		String Optixfulladdress= Optixfirstaddress+Optixsecondaddress;
    		
    		String OptixFinaladdress=Optixfulladdress.trim().replace(" ", "").replace(",", "");
    		String RunmanagerFinaladdress=Runmanageraddress.trim().replace(" ", "").replace(",", "");
    		
    		
    		if(RunmanagerFinaladdress.equalsIgnoreCase(OptixFinaladdress)){
    			report.reportPass("compare displayed address at Optix header is same as given in Run manager","Both address should be same", "Both address are same. Address at RunManager-"+RunmanagerFinaladdress+" Address at Optix header-"+OptixFinaladdress); 
    			}
    		else{
    			report.reportFail("compare displayed address at Optix header is same as given in Run manager","Both address should be same", "Both address are not same. Address at RunManager-"+RunmanagerFinaladdress+" Address at Optix header-"+OptixFinaladdress); 
    		}
    		}
    		catch(Exception e){
    			
    			report.reportFail("compare displayed address at Optix header is same as given in Run manager","Both address should be same", "unable to verify due to "+e.toString()); 

    			
    		}*/
    	    question = getQuestion(installMatrix);

    	    if (!question.isEmpty()) {
    		selectRGQuestoins(question);
    	    } else {

    		report.reportFail("Select RG Questions..", "RG questions should be displayed and selected.",
    			"Error: No Questions were found in current scenario...please updated questionare in RG page matrix.");
    		report.updateMainReport("ErrorMessage", "Error: No Questions were found in current scenario...please updated questionare in RG page matrix.");
    		throw new UserDefinedException("Error: No Questions were found in current scenario..please updated questionare in RG page matrix.");
    	    }

    	} else if (get("FlowType").toLowerCase().contains("change")) {

    	    question = getQuestion(changeMatrix);
    	    if (!question.isEmpty()) {
    		selectRGQuestoins(question);
    	    } else {
    		throw new UserDefinedException("Error: No Questions were found in current scenario..please updated questionare in RG page matrix..");
    	    }

    	} else if (get("FlowType").toLowerCase().contains("move")) {

    	    question = getQuestion(moveMatrix);
    	    if (!question.isEmpty()) {
    		selectRGQuestoins(question);
    	    } else {
    		throw new UserDefinedException("Error: No Questions were found in current scenario..please updated questionare in RG page matrix.");
    	    }

    	} else if (get("FlowType").toLowerCase().contains("disconnect")) {

    	    question = getQuestion(disconnectMatrix);
    	    if (!question.isEmpty()) {
    		selectRGQuestoins(question);
    	    } else {
    		throw new UserDefinedException("Error: No Questions were found in current scenario..please updated questionare in RG page matrix.");
    	    }

    	}

        }

    /**
     * Identifies which questioner to be passed in current scenario.
     * 
     * @author Shiva Kumar Simharaju
     * @param matrix
     * @return
     * @throws Exception
     */
    protected String getQuestion(HashMap<String, String> matrix) throws Exception {

	try {

	    String question = "";
	    waitForLoader();
	    waitForPageToLoad(driver);
	    switchToDefaultcontent();
	    System.out.println();
	  /*  if(get("FlowType").equalsIgnoreCase("Install") && (get("Application").equalsIgnoreCase("C2G"))){
	    	
	    	try{
			waitForElementDisplay(AvailableServicesText, objectValue, pageTimeoutInSeconds);
			String x = getTextFromElement(AvailableServicesText, objectValue);
			System.out.println(x);
			report.reportPass("Display Available Services", "Show Available Services", "Available Services are: " + x);
			
			waitForElementDisplay(snapshotText, objectValue, pageTimeoutInSeconds);
			String y = getTextFromElement(snapshotText, objectValue);
			System.out.println(y);
			report.reportPass("Display Alerts and Sales Opportunities", "Show Alerts and Sales Opportunities", "Alerts and Sales Opportunities are: " + y);
			
			WebElement e1=driver.findElement(By.xpath("//div[@ng-click='ConnectionsAvailableServicesPopup();']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", e1);
			report.reportPass("Check Whether able to Click Available Services", "Click Available Services", "Able to Click Available Services");
			waitForLoader();
			String r4=driver.findElement(By.xpath("//div[@data-ui-view='modal']/div")).getText();
			System.out.println(r4);
			report.reportPass("Display Available Services", "Show Available Services", "Available Services are: " + r4);
			WebElement e3=driver.findElement(By.xpath("//button[@ng-click='redirectToDummyState()']"));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", e3);
			report.reportPass("Check Whether able to click Close button in Available Services", "Click Close button in Available Services", "Able to Click Close button in Available Services");
			waitForLoader();
			String m=driver.findElement(By.xpath("//section[@data-ng-controller='HeaderController']")).getText();
			System.out.println(m);
			report.reportPass("Verify Header Text", "Header Text", "Header Text: " +m);
			String o=driver.findElement(By.xpath("//section[@data-ng-controller='HeaderController']/div/ul/li[2]")).getText();
			System.out.println(o);
			report.reportPass("Verify Header Text", "Header Text", "Header Text: " +o);
			String p=driver.findElement(By.xpath("//section[@data-ng-controller='HeaderController']/div/ul/li[3]")).getText();
			System.out.println(p);
			report.reportPass("Verify Header Text", "Header Text", "Header Text: " +p);
	    	}
	    	catch (Exception e) {
	    		
	    	    }

			
		}*/
	    
	    try {
	    	if (get("ChangeType").contains("Disconnect")) {
				waitForElementDisplay(getQuestionerType, "LOYAL", pageTimeoutInSeconds);
			    } else if (get("ChangeType").equalsIgnoreCase("CancelOrder")) {
			    	waitForElementDisplay(getQuestionerType, "cancel reason", pageTimeoutInSeconds);
			    }
			    else if(get("ChangeType").equalsIgnoreCase("Reissue Reason"))
			    {
			    	waitForElementDisplay(getQuestionerType, "Address Validated", pageTimeoutInSeconds);
			    }
			    else if(get("ChangeType").equalsIgnoreCase("Loyalty"))
			    {
			    	waitForElementDisplay(getQuestionerType, "disconnect", pageTimeoutInSeconds);
			    }
			    else{
				waitForElementDisplay(getQuestionerType, "Address Validated", pageTimeoutInSeconds);
			    }
		    	if(Smartcartpopup.isDisplayed())
		    	{
		    		mouseOver(Smartcartpopup, objectValue);
		    		click(Smartcartpopup, objectValue);
		    		
		    	}
		    	if(isDisplayed(PopupClose, objectValue, 3)){
			    	clickUsingJavaScript(PopupClose, objectValue);
			    }

	    	
	    	System.out.println("RG Page-->Negotiating RG");
		/*if(get("FlowType").equalsIgnoreCase("Install") && (get("Application").equalsIgnoreCase("C2G"))){
			waitForElementDisplay(AvailableServicesText, objectValue, pageTimeoutInSeconds);
			String x = getTextFromElement(AvailableServicesText, objectValue);
			System.out.println(x);
			report.reportPass("Display Available Services", "Show Available Services", "Available Services are: " + x);
			
			waitForElementDisplay(snapshotText, objectValue, pageTimeoutInSeconds);
			String y = getTextFromElement(snapshotText, objectValue);
			System.out.println(y);
			report.reportPass("Display Alerts and Sales Opportunities", "Show Alerts and Sales Opportunities", "Alerts and Sales Opportunities are: " + y);
		}*/
	    } catch (Exception e) {
		String strFailed = "RG page is not loaded";
		logger.error(strFailed);

		report.updateMainReport("comments", strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		captureErrorMsg(strFailed);

		report.reportFail("Check display of RG page", "RG page should be loaded and displayed.", "RG page was not loaded.");
		throw new UserDefinedException("RG page is not loaded");
	    }

	    for (Map.Entry<String, String> value : matrix.entrySet()) {

		if (isDisplayed(getQuestionerType, value.getKey(), 1)) {

		    question = value.getValue();
		    System.out.println(getElement(getQuestionerType, value.getKey()).getText());
		  //  processRGAlertValidations(getElement(getQuestionerType, value.getKey()).getText());
		    break;
		}
	    }
	    System.out.println("Selected questioner: " + question);
	    return question;

	} catch (Exception e) {

	    throw e;
	}

    }

    /**
     * Selects RG questions in sequence from given semicolon separated
     * questioner data.
     * 
     * @param semicolonSeperatedQuestions
     * @throws Exception
     */
    public void selectRGQuestoins(String semicolonSeperatedQuestions) throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	String getUrl = "";

	try {
	    strDescription = "Selecting RG Questions";
	    strExpected = "Answering RG questions and completing the flow.";
	    strActual = "Answering RG Questions in RG Page was successful";
	    strFailed = "Answering RG Questions in RG Page was not successful";

	    waitForLoader();
	    switchToDefaultcontent();
	    getUrl = ", URL Launched --> " + returnURL();
	    

	    if (!get("FlowType").equalsIgnoreCase("SuppMove") && !get("RG_Selection").isEmpty()) {

		try {
		    if (get("ChangeType").contains("Disconnect")||get("ChangeType").contains("Loyalty")) {
			waitForElementDisplay(getQuestionerType, "LOYAL", pageTimeoutInSeconds);
		    } 
		    else if (get("ChangeType").contains("CancelOrder")) {
		    	waitForElementDisplay(getQuestionerType, "cancel reason", pageTimeoutInSeconds);
		    }
		    else if (get("ChangeType").equalsIgnoreCase("Renew Bundle/Contract")) 
			{
		    	waitForElementDisplay(getQuestionerType, "LOYAL", pageTimeoutInSeconds);
		    }
		    else{
			waitForElementDisplay(getQuestionerType, "Address Validated", pageTimeoutInSeconds);
		    }
		    if(Smartcartpopup.isDisplayed())
			{
				mouseOver(Smartcartpopup, objectValue);
				click(Smartcartpopup, objectValue);
				
			}
		    if(isDisplayed(PopupClose, objectValue, 3)){
		    	clickUsingJavaScript(PopupClose, objectValue);
		    }
			if(isDisplayed(MessageAlert, "", 6)){
		clickUsingJavaScript(MessageAlert, objectValue);

		waitForLoader();
		
	    }


		    
		    System.out.println("RG Page-->Negotiating RG");
		} catch (Exception e) {

		    strFailed = "RG page is not loaded";
		    logger.error(strFailed);

		    report.updateMainReport("comments", strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		    captureErrorMsg(strFailed);

		    report.reportFail("Check display of RG page", "RG page should be loaded and displayed.", "RG page was not loaded.");
		    throw new UserDefinedException("RG page is not loaded");
		}

		String[] Ques = semicolonSeperatedQuestions.split(";");

		for (String currentAns : Ques) {

		    String[] optionalAns = currentAns.split("<OR>");

		    for (String ans : optionalAns) {
		    	if(ans.contains("#")){
	            	String[] ans2=ans.split("#");
	            	for(String currentans2 : ans2){
	            		clickUsingJavaScript(RGQuestions, currentans2.trim());	
	            		 report.reportPass("Select RG questions", currentans2 + " should be selected.", "selected " + currentans2 + " RG question");
	            	}
	            }

			if (isDisplayed(RGQuestions, ans.trim(), 1)) {
			    clickUsingJavaScript(RGQuestions, ans.trim());
			    report.reportPass("Select RG questions", ans + " should be selected.", "selected " + ans + " RG question");
			    break;
			} else {

			    // Enable below statements validate RG specific RG
			    // questions --- Shiva
			    // report.reportFail("Select RG questions", ans + "
			    // should be selected.", "Unable to select " + v + "
			    // RG question");
			    // throw new UserDefinedException(ans+"Answer was
			    // not available.");
			}

		    }

		    if (btnRGNextList.size() > 0) {

			if (isDisplayed(btnRGNext, "", 0)) {
			    clickUsingJavaScript(btnRGNext, objectValue);	
			    waitForLoader();
			    switchToDefaultcontent();
			}
		    }
		    // Entering Billing Telephone Number in check port
		    // eligibility pag
		    if (txtBTNList.size() > 0) {
			try {

			    if (isDisplayed(txtBTN, "", 0)) {
				setText(txtBTN, objectValue, get("Alternate_Phone_No"));
				waitForLoader();
				switchToDefaultcontent();
			    }
			}

			catch (Exception e) {
			    System.out.println("Billing Telephone Number is not present in this flow as no check portability page ");
			}
		    }

		    // Click on Next button in check port eligibility page
		    if (btnBTNxtList.size() > 0) {
			try {

			    if (isDisplayed(btnBTNxt, "", 0)) {
				clickUsingJavaScript(btnBTNxt, objectValue);
				waitForLoader();
				switchToDefaultcontent();
			    }
			} catch (Exception e) {
			    System.out.println("Next Button present in this flow as no check portability page ");
			}

		    }
		    // Portability Eligible
		    String portNo = get("Alternate_Phone_No").trim();
		    if (btnPortableEligibleList.size() > 0) {
			try {

			    if (isDisplayed(btnPortableEligible, "", 0)) {
				report.reportPass("portability check page", portNo + " should be eligible.", portNo + " is port eligible.");

				// Service provider details
				clickUsingJavaScript(btnPortableEligibleContinue, objectValue);
				waitForLoader();
				waitForLoader();

				setText(btnPortEligName, objectValue, get("Calling_Party_Name"));

				setText(btnPortEligAccNo, objectValue, portNo);
				setText(password, objectValue, "1234");

				clickUsingJavaScript(btnPortEligNext, objectValue);
				waitForLoader();

			    } else {
				System.out.println("Number is not eligible for portability check");
				report.reportFail("portability check page", portNo + " should be eligible.", portNo + " is not port eligible.");
				throw new UserDefinedException(portNo + " Number is not eligible for portability check");
			    }
			} catch (Exception e) {
			    System.out.println(portNo + " Number is not eligible for portability check");
			}

		    }

		}
		
		
		if(isDisplayed(modalOrderConfirm)){
			clickUsingJavaScript(btnOrderConfirmYes, "");
		}
		
		waitForLoader();
		waitForLoader();
		
		//Naresh
		 if(!get("ETF").isEmpty()){ 
				 if(get("FlowType").contains("disconnect") && get("ChangeType").contains("PartialDisconnect")){
					if (isDisplayed(clickSave))
					{
						report.reportPass(strDescription + getUrl, strExpected, strActual);
						click(clickSave);
						waitForLoader();
						waitForLoader();
						waitForLoader();
						waitForLoader();
						Thread.sleep(10000);
						click(isCustomerAwareOfETFRadiobtn, "");
						report.reportPass("Select - Is customer aware of ETF charges radio button","Select - Is customer aware of ETF radio button ", "ETF charges radio button selected");
						waitForLoader();
						click(saveAndMakeMoreChanges, "");
						
					}else{
						strFailed = "Failed on clicking on SAVE after RG selection for Loyalty /Disconnect";
					    logger.error(strFailed);
					    report.reportFail("Click on SAVE in profile information", "SAVE is not selected or clickable.", strFailed);
					}
				}
		 }
		if(get("FlowType").equalsIgnoreCase("Install") || (get("FlowType").contains("Move")) || (get("FlowType").equalsIgnoreCase("MoveAsIs"))){
		if (!isNotDisplayed(addressValidated, 100)) {
			
			if(isDisplayed(EndOfFlow, getUrl, 30)){
				strFailed = "Application Issue, OPO Products Page is not loaded after negotiating RG Questionaire";
			    logger.error(strFailed);
			    report.reportFail("OPO Should be Loaded", "OO, Products Page should be loaded", strFailed);
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);	
			}
			else{
		    strFailed = "Failed in RG Selection, RG questionnaire was not correct..please check the given data.";
		    logger.error(strFailed);
		    report.reportFail("Select RG questions.", "RG questions should be selected according to flow.", strFailed);
		    report.updateMainReport("comments", strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		    captureErrorMsg(strFailed);
		    throw new UserDefinedException(strFailed);
			}
		}
		}
		else if(get("ChangeType").contains("Disconnect")){
			if (!isNotDisplayed(Disconnect, 100)) {
				strFailed = "Failed in RG Selection, RG questionnaire was not correct..please check the given data.";
			    logger.error(strFailed);
			    report.reportFail("Select RG questions.", "RG questions should be selected according to flow.", strFailed);
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);
				
			}
			
		}
		
		waitForLoader();

		report.reportPass(strDescription + getUrl, strExpected, strActual);
		waitForLoader();
	    }
	} catch (Exception exe) {
	    exe.printStackTrace();
	    if (!isUserDefinedException(exe)) {
		report.reportFail(strDescription + getUrl, strExpected, strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
	    }

	    throw exe;
	}

    }

    /**
     * @author Mounika,Padmini
     * @Method: gotoProductpageForChange
     * 
     * 
     * @throws Exception
     */

    public void gotoProductpageForChange() throws Exception, UserDefinedException {

	try {

	    strDescription = "Negotiating Change Flow in RG Page";
	    strExpected = "Negotiate Change Flow in RG Page";
	    strActual = "Negotiate Change Flow in RG Page was successful";
	    strFailed = "Negotiate Change Flow in RG Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();
	    waitForLoader();
	    waitForLoader();	   
	    switchToDefaultcontent();
	    try {
		waitForElementDisplay(snapshot, objectValue, 200);
		System.out.println("Snapshot is Loaded");
		 report.reportPass("Verify Whether Snapshot is Loaded", "Check Whether Snapshot is Loaded", "Snapshot is Loaded");
	    } catch (Exception e) {
	    	System.out.println("Snapshot is not displayed");
	        String strFailed="Snapshot is not Loaded even after 200 seconds";
		    report.reportFail("Verify Whether Snapshot is Loaded", "Check Whether Snapshot is Loaded", "Snapshot is not Loaded even after 200 seconds");
		    report.updateMainReport("comments", strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		    logger.error(strFailed);
		    captureErrorMsg(strFailed);
		    throw new UserDefinedException(strFailed);
	    	
            

	    }
	    waitForLoader();
	    waitForLoader();
	    if(isDisplayed(AlertMessage, "", 5)){
		clickUsingJavaScript(AlertMessage, objectValue);

		waitForLoader();
		
	    }
	    
	    //Prakash -- Suspend restore alert  validation 
	    if (get("ChangeType").contains("VacationSuspendRestore"))
	    {	
	    if(isDisplayed(SuspendRestoreAlert, "", 6)){
	    	 report.reportPass("Verify Vacation Suspend Restore Alert Displayed", "Vacation Suspend Restore Alert Displayed", "Vacation Suspend Restore Alert Displayed");
		    }
	    else
	    {
	    	report.reportFail("Verify Vacation Suspend Restore Alert Displayed", "Vacation Suspend Restore Alert Not Displayed", "Vacation Suspend Restore Alert Not Displayed");
	    }
	    }
	    
	    //Prakash -- Suspend restore alert  validation 
		if(isDisplayed(MessageAlert, "", 6)){
		clickUsingJavaScript(MessageAlert, objectValue);

		waitForLoader();
		
	    }
		
	    waitForLoader();
	    waitForLoader();
	    if(isDisplayed(NotificationMessage, "", 3)){
		clickUsingJavaScript(NotificationMessage, objectValue);

		waitForLoader();
		}
	    if(!get("ETF").isEmpty()){ 
	    checkETFCharge();
	    }
	    if(get("Application").equals("C2G") && !get("FlowType").equalsIgnoreCase("Move")){
	    	clickDoCCAgreement();
	    	switchToDefaultcontent();
	    }
	    
	    

	    if (!getAttribute(productsButton, "", "class").contains("active")) {
		clickUsingJavaScript(productsButton, objectValue);
		report.reportPass("Check whether Global naviagtor is clicked", "Check whether Global naviagtor is clicked", "Global naviagtor is clicked");

	    }

	    waitForLoader();
	    switchToDefaultcontent();
	    if(isDisplayed(PopupClose, objectValue, 3)){
	    	clickUsingJavaScript(PopupClose, objectValue);
	    }
	    
	    
	    List<WebElement> lst = driver.findElements(By.xpath("//div[@ng-repeat='order in Orders']"));

	  		for (int i = 0; i < lst.size(); i++) {
	  			System.out.println(lst.size());
	  			if(lst.size()>1){
	  				if (!getAttribute(expandOrder, objectValue, "class").contains("open")) {
	  					clickUsingJavaScript(expandOrder, objectValue);	
	  					 waitForLoader();
	  					 waitForLoader();
	  					 break;
	  					
	  				}
	  			}
	  		    
	  		    }

	  		 //////// *********Normal Change Flow***********/////////
		    if (get("ChangeType").equalsIgnoreCase("Change")) {
			try {

			    
	            if(isDisplayed(waitForChangeServices, objectValue, 30)){
		
	                }
	            else if(isDisplayed(IWantTolink, objectValue, 1)){
		
	                   }
	               else{
						strFailed = "Failed in RG Page, Change serivces was not loaded even after " + pageTimeoutInSeconds + " seconds.";
						report.reportFail("Select change serivces in RG page.", "Change services should be selected.", "Product services page is not loaded even after 200 seconds.");
						report.updateMainReport("ErrorMessage", "Product services page is not loaded even after 200 seconds.");
						report.updateMainReport("comments", strFailed);			   
					    logger.error(strFailed);
					    captureErrorMsg(strFailed);
					    throw new UserDefinedException(strFailed);
	                     }
				/*waitForElementDisplay(waitForChangeServices, "", pageTimeoutInSeconds);
				
				waitForLoader();

			    } catch (Exception e) {
			    	strFailed = "Failed in RG Page, Change serivces was not loaded even after " + pageTimeoutInSeconds + " seconds.";
					report.reportFail("Select change serivces in RG page.", "Change services should be selected.", "Product services page is not loaded even after 60 seconds.");
					report.updateMainReport("ErrorMessage", "Product services page is not loaded even after 60 seconds.");
					report.updateMainReport("comments", strFailed);			   
				    logger.error(strFailed);
				    captureErrorMsg(strFailed);
				    throw new UserDefinedException(strFailed);
			    }
			    */

			    if (isDisplayed(btnChangeExistingServices, "",10)) {

				try {

				   // waitForElementDisplay(btnChangeExistingServices, objectValue, pageTimeoutInSeconds);

				    clickUsingJavaScript(btnChangeExistingServices, objectValue);
				    report.reportPass("Check whether Change existing services is clicked", "Check whether Change existing services is clicked", "Change existing services is clicked");
				    if(get("Application").equals("C2G")){
				    	clickDoCCAgreement();
				    }
                         waitForLoader();
                         waitForLoader();
				    	
                  
				    if(isDisplayed(saleswindow, objectValue, 3)){
				    	try{
				    		report.reportPass("Check whether Sales popup is displayed", "Check whether Sales popup is displayed", "Sales popup is displayed");
				    	clickUsingJavaScript(saleswindow, objectValue);
				    	report.reportPass("Save button should be clicked in Sales popup", "Save button should be clicked in Sales popup", "Save button is clicked in Sales popup");
				    	}
				    	catch(Exception e){
				    		report.reportFail("Save button should be clicked in Sales popup", "Save button should be clicked in Sales popup", "Save button is not clicked in Sales popup");
				    	}
				    	 
				    	}

				    	waitForLoader();
				    	waitForLoader();
				    	
				    	if(isDisplayed(errormsg, objectValue, 2)){
				    		String s=getTextFromElement(errormsg, objectValue);
				    		strFailed = "Getting following error after clicking Change Existing Services: "+s;
							report.reportFail("Click change serivces in RG page.", "Change services should be Clicked.", "Product services page is not loaded after clicking Change Existing Services due to: "+s);
							report.updateMainReport("ErrorMessage", strFailed);
							report.updateMainReport("comments", strFailed);			   
						    logger.error(strFailed);
						    captureErrorMsg(strFailed);
						    throw new UserDefinedException(strFailed);
				    	}
				    	
				    	
				}

				catch (Exception e) {

					strFailed = "Failed in RG Page, Change serivces was not loaded even after " + pageTimeoutInSeconds + " seconds.";
					report.reportFail("Select change serivces in RG page.", "Change services should be selected.", "Product services page is not loaded even after 200 seconds.");
					report.updateMainReport("ErrorMessage", "Product services page is not loaded even after 200 seconds.");
					report.updateMainReport("comments", strFailed);			   
				    logger.error(strFailed);
				    captureErrorMsg(strFailed);
				    throw new UserDefinedException(strFailed);
				}
				

			    } else if (isDisplayed(IWantTolink, "",10)) {

				try {

				    clickUsingJavaScript(IWantTolink, objectValue);
				    waitForLoader();

				    clickUsingJavaScript(Change_Existing_Services_under_I_want_To, objectValue);

				    report.reportPass("Click Change Existing Services Button in I Want To Link", "Click Change Existing Services Button if Exists in I Want to Link",
					    "Clicking Change Existing Services button in I Want To Link");
				    
				    waitForLoader();
			    	
				    if(isDisplayed(saleswindow, objectValue, 3)){
				    	try{
				    		report.reportPass("Check whether Sales popup is displayed", "Check whether Sales popup is displayed", "Sales popup is displayed");
				    	clickUsingJavaScript(saleswindow, objectValue);
				    	report.reportPass("Save button should be clicked in Sales popup", "Save button should be clicked in Sales popup", "Save button is clicked in Sales popup");
				    	}
				    	catch(Exception e){
				    		report.reportFail("Save button should be clicked in Sales popup", "Save button should be clicked in Sales popup", "Save button is not clicked in Sales popup");
				    	}
				    	 
				    	}

				    	waitForLoader();
				    	waitForLoader();
				    	
				}

				catch (Exception e) {

					strFailed = "Failed in RG Page, Change serivces was not loaded even after " + pageTimeoutInSeconds + " seconds.";
					report.reportFail("Select change serivces in RG page.", "Change services should be selected.", "Product services page is not loaded even after 200 seconds.");
					report.updateMainReport("ErrorMessage", "Product services page is not loaded even after 200 seconds.");
					report.updateMainReport("comments", strFailed);			   
				    logger.error(strFailed);
				    captureErrorMsg(strFailed);
				    throw new UserDefinedException(strFailed);
				}
			    } else {
			    	strFailed = "Failed in RG Page, Change serivces was not loaded even after " + pageTimeoutInSeconds + " seconds.";
					report.reportFail("Select change serivces in RG page.", "Change services should be selected.", "Change serivces was not loaded even after " + pageTimeoutInSeconds + " seconds.");
					report.updateMainReport("ErrorMessage", "Change serivces was not loaded even after " + pageTimeoutInSeconds + " seconds.");
					report.updateMainReport("comments", strFailed);			   
				    logger.error(strFailed);
				    captureErrorMsg(strFailed);
				    throw new UserDefinedException(strFailed);

			    }
			    waitForLoader();
				   
			    if(isDisplayed(DryLoopHeader, objectValue, 5))
			    {
			    	String changetype = get("StackDisconnectOption").trim();
			    	
			    	pageScroll(DryLooptype, changetype, true);
			    	clickUsingJavaScript(DryLooptype, changetype);
			    	Thread.sleep(2000);
			    	report.reportPass("Click on Dryloop type Radio Button", "Dryloop type Radio Button Should be Clicked", "Dryloop type Radio Button is clicked");
			    	clickUsingJavaScript(Btnyes, "");
			    	report.reportPass("Click on Yes Button", "Yes Button Should be Clicked", "Yes Button is clicked");
			    	waitForLoader();
			    	waitForLoader();
			    	waitForLoader();
			    	
			    	if(isDisplayed(saleswindow, objectValue, 10)){
			    		
			    	     clickUsingJavaScript(saleswindow, objectValue);
			    	     }
			    }
			    
			    if(isDisplayed(HOAAddressAlert, "", 5))
			    {
			    	String HOAErrorAlertMessage = HOAAddressAlert.getText().trim();
			    	report.reportPass("Validate that HOA Alert Error Message is Displaying or not", "HOA Alert Error Message Should be Displayed", "HOA Alert Error message is Displaying"+HOAErrorAlertMessage);
			    	System.out.println("HOA Error Alert Message:"+HOAErrorAlertMessage);
			    }
			    
			    if(isDisplayed(HOAerror, "", 5))
			    {
			    	String HOAErrorMessage = HOAerror.getText().trim();
			    	report.reportPass("Validate that HOA Error Message is Displaying or not", "HOA Error Message Should be Displayed", "HOA Error message is Displaying"+HOAErrorMessage);
			    	System.out.println("HOA Error Message:"+HOAErrorMessage);
			    }  
			    
			 Thread.sleep(5000);
			    
			    if(!isNotDisplayed(OPOPage, 100)){
			    	
			    	strFailed = "Application Issue, Failed in loading OPO Page after clicking Change Existing Services even after 180 seconds";
				    logger.error(strFailed);
				    report.reportFail("Negotiate Change Existing Services", "RG Page should not be displayed after clicking Change Existing services", strFailed);
				    report.updateMainReport("comments", strFailed);
				    report.updateMainReport("ErrorMessage", strFailed);
				    captureErrorMsg(strFailed);
				    throw new UserDefinedException(strFailed);
			    	
			    }
			} catch (Exception e) {
			    e.printStackTrace();
			    report.reportFail("Select Change serivces in RG page.", "Change services should be selected.",
				    "Not able to Click Change Existing Services button in I Want to Link due to Object not dispalyed");
			    report.updateMainReport("comments", "Not able to Click Change Existing Services button in I Want to Link due to Object not dispalyed");	
			    report.updateMainReport("ErrorMessage", "Not able to Click Change Existing Services button in I Want to Link due to Object not dispalyed");
			    throw new UserDefinedException("Failed in Change Existing Services Page");
			}
		    }
	    
////////*********Change Supp Address***********///////// Anu - March 20, 2018
	    
	    else if (get("ChangeType").equalsIgnoreCase("ChangeAddress")){
	    	
			waitForLoader();		
		
	        
			if (isDisplayed(ChangeAddresslink, "")) {
				String txtZipcode = get("Zipcode").trim();
		        String txtAddress = get("StreetAddress").trim();
				
			    try {
			    	
				clickUsingJavaScript(ChangeAddresslink, objectValue);
				System.out.println("Clicked on Change address");
				report.reportPass("Click on Change Address link", "Click on Change Address link if Exists", "Clicking on Change Address Link");
				 if (isDisplayed(zipCode, strFailed, 3)) {
					 clearText(zipCode, "");
	                   setText(zipCode, "", txtZipcode);
	                   
	                   System.out.println("Entered Zip Code");
	               	
	                   report.reportPass("Address search tab -- enter zip code.", "Zip code should be entered.", "Entered "+txtZipcode+" zip code.");
	                   waitForLoader();
	                   Actions action = new Actions(driver);
	                      action.moveToElement(driver.findElement(By.xpath("//input[@id='addressAddress']"))).click().build().perform();
	        
	               }
	               waitForLoader();
	               if (isDisplayed(address, strFailed, pageTimeoutInSeconds)) {
	                   
	                   clickUsingJavaScript(address, txtAddress);
	                   clearText(address, "");
	                setText(address, "", txtAddress);
	                System.out.println("Entered  Address");
	                report.reportPass("Address search tab -- Enter address.", "Address should be entered.", "Entered "+txtAddress+" address.");
	                report.reportPass("Address search tab -- Enter address.", "Address should be entered.", "Entered "+txtAddress+" address.");
	              
	                if (isDisplayed(btnNext, "")){
	                    clickUsingJavaScript(btnNext, "");
	                System.out.println("Clicked Next Button on Address Search");
	                    report.reportPass("Click on next button of Address search tab.", "Next button should be clicked on address search tab.", "Clicked on Next button of address search tab.");

	                }  
	                waitForLoader();
	                waitForLoader();
	                if (isDisplayed(firstMultipleAddress, "", 3)) {
	                    clickUsingJavaScript(firstMultipleAddress, "");	                    
	                    System.out.println("Clicked Next on First Address Search");
	                    report.reportPass("Click on First Address in the Multiple Addresses", "First Address in the Multiple Addresses should be clicked", "Clicked on First Address in the Multiple Addresses");
	                }
	                if (isDisplayed(btnNext, "", 3)){
	                	clickUsingJavaScript(btnNext, "");
	                    System.out.println("Clicked Next on Verify Address ");
	                    waitForLoader();
	                    waitForLoader();
	                    report.reportPass("Click on Next Button", "Next Button should be clicked", "Clicked on Next Button");
	                }
	                if ((isDisplayed(salesProfileInformationTab, "", 5))) {  
	                	
	                        clickUsingJavaScript(salesProfileSave, "");
	                        System.out.println("Clicked Next on Sales Info Page");
	                        waitForLoader();
	             	   report.reportPass(strDescription, strExpected, strActual); 
	                }
	                waitForLoader();
	                if ((isDisplayed(currentActiveTab, "availableServices", 6))) {
	             	
	             	   if (isDisplayed(btnNext, "",6)) {
	                        clickUsingJavaScript(btnNext, "");
	                        System.out.println("Clicked Next on AvailableServices Page");
	                        report.reportPass("Click on next button of verify Address tab.", "Next button should be clicked on verify address tab.", "Clicked on Next button of verify address tab.");
	                        waitForLoader();
	                        waitForLoader();
	                        waitForLoader();
	                        waitForLoader();
	                        waitForLoader();
	                        waitForLoader();
	                    }
	                  
	                }                
	            
	               }
			    } catch (Exception e) {
			    	
				report.reportFail("Select on Change Address Link in RG page.", "Change Address Link should be Clicked", "n Change Address Link is not displayed");
				report.updateMainReport("comments", "Change Address Link is not displayed");	
				report.updateMainReport("ErrorMessage", "Change Address Link is not displayed");
				 throw new UserDefinedException("Failed in Change Address Link Page");
			    }
	    }
	    }
	    //////// *********Change Ownership Flow***********/////////

	    else if (get("ChangeType").equalsIgnoreCase("Ownership")) {

		waitForLoader();
		waitForLoader();

		if (isDisplayed(IWantTolink, "")) {
		    try {
			clickUsingJavaScript(IWantTolink, objectValue);
			report.reportPass("Click I Want To Link", "Click I Want To Link if Exists", "Clicking  I Want To Link");
			
		    } catch (Exception e) {

			report.reportFail("Select I Want To Link in RG page.", "I Want To Link should be Clicked", "I Want to Link is not displayed");
			report.updateMainReport("comments", "I Want to Link is not displayed");	
			report.updateMainReport("ErrorMessage", "I Want to Link is not displayed");
			 throw new UserDefinedException("Failed in Change Existing Services Page");
		    }

		}
		if (isDisplayed(ChangeOfOwnership, "")) {
		    try {

			clickUsingJavaScript(ChangeOfOwnership, objectValue);
			waitForLoader();
	    	waitForLoader();
	    	
			if(isDisplayed(saleswindow, objectValue, 6)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    	waitForLoader();
			report.reportPass("Click Change Ownership Button", "Click Change Ownership Button if Exists", "Clicking Change Ownership button");
		    } catch (Exception e) {

			report.reportFail("Click Change Ownership Button in RG page.", "Click Change Ownership Button if Exists", "Change Ownership button is not displayed");
			report.updateMainReport("comments", "Change Ownership button is not displayed");	
			report.updateMainReport("ErrorMessage", "Change Ownership button is not displayed");
			 throw new UserDefinedException("Failed in Change Services Page");
		    }

		} else {
		    try {
			waitForElementDisplay(btnChangeOfOwnership, objectValue, 20);

			clickUsingJavaScript(btnChangeOfOwnership, objectValue);
              waitForLoader();
              waitForLoader();
              waitForLoader();
  	    	
			if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    	waitForLoader();
			report.reportPass("Click Change Ownership Button", "Click Change Ownership Button if Exists", "Clicking Change Ownership button");
		    } catch (Exception e) {

		    	report.reportFail("Click Change Ownership Button in RG page.", "Click Change Ownership Button if Exists", "Change Ownership button is not displayed");
				report.updateMainReport("comments", "Change Ownership button is not displayed");	
				report.updateMainReport("ErrorMessage", "Change Ownership button is not displayed");
				 throw new UserDefinedException("Failed in Change Services Page");
		    }

		}
		if(isDisplayed(errormsg, objectValue, 2)){
    		String s=getTextFromElement(errormsg, objectValue);
    		strFailed = "Getting following error after clicking Change Existing Services: "+s;
			report.reportFail("Click change serivces in RG page.", "Change services should be Clicked.", "Product services page is not loaded after clicking Change Existing Services due to: "+s);
			report.updateMainReport("ErrorMessage", strFailed);
			report.updateMainReport("comments", strFailed);			   
		    logger.error(strFailed);
		    captureErrorMsg(strFailed);
		    throw new UserDefinedException(strFailed);
    	}
    	

	    }
	    //////// *********Change PPV Flow***********/////////

	    else if (get("ChangeType").equalsIgnoreCase("PPVFlow")) {

		waitForLoader();
		waitForElementDisplay(btnChangePPV, objectValue, 20);

		clickUsingJavaScript(btnChangePPV, objectValue);
		waitForLoader();
        waitForLoader();
        waitForLoader();
		if(isDisplayed(saleswindow, objectValue, 10)){
	    	clickUsingJavaScript(saleswindow, objectValue);
	    	}

	    	waitForLoader();
		report.reportPass("Click Change PPV Button", "Click Change PPV Button if Exists", "Clicking Change PPV Button");

	    waitForPageToLoad(driver);
	    waitForLoader();
	    
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    
	    if(isDisplayed(PPVTAB))
	    {
	    	
	    	String eventtype = get("StackDisconnectOption").trim();
	    	String OrderSubmit = get("ProccedForCancel").trim();
	    	
	    	if(isDisplayed(SearchType))
	    	{
	    		pageScroll(SearchType);
	    		clickUsingJavaScript(SearchType, objectValue);
	    		
	    		selectDropDownUsingValue(EventType, "", eventtype);
	    		waitForLoader();
	    		clickUsingJavaScript(BtnGetEvents, "");
	    		
	    		report.reportPass("Click Get PPV Events Button", "Click Get PPV Events Button if Exists", "Clicking Get PPV Events Button");
	    		
	    		waitForLoader();
	    		waitForLoader();
	    		
	    		switchToDefaultcontent();
	    	    switchToFrame("IfProducts");
	    	    
	    	    String p="0";
	    		for(int i=1; i<=availableEvents.size(); i++)
	    		{
	    			
	    			if(i<4){
	    				 p= "0"+i;
	    			}
	    			else{
	    				break;
	    			}
	    			
	    			clickUsingJavaScript(EventIDs, p);
	    		}
	    		waitForLoader();
	    		pageScroll(OneTimeEvents);
	    		report.reportPass("Select All PPV Events", "All PPV Events should be Selected", "Clicking All PPV Events");
	    		clickUsingJavaScript(BtnAddSelectedEvents, "");
	    		waitForLoader();
	    		pageScroll(SelectedEvents);
	    		report.reportPass("Displayed Selected All PPV Events", "Selected All PPV Events should be Displayed ", "Displaying Selected All PPV Events");
	    	}
	    	
	    	switchToDefaultcontent();
	    	switchToFrame("IfProducts");
	    	
	    	if(isDisplayed(BtnExceedLimit)){
	    		clickUsingJavaScript(BtnExceedLimit, "");
	    		waitForLoader();
	    		waitForLoader();
	    		
	    	}
	    	
	    	switchToDefaultcontent();
	    	switchToFrame("IfProducts");
	    	
	    	if(isDisplayed(errormessagePPV)){
	    	    String errormsg=getTextFromElement(errormessagePPV, objectValue);
	    	    System.out.println(errormsg);
	    	    strFailed = errormsg;
		    	report.reportFail("Select PPV Events", "PPV events should be selected", "PPV events have not been successfully selected");
				report.updateMainReport("ErrorMessage", strFailed);
	    		
	    	}
	    	
	    	switchToDefaultcontent();
	    	switchToFrame("IfProducts");
	    	
		    if(OrderSubmit.equalsIgnoreCase("Submit"))
		    {
		    	pageScroll(BtnSubmitOrder);
		    	clickUsingJavaScript(BtnSubmitOrder, "");
		    	switchToDefaultcontent();
		    	String mon = MON.getText();
		    	System.out.println("MON Number:- " +mon);
		    	report.reportPass("Click the Submit Order Button", "Submit Order Button Should be Clicked", "Clicking Submit Order Button:   "+mon);
		    	waitForLoader();
		    	waitForLoader();
		    	if(isDisplayed(DrpcloseReasonForCall))
		    	{
		    		pageScroll(DrpcloseReasonForCall);
		    		selectDropDownUsingVisibleText(DrpcloseReasonForCall, "", "Sales / Acquisition");
		    		waitForLoader();
		    		pageScroll(NotesText);
		    		setText(NotesText, "", "Test");
		    		report.reportPass("Click the Btn SaveandClose Button", "Btn SaveandClose Button Should be Clicked", "Clicking Btn SaveandClose Button");
		    		pageScroll(BtnSaveClose);
		    		clickUsingJavaScript(BtnSaveClose, "");
		    		
		    	}
		    }
		    else
		    {
		    	pageScroll(BtnSubmitOrder);
		    	switchToDefaultcontent();
		    	String mon = MON.getText();
		    	System.out.println("MON Number:- " +mon);
		    	report.reportPass("Not Click the Submit Order Button", "Submit Order Button Should not be Clicked", "Not Clicking Submit Order Button:   "+mon);
		    }
	    	
	    }
	    
	    
	    }
	    //////// *********Change Programming Only Flow***********/////////

	    else if (get("ChangeType").equalsIgnoreCase("Programming")) {
		waitForLoader();

		if (isDisplayed(IWantTolink, "")) {
		    try {

			clickUsingJavaScript(IWantTolink, objectValue);
			report.reportPass("Click I Want To Link", "Click I Want To Link if Exists", "Clicking  I Want To Link");
		    } catch (Exception e) {

		    	report.reportFail("Select I Want To Link in RG page.", "I Want To Link should be Clicked", "I Want to Link is not displayed");
				report.updateMainReport("comments", "I Want to Link is not displayed");	
				report.updateMainReport("ErrorMessage", "I Want to Link is not displayed");
				 throw new UserDefinedException("Failed in Change Existing Services Page");
		    }

		}
		if (isDisplayed(ChangeProgramming, "")) {
		    try {

			clickUsingJavaScript(ChangeProgramming, objectValue);
			
			report.reportPass("Click Change Programming Only Button", "Click Change Programming Only Button if Exists", "Clicking Change Programming Only Button");
			waitForLoader();
            waitForLoader();
            waitForLoader();
			if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    	waitForLoader();
		    	if(isDisplayed(errormsg, objectValue, 2)){
		    		String s=getTextFromElement(errormsg, objectValue);
		    		strFailed = "Getting following error after clicking Clicking Change Programming Only Button: "+s;
					report.reportFail("Click Clicking Change Programming Only Button in RG page.", "Change services should be Clicked.", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					report.updateMainReport("comments", strFailed);			   
				    logger.error(strFailed);
				    captureErrorMsg(strFailed);
				    throw new UserDefinedException(strFailed);
		    	}
		    	
		    } catch (Exception e) {

			report.reportFail("Select Programming Only Button in RG page.", "Programming Only Button should be Clicked", "Programming Only Button is not displayed");
			report.updateMainReport("comments", "Programming Only Button is not displayed");	
			report.updateMainReport("ErrorMessage", "Programming Only Button is not displayed");
			 throw new UserDefinedException("Failed in Change Existing Services Page");
		    }
		} else {
		    try {

			waitForElementDisplay(btnChangeProgramming, objectValue, 20);

			clickUsingJavaScript(btnChangeProgramming, objectValue);
			report.reportPass("Click Change Programming Only Button", "Click Change Programming Only Button if Exists", "Clicking Change Programming Only Button");
			waitForLoader();
            waitForLoader();
            waitForLoader();
			if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    	waitForLoader();
		    	if(isDisplayed(errormsg, objectValue, 2)){
		    		String s=getTextFromElement(errormsg, objectValue);
		    		strFailed = "Getting following error after clicking Clicking Change Programming Only Button: "+s;
					report.reportFail("Click Clicking Change Programming Only Button in RG page.", "Change services should be Clicked.", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					report.updateMainReport("comments", strFailed);			   
				    logger.error(strFailed);
				    captureErrorMsg(strFailed);
				    throw new UserDefinedException(strFailed);
		    	}
		    	
		    } catch (Exception e) {

		    	report.reportFail("Select Programming Only Button in RG page.", "Programming Only Button should be Clicked", "Programming Only Button is not displayed");
				report.updateMainReport("comments", "Programming Only Button is not displayed");	
				report.updateMainReport("ErrorMessage", "Programming Only Button is not displayed");
				 throw new UserDefinedException("Failed in Change Existing Services Page");
		    }
		}

		waitForLoader();
		waitForLoader();
	    }

	    //////// *********Change Stacked Order Flow***********/////////

	    else if (get("ChangeType").equalsIgnoreCase("StackedOrder")) {

			waitForLoader();
			waitForLoader();
		try {
		    // Thread.sleep(5000);
		    waitForElementDisplay(txtStack, objectValue, pageTimeoutInSeconds);

		    clickUsingJavaScript(btnChangeStackOrder, objectValue);
		    
		    report.reportPass("Click Change Stack Order Button", "Click Change Stack Order Button if Exists", "Clicking Change Stack Order Button");
		    waitForLoader();
            waitForLoader();
            waitForLoader();
		    if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    waitForLoader();
		    waitForLoader();
		}

		catch (Exception exe) {
		    report.reportFail("Select Stacked Order in RG Page", "Stacked Order Should be Selected", "Stack Order button is not displayed");
		    report.updateMainReport("comments", "Stack Order button is not displayed");
		    report.updateMainReport("ErrorMessage", "Stack Order button is not displayed");
		    throw new UserDefinedException("Failed in Change Existing Services Page");

		}

	    }
	    //////// *********Change Supp Order Flow***********/////////

	    else if (get("ChangeType").equalsIgnoreCase("SuppOrder")) {
	    	waitForLoader();
	    	
	    	// Mounika changes on 01/09/2019
	    	if(get("Application").equalsIgnoreCase("C2G")) {
	    		
	    		report.reportPass("C2G should not allow Supp Order", "C2G should not allow Supp Order", "Supp Order is not allowed in C2G");
	    	}
	    	else {
		
		try {
			// Gopal changes on 10/04/2017 
			
			if(isDisplayed(NotificationMessage, "", 3))
			{
				clickUsingJavaScript(NotificationMessage, objectValue);
			
				waitForLoader();
			}

			int NoOfPendingOrders  =  driver.findElements(By.xpath("//*[@ng-class = 'order.accordionClass' and @aria-expanded = 'true']")).size();
			
			if(NoOfPendingOrders>1)
			{
				
				if(isDisplayed(PendingAccountDetails, ""))
				{
					pageScroll(PendingAccountDetails);
					clickUsingJavaScript(PendingAccountDetails, objectValue);
					waitForLoader();
				}
				
			}
		    waitForElementDisplay(btnChangeSuppOrder, objectValue, pageTimeoutInSeconds);

		    clickUsingJavaScript(btnChangeSuppOrder, objectValue);
		    if(isDisplayed(UpdateOrder, objectValue, 10))
		    {
		    	clickUsingJavaScript(UpdateOrder, objectValue);
		    	waitForLoader();
		    }

		    report.reportPass("Click Update Order Button", "Click Update Order Button if Exists", "Clicking Update Order Button");
		    waitForLoader();
            waitForLoader();
            waitForLoader();
		    if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    	waitForLoader();
		    waitForLoader();
		} catch (Exception exe) {
		    report.reportFail("Select Supp Order in RG Page", "Supp Order Should be Selected", "Supp Order button is not displayed");
		    report.updateMainReport("comments", "Supp Order button is not displayed");
		    report.updateMainReport("ErrorMessage", "Supp Order button is not displayed");
		    throw new UserDefinedException("Failed in Change Existing Services Page");

		}
	    	}

	    }
	    //////// *********Change Cancel Order Flow***********/////////

	    else if (get("ChangeType").contains("CancelOrder")) {
	    	String ProccedForCancel = get("ProccedForCancel").trim();
		waitForLoader();
		
		try{
			try{
				if (isDisplayed(msgbar, objectValue, 2))
				{
					String msgShip = msgbar.getText().toString();
					report.reportPass("Verify Equipment Shipped message", "Equipment Shipped message should be displayed", "Equipment Shipped message is displayed - "+msgShip);
				}	
				else
				{
					report.reportPass("Verify Equipment Shipped message", "Equipment Shipped message should be displayed", "Equipment Shipped message is not displayed");
				}
				waitForLoader();
			}
			catch(Exception e){
				report.reportFail("Verify Equipment Shipped message", "Equipment Shipped message should be displayed", "unable to verify due to "+e);
			}
			
			// Click on Cancel Order_pending order
		try {
		    waitForElementDisplay(btnChangeCancelOrder, objectValue, pageTimeoutInSeconds);

		    clickUsingJavaScript(btnChangeCancelOrder, objectValue);

		    report.reportPass("Click Cancel Order Button", "Click Cancel Order Button if Exists", "Clicking Cancel Order Button");
		    

		    	waitForLoader();
		    waitForLoader();

		} catch (Exception exe) {
		    report.reportFail("Select Cancel Order in RG Page", "Cancel Order Should be Selected", "Cancel Order button is not dispalyed");
		    report.updateMainReport("comments", "Cancel Order button is not dispalyed");
		    report.updateMainReport("ErrorMessage", "Cancel Order button is not dispalyed");
		    throw new UserDefinedException("Failed in Change Existing Services Page");

		}
		waitForLoader();
		if (get("RG_Selection").equalsIgnoreCase("Dynamic")) {

		    dynamicRGSelection();

		} else if(!get("RG_Selection").equalsIgnoreCase("Dynamic") && (!get("RG_Selection").isEmpty())) {
		    selectRGQuestoins(get("RG_Selection"));
		}

		waitForLoader();
		if(isDisplayed(CancelComments, objectValue, 3)){
		setText(CancelComments, objectValue, "Test Cancelled");	
	    report.reportPass("Enter Cancel Comments on 'Cancel confirmation' pop up", "Cancel Commnents should be enterable on 'Cancel confirmation' pop up", "Cancel Comments is entered on 'Cancel confirmation' pop up");
		}
		
	 	// Dinesh 03/08/2018 --> Dont Cancel
		
		if(!get("CancelType").contains("withoutSubmission")){	
		
		if(isDisplayed(btnCancel2)){
			clickUsingJavaScript(btnCancel2, objectValue);
			report.reportPass("Click 'cancel button' on 'Cancel confirmation' pop up", "'cancel button' on 'Cancel confirmation' pop up should be clickable", "'cancel button' on 'Cancel confirmation' pop up is clicked");

		}
		else if(isDisplayed(btnCancel2)){
			clickUsingJavaScript(btnCancel2, objectValue);
			report.reportPass("Click 'cancel button' on 'Cancel confirmation' pop up", "'cancel button' on 'Cancel confirmation' pop up should be clickable", "'cancel button' on 'Cancel confirmation' pop up is clicked");

		}
		else if(isDisplayed(btnCancelatpopupleadtoLoyalty)){
			clickUsingJavaScript(btnCancelatpopupleadtoLoyalty, objectValue);
			report.reportPass("Click 'cancel button' on 'Cancel confirmation' pop up", "'cancel button' on 'Cancel confirmation' pop up should be clickable", "'cancel button' on 'Cancel confirmation' pop up is clicked");

		}	
		else {
			report.reportFail("Click 'cancel button' on 'Cancel confirmation' pop up", "'cancel button' on 'Cancel confirmation' pop up should be clickable", "Cancel confirmation pop up was not displayed");
		    report.updateMainReport("comments", "Cancel confirmation pop up was not displayed");	
		    report.updateMainReport("ErrorMessage", "Cancel confirmation pop up was not displayed");
		    captureErrorMsg("Cancel confirmation pop up was not displayed");
		    throw new UserDefinedException("Cancel confirmation pop up was not displayed");
			
		}
		}
		else if(get("CancelType").contains("withoutSubmission") &&  get("ProccedForCancel").contains("No")){
			
			if(isDisplayed(DontCancel, objectValue, 3)){
				clickUsingJavaScript(DontCancel, objectValue);
			
			System.out.println("Donot Cancel clicked");
			report.reportPass("Cancel Order", "Cancel Order window should be displayed", "Cancel Order window is displayed");
			report.reportPass("Cancel Order", "Cancel Order window should be displayed", "Donot Cancel clicked");
			}
			else if(isDisplayed(NoCancel, objectValue, 3)) // Gopal 0313
			{
				clickUsingJavaScript(NoCancel, objectValue);
				
				System.out.println("Donot Cancel clicked");
				report.reportPass("Cancel Order", "Cancel Order window should be displayed", "Cancel Order window is displayed");
				report.reportPass("Cancel Order", "Cancel Order window should be displayed", "Donot Cancel clicked");
			}
		}
		waitForLoader();
        waitForLoader();
        waitForLoader();
		if(isDisplayed(saleswindow, objectValue,5)){
	    	clickUsingJavaScript(saleswindow, objectValue);
	    	}
		waitForLoader();
		waitForLoader();
		if(isDisplayed(btnCancel2)){
			clickUsingJavaScript(btnCancel2, objectValue);
			report.reportPass("Click 'cancel button' on 'Cancel confirmation' pop up", "'cancel button' on 'Cancel confirmation' pop up should be clickable", "'cancel button' on 'Cancel confirmation' pop up is clicked");

		}
		
		
		if(isDisplayed(custcancel, objectValue, 3)){
	    	clickUsingJavaScript(custcancel, objectValue);
		    report.reportPass("Select Cancel Category ", "'Customer/Company' should be selected", "Cancel category-'Customer' is selected");

	    	waitForLoader();
	    	try{
		    	selectDropDownUsingVisibleText(reasonForCancel, objectValue, "Current service not available with FTTP");
		    	}
		    	catch (Exception exe) {
		    		selectDropDownUsingVisibleText(reasonForCancel, objectValue, "Refused to provide reason");
				    }
	    	report.reportPass("Select Cancel Reason", "Cancel Reason should be selectable", "Cancel Reason is selected ");
	    	waitForLoader();
	    	setText(CancelComments2, objectValue, "Test Cancelled");
		    report.reportPass("Click 'Cancel Button' ", "Cancel Commnents should be enterable", "Cancel Comments is entered");
	    	waitForLoader();	
	    	if(!get("CancelType").contains("withoutSubmission")){
        	clickUsingJavaScript(btnCancel3, objectValue);
		    report.reportPass("Click 'Cancel order' submission button", "'Cancel order' submission button should be clickable", "'Cancel order' submission is clicked");
	    	}
	    	else if(get("CancelType").contains("withoutSubmission")){   		
	    		if(isDisplayed(btnCancelDontCancel)){
	    		clickUsingJavaScript(btnCancelDontCancel, objectValue);
			    report.reportPass("Click 'Do not Cancel order' submission button", "'Do notCancel order' submission button should be clickable", "'Do not Cancel order' is clicked");
	    		}
	    	}
	
	       	waitForLoader();
			waitForLoader();
	    	}
		
		if(!get("CancelType").contains("withoutSubmission")){
		if(isDisplayed(saleswindow, objectValue, 3)){
	    	clickUsingJavaScript(saleswindow, objectValue);
	    	}
		waitForLoader();
		//waitForElementDisplay(IfProducts, objectValue, 30);
        Thread.sleep(3000);
		switchToDefaultcontent();
		switchToFrame("IfProducts");
		System.out.println("");
		if (isDisplayed(loyalityTab, objectValue, 30)) {
		// Switch Frame
	    report.reportPass("Verify Loyalty tab", "Loyalty tab should be displayed", "Loyalty tab is displayed");
	
		switchToDefaultcontent();
		waitForElementDisplay(IfProducts, objectValue, 30);
		switchToDefaultcontent();
		switchToFrame("IfProducts");
		waitForLoader();
		waitForLoader();
		pause();
		if(isDisplayed(reasonForCancel, objectValue, 3)){
		    try {

			selectDropDownUsingVisibleText(reasonForCancel, objectValue, "Current service not available with FTTP");

	    	report.reportPass("Select Cancel Reason", "Cancel Reason should be selectable", "Cancel Reason is selected ");
			waitForLoader();
		    } catch (Exception exe) {
			report.reportFail("Select Dropdown in Loyality Tab", "Select Dropdown Text if Loyality Tab id displayed", "Not able to Select Dropdown Text due to Object not displayed");
			report.updateMainReport("ErrorMessage", "Not able to Select Dropdown Text due to Object not displayed");
		    throw new UserDefinedException("'Cancel Reason' at cancel order-Loyalty page not found");

		    }
		    
		    switchToDefaultcontent();
			switchToFrame("IfProducts");
		}
		    //Added By SasiKiran, Thothada - 07/13/2017
		    try {
			    clickUsingJavaScript(btnSaveContinue, objectValue);
			    waitForLoader();
			    report.reportPass("Click Save And Continue", "Click Save And Continue if Exists", "Clicked Save And Continue in loyalty Tab");
			} catch (Exception exe) {
			    report.reportFail("Click Save And Continue Button", "Click Save And Continue Button if Exists",
				    "Not able to Click Save And Continue Button in Suspend Tab due to Object not Displayed");
			    report.updateMainReport("ErrorMessage", "Not able to click Click Save And Continue Button in Suspend Tab due to Object not Displayed");
			    throw new UserDefinedException("Save and continue button at cancel order-Loyalty page not found");

			}
		    
		    
		    switchToDefaultcontent();
			 switchToFrame("IfProducts");
		//Modified By SasiKiran, Thothada - 07/13/2017
	 
				if(ProccedForCancel.contains("Yes"))
				{
					mouseOver(ProceedCancel, "");
					clickUsingJavaScript(ProceedCancel, "");
					report.reportPass("Cancel Order Submission in Loyality Tab ", "Cancel Order Submitted Successfully", "Cancel Order Submitted Successfully");
					waitForLoader();
					waitForLoader();
					switchToDefaultcontent();
					
				    try {
					waitForElementDisplay(closingNotesText, objectValue, 20);
					if(isDisplayed(closingNotesText)){
					setText(closingNotesText, objectValue, "Cancel order");
					report.reportPass("Enter Closing Notes", "Closing Notes Text should be entered.", "Closing Notes Text should be entered..");
					}
				    }

				    catch (Exception exe) {
					report.reportFail("Enter Closing Notes", "Closing Notes Text should be entered.", "Not able to enter Closing Notes due to Object not displayed");
					report.updateMainReport("ErrorMessage", "Not able to enter Closing Notes due to Object not displayed");
					 throw new UserDefinedException("Failed in Loyalty Page");

				    }
				    //Added By SasiKiran, Thothada - 07/13/2017
				    try {
					    waitForElementDisplay(SaveandClose, objectValue, 20);
					    if(isDisplayed(SaveandClose)){    
				    report.reportPass("Check whether save and close button is displayed", "Save and close button should be displayed", "Save and close button is displayed");
				    //clickUsingJavaScript(SaveandClose, objectValue);
				   	}
		    			} catch (Exception e) {
		    			    report.reportFail("Click on save and close button.", "Save and close button should be clicked", "Save and Close button is not clicked due to "+e.toString());
		    				 throw new UserDefinedException("Failed in Loyalty Page");

		    			}
				}
				else
				{
					mouseOver(NotProceedCancel, "");
					clickUsingJavaScript(NotProceedCancel, "");
					report.reportPass("Cancel Order Submission in Loyality Tab ", "Cancel Order not Submitted Successfully", "Cancel Order not Submitted Successfully");
					waitForLoader();
					waitForLoader();
				}
		
		}
		else{
			 try {
				 switchToDefaultcontent();
					waitForElementDisplay(closingNotesText, objectValue, 20);
					if(isDisplayed(closingNotesText)){
					setText(closingNotesText, objectValue, "Cancel order");
					report.reportPass("Enter Closing Notes", "Closing Notes Text should be entered.", "Closing Notes Text should be entered..");
					}
				    }

				    catch (Exception exe) {
					report.reportFail("Enter Closing Notes", "Closing Notes Text should be entered.", "Not able to enter Closing Notes due to Object not displayed");
					report.updateMainReport("ErrorMessage", "Not able to enter Closing Notes due to Object not displayed");
					 throw new UserDefinedException("Failed in Loyalty Page");

				    }
			 if(ProccedForCancel.contains("Yes"))
				{
				    //Added By SasiKiran, Thothada - 07/13/2017
				    try {
					    waitForElementDisplay(SaveandClose, objectValue, 20);
					    if(isDisplayed(SaveandClose)){    
				    report.reportPass("Check whether save and close button is displayed", "Save and close button should be displayed", "Save and close button is displayed");
				    //clickUsingJavaScript(SaveandClose, objectValue);
				   	}
		    			} catch (Exception e) {
		    			    report.reportFail("Click on save and close button.", "Save and close button should be clicked", "Save and Close button is not clicked due to "+e.toString());
		    				 throw new UserDefinedException("Failed in Loyalty Page");

		    			}
				}
		   // report.reportFail("Negotiate Cancel Order", "Cancel Order-Loyalty page should be negotiated", "Cancel Order-Loyalty page is not negotiated since page was not displayed");
		   
			
		}
		
			}		
		
		}
		catch (Exception exe) {
		    report.reportFail("Negotiate Cancel Order", "Cancel Order should be negotiated", "Cancel Order is not negotiated due to "+exe.toString());
		    report.updateMainReport("comments", "Cancel Order is not negotiated");	
		    report.updateMainReport("ErrorMessage", "Cancel Order is not negotiated");
		    captureErrorMsg("Cancel Order is not negotiated");
		    throw new UserDefinedException("Cancel Order is not negotiated");
		    

		}
	    }
	//////***********Change Billing ADdress and Name****************///////////////
			    /*Developed By Praveen - 07-Sept-2017
			     * Description: To change Billing Address and name
			     */ 
			     else if (get("ChangeType").equalsIgnoreCase("Change Billing Name and Address")) {
				waitForLoader();
				try{
				//Click on Change Duedate Option on Products page
				if(isDisplayed(ChangeBillingAddOption, objectValue)){
				clickUsingJavaScript(ChangeBillingAddOption, objectValue);
				}
				else{
					clickUsingJavaScript(changeBillingAddress, objectValue);
			    	waitForLoader();
				}
				report.reportPass("Click 'Change Billing Address and name' Link", "Click 'Change Billing Address and name'", "Clicked 'Change Billing Address and name'");
				waitForLoader();
				waitForLoader();
				if(isDisplayed(errormsg, objectValue, 2)){
		    		String s=getTextFromElement(errormsg, objectValue);
		    		strFailed = "Getting following error after clicking Change Billing Name and Address: "+s;
					report.reportFail("Click Change Billing Name and Address in RG page.", "Change Billing Name and Address should be Clicked.", strFailed);
					report.updateMainReport("ErrorMessage", strFailed);
					report.updateMainReport("comments", strFailed);			   
				    logger.error(strFailed);
				    captureErrorMsg(strFailed);
				    throw new UserDefinedException(strFailed);
		    	}

				}
				catch (Exception exe) {
					report.reportFail("Click Change Billing Address Link", "Click Change Billing Address Link if Exists", "Change Billing Address Link is not dispalyed");
					report.updateMainReport("comments", "Change Billing Address Link is not dispalyed");	
					report.updateMainReport("ErrorMessage", "Change Billing Address Link is not dispalyed");
					throw new UserDefinedException("Failed in Clicking Change Billing Address");
				    }
			     }
	    //////// *********Vacation Suspend Flow***********/////////

	    else if (get("ChangeType").equalsIgnoreCase("VacationSuspend") || (get("ChangeType").equalsIgnoreCase("VacationSuspendRestore"))) {
		waitForLoader();
		try{

		if (isDisplayed(IWantTolink, "")) {
		    try {
			clickUsingJavaScript(IWantTolink, objectValue);
		    } catch (Exception exe) {
		    	report.reportFail("Select I Want To Link in RG page.", "I Want To Link should be Clicked", "I Want to Link is not displayed");
				report.updateMainReport("comments", "I Want to Link is not displayed");	
				report.updateMainReport("ErrorMessage", "I Want to Link is not displayed");
				 throw new UserDefinedException("Failed in Change Existing Services Page");
		    }

		}
		if (isDisplayed(btnChangeVacationSuspend, "")) {
		    try {
			waitForElementDisplay(btnChangeVacationSuspend, objectValue, 20);
			clickUsingJavaScript(btnChangeVacationSuspend, objectValue);
			report.reportPass("Click Vacation Suspend Button", "Click Vacation Suspend Button if Exists", "Clicking Vacation Suspend Button");
			waitForLoader();
            waitForLoader();
            waitForLoader();
			if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    	waitForLoader();
		    } catch (Exception exe) {
			report.reportFail("Click Vacation Suspend Button", "Click Vacation Suspend Button if Exists", "Vacation Suspend Button is not dispalyed");
			report.updateMainReport("comments", "Vacation Suspend Button is not dispalyed");	
			report.updateMainReport("ErrorMessage", "Vacation Suspend Button is not dispalyed");
			throw new UserDefinedException("Failed in Clicking Vacation Suspend Button");
		    }
		}
		if (isDisplayed(btnChangeVacationSuspend2, "")) {
		    try {
			waitForElementDisplay(btnChangeVacationSuspend2, objectValue, 20);
			clickUsingJavaScript(btnChangeVacationSuspend2, objectValue);
			report.reportPass("Click Vacation Suspend Button", "Click Vacation Suspend Button if Exists", "Clicking Vacation Suspend Button");
			waitForLoader();
            waitForLoader();
            waitForLoader();
			if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    	waitForLoader();
		    } catch (Exception exe) {
		    	report.reportFail("Click Vacation Suspend Button", "Click Vacation Suspend Button if Exists", "Vacation Suspend Button is not dispalyed");
				report.updateMainReport("comments", "Vacation Suspend Button is not dispalyed");	
				report.updateMainReport("ErrorMessage", "Vacation Suspend Button is not dispalyed");
				throw new UserDefinedException("Failed in Change Existing Services Page");

		    }
		}
		
		if(isDisplayed(errormsg, objectValue, 2)){
    		String s=getTextFromElement(errormsg, objectValue);
    		strFailed = "Getting following error after clicking Vacation Suspend: "+s;
			report.reportFail("Click Vacation Suspend in RG page.", "Vacation Suspend should be Clicked.", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			report.updateMainReport("comments", strFailed);			   
		    logger.error(strFailed);
		    captureErrorMsg(strFailed);
		    throw new UserDefinedException(strFailed);
    	}
		waitForLoader();
		switchToDefaultcontent();
		switchToFrame("IfProducts");
		waitForLoader();
		waitForLoader();
		Thread.sleep(5000);
		waitForLoader();
		// waitForElementDisplay(SuspendButton, objectValue, 30);
		if (get("ChangeType").equalsIgnoreCase("VacationSuspend")) {
			String scenariodes=get("TestCase_Name").toString();
			 if(scenariodes.contains("Copper") || scenariodes.contains("HSI") || scenariodes.contains("PSTN"))
	          {
	        	if(isDisplayed(suspendall,objectValue)){
	        		try{
	        		    clickUsingJavaScript(suspendall, objectValue);
					    report.reportPass("Click Checkbox Suspend", "Click Checkbox Suspend if Exists", "Clicked Checkbox Suspend in Suspend Tab");
	        		}
	        		catch(Exception e){
	        			  report.reportFail("Click Checkbox Suspend Button", "Click Checkbox Suspend Button if Exists",
	  						    "Not able to click Checkbox Suspend Button in Suspend Tab due to Object not Displayed");
	  					    report.updateMainReport("ErrorMessage", "Not able to click Checkbox Suspend Button in Suspend Tab due to Object not Displayed");
	  					    throw new UserDefinedException("Failed in Suspend Status Page");

	        		}
	        	}
	          }
			 else{
			 if (isDisplayed(SuspendButton2, objectValue)) {
					try {
					    clickUsingJavaScript(SuspendButton2, objectValue);
					    report.reportPass("Click Checkbox Suspend For Bundle", "Click Checkbox Suspend for Bundle if Exists", "Clicked Checkbox Suspend for Bundle in Suspend Tab");
					} catch (Exception exe) {
					    report.reportFail("Click Checkbox Suspend For Bundle Button", "Click Checkbox Suspend Button For Bundle if Exists",
						    "Not able to click Checkbox Suspend Button in Suspend Tab due to Object not Displayed");
					    report.updateMainReport("ErrorMessage", "Not able to click Checkbox Suspend Button in Suspend Tab due to Object not Displayed");
					    throw new UserDefinedException("Failed in Suspend Status Page");

					}

				    } else if(isDisplayed(SuspendDataButton))
				    {
				    	try {
						    clickUsingJavaScript(SuspendDataButton, objectValue);
						    report.reportPass("Click Checkbox Suspend For Data", "Click Checkbox Suspend for Data if Exists", "Clicked Checkbox Suspend For Data in Suspend Tab");
						} catch (Exception exe) {
						    report.reportFail("Click Checkbox Suspend For Data Button", "Click Checkbox Suspend For Data Button if Exists",
							    "Not able to click Checkbox Suspend For Data Button in Suspend Tab due to Object not Displayed");
						    report.updateMainReport("ErrorMessage", "Not able to click Checkbox Suspend For Data Button in Suspend Tab due to Object not Displayed");
						    throw new UserDefinedException("Failed in Suspend Status Page");

						}
				    }
				    else if(isDisplayed(SuspendPSTNBundle, "")) // --- Gopal 04/26
					{
					try {
					    clickUsingJavaScript(SuspendPSTNBundle, objectValue);
					    report.reportPass("Click Checkbox Suspend PSTN Bundle", "Click Checkbox Suspend PSTN Bundle if Exists", "Clicked Checkbox Suspend PSTN Bundle in Suspend Tab");
					} catch (Exception exe) {
					    report.reportFail("Click Checkbox Suspend PSTN Bundle Button", "Click Checkbox Suspend PSTN Bundle Button if Exists", "Not able to click Checkbox Suspend PSTN Bundle Button due to Object not Displayed");
					    report.updateMainReport("ErrorMessage", "Not able to click Checkbox Suspend PSTN Bundle Button due to Object not Displayed");
					    throw new UserDefinedException("Failed in Suspend Status Page");
					}
					}
			 
			 else {
					try {
					    clickUsingJavaScript(SuspendButton, objectValue);
					    report.reportPass("Click Checkbox Suspend For Video", "Click Checkbox Suspend For Video if Exists", "Clicked Checkbox Suspend for Video in Suspend Tab");
					} catch (Exception exe) {
					    report.reportFail("Click Checkbox Suspend For Video Button", "Click Checkbox Suspend Button For Video if Exists", "Not able to click Checkbox Suspend For Video Button due to Object not Displayed");
					    report.updateMainReport("ErrorMessage", "Not able to click Checkbox Suspend For Video Button due to Object not Displayed");
					    throw new UserDefinedException("Failed in Suspend Status Page");

					}

					waitForLoader();
					waitForLoader();
				    }
			 }

		    waitForLoader();
		    waitForLoader();

		}
					
			//

		if (get("ChangeType").equalsIgnoreCase("VacationSuspendRestore")) {

		    // Click on restore checkbox
			try{
		    List<WebElement> restr1 = driver.findElements(by.xpath("//*[contains(@name,'ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$vacation$vacation_')]"));

		    for (WebElement restr2 : restr1) {

			if (restr2.isDisplayed()) {

			    try {

				((JavascriptExecutor) driver).executeScript("arguments[0].click();", restr2);
				report.reportPass("Click Checkbox Restore", "Click Checkbox restore if Exists", "Clicked Checkbox Restore in Suspend Tab");
				
				//Prakash -- Validating Restore text message
				if(get("HLRValidations").equalsIgnoreCase("Yes")){
				String Restoremsg="N";
				for (int i=0; i < allAgreementsRestore.size(); i++ )
				{
					System.out.println(allAgreementsRestore.get(i).getText());
					
					if (allAgreementsRestore.get(i).getText().contains("Suspended - Will be restored"))
					{
						report.reportPass("Validate Restore message", "Restore Message Displayed", "Restore message Displayed is :"+allAgreementsRestore.get(i).getText());
						 Restoremsg="Y";
						 break;
					}
				}
				if (Restoremsg.contains("Y"))
				{
					report.reportPass("Validate Restore message", "Restore Message Displayed", "Restore message Displayed");
				}
				else
				{
					report.reportFail("Validate Restore message", "Restore Message Not Displayed", "Restore message Not Displayed");
				}
				}
				
				///Prakash -- Validating Restore text message
			    } catch (Exception exe) {
				report.reportFail("Click Checkbox Restore ", "Click Checkbox Restore Button if Exists",
					"Not able to click Checkbox Restore in Suspend Restore Tab due to Object not Displayed");
				report.updateMainReport("ErrorMessage", "Not able to click Checkbox Restore in Suspend Tab due to Object not Displayed");
				 throw new UserDefinedException("Failed in Suspend Status Page");

			    }
			}
		    }
		}
		catch (Exception exe) {
		    report.reportFail("Click Checkbox Suspend Button", "Click Checkbox Suspend Button if Exists",
			    "Not able to click Checkbox Suspend Button in Suspend Tab due to Object not Displayed");
		    report.updateMainReport("ErrorMessage", "Not able to click Checkbox Suspend Button in Suspend Tab due to Object not Displayed");
		    throw new UserDefinedException("Failed in Suspend Status Page");

		}

		}

		try {
		    clickUsingJavaScript(SaveAndContinue, objectValue);
		    waitForLoader();
		    report.reportPass("Click Save And Continue", "Click Save And Continue if Exists", "Clicked Save And Continue in Suspend Tab");
		} catch (Exception exe) {
		    report.reportFail("Click Save And Continue Button", "Click Save And Continue Button if Exists",
			    "Not able to Click Save And Continue Button in Suspend Tab due to Object not Displayed");
		    report.updateMainReport("ErrorMessage", "Not able to click Click Save And Continue Button in Suspend Tab due to Object not Displayed");
		    throw new UserDefinedException("Failed in Suspend Status Page");

		}

		if (get("ChangeType").equalsIgnoreCase("VacationSuspend")) {
		    if (isDisplayed(okButton, objectValue)) {
			clickUsingJavaScript(okButton, objectValue);
			waitForLoader();

		    }
		    waitForLoader();
		    if (isDisplayed(SaveAndContinue2, objectValue)) {
			try {

			    clickUsingJavaScript(SaveAndContinue2, objectValue);
			    report.reportPass("Click Save And Continue", "Click Save And Continue if Exists", "Click Save And Continue");
			    waitForLoader();
			} catch (Exception exe) {
			    report.reportFail("Click Save And Continue Button", "Click Save And Continue Button if Exists",
				    "Not able to Click Save And Continue Button in Fios Tab due to Object not displayed");
			    report.updateMainReport("ErrorMessage", "Not able to click Click Save And Continue Button in Fios Tab due to Object not displayed");
			    throw new UserDefinedException("Failed in Fios Data/TV Page");

			}
		    }

		}
	    } catch (Exception exe) {
		    report.reportFail("Negotiate Vacation Suspend/Restore", "Negotiate Vacation Suspend/Restore Link if Exists", "Vacation Suspend/Restore link is not Negotiated");
		    report.updateMainReport("comments", "Vacation Suspend/Restore link is not Negotiated");	
		    report.updateMainReport("ErrorMessage", "Vacation Suspend/Restore link is not Negotiated");
		    captureErrorMsg("Vacation Suspend/Restore link is not Negotiated");
		    throw new UserDefinedException("Failed in Negotiating Vacation Suspend/Restore");
		    

		}
	    }

	    //////// *********Change Due Date Flow***********/////////

	    else if (get("ChangeType").equalsIgnoreCase("ChangeDueDate")) {
		waitForLoader();
		try {

		    waitForElementDisplay(btnChangeDueDate, objectValue, 40);
		    clickUsingJavaScript(btnChangeDueDate, objectValue);
		    report.reportPass("Click Change DueDate Button Link", "Click Change DueDate Link if Exists", "Clicking Change DueDate Link");
		    waitForLoader();
            waitForLoader();
            waitForLoader();
		    if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    	waitForLoader();

		    	waitForLoader();

		    	waitForLoader();
		    	pause();
		   
		} catch (Exception exe) {
		    report.reportFail("Click Change DueDate Link", "Click Change DueDate Link if Exists", "Change DueDate link is not available");
		    report.updateMainReport("comments", "Change DueDate link is not available");	
		    report.updateMainReport("ErrorMessage", "Change DueDate link is not available");
		    captureErrorMsg("Change DueDate link is not available");
		    throw new UserDefinedException("Failed in Changing Due Date");
		    

		}
	    }

	    //////// ********Disconnect Flow***********/////////

	    else if (get("ChangeType").equalsIgnoreCase("Disconnect") || get("ChangeType").equalsIgnoreCase("PartialDisconnect")) {
	    	
	    	try{
		waitForLoader();
		waitForLoader();
		
		if (isDisplayed(btnDisconnect, objectValue,20)) {
			
		}
		else if (isDisplayed(IWantTolink, "")) {
		    try {

			clickUsingJavaScript(IWantTolink, objectValue);
			report.reportPass("Click I Want To Link", "Click I Want To Link if Exists", "Clicking  I Want To Link");
		    } catch (Exception exe) {
			report.reportFail("Click I Want to Link", "I Want to Link should be  clicked", "Not able to click I Want to Link due to Object not displayed");
			report.updateMainReport("comments", "I Want to Link is not displayed");	
			report.updateMainReport("ErrorMessage", "Not able to click I Want to Link due to Object not displayed");
			throw new UserDefinedException("Failed in Change Existing Services Page");

		    }

		}
		else{
			report.reportFail("Click Disconnect button", "Disconnect button should be  clicked", "Not able to click Disconnect button due to Object not displayed");
			report.updateMainReport("comments", "Not able to click Disconnect button due to Object not displayed");	
			report.updateMainReport("ErrorMessage", "Not able to click Disconnect button due to Object not displayed");
			throw new UserDefinedException("Failed in Change Existing Services Page");
		}

		if (isDisplayed(btnDisconnect, objectValue,10)) {

		    try {
			clickUsingJavaScript(btnDisconnect, objectValue);
			report.reportPass("Click Disconnect Button", "Click Disconnect Button if Exists", "Clicking Disconnect Button");
			waitForLoader();
            waitForLoader();
            waitForLoader();
			if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    	waitForLoader();
		    } catch (Exception exe) {
			report.reportFail("Click Disconnect button", "Disconnect button should be  clicked", "Not able to click Disconnect button due to Object not displayed");
			report.updateMainReport("comments", "Not able to click Disconnect button due to Object not displayed");	
			report.updateMainReport("ErrorMessage", "Not able to click Disconnect button due to Object not displayed");
			throw new UserDefinedException("Failed in Change Existing Services Page");

		    }
		} else {
		    try {
			clickUsingJavaScript(btnDisconnect2, objectValue);

			report.reportPass("Click Disconnect Button", "Click Disconnect Button if Exists", "Clicking Disconnect Button");
			waitForLoader();
            waitForLoader();
            waitForLoader();
			if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    	waitForLoader();
			waitForLoader();
		    } catch (Exception exe) {
		    	report.reportFail("Click Disconnect button", "Disconnect button should be  clicked", "Not able to click Disconnect button due to Object not displayed");
				report.updateMainReport("comments", "Not able to click Disconnect button due to Object not displayed");	
				report.updateMainReport("ErrorMessage", "Not able to click Disconnect button due to Object not displayed");
				throw new UserDefinedException("Failed in Change Existing Services Page");

		    }
		}

		waitForLoader();
		if (get("RG_Selection").equalsIgnoreCase("Dynamic")) {

		    dynamicRGSelection();

		} else {
		    selectRGQuestoins(get("RG_Selection"));
		}

		
		waitForLoader();
        waitForLoader();
        waitForLoader();
		if(isDisplayed(saleswindow, objectValue, 10)){
	    	clickUsingJavaScript(saleswindow, objectValue);
	    	}
		waitForLoader();
		/*
		if (get("ChangeType").equalsIgnoreCase("PartialDisconnect")) {

		    try {
			clickUsingJavaScript(PartialDisconnectRadiobtn, objectValue);
			report.reportPass("Click Partial Disconnect Button in RG", "Click Partial Disconnect Radio Button in RG ", "Clicking Partial Disconnect Radio Button in RG");
			waitForLoader();
			  waitForLoader();
			if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    	waitForLoader();
		    } catch (Exception exe) {
			report.reportFail("Click Partial Disconnect button", "Partial Disconnect should be  clicked", "Not able to click Partial Disconnect due to Object not displayed");
			report.updateMainReport("ErrorMessage", "Not able to click Partial Disconnect due to Object not displayed");
			throw exe;

		    }
		    // Internet
		    if (get("Internet_PartialDisconnect").equalsIgnoreCase("Yes")) {
			try {
			    clickUsingJavaScript(InternetPartialDisconnect, objectValue);
			    report.reportPass("Click Internet checkbox in RG", "Click Internet checkbox in RG ", "Clicking Internet checkbox in RG");
			    waitForLoader();
			    waitForLoader();
			} catch (Exception exe) {
			    report.reportFail("Click Internet checkbox in RG", "Internet checkbox in RG should be  clicked", "Not able to click Internet checkbox in RG due to Object not displayed");
			    report.updateMainReport("ErrorMessage", "Not able to click Internet checkbox in RG due to Object not displayed");
			    throw exe;

			}
		    }
		    // TV
		    if (get("TV_PartialDisconnect").equalsIgnoreCase("Yes")) {
			try {
			    clickUsingJavaScript(TVPartialDisconnect, objectValue);
			    report.reportPass("Click TV checkbox in RG", "Click TV checkbox in RG ", "Clicking TV checkbox in RG");
			    waitForLoader();
			    waitForLoader();
			} catch (Exception exe) {
			    report.reportFail("Click TV checkbox in RG", "TV checkbox in RG should be  clicked", "Not able to click TV checkbox in RG due to Object not displayed");
			    report.updateMainReport("ErrorMessage", "Not able to click TV checkbox in RG due to Object not displayed");
			    throw exe;

			}
		    }

		    try {
			clickUsingJavaScript(PartdisconnectNext, objectValue);
			report.reportPass("Click Next Button in RG", "Click Next Button in RG ", "Clicking Next Button in RG");
			  waitForLoader();
			    waitForLoader();
		    } catch (Exception exe) {
			report.reportFail("Click Next in RG", "Next Button in RG should be clicked", "Not able to click Next Button in RG due to Object not displayed");
			report.updateMainReport("ErrorMessage", "Not able to click Next Button in RG due to Object not displayed");
			throw exe;

		    }
		    try {
			clickUsingJavaScript(ContinuePartialDisconnect, objectValue);
			report.reportPass("Click Continue Partial Disconnect Button in RG", "Click  Continue Partial Disconnect Radio Button in RG ",
				"Clicking Continue Partial Disconnect Radio Button in RG");
			  waitForLoader();
			    waitForLoader();
		    } catch (Exception exe) {
			report.reportFail("Click Continue Partial Disconnect Button in RG", "Continue Partial Disconnect in RG should be  clicked",
				"Not able to click Continue Partial Disconnect in RG due to Object not displayed");
			report.updateMainReport("ErrorMessage", "Not able to click TV checkbox in RG due to Object not displayed");
			throw exe;

		    }
		    try {
			clickUsingJavaScript(NoPartialDisconnect, objectValue);

			report.reportPass("Click No in RG", "Click No Radio Button in RG ", "Clicking No Radio Button in RG");

		    } catch (Exception exe) {
			report.reportFail("Click No in RG", "No radio button in RG should be clicked", "Not able to click No radio button in RG due to Object not displayed");
			report.updateMainReport("ErrorMessage", "Not able to click No radio button in RG due to Object not displayed");
			throw exe;

		    }
		    Thread.sleep(1000);
		    waitForLoader();
		    waitForLoader();

		}
		*/
		 waitForLoader();
	    waitForLoader();
		
	    }
    	catch (Exception exe) {
    		  report.reportFail("Verify Disconnect Or Partial Disconnect is Negotiated", "Disconnect Or Partial Disconnect should be Negotiated", "Disconnect Or Partial Disconnect is not Negotiated");
		    report.updateMainReport("comments", "Disconnect Or Partial Disconnect is not Negotiated");
		    report.updateMainReport("ErrorMessage", "Disconnect Or Partial Disconnect is not Negotiated");
		    captureErrorMsg("Disconnect Or Partial Disconnect is not Negotiated");
		    throw new UserDefinedException("Disconnect Or Partial Disconnect is not Negotiated");
		    
		}
	    }
		    
	////////********************Loyalty Flow****************////////////////////
		    
		    else if(get("ChangeType").toLowerCase().equalsIgnoreCase("loyalty")){
		    	try{
		    		waitForLoader();
		    		waitForLoader();
		    		if (isDisplayed(Compass, "")) {
		    		    try {

		    			clickUsingJavaScript(Compass, objectValue);
		    			report.reportPass("Click I Want To Link", "Click I Want To Link if Exists", "Clicking  I Want To Link");
		    		    } catch (Exception exe) {
		    			report.reportFail("Click I Want to Link", "I Want to Link should be  clicked", "Not able to click I Want to Link due to Object not displayed");
		    			report.updateMainReport("comments", "I Want to Link is not displayed");	
		    			report.updateMainReport("ErrorMessage", "Not able to click I Want to Link due to Object not displayed");
		    			throw new UserDefinedException("Failed in Change Existing Services Page");

		    		    }

		    		}

		    		else if (isDisplayed(btnDisconnect, objectValue,10)) {

		    		    try {//Updated BtnDisconnect as Compass
		    			clickUsingJavaScript(btnDisconnect, objectValue);
		    			report.reportPass("Click Compass Flow Button", "Click Compass Flow Button if Exists", "Clicking Compass Flow Button");
		    			if(isDisplayed(saleswindow, objectValue, 10)){
		    		    	clickUsingJavaScript(saleswindow, objectValue);
		    		    	}

		    		    	waitForLoader();
		    		    } catch (Exception exe) {
		    			report.reportFail("Click Compass Flow button", "Compass Flow button should be  clicked", "Not able to click Compass Flow button due to Object not displayed");
		    			report.updateMainReport("comments", "Not able to click Loyalty Flow button due to Object not displayed");	
		    			report.updateMainReport("ErrorMessage", "Not able to click Loyalty Flow button due to Object not displayed");
		    			throw new UserDefinedException("Failed in Change Existing Services Page");

		    		    }
		    		} else {
		    		    try {
		    			clickUsingJavaScript(btnDisconnect2, objectValue);

		    			report.reportPass("Click Loyalty Flow Button", "Click Loyalty Flow Button if Exists", "Clicking Loyalty Flow Button");
		    			if(isDisplayed(saleswindow, objectValue, 10)){
		    		    	clickUsingJavaScript(saleswindow, objectValue);
		    		    	}

		    		    	waitForLoader();
		    			waitForLoader();
		    		    } catch (Exception exe) {
		    		    	report.reportFail("Click Loyalty Flow button", "Loyalty Flow button should be  clicked", "Not able to click Loyalty Flow button due to Object not displayed");
		    				report.updateMainReport("comments", "Not able to click Loyalty Flow button due to Object not displayed");	
		    				report.updateMainReport("ErrorMessage", "Not able to click Loyalty Flow button due to Object not displayed");
		    				throw new UserDefinedException("Failed in Change Existing Services Page");

		    		    }
		    		}

		    		waitForLoader();
		    		if (get("RG_Selection").equalsIgnoreCase("Dynamic")) {

		    		    dynamicRGSelection();

		    		} else {
		    		    selectRGQuestoins(get("RG_Selection"));
		    		}

		    		waitForLoader();
		    		if(isDisplayed(saleswindow, objectValue, 10)){
		    	    	clickUsingJavaScript(saleswindow, objectValue);
		    	    	}
		    		waitForLoader();
		    		
		    	}catch(Exception e){
		    		report.reportFail("Click Loyalty Flow button", "Loyalty Flow button should be  clicked", "Not able to click Loyalty Flow button due to Object not displayed");
					report.updateMainReport("comments", "Not able to click Loyalty Flow button due to Object not displayed");	
					report.updateMainReport("ErrorMessage", "Not able to click Loyalty Flow button due to Object not displayed");
					throw new UserDefinedException("Failed in Change Existing Services Page");

		    	}
		    }    

	    //////// ********Stack Disconnect Flow***********/////////

	    else if (get("ChangeType").equalsIgnoreCase("StackDisconnect")) {
	    	try{

		String Stackdisc = get("StackDisconnectOption");

		waitForLoader();
		
		    try {
		    	waitForElementDisplay(stackdisconnect, objectValue, 60);
		    	if (isDisplayed(stackdisconnect, "")) {
			clickUsingJavaScript(stackdisconnect1, Stackdisc);
			// selectDropDownUsingVisibleText((Element)
			// stackdisconnect1, "", Stackdisc);
			
			report.reportPass("Stack Disconnect Order", " Select Disconnect Order option", "Disconnect Order option is selected");
			waitForLoader();
            waitForLoader();
            waitForLoader();
			if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}

		    	waitForLoader();
			waitForLoader();
		    	}
		    } catch (Exception exe) {
			report.reportFail("Verify Stack Disconnect Order Option", "Click Stack Disconnect Order option", "Stack Disconnect Order option is not available");
			report.updateMainReport("ErrorMessage", "Stack Disconnect Order option is not available");
			report.updateMainReport("comments", "Stack Disconnect Order option is not available");
			logger.error("Stack Disconnect Order option is not available");
			captureErrorMsg("Stack Disconnect Order option is not available");
			throw new UserDefinedException("Stack Disconnect Order option is not available");
			 

		    }
		  
		

		waitForLoader();
		if (get("RG_Selection").equalsIgnoreCase("Dynamic")) {

		    dynamicRGSelection();

		} else {
		    selectRGQuestoins(get("RG_Selection"));
		}
		waitForLoader();
        waitForLoader();
        waitForLoader();
		if(isDisplayed(saleswindow, objectValue, 10)){
	    	clickUsingJavaScript(saleswindow, objectValue);
	    	}

		waitForLoader();
		waitForLoader();

		
		
		

	    }
	    	catch (Exception exe) {
	    		  report.reportFail("Verify Stack Disconnect Order is Negotiated", "Stack Disconnect Order should be Negotiated", "Stack Disconnect Order is not Negotiated");
			    report.updateMainReport("comments", "Stack Disconnect Order is not Negotiated");
			    report.updateMainReport("ErrorMessage", "Stack Disconnect Order is not Negotiated");
			    captureErrorMsg("Stack Disconnect Order is not Negotiated");
			    throw new UserDefinedException("Stack Disconnect Order is not Negotiated");
			    
			}
	    	
	    }
	    else if (get("ChangeType").equalsIgnoreCase("SmartCartResume")) {
	    	waitForLoader();
	    	
	     	waitForLoader();

	    	waitForLoader();
	    	if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
	    	}
		    	
		    	waitForLoader();
		    	if (get("Application").equalsIgnoreCase("COA")){
		               if ((isDisplayed(currentActiveTab, "availableServices", 6))) {
		            	
		            	   if (isDisplayed(btnNext1, "",6)) {
		                       clickUsingJavaScript(btnNext1, "");
		                       report.reportPass("Click on next button of verify Address tab.", "Next button should be clicked on verify address tab.", "Clicked on Next button of verify address tab.");
		                      
		                       waitForLoader();
		                   }
		                 if(isDisplayed(btnResume, "",6)){  //Anu added
		            		   clickUsingJavaScript(btnResume, objectValue);

		       			    report.reportPass("Click Resume Button", "Click Resume Button if Exists", "Clicking Resume Button");
		       			  waitForLoader(); 
		            	  }
		               }
		               else{
		            	   if(isDisplayed(smartCartResume, "",6)){  //Mounika added
		            		   clickUsingJavaScript(smartCartResume, objectValue);

		       			    report.reportPass("Click Resume Button", "Click Resume Button if Exists", "Clicking Resume Button");
		       			  waitForLoader(); 
		            	  }
		                 if(isDisplayed(saleswindow, objectValue, 2)){
		     		    	clickUsingJavaScript(saleswindow, objectValue);
		     	    	}
		               
		               }
			    	}else if (get("Application").equalsIgnoreCase("C2G")){
		            	   if (isDisplayed(btnNext1, "",6)) {
		                       clickUsingJavaScript(btnNext1, "");
		                       report.reportPass("Click on next button of verify Address tab.", "Next button should be clicked on verify address tab.", "Clicked on Next button of verify address tab.");
		                      
		                       waitForLoader();
		                   }
			    	}
		    	
			/*try {
			    waitForElementDisplay(btnResume, objectValue, pageTimeoutInSeconds);
                if(isDisplayed(activitytimelinetext, objectValue, 5)){
			    	
			    	String x=getTextFromElement(activitytimelinetext, objectValue);
			    	System.out.println(x);
			    	 report.reportPass("View text of Notes Under Activity Timeline", "To display text of Notes Under Activity Timeline", "Text of Notes Under Activity Timeline is: "+x);
			    	
			    }

			    clickUsingJavaScript(btnResume, objectValue);

			    report.reportPass("Click Resume Button", "Click Resume Button if Exists", "Clicking Resume Button");
			    

			    	waitForLoader();

			    	waitForLoader();
			    	if(isDisplayed(saleswindow, objectValue, 3)){
				    	clickUsingJavaScript(saleswindow, objectValue);
				    	}
			    waitForLoader();
			    waitForLoader();

			} catch (Exception exe) {
			    report.reportFail("Select Resume in RG Page", "Resume button Should be Selected", "Resume button is not dispalyed");
			    report.updateMainReport("comments", "Resume button is not dispalyed");
			    report.updateMainReport("ErrorMessage", "Resume button is not dispalyed");
			    throw new UserDefinedException("Failed in Change Existing Services Page");

			}*/
	    	
	    	
	    
	    }
	    else if (get("ChangeType").equalsIgnoreCase("FastPassResume")) {
	    	waitForLoader();
			try {
			    waitForElementDisplay(btnResume, objectValue, pageTimeoutInSeconds);
                if(isDisplayed(activitytimelinetext, objectValue, 5)){
			    	
			    	String x=getTextFromElement(activitytimelinetext, objectValue);
			    	System.out.println(x);
			    	 report.reportPass("View text of Notes Under Activity Timeline", "To display text of Notes Under Activity Timeline", "Text of Notes Under Activity Timeline is: "+x);
			    	
			    }

			    clickUsingJavaScript(btnResume, objectValue);

			    report.reportPass("Click Resume Button", "Click Resume Button if Exists", "Clicking Resume Button");
			    

			    	waitForLoader();

			    	waitForLoader();
			    	if(isDisplayed(saleswindow, objectValue, 10)){
				    	clickUsingJavaScript(saleswindow, objectValue);
				    	}
			    waitForLoader();
			    waitForLoader();
				Thread.sleep(40000);

			} catch (Exception exe) {
			    report.reportFail("Select Resume in RG Page", "Resume button Should be Selected", "Resume button is not dispalyed");
			    report.updateMainReport("comments", "Resume button is not dispalyed");
			    report.updateMainReport("ErrorMessage", "Resume button is not dispalyed");
			    throw new UserDefinedException("Failed in Change Existing Services Page");

			}
	    	
	    	
	    
	    }
	    else if (get("ChangeType").equalsIgnoreCase("AutoPay")) {
	    	waitForLoader();
			try {
			    waitForElementDisplay(setupAutopay, objectValue, pageTimeoutInSeconds);

			    clickUsingJavaScript(setupAutopay, objectValue);

			    report.reportPass("Click Resume Button", "Click Resume Button if Exists", "Clicking Resume Button");
			    

			    	waitForLoader();

			    	waitForLoader();
			    	if(isDisplayed(saleswindow, objectValue, 10)){
				    	clickUsingJavaScript(saleswindow, objectValue);
				    	}
			    waitForLoader();
			    waitForLoader();
			   
			} catch (Exception exe) {
			    report.reportFail("Select Resume in RG Page", "Resume button Should be Selected", "Resume button is not dispalyed");
			    report.updateMainReport("comments", "Resume button is not dispalyed");
			    report.updateMainReport("ErrorMessage", "Resume button is not dispalyed");
			    throw new UserDefinedException("Failed in Change Existing Services Page");

			}
	    }
			else if (get("ChangeType").equalsIgnoreCase("StackSuspend")) {
		    	waitForLoader();
				try {
					waitForElementDisplay(stackdisconnect, objectValue, 60);
			    	
				clickUsingJavaScript(stackdisconnect1, "Suspend");
				    report.reportPass("Click Resume Button", "Click Resume Button if Exists", "Clicking Resume Button");
				    
				    	waitForLoader();
				    	waitForLoader();
				    	if(isDisplayed(saleswindow, objectValue, 10)){
					    	clickUsingJavaScript(saleswindow, objectValue);
					    	}
				    	waitForLoader();
						switchToDefaultcontent();
						switchToFrame("IfProducts");
						waitForLoader();
						waitForLoader();
						Thread.sleep(5000);
						waitForLoader();
						if (isDisplayed(SuspendButton2, objectValue)) {
							try {
							    clickUsingJavaScript(SuspendButton2, objectValue);
							    report.reportPass("Click Checkbox Suspend", "Click Checkbox Suspend if Exists", "Clicked Checkbox Suspend in Suspend Tab");
							} catch (Exception exe) {
							    report.reportFail("Click Checkbox Suspend Button", "Click Checkbox Suspend Button if Exists",
								    "Not able to click Checkbox Suspend Button in Suspend Tab due to Object not Displayed");
							    report.updateMainReport("ErrorMessage", "Not able to click Checkbox Suspend Button in Suspend Tab due to Object not Displayed");
							    throw new UserDefinedException("Failed in Suspend Status Page");
							}
						    } else {
							try {
							    clickUsingJavaScript(SuspendButton, objectValue);
							    report.reportPass("Click Checkbox Suspend", "Click Checkbox Suspend if Exists", "Clicked Checkbox Suspend in Suspend Tab");
							} catch (Exception exe) {
							    report.reportFail("Click Checkbox Suspend Button", "Click Checkbox Suspend Button if Exists", "Not able to click Checkbox Suspend Button due to Object not Displayed");
							    report.updateMainReport("ErrorMessage", "Not able to click Checkbox Suspend Button due to Object not Displayed");
							    throw new UserDefinedException("Failed in Suspend Status Page");
							}
							waitForLoader();
							waitForLoader();
						    }
						try {
						    clickUsingJavaScript(SaveAndContinue, objectValue);
						    waitForLoader();
						    report.reportPass("Click Save And Continue", "Click Save And Continue if Exists", "Clicked Save And Continue in Suspend Tab");
						} catch (Exception exe) {
						    report.reportFail("Click Save And Continue Button", "Click Save And Continue Button if Exists",
							    "Not able to Click Save And Continue Button in Suspend Tab due to Object not Displayed");
						    report.updateMainReport("ErrorMessage", "Not able to click Click Save And Continue Button in Suspend Tab due to Object not Displayed");
						    throw new UserDefinedException("Failed in Suspend Status Page");
						}
						 if (isDisplayed(okButton, objectValue)) {
								clickUsingJavaScript(okButton, objectValue);
								waitForLoader();
							    }
							    waitForLoader();
							    if (isDisplayed(SaveAndContinue2, objectValue)) {
								try {
								    clickUsingJavaScript(SaveAndContinue2, objectValue);
								    report.reportPass("Click Save And Continue", "Click Save And Continue if Exists", "Click Save And Continue");
								    waitForLoader();
								} catch (Exception exe) {
								    report.reportFail("Click Save And Continue Button", "Click Save And Continue Button if Exists",
									    "Not able to Click Save And Continue Button in Fios Tab due to Object not displayed");
								    report.updateMainReport("ErrorMessage", "Not able to click Click Save And Continue Button in Fios Tab due to Object not displayed");
								    throw new UserDefinedException("Failed in Fios Data/TV Page");
								}
							    }
				  
				   
				} catch (Exception exe) {
				    report.reportFail("Select Resume in RG Page", "Resume button Should be Selected", "Resume button is not dispalyed");
				    report.updateMainReport("comments", "Resume button is not dispalyed");
				    report.updateMainReport("ErrorMessage", "Resume button is not dispalyed");
				    throw new UserDefinedException("Failed in Change Existing Services Page");
				}
		    	
		    
		    }
	    
 // for Renew Bundle by Gopal 07/10/2017
	    
			else if (get("ChangeType").equalsIgnoreCase("Renew Bundle/Contract")) {
	    	waitForLoader();
	    	switchToDefaultcontent();
			try{
	    	try {
			    waitForElementDisplay(RenewBundle, objectValue, pageTimeoutInSeconds);

			    clickUsingJavaScript(RenewBundle, objectValue);

			    report.reportPass("Click Renew Bundle Button", "Click Renew Button if Exists", "Clicking Renew Button");
			    
			    waitForLoader();
			    switchToDefaultcontent();
			    			   
			} catch (Exception exe) {
			    report.reportFail("Select Renew in RG Page", "Renew button Should be Selected", "Renew button is not dispalyed");
			    report.updateMainReport("comments", "Renew button is not dispalyed");
			    report.updateMainReport("ErrorMessage", "Renew button is not dispalyed");
			    throw new UserDefinedException("Failed in Change Existing Services Page");

			}
	    	
	    	waitForLoader();
			if (get("RG_Selection").equalsIgnoreCase("Dynamic")) {

			    dynamicRGSelection();

			} else {
			    selectRGQuestoins(get("RG_Selection"));
			}
			waitForLoader();
	    	if(isDisplayed(saleswindow, objectValue, 10)){
		    	clickUsingJavaScript(saleswindow, objectValue);
		    	}
	    	waitForLoader();
	    	waitForLoader();
			}
			catch (Exception exe) {
			    report.reportFail("Select RG Page for RenewBundle Order", "RG Questions Should be Selected", "RG Questions is not dispalyed");
			    report.updateMainReport("comments", "RG Questions are not dispalyed");
			    report.updateMainReport("ErrorMessage", "RG Questions are not dispalyed");
			    throw new UserDefinedException("Failed in Change Existing Services Page");
			}
	    
	    }
		    
		    else if (get("ChangeType").equalsIgnoreCase("StackChangeServAddress")) {
		  
		    	
		    	waitForLoader();
				try {
					waitForElementDisplay(stackdisconnect, objectValue, 60);
			    	
					clickUsingJavaScript(stackdisconnect1, "Change Service Address");
					    report.reportPass("Click Resume Button", "Click Resume Button if Exists", "Clicking Resume Button");
				    	waitForLoader();
				    	waitForLoader();
				    	if(isDisplayed(saleswindow, objectValue, 10)){
					    	clickUsingJavaScript(saleswindow, objectValue);
					    	}
				    waitForLoader();
				    waitForLoader();
				    switchToDefaultcontent();
					waitForElementDisplay(IfProducts, objectValue, 60);
					switchToDefaultcontent();
					switchToFrame("IfProducts");
					
					waitForElementDisplay(newAccount, objectValue, 60);
					waitForLoader();
			    	
					 pageScroll(callingPartyName, objectValue, true);
					 clearText(callingPartyName, objectValue);
					 setText(callingPartyName, objectValue, "Automation");
					    
					 pageScroll(EmailID, objectValue, true);
					 clearText(EmailID, objectValue);
					 setText(EmailID, objectValue, "bouncetest@verizon.com");
				    
				    if(!get("HouseName").isEmpty()){
				    
				    	
		    	    pageScroll(housename, objectValue, true);
				    clearText(housename, objectValue);				    	
				    setText(housename, objectValue, get("HouseName"));
				    
				    clearText(streetname, objectValue);				    	
				    setText(streetname, objectValue, get("StreetAddress"));
				    
				    
				    clearText(city, objectValue);				    	
				    setText(city, objectValue, get("City"));
				    
				    
				    clearText(state, objectValue);				    	
				    selectDropDownUsingVisibleText(state, objectValue, get("State"));
				    
				    
				    clearText(zipcode, objectValue);				    	
				    setText(zipcode, objectValue, get("Zipcode"));
				    	
				    		    	
				    	
				    }
				    
				    clickUsingJavaScript(qualifyAddress, objectValue);
				    
				    waitForLoader();
				    clickUsingJavaScript(newRoomMate, objectValue);
				    
				    clickUsingJavaScript(saveAndcnt, objectValue);
				    waitForLoader();
				    waitForLoader();
				    
				    if (isDisplayed(LecSection, objectValue, 10)) {
					    waitForLoader();
					
					clickUsingJavaScript(SACbtn, objectValue);
					
					waitForLoader();
					}
				    // Gopal changes on 10/04/2017 
				    else if (isDisplayed(FDVTab, objectValue, 10)) 
					{
					    	waitForLoader();
					
						clickUsingJavaScript(SaveAndContinue2, objectValue);
					
						waitForLoader();
					}
				    waitForLoader();
				    waitForLoader();
				    clickUsingJavaScript(btnDuedateContinue, objectValue);
				    if(isDisplayed(btnDuedateContinue))
				    {
				    clickUsingJavaScript(btnDuedateContinue, objectValue);
				    }
				} catch (Exception exe) {
				    report.reportFail("Select Resume in RG Page", "Resume button Should be Selected", "Resume button is not dispalyed");
				    report.updateMainReport("comments", "Resume button is not dispalyed");
				    report.updateMainReport("ErrorMessage", "Resume button is not dispalyed");
				    throw new UserDefinedException("Failed in Change Existing Services Page");
				}
	    
	    }
		    else if (get("ChangeType").equalsIgnoreCase("Correct Service Address")) {		
		  		
    			
		    	waitForLoader();		
				try {		
					waitForElementDisplay(CorrectServiceAddress, objectValue, 60);		
			    			
					clickUsingJavaScript(CorrectServiceAddress, "");		
					waitForLoader();		
				    waitForLoader();		
				    report.reportPass("Click Correct Service Address Button", "Click Correct Service Address Button if Exists", "Clicking Correct Service Address Button");		
				    		
				    if(isDisplayed(saleswindow, objectValue, 2))		
				    {		
					    clickUsingJavaScript(saleswindow, objectValue);		
					}		
				    waitForLoader();		
				    waitForLoader();		
				    switchToDefaultcontent();		
					waitForElementDisplay(IfProducts, objectValue, 60);		
					switchToDefaultcontent();		
					switchToFrame("IfProducts");		
							
					waitForElementDisplay(newAccount, objectValue, 60);		
					waitForLoader();		
							
					report.reportPass("New Account Page ", "New Account Section should be displayed", "New Account Section is Displayed");	
					
						
				    pageScroll(callingPartyName, objectValue, true);		
				    		
				    if(!callingPartyName.getText().isEmpty())		
				    {		
				    setText(callingPartyName, objectValue, "Automation");		
				    }		
				    	
				    
				    String HouseNumer = get("HouseName").trim();		
				    String Streetname = get("StreetAddress").trim();		
				    		
				    if(!HouseNumer.isEmpty())		
				    {		
				    	pageScroll(HouseNumber, objectValue, true);		
					    clearText(HouseNumber, objectValue);				    			
					    setText(HouseNumber, objectValue, HouseNumer);		
					    		
					    clearText(StreetName, objectValue);				    			
					    setText(StreetName, objectValue, Streetname);		
					    		
					    if(!get("StructureType").trim().isEmpty())		
					    {		
					    	selectDropDownUsingVisibleText(StructureType, objectValue, get("StructureType"));		
					    	waitForLoader();		
					    	clearText(StructureName, objectValue);		
					    	setText(StructureName, objectValue, get("StructureName"));		
					    }		
					    		
					    if(!get("FloorNumber").trim().isEmpty())		
					    {		
					    	clearText(FloorNumber, objectValue);		
					    	setText(FloorNumber, objectValue, get("FloorNumber"));		
					    }		
					    		
					    if(!get("UnitType").trim().isEmpty())		
					    {		
					    	selectDropDownUsingVisibleText(UnitType, objectValue, get("UnitType"));		
					    	waitForLoader();		
					    	clearText(UnitName, objectValue);		
					    	setText(UnitName, objectValue, get("UnitName"));		
					    }		
					    		
					    if(!get("City").trim().isEmpty()){
						    clearText(CityName, objectValue);				    			
						    setText(CityName, objectValue, get("City"));	
						    }
						    		
						    if(!get("State").trim().isEmpty()){	
						    clearText(StateName, objectValue);				    			
						    selectDropDownUsingVisibleText(StateName, objectValue, get("State"));		
						    }
						    if(!get("Zipcode").trim().isEmpty()){
						    		
						    clearText(ZipCode, objectValue);				    			
						    setText(ZipCode, objectValue, get("Zipcode"));
						    }		
				    }		
				    report.reportPass("Address Search Section", "Address details should be Entered Properly", "Address details Entered Properly");		
				    		
				    pageScroll(QualifyAddress, objectValue, true);		
				    clickUsingJavaScript(QualifyAddress, "");		
				    		
				    waitForLoader();		
				    waitForLoader();		
				    waitForLoader();		
				    waitForLoader();		
				    		
				    if(isDisplayed(SqeResultSection, ""))		
				    {		
				    	waitForLoader();		
				    	pageScroll(SqeResultSection, "", true);		
				    	report.reportPass("SQE Results should be displayed", "SQE Results are displayed", "SQE Results are displaying");		
				    }		
				    		
				    waitForLoader();	
					if(isDisplayed(newroommate, "")){
				    clickUsingJavaScript(newroommate, "");	
				    }					
				    pageScroll(SaveandContinue, objectValue, true);		
				    click(SaveandContinue, "");		
				    waitForLoader();		
				    waitForLoader();
				    		
				    waitForLoader();		
				    waitForLoader();		
				}		
				catch(Exception exe)		
				{		
					 exe.printStackTrace();		
					 report.reportFail("Click Correct Service Address Button", "Click Correct Service Address Button if Exists", "Unable to Click on Correct Service Address Button");		
				}		
		    }		
	 // for Voice to Voice+HSI Bundle along with BBE 07/27		
	    		
		    else if (get("ChangeType").equalsIgnoreCase("Get Copper Bundle")) {		
		    			
		    	waitForLoader();		
				try {		
					waitForElementDisplay(GetCopperBundle, objectValue, 60);		
			    	pageScroll(GetCopperBundle, objectValue, true);		
					clickUsingJavaScript(GetCopperBundle, "");		
					report.reportPass("Click on Get Copper Bundle Button", "Click on Get Copper Bundle Button if Exists", "Clicking on Get Copper Bundle Button");		
					waitForLoader();		
				    waitForLoader();		
				    if(isDisplayed(saleswindow, objectValue, 2))		
				    {		
					    clickUsingJavaScript(saleswindow, objectValue);		
					}		
				    waitForLoader();		
				    waitForLoader();		
				    		
				}		
				catch(Exception exe)		
				{		
						
					exe.printStackTrace();		
					report.reportFail("Click on Get Copper Bundle Button", "Click on Get Copper Bundle Button if Exists", "Unable to click on Copper Bundle Button");		
				}		
		    			
		    			
		    }		
		    else if (get("ChangeType").equalsIgnoreCase("Change LEC Voice")) {		
		    			
		    	waitForLoader();		
				try {		
					waitForElementDisplay(ChangeLECVoice, objectValue, 60);		
			    	pageScroll(ChangeLECVoice, objectValue, true);		
					clickUsingJavaScript(ChangeLECVoice, "");		
					report.reportPass("Click on Change LEC Voice Button", "Click on Change LEC Voice Button if Exists", "Clicking on Change LEC Voice Button");		
					waitForLoader();		
				    waitForLoader();		
				    if(isDisplayed(saleswindow, objectValue, 2))		
				    {		
					    clickUsingJavaScript(saleswindow, objectValue);		
					}		
				    waitForLoader();		
				    waitForLoader();		
				    		
				}		
				catch(Exception exe)		
				{		
						
					exe.printStackTrace();		
					report.reportFail("Click on Change LEC Voice Button", "Click on Change LEC Voice Button if Exists", "Unable to click on Change LEC Voice Button");		
				}		
		    			
		    			
		    }
	    
	     else if (get("ChangeType").equalsIgnoreCase("UNEP/TDRL")) {

		    	waitForLoader();
		    	waitForElementDisplay(btnAddUNEPTDRL, objectValue, 20);

		    	clickUsingJavaScript(btnAddUNEPTDRL, objectValue);
		    	waitForLoader();
	              waitForLoader();
	              waitForLoader();
		    	if(isDisplayed(saleswindow, objectValue, 10)){
		    	     clickUsingJavaScript(saleswindow, objectValue);
		    	     }

		    	     waitForLoader();
		    	report.reportPass("Click Change UNEPTDRL Button", "Click Change UNEPTDRL Button if Exists", "Clicking Change UNEPTDRL Button");

		    	    }
	    
	    
	    
	    /*****************updated by Mounika 11/08/2017 *****************************/
	    
	              //Global Navigator--> HSI- ADD EQUIPMENT
	    
	    /****************************************************************************/
	    
	     else if (get("ChangeType").equalsIgnoreCase("AddHSI")) {
		    	

		    	waitForLoader();
		    	Set<String> allExistingWindows = driver.getWindowHandles();
		    	waitForElementDisplay(addHSI, objectValue, 20);

		    	clickUsingJavaScript(addHSI, objectValue);
		    	waitForLoader();
	              waitForLoader();
	              waitForLoader();
		    	if(isDisplayed(saleswindow, objectValue, 2)){
		    	     clickUsingJavaScript(saleswindow, objectValue);
		    	     }

		    	     waitForLoader();
		    	    
		    	     waitForLoader();
		    	     Thread.sleep(10000);
		    	    // waitForElementDisplay(clickhere, objectValue, 30);
		    	     String productsWindow = driver.getWindowHandle();
		    			// Switching to BBE window
		    			Set<String> allWindows = driver.getWindowHandles();
		    			for (String Child_Window : allWindows) {

		    			    if (!allExistingWindows.contains(Child_Window)) {
		    				driver.switchTo().window(Child_Window);
		    				waitForLoader();
		    				waitForLoader();
		    				break;
		    			    }

		    			}
		    			System.out.println(driver.getTitle());
		    	  
		    	     System.out.println("Switched window");
		    	report.reportPass("Click HSI - Add Equipment Button", "Click HSI - Add Equipment Button if Exists", "Clicking HSI - Add Equipment Button");
		    	waitForLoader();
		    	waitForElementDisplay(addEquipment, objectValue, 20);
		    	clickUsingJavaScript(addEquipment, objectValue);
		    	waitForLoader();
		    	waitForLoader();
		    	waitForElementDisplay(Packageframe, objectValue, 10);
		    	 switchToFrame("extifrmpop");
		    	selectDropDownUsingIndex(selectpackage, objectValue, 1);		    	
				waitForLoader();  
				 switchToFrame("extifrmpop");
				click(ok, objectValue);
				switchToDefaultcontent();
				clickUsingJavaScript(rbtModem, objectValue);
				waitForLoader(); 
				clickUsingJavaScript(selectModem, objectValue);
				clickUsingJavaScript(SaveAndCont, objectValue);
				waitForLoader();
	     
	     }
	    
	     else if (get("ChangeType").equalsIgnoreCase("AddVVL")) {

		    	waitForLoader();
		    	waitForElementDisplay(verizonvoicelink, objectValue, 20);

		    	clickUsingJavaScript(homealarmsystem, objectValue);
		    	clickUsingJavaScript(legallyrequireddevices, objectValue);
		    	clickUsingJavaScript(securitydoor, objectValue);
		    	waitForLoader();
		    	clickUsingJavaScript(OkButton, objectValue);
		    	waitForLoader();
	              waitForLoader();
	              waitForLoader();
		    	if(isDisplayed(saleswindow, objectValue, 2)){
		    	     clickUsingJavaScript(saleswindow, objectValue);
		    	     }

		    	     waitForLoader();
		    	     waitForLoader();
		    	     waitForLoader();
		    	     Thread.sleep(2000);
		    	     switchToWindowWithURL("Thunder");
		    	report.reportPass("Click Change UNEPTDRL Button", "Click Change UNEPTDRL Button if Exists", "Clicking Change UNEPTDRL Button");

		    	    }
	 // Gopal changes on 10/04/2017 need to push to stash

		    else if (get("ChangeType").equalsIgnoreCase("Reissue Reason") && get("StackDisconnectOption").equalsIgnoreCase("System Issue"))
		    {
		    	try
		    	{
		    		String ordertype = get("ChangeType").trim();
		    		
		    		String ReissueReasoncode = get("StackDisconnectOption").trim();
		    		
		    		waitForElementDisplay(ReissueReason, ordertype, 60);
		    		
		    		clickUsingJavaScript(ReissueReason, ordertype);
		    		Thread.sleep(1000);
					clickUsingJavaScript(stackdisconnect1, ReissueReasoncode);
					
					report.reportPass("Click System Issue Button", "Click System Issue Button if Exists", "Clicking System Issue Button");
				    waitForLoader();
				    waitForLoader();	
				    if(isDisplayed(BtnYes, objectValue, 3))
				    {
					   	clickUsingJavaScript(BtnYes, objectValue);
					}
				    waitForLoader();
				    waitForLoader();
		    	}
		    	catch(Exception e)
		    	{
		    		e.printStackTrace();
		    	}
		    }
		    
		    else if (get("FlowType").contains("Change") && get("RG_Selection").equalsIgnoreCase("Dynamic"))
			{
				dynamicRGSelection();
			}
		    
		    else if(get("ChangeType").contains("Edit PIN"))
		    {
		    	
		    	String PIN = get("PINNumber").trim();
		    	String PINType = get("StackDisconnectOption").trim();
		    	
		    	if(isDisplayed(EditPIN))
		    	{
		    		pageScroll(EditPIN);
		    		clickUsingJavaScript(EditPIN, "");
		    		waitForLoader();
		    		report.reportPass("Validate Edit PIN Button is clicking or not" , "Edit PIN Button Should be Clicked", "Edit PIN Button is Clicked");
		    	}
		    	
		    	if(isDisplayed(ToolsOption, "", 5)) 		
		    	{
		    		pageScroll(ToolsOption);
		    		clickUsingJavaScript(ToolsOption, "");
		    		
			    	if(isDisplayed(EditPINInfo))
			    	{
			    		pageScroll(EditPINInfo);
			    		clickUsingJavaScript(EditPINInfo, "");
			    		waitForLoader();
			    		report.reportPass("Validate Edit PIN Button is clicking or not" , "Edit PIN Button Should be Clicked", "Edit PIN Button is Clicked");
			    	}
		        }
		    	
		    	if(isDisplayed(EditPINInformation))
		    	{
		    		mouseOver(TXTPIN);
		    		clearText(TXTPIN, "");
		    		setText(TXTPIN, "", PIN);
		    		report.reportPass("Validate that PIN Number Entered Successfully" , "PIN Number should be Entered Successfully", "PIN Number Entered Successfully");
		    		if(PINType.contains("Optional"))
		    		{
		    		
			    		clickUsingJavaScript(RBNOptional, "");
			    		report.reportPass("Validate that PIN Type selected Successfully" , "PIN Type should be selected Successfully", "PIN Type Selected Successfully");
		    		}
		    		else
		    		{
		    			
			    		clickUsingJavaScript(RBNMandatory, "");
			    		report.reportPass("Validate that PIN Type selected Successfully" , "PIN Type should be selected Successfully", "PIN Type Selected Successfully");
		    		}
		    		if(isDisplayed(Savepin))
		    		{
		    			mouseOver(Savepin, "");
			    		clickUsingJavaScript(Savepin, "");
			    		report.reportPass("Validate Save Button is clicking or not" , "Save Button Should be Clicked", "Save Button is Clicked");
		    		}
		    	}
		    	
		    }
		    else if(get("ChangeType").contains("SameDuedate"))
		    {
			    if(isDisplayed(InstallationTime, "", 5))		
				{
					String Installationtime = InstallationTime.getText().trim();
					report.reportPass("Validate that Estimated installation time is Displayed or not", "Estimated installation time should be Displayed", "Estimated installation time is Displaying" + Installationtime);
					System.out.println("Installation Time:" +Installationtime);
				}
		    }
		    else if(get("ChangeType").contains("CloseAccount"))
		    {
		    	if(isDisplayed(BtnCloseAccount, "", 5))
		    	{
		    		waitForLoader();
		    		pageScroll(BtnCloseAccount);
		    		clickUsingJavaScript(BtnCloseAccount, "");
		    		report.reportPass("Validate that CloseAccount Button is Clicked or not", "CloseAccount Button should be Clicked", "CloseAccount Button is Clicked");
		    		waitForLoader();
		    	}
		    	if(isDisplayed(CloseReasonForCall, "", 5))
		    	{
		    		String ReasonforCall = get("StackDisconnectOption").trim();
		    		pageScroll(CloseReasonForCall);
		    		selectDropDownUsingValue(CloseReasonForCall, "", ReasonforCall);
		    		report.reportPass("Validate that CloseReasonForCall is selected or not", "CloseReasonForCall Should be selected", "CloseReasonForCall is selected");
		    		waitForLoader();
		    	}
		    	if(isDisplayed(TxtCloseNotes, "", 5))
		    	{
		    		pageScroll(TxtCloseNotes);
		    		clearText(TxtCloseNotes, objectValue);
		    		setText(TxtCloseNotes, "", "GopalTest");
		    		report.reportPass("Validate that Close notes Text entered or not", "Close notes Text should be entered", "Close notes Text is entered");
		    		waitForLoader();
		    	}
		    	if(isDisplayed(BtnSaveAndClose, "", 5))
		    	{
		    		pageScroll(BtnSaveAndClose);
		    		clickUsingJavaScript(BtnSaveAndClose, objectValue);
		    		report.reportPass("Validate that Save and Close Button is clicked", "Save and Close Button shuld be clicked", "Save and Close Button is clicked");
		    		waitForLoader();
		    	}
		    	if(isDisplayed(BtnRefresh, "", 5))
		    	{
		    		pageScroll(BtnRefresh);
		    		clickUsingJavaScript(BtnRefresh, objectValue);
		    		report.reportPass("Validate that Refresh Button is clicked", "Refresh Button shuld be clicked", "Refresh Button is clicked");
		    		waitForElementDisplay(Timestamp, objectValue, pageTimeoutInSeconds);
		    		String TimeStamp = Timestamp.getText().trim();
		    		String ReasonforCall = TxtReasonforCall.getText().trim();
		    		report.reportPass("Displaying Time Stamp and Reason for Call", "Time Stamp and Reason for Call Should be Displayed", "Time Stamp and Reason for Call Displayed: "+ ReasonforCall + "      " +TimeStamp);
		    		System.out.println("Reason for Call and Time Stamp: "+ReasonforCall + "   " +TimeStamp);
		    		
		    	}
		    	
		    }
	       /******************Bharathi SAC**************/
	      ////// *********Change Password Flow***********/////////
		    else if (get("ChangeType").equalsIgnoreCase("ChangePassword")) {
		    	
		    waitForLoader();
		    		    
		    	clickUsingJavaScript(changePwd, objectValue);
				report.reportPass("Click on Change Password", "Change Password should be clicked", "Change Password is clicked"+get("N1P2"));
		    	waitForLoader();
		    	
		    }
		    

		    ////// *********Change Contact Info Flow***********/////////
		    else if (get("ChangeType").equalsIgnoreCase("EditContactInfo")) {
		    	
		    waitForLoader();
		
		    editContactInfo();
		    }
		    
		    
		////// *********Change PIN Flow***********/////////
				    else if (get("ChangeType").equalsIgnoreCase("ChangePIN")) {
				    	
				   /* waitForLoader();
				    String oldP=getPIN.getText();
				    String oldPIN= oldP.replaceAll("[^0-9]", "");
			    	System.out.println("Old pIN displayed"+oldPIN);
			    	report.reportPass("Captured Old PIN", "Old PIN in Snapshot", "PIN before Change:"+oldPIN);
				    waitForElementDisplay(productTools, objectValue, pageTimeoutInSeconds);
			    	productTools.click();*/
				    if (isDisplayed(editPIN, objectValue))
				    	{
				    	
				    	clickUsingJavaScript(editPIN, objectValue);
				    	waitForLoader();
				    	
				    	}
				    }
	    /********************Mounika****************************/
				    else if(get("ChangeType").contains("ExpediteServices") && (get("Application").equalsIgnoreCase("C2G")))
				    {
				    waitForElementDisplay(expdServices, objectValue, 30);
				    clickUsingJavaScript(expdServices, objectValue);
				    waitForLoader();
				    waitForLoader();
				    waitForLoader();
				    switchToWindowWithURL("VasipD2D");
					System.out.println(driver.getTitle());
					waitForLoader();
					waitForLoader();
					waitForLoader();
					String[] VasProds = get("VAS_Expedite").split(",");
					for (String VasProd : VasProds) {
					try {
					    pageScroll(BBEOptions, VasProd, true);
					    clickUsingJavaScript(BBEOptions, VasProd);
					    if(isDisplayed(yesIHaveRead1, objectValue)){
					    	clickUsingJavaScript(yesIHaveRead1, objectValue);
					    }
					    else if(isDisplayed(yesIHaveRead2, objectValue)){
					    	clickUsingJavaScript(yesIHaveRead2, objectValue);
					    }
					    else if(isDisplayed(yesIHaveRead3, objectValue)){
					    	clickUsingJavaScript(yesIHaveRead3, objectValue);
					    }
						else if(isDisplayed(yesIHaveRead4, objectValue)){
					    	clickUsingJavaScript(yesIHaveRead4, objectValue);
					    }
						else if(isDisplayed(yesIHaveRead5, objectValue)){
					    	clickUsingJavaScript(yesIHaveRead5, objectValue);
					    }
                        else if(isDisplayed(yesIHaveRead6, VasProd)){
							clickUsingJavaScript(yesIHaveRead6, objectValue);
						}
					    report.reportPass("Verify VASProduct is Selected", "Check whether Vas Product is Clicked", "VAS Product is Clicked:" + VasProd);
					    // Click on save and COntinue in BBE page
					    clickUsingJavaScript(VASSaveandContinue, objectValue);
					    report.reportPass("Click on VAS save and continue button.", "Save and continue button should be clicked.", "Clicked on save and continue button.");
					    pause();
					    waitForLoader();
					    waitForLoader();
					    waitForLoader();
					    if (isDisplayed(BBE_warning))
					    {
					    	clickUsingJavaScript(BBE_Existing,objectValue);
					    	if(isDisplayed(reasonForRemoval)){
				    			 pageScroll(reasonForRemoval);
				    			 report.reportPass("Click on Reason for Removal.", "Click on Reason for Removal.", "Reason for Removal is selected");
				    			 selectDropDownUsingIndex(reasonForRemoval, "", 2);
				    			 waitForLoader();
				    			 waitForLoader();
				    			 
				    		 }
				    		 
					    	 clickUsingJavaScript(VASSaveandContinue, objectValue);
							    report.reportPass("Click on VAS save and continue button.", "Save and continue button should be clicked.", "Clicked on save and continue button.");
					    }
					} catch (Exception e) {
					    strFailed = "Failed in VAS section, Required VAS product " + VasProd + " not available.";
					    report.reportFail("Select VAS option.", "VAS option should be selected.", strFailed);
					    report.updateMainReport("comments", strFailed);
					    report.updateMainReport("ErrorMessage", strFailed);
					    logger.error(strFailed);
					    captureErrorMsg(strFailed);
					    throw new UserDefinedException(strFailed);
					}
					
					}
					waitForLoader();
				    waitForLoader();


				    }
	    
/***********************  Naresh   - VAS Product- add adults and child information  *********************/
	    
				    else if(get("ChangeType").contains("ExpediteServices") && (get("Application").equalsIgnoreCase("COA")))
				    {
				    	waitForElementDisplay(expdServices, objectValue, 30);
					    clickUsingJavaScript(expdServices, objectValue);
					    waitForLoader();
					    waitForLoader();
					    waitForLoader();
					   // selectDropDownUsingVisibleText(selectAgencyID, " ", get("AgencyID"));
					    //report.reportPass("Select agency Id", "Select agency Id", "Agency Id is Selected");
					    if (isDisplayed(salesProfileSave, "", 2)) {
			                   clickUsingJavaScript(salesProfileSave, "");
			                   waitForLoader();
			               }
					    pause();
					    pause();
					    pause();
					    //switchToWindowWithURL("VasipD2D");
					    
					    switchToWindowWithTitle("Change");
						System.out.println(driver.getTitle());
						waitForLoader();
						waitForLoader();
						waitForLoader();
						Thread.sleep(15000);
						
						String[] listChannels = get("VASProduct").split(";");
			    		System.out.println(listChannels);
			    		try {
			    		 for (int i = 0; i < listChannels.length; i++) {
			    			 System.out.println(listChannels[i]);
			    			 if(listChannels[i].toUpperCase().contains(":X") ){
			    				 
			    				String BBEProduct = listChannels[i].split(":X")[0];
			    				System.out.println(BBEProduct);
			    				pageScroll(RemoveBBE, BBEProduct, true);
			    				report.reportPass("Display Existing BBE", "Display Existing BBE", "Existing BBE is displayed");
			    					//clickUsingJavaScript(RemoveBBE, BBEProduct);
			    				//waitForLoader();
			    				//report.reportPass("Check whether BBE is removed", "Check whether BBE is removed", "BBE is removed");
			    				if(!BBEProduct.equalsIgnoreCase("TechSure")){
			    				clickUsingJavaScript(ChangeBtn, BBEProduct);
			    				waitForLoader();
			    				waitForLoader();
			    				waitForLoader();
			    				waitForLoader();
			    				waitForLoader();
			    				waitForLoader();
			    				waitForLoader();
			    				waitForLoader();
			    				waitForLoader();
			    				waitForLoader();
			    				
			    				
			    				//clickUsingJavaScript(RemoveBBE, BBEProduct);
			    				
			    				//clickUsingJavaScript(RemoveBBE, BBEProduct);
			    				report.reportPass("Check whether BBE is removed", "Check whether BBE is removed", "BBE is removed");
			    				}
			    				else{
			    					clickUsingJavaScript(RemoveBBE, BBEProduct);
				    				waitForLoader();
				    				report.reportPass("Check whether BBE is removed", "Check whether BBE is removed", "BBE is removed");
			    				}
			    				waitForLoader();
			    				waitForLoader();
			    		
			    			waitForLoader();
			    			
			    			 }
			    			 else{
			    			 	if(listChannels[i].equalsIgnoreCase("TechSure Plus")|| listChannels[i].equalsIgnoreCase("TechSure Premium") ){
			    						if(listChannels[i].equalsIgnoreCase("TechSure Plus")){
			    							pageScroll(VASProduct_TechSurePlus_ProductsPage, "", true);
			    				   		 	clickUsingJavaScript(VASProduct_TechSurePlus_ProductsPage, "");
			    				   		 waitForLoader();
			    				   		    report.reportPass("Select VAS Product TechSure Plus", "VAS Product TechSure Plus must be selected", "TechSure Plus is selected");
			    				   		 	}else if(listChannels[i].equalsIgnoreCase("TechSure Premium")){
			    				   		 	pageScroll(VASProduct_TechSurePremium_ProductsPage, "", true);
			    				   		 	clickUsingJavaScript(VASProduct_TechSurePremium_ProductsPage, "");
			    				   		    report.reportPass("Select VAS Product TechSure Premium", "VAS Product TechSure Premium must be selected", "TechSure Plus Premium is selected");
			    				   		 	waitForLoader();
			    				   		 	if(isDisplayed(VASProduct_TechSurePremium_Coverage, "", 1)){
			    				   		 	clickUsingJavaScript(VASProduct_TechSurePremium_Coverage, objectValue);
			    				   		 	}
			    				   		 	}
			    				   		 System.out.println("");
			    					    	switchToFrame("IfProducts");
			    					    	
			    					    	 List<WebElement> fsname = driver.findElements(By.xpath("//input[@id='txtParentFirstName']"));			    	 		  			      	 				  
			    			      	 				  for (int x=0;x<fsname.size();x++)
			    			      	 				  {			      	 					 
			    			      	 						 if(isDisplayed(fsname.get(x))){
			    			      	 							if(fsname.get(x).isEnabled()){
			    			      	 						fsname.get(x).sendKeys("Passlow");
			    			      	 						  waitForLoader();
			    			      	 							}
			    			      	 						break ;
			    			      	 					  }
			    			      	 				  }				   		 	
			    							    report.reportPass("For VAS Product "+get("VASProduct").trim()+" input must be provided in First Name field", "Input provided in First Name Field", "Input provided in First Name field is .Passlow");
			    							    List<WebElement> Lsname = driver.findElements(By.xpath("//input[@id='txtParentLastName']"));			    	 		  			      	 				  
			    		      	 				  for (int y=0;y<Lsname.size();y++)
			    		      	 				  {
			    		      	 					
			    		      	 					 if(isDisplayed(Lsname.get(y))){
			    		      	 					  if(Lsname.get(y).isEnabled()){
			    		      	 						Lsname.get(y).sendKeys("Customer");
			    		      	 						  waitForLoader();
			    		      	 					  }
			    		      	 						break ;
			    		      	 					  }
			    		      	 				  }	
			    							    report.reportPass("For VAS Product "+get("VASProduct").trim()+" input must be provided in Last Name field", "Input provided in Last Name Field", "Input provided in Last Name field is .Customer");
			    							    
			    							    //check for Junior & Senior selection
			    							    if(get("TechSure_LifeLock_Adult").equalsIgnoreCase("Yes")){
			    							    	if(get("TechSure_LifeLock_Adult_Quantity").equals("1")){
			    							    		
			    							    		List<WebElement> CheckboxAdult = driver.findElements(By.xpath("//input[@id='chkDGAdultSubscription']"));			    	 		  			      	 				  
			    				      	 				  for (int z=0;z<CheckboxAdult.size();z++)
			    				      	 				  {
			    				      	 					
			    				      	 					 if(isDisplayed(CheckboxAdult.get(z))){
			    				      	 					  
			    				      	 						CheckboxAdult.get(z).click();
			    				      	 						  waitForLoader();
			    				      	 						break ;
			    				      	 					  }
			    				      	 				  }	
			    				      	 				  
			    				      	 				List<WebElement> AdultFisrtName = driver.findElements(By.xpath("//input[@id='txtAdultFirstName']"));			    	 		  			      	 				  
			    				      	 				  for (int x1=0;x1<AdultFisrtName.size();x1++)
			    				      	 				  {
			    				      	 					
			    				      	 					if(isDisplayed(AdultFisrtName.get(x1))){
			    				      	 					  
			    				      	 						AdultFisrtName.get(x1).sendKeys("Yugendher");
			    				      	 						  waitForLoader();
			    				      	 						 report.reportPass("For Tech Sure - LifeLock Adult Product input must be provided in First Name field", "Input provided in First Name Field", "Input provided in First Name field is .Yegendher");
			    				      	 						break ;
			    				      	 					  }
			    				      	 				  }	
			    				      	 				List<WebElement> AdultLastName = driver.findElements(By.xpath("//input[@id='txtAdultLastName']"));			    	 		  			      	 				  
			    				      	 				  for (int x2=0;x2<AdultLastName.size();x2++)
			    				      	 				  {
			    				      	 					
			    				      	 					 
			    				      	 					if(isDisplayed(AdultLastName.get(x2))){
			    				      	 						AdultLastName.get(x2).sendKeys("Reddy");
			    				      	 						  waitForLoader();
			    				      	 						 report.reportPass("For Tech Sure - LifeLock Adult Product input must be provided in Last Name field", "Input provided in Last Name Field", "Input provided in Last Name field is .Yegendher");
			    				      	 						break ;
			    				      	 					  }
			    				      	 				  }	
			    				      	 				List<WebElement> AdultEmail = driver.findElements(By.xpath("//input[@id='txtAdultEmail']"));			    	 		  			      	 				  
			    				      	 				  for (int x3=0;x3<AdultEmail.size();x3++)
			    				      	 				  {
			    				      	 					
			    				      	 					if(isDisplayed(AdultEmail.get(x3))){
			    				      	 						AdultEmail.get(x3).sendKeys("yugendhar.m.reddy@g.verizon.com");
			    				      	 						  waitForLoader();
			    				      	 						 report.reportPass("For Tech Sure - LifeLock Adult Product input must be provided in Email Name field", "Input provided in Email Field", "Input provided in Last Name field is .yugendhar.m.reddy@g.verizon.com");
			    				      	 						break ;
			    				      	 					  }
			    				      	 				  }	
			    										   
			    										   
			    										   
			    										    
			    										   
			    							    		
			    							    	}
			    							    		else if(get("TechSure_LifeLock_Adult_Quantity").equals("2")){
			    							    			List<WebElement> CheckboxAdult = driver.findElements(By.xpath("//input[@id='chkDGAdultSubscription']"));			    	 		  			      	 				  
			    					      	 				  for (int z=0;z<CheckboxAdult.size();z++)
			    					      	 				  {
			    					      	 					
			    					      	 					 if(isDisplayed(CheckboxAdult.get(z))){
			    					      	 					  
			    					      	 						CheckboxAdult.get(z).click();
			    					      	 						  waitForLoader();
			    					      	 						break ;
			    					      	 					  }
			    					      	 				  }	
			    					      	 				  
			    					      	 				List<WebElement> AdultFisrtName = driver.findElements(By.xpath("//input[@id='txtAdultFirstName']"));			    	 		  			      	 				  
			    					      	 				  for (int x1=0;x1<AdultFisrtName.size();x1++)
			    					      	 				  {
			    					      	 					
			    					      	 					if(isDisplayed(AdultFisrtName.get(x1))){
			    					      	 						if(AdultFisrtName.get(x1).isEnabled()){
			    					      	 						AdultFisrtName.get(x1).sendKeys("Yugendher");
			    					      	 						  waitForLoader();
			    					      	 						 report.reportPass("For Tech Sure - LifeLock Adult Product input must be provided in First Name field", "Input provided in First Name Field", "Input provided in First Name field is .Yegendher");
			    					      	 						break ;
			    					      	 						}
			    					      	 					  }
			    					      	 				  }	
			    					      	 				List<WebElement> AdultLastName = driver.findElements(By.xpath("//input[@id='txtAdultLastName']"));			    	 		  			      	 				  
			    					      	 				  for (int x2=0;x2<AdultLastName.size();x2++)
			    					      	 				  {
			    					      	 					
			    					      	 					 
			    					      	 					if(isDisplayed(AdultLastName.get(x2))){
			    					      	 						if(AdultLastName.get(x2).isEnabled()){
			    					      	 						AdultLastName.get(x2).sendKeys("Reddy");
			    					      	 						  waitForLoader();
			    					      	 						 report.reportPass("For Tech Sure - LifeLock Adult Product input must be provided in Last Name field", "Input provided in Last Name Field", "Input provided in Last Name field is .Yegendher");
			    					      	 						break ;
			    					      	 						}
			    					      	 					  }
			    					      	 				  }	
			    					      	 				List<WebElement> AdultEmail = driver.findElements(By.xpath("//input[@id='txtAdultEmail']"));			    	 		  			      	 				  
			    					      	 				  for (int x3=0;x3<AdultEmail.size();x3++)
			    					      	 				  {
			    					      	 					
			    					      	 					if(isDisplayed(AdultEmail.get(x3))){
			    					      	 						if(AdultEmail.get(x3).isEnabled()){
			    					      	 						AdultEmail.get(x3).sendKeys("yugendhar.m.reddy@g.verizon.com");
			    					      	 						  waitForLoader();
			    					      	 						 report.reportPass("For Tech Sure - LifeLock Adult Product input must be provided in Email Name field", "Input provided in Email Field", "Input provided in Last Name field is .yugendhar.m.reddy@g.verizon.com");
			    					      	 						break ;
			    					      	 						}
			    					      	 					  }
			    					      	 				  }	
			    					      	 				  
			    					      	 				List<WebElement> AddAdultSubscription = driver.findElements(By.xpath("//a[@id='lnkAddAdultSubscription']"));			    	 		  			      	 				  
			    					      	 				  for (int x3=0;x3<AddAdultSubscription.size();x3++)
			    					      	 				  {
			    					      	 					
			    					      	 					if(isDisplayed(AddAdultSubscription.get(x3))){
			    					      	 						AddAdultSubscription.get(x3).click();
			    					      	 						  waitForLoader();
			    					      	 						  report.reportPass("For Tech Sure - LifeLock Adult Product Add More Subscription link must be clicked", "Add more subscription link is clicked", "Add more subscription link is clicked");
			    					      	 						break ;
			    					      	 					  }
			    					      	 				  }						      	 				  
			    					      	 				  
			    										   
			    										    Thread.sleep(1000);
			    										    List<WebElement> AdultFsName2 = driver.findElements(By.xpath("//input[contains(@id,'txtAdultFirstName2')]"));			    	 		  			      	 				  
			    					      	 				  for (int x3=0;x3<AdultFsName2.size();x3++)
			    					      	 				  {
			    					      	 					
			    					      	 					if(isDisplayed(AdultFsName2.get(x3))){
			    					      	 						if(AdultFsName2.get(x3).isEnabled()){
			    					      	 						AdultFsName2.get(x3).sendKeys("Naresh");
			    					      	 						  waitForLoader();
			    					      	 						report.reportPass("For Tech Sure - LifeLock Adult Product input must be provided in First Name field", "Input provided in First Name Field", "Input provided in First Name field is . Naresh");
			    					      	 						break ;
			    					      	 						}
			    					      	 					  }
			    					      	 				  }		
			    					      	 				List<WebElement> AdultLsName2 = driver.findElements(By.xpath("//input[contains(@id,'txtAdultLastName2')]"));			    	 		  			      	 				  
			    					      	 				  for (int x3=0;x3<AdultLsName2.size();x3++)
			    					      	 				  {
			    					      	 					
			    					      	 					if(isDisplayed(AdultLsName2.get(x3))){
			    					      	 						if(AdultLsName2.get(x3).isEnabled()){
			    					      	 						AdultLsName2.get(x3).sendKeys("Madipelly");
			    					      	 						  waitForLoader();
			    					      	 						report.reportPass("For Tech Sure - LifeLock Adult Product input must be provided in Last Name field", "Input provided in Last Name Field", "Input provided in Last Name field is . Madipelly");
			    					      	 						break ;
			    					      	 						}
			    					      	 					  }
			    					      	 				  }	
			    					      	 				  
			    					      	 				List<WebElement> AdultEmail2 = driver.findElements(By.xpath("//input[contains(@id,'txtAdultEmail2')]"));			    	 		  			      	 				  
			    					      	 				  for (int x3=0;x3<AdultEmail2.size();x3++)
			    					      	 				  {
			    					      	 					
			    					      	 					if(isDisplayed(AdultEmail2.get(x3))){
			    					      	 						if(AdultEmail2.get(x3).isEnabled()){
			    					      	 						AdultEmail2.get(x3).sendKeys("naresh.madipelly2@verizon.com");
			    					      	 						  waitForLoader();
			    					      	 						report.reportPass("For Tech Sure - LifeLock Adult Product input must be provided in Email Name field", "Input provided in Email Field", "Input provided in Last Name field is . naresh.madipelly2@verizon.com");
			    					      	 						break ;
			    					      	 						}
			    					      	 					  }
			    					      	 				  }
			    										    
			    										   
			    										    
			    										    
			    							    	
			    							    	}
			    							    	
			    								  

			    							    }
			    							    if(get("TechSure_LifeLock_Junior").equalsIgnoreCase("Yes")){
			    							    	if(get("TechSure_LifeLock_Junior_Quantity").equals("1")){
			    							    		
			    							    		List<WebElement> ChckboxJunior = driver.findElements(By.xpath("//input[@id='chkDGChildSubscription']"));			    	 		  			      	 				  
			    				      	 				  for (int x3=0;x3<ChckboxJunior.size();x3++)
			    				      	 				  {
			    				      	 					
			    				      	 					if(isDisplayed(ChckboxJunior.get(x3))){
			    				      	 						
			    				      	 						ChckboxJunior.get(x3).click();
			    				      	 						  waitForLoader();
			    				      	 						  report.reportPass("For Tech Sure - LifeLock Adult Product Add More Subscription link must be clicked", "Add more subscription link is clicked", "Add more subscription link is clicked");
			    				      	 						break ;
			    				      	 					  }
			    				      	 				  }						      	 				  
			    				      	 				List<WebElement> JuniorFname = driver.findElements(By.xpath("//input[@id='txtChildFirstName']"));			    	 		  			      	 				  
			    				      	 				  for (int x3=0;x3<JuniorFname.size();x3++)
			    				      	 				  {
			    				      	 					
			    				      	 					if(isDisplayed(JuniorFname.get(x3))){
			    				      	 						if(JuniorFname.get(x3).isEnabled()){
			    				      	 						JuniorFname.get(x3).sendKeys("Soham");
			    				      	 						  waitForLoader();
			    				      	 						report.reportPass("For Tech Sure - LifeLock Junior Product input must be provided in First Name field", "Input provided in First Name Field", "Input provided in First Name field is . Soham");
			    				      	 						break ;
			    				      	 						}
			    				      	 					  }
			    				      	 				  }  
			    				      	 				List<WebElement> JuniorLname = driver.findElements(By.xpath("//input[@id='txtChildLastName']"));			    	 		  			      	 				  
			    				      	 				  for (int x3=0;x3<JuniorLname.size();x3++)
			    				      	 				  {
			    				      	 					
			    				      	 					if(isDisplayed(JuniorLname.get(x3))){
			    				      	 						if(JuniorLname.get(x3).isEnabled()){
			    				      	 						JuniorLname.get(x3).sendKeys("Shah");
			    				      	 						  waitForLoader();
			    				      	 						 report.reportPass("For Tech Sure - LifeLock Junior Product input must be provided in Last Name field", "Input provided in Last Name Field", "Input provided in Last Name field is .Shah");
			    				      	 						break ;
			    				      	 						}
			    				      	 					  }
			    				      	 				  }  
			    									    
			    									   
			    							    	}
			    							    	else if(get("TechSure_LifeLock_Junior_Quantity").equals("2")){
			    							    		List<WebElement> ChckboxJunior = driver.findElements(By.xpath("//input[@id='chkDGChildSubscription']"));			    	 		  			      	 				  
			    				      	 				  for (int x3=0;x3<ChckboxJunior.size();x3++)
			    				      	 				  {
			    				      	 					
			    				      	 					if(isDisplayed(ChckboxJunior.get(x3))){
			    				      	 						ChckboxJunior.get(x3).click();
			    				      	 						  waitForLoader();
			    				      	 						  report.reportPass("For Tech Sure - LifeLock Junior Product Add More Subscription link must be clicked", "Add more subscription link is clicked", "Add more subscription link is clicked");
			    				      	 						break ;
			    				      	 					  }
			    				      	 				  }						      	 				  
			    				      	 				List<WebElement> JuniorFname = driver.findElements(By.xpath("//input[@id='txtChildFirstName']"));			    	 		  			      	 				  
			    				      	 				  for (int x3=0;x3<JuniorFname.size();x3++)
			    				      	 				  {
			    				      	 					
			    				      	 					if(isDisplayed(JuniorFname.get(x3))){
			    				      	 						if(JuniorFname.get(x3).isEnabled()){
			    				      	 						JuniorFname.get(x3).sendKeys("Soham");
			    				      	 						  waitForLoader();
			    				      	 						report.reportPass("For Tech Sure - LifeLock Junior Product input must be provided in First Name field", "Input provided in First Name Field", "Input provided in First Name field is . Soham");
			    				      	 						break ;
			    				      	 						}
			    				      	 					  }
			    				      	 				  }  
			    				      	 				List<WebElement> JuniorLname = driver.findElements(By.xpath("//input[@id='txtChildLastName']"));			    	 		  			      	 				  
			    				      	 				  for (int x3=0;x3<JuniorLname.size();x3++)
			    				      	 				  {
			    				      	 					
			    				      	 					if(isDisplayed(JuniorLname.get(x3))){
			    				      	 						if(JuniorLname.get(x3).isEnabled()){
			    				      	 						JuniorLname.get(x3).sendKeys("Shah");
			    				      	 						  waitForLoader();
			    				      	 						 report.reportPass("For Tech Sure - LifeLock Junior Product input must be provided in Last Name field", "Input provided in Last Name Field", "Input provided in Last Name field is .Shah");
			    				      	 						break ;
			    				      	 						}
			    				      	 					  }
			    				      	 				  }  
			    				      	 				  
			    				      	 				List<WebElement> JuniorMoreSubsc = driver.findElements(By.xpath("//a[@id='lnkAddChildSubscription']"));			    	 		  			      	 				  
			    				      	 				  for (int x3=0;x3<JuniorMoreSubsc.size();x3++)
			    				      	 				  {
			    				      	 					
			    				      	 					if(isDisplayed(JuniorMoreSubsc.get(x3))){
			    				      	 						JuniorMoreSubsc.get(x3).click();
			    				      	 						  waitForLoader();
			    				      	 						  report.reportPass("For Tech Sure - LifeLock Junior Product Add More Subscription link must be clicked", "Add more subscription link is clicked", "Add more subscription link is clicked");
			    				      	 						break ;
			    				      	 					  }
			    				      	 				  }	
			    							    		
			    							    		Thread.sleep(1000);
			    							    		List<WebElement> JuniorFname2 = driver.findElements(By.xpath("//input[contains(@id,'txtChildFirstName2')]"));			    	 		  			      	 				  
			    				      	 				  for (int x3=0;x3<JuniorFname2.size();x3++)
			    				      	 				  {
			    				      	 					
			    				      	 					if(isDisplayed(JuniorFname2.get(x3))){
			    				      	 						if(JuniorFname2.get(x3).isEnabled()){
			    				      	 						JuniorFname2.get(x3).sendKeys("Alpha");
			    				      	 						  waitForLoader();
			    				      	 						report.reportPass("For Tech Sure - LifeLock Junior Product input must be provided in First Name field", "Input provided in First Name Field", "Input provided in First Name field is .Alpha");
			    				      	 						break ;
			    				      	 						}
			    				      	 					  }
			    				      	 				  }  
			    				      	 				List<WebElement> JuniorLname2 = driver.findElements(By.xpath("//input[contains(@id,'txtChildLastName2')]"));			    	 		  			      	 				  
			    				      	 				  for (int x3=0;x3<JuniorLname2.size();x3++)
			    				      	 				  {
			    				      	 					
			    				      	 					if(isDisplayed(JuniorLname2.get(x3))){
			    				      	 						if(JuniorLname2.get(x3).isEnabled()){
			    				      	 						JuniorLname2.get(x3).sendKeys("Beta");
			    				      	 						  waitForLoader();
			    				      	 						report.reportPass("For Tech Sure - LifeLock Junior Product input must be provided in Last Name field", "Input provided in Last Name Field", "Input provided in Last Name field is .Beta");
			    				      	 						break ;
			    				      	 					}
			    				      	 					  }
			    				      	 				  }  
			    				      	 				  
			    							    		
			    									    

			    							    	}
			    								    
			    							    }	
			    						
			    					}
			    					   else if(listChannels[i].equalsIgnoreCase("TechSure")){
			    					   		pageScroll(VASProduct_TechSure_ProductsPage, "", true);
			    					   		clickUsingJavaScript(VASProduct_TechSure_ProductsPage, "");
			    						    report.reportPass("Verify VASProduct is Selected", "Check whether Vas Product is Clicked", "VAS Product is Clicked:");
			    							
			    					
			    					   	 }
			    					   else{
			    				    pageScroll(BBEOptions, listChannels[i].trim(), true);
			    				    clickUsingJavaScript(BBEOptions, listChannels[i].trim());
			    				    report.reportPass("Click on category.", "Channel category should be clicked.", "Clicked on " + listChannels[i] + "channel category");
			    					   }
			    			 }
			    		 }
			    				
			       		
			    		 } catch (Exception e) {
			    			    strFailed = "Failed in VAS section, Required VAS product " + get("VASProduct") + " not available.";
			    			    report.reportFail("Select VAS option.", "VAS option should be selected.", strFailed);
			    			    report.updateMainReport("comments", strFailed);
			    			    report.updateMainReport("ErrorMessage", strFailed);
			    			    logger.error(strFailed);
			    			    captureErrorMsg(strFailed);
			    			    throw new UserDefinedException(strFailed);
			    			}
			    		
			    		waitForLoader();
			    		waitForLoader();
			    		waitForLoader();
			    		
			    		 if(isDisplayed(YesButton, "", 1)){
			    			 clickUsingJavaScript(YesButton, objectValue);
			    			 waitForLoader();
			    			 waitForLoader();
			    		 }
			    		 if(isDisplayed(reasonForRemoval, "", 1)){
			    			 pageScroll(reasonForRemoval, "", true);
			    			 report.reportPass("Click on Reason for Removal.", "Click on Reason for Removal.", "Reason for Removal is selected");
			    			 selectDropDownUsingIndex(reasonForRemoval, "", 2);
			    			 waitForLoader();
			    			 waitForLoader();
			    			 
			    		 }
			    		 
			    		 
			       	               
			    		if(isDisplayed(Submitbtn, "", 2)){
			    			clickUsingJavaScript(Submitbtn, objectValue);			    			 
			    			 waitForLoader();
			    			 waitForLoader();
			    			 report.reportPass("Select Submit button", "Select Submit button", "Submit button is selecteed");
			    		 }
			    		 if(isDisplayed(reasonForRemoval, "", 1)){
			    			 pageScroll(reasonForRemoval, "", true);
			    			 report.reportPass("Click on Reason for Removal.", "Click on Reason for Removal.", "Reason for Removal is selected");
			    			 selectDropDownUsingIndex(reasonForRemoval, "", 2);
			    			 waitForLoader();
			    			 waitForLoader();
			    			 
			    		 }
			    		 	 
			    		try {
			    		    
			    		    // Click on save and COntinue in BBE page
			    			pageScroll(VASSaveandContinue, "", true);
			    			report.reportPass("Click on VAS save and continue button.", "Save and continue button should be clicked.", "save and continue button should be clicked");
			    		    clickUsingJavaScript(VASSaveandContinue, objectValue);
			    		    
			    		} catch (Exception e) {
			    		    strFailed = "Failed in VAS section, Required VAS product " + get("VASProduct") + " not available.";
			    		    report.reportFail("Select VAS option.", "VAS option should be selected.", strFailed);
			    		    report.updateMainReport("comments", strFailed);
			    		    report.updateMainReport("ErrorMessage", strFailed);
			    		    logger.error(strFailed);
			    		    captureErrorMsg(strFailed);
			    		    throw new UserDefinedException(strFailed);
			    		}
	    
				    }
	    
				    else if(get("ChangeType").contains("HighSpeedInternet")){		    	
				    	
				    	if(isDisplayed(upshellPopup, objectValue, 10)){
				    		clickUsingJavaScript(closePopup, objectValue);
				    	}
				    		waitForElementDisplay(btnHighSpeedInternet, objectValue, 20);
				    		pageScroll(btnHighSpeedInternet, objectValue, true);
				    		report.reportPass("Check whether High Speed Internet is Displayed", "Verify whether High Speed Internet is Displayed", "High speed Internet is Dispalyed");
				    	clickUsingJavaScript(btnHighSpeedInternet, objectValue);
				    	waitForLoader();
					    waitForLoader();
					    pause();
					    switchToWindowWithURL("HSID2D");
					    clickUsingJavaScript(BTNno, objectValue);
					    report.reportPass("Check whether BTN is clicked", "Verify whether BTN is Clicked", "BTN is Clicked");
					    waitForLoader();
					    waitForLoader();
					    waitForLoader();
					    pageScroll(HBONow, objectValue, true);
					    clickUsingJavaScript(HBONow, objectValue);
					    report.reportPass("Check whether HBO Now is clicked", "Verify whether HBO Now is Clicked", "HBO Now is Clicked");
					    clickUsingJavaScript(SaveAndCont, objectValue);
						waitForLoader();
						waitForLoader();
						waitForLoader();
						 switchToWindowWithURL("LCWD2D");
						 clickUsingJavaScript(LecSaveAndCont, objectValue);
						 report.reportPass("Check whether Save And Continue is clicked in LEC Page", "Verify whether Save And Continue is clicked in LEC Page", "Save And Continue is clicked in LEC Page");
						 waitForLoader();
					     waitForLoader();
							
				    	
		               }
				    else if(get("ChangeType").contains("EquipmentDropOff")){
				    	
				    	pageScroll(EquipmentDropoff, objectValue, true);
				    	report.reportPass("Click Equipment Dropoff if exists", "Verify Whether Equipment Dropoff is clicked", "Equipment Dropoff is clicked");
                    	clickUsingJavaScript(EquipmentDropoff, "Equipment Dropoff");                    	
                    	waitForLoader();
                    	waitForLoader();
                    	switchToWindowWithURL("CPEquipment");
                    	waitForLoader();
                    	waitForLoader();
                    	setText(customerName, objectValue, "ITOTest");
                    	
                    	selectDropDownUsingValue(familyRelation, objectValue, "Family member");
                    	report.reportPass("Select Family Relation  if exists", "Verify Whether Family Relation  is Selected", "Family Relation  is Selected");
                    	clickUsingJavaScript(selectAllEquipment, objectValue);
                    	
                    	selectDropDownUsingValue(reasonForDropOff, objectValue, "RPIR");
                    	waitForLoader();
                    	
                    	clickUsingJavaScript(applyAll, objectValue);
                    	waitForLoader();
                    	report.reportPass("Select Apply All if exists", "Verify whether Apply All is Clicked", "Apply All is Clicked");
                    	clickUsingJavaScript(submitbtn, objectValue);
                    	report.reportPass("Check whether Submit button is clicked", "Verify whether Submit button is clicked", "Submit button is clicked");
                    	waitForLoader();
                    	if(get("ProccedForCancel").equalsIgnoreCase("Yes")){
                    		clickUsingJavaScript(btnYes, objectValue);
                    	}
                    	else{
                    	clickUsingJavaScript(btnNo, objectValue);
                    	}
                    	report.reportPass("Check whether Yes/No is clicked", "Verify whether Yes/No is clicked", "Yes/No is clicked");
                    	waitForLoader();
                    	
				    }
	   	// HSI - Add UNEP/TDRL
	    
				    else if(get("ChangeType").contains("HSI - Add UNEP/TDRL"))
				    {
				    	
				    	String  producttype = get("ChangeType").trim();
				    	
				    	if(isDisplayed(ProductType, producttype, 5))
				    	{
				    		pageScroll(ProductType, producttype, true);
				    		clickUsingJavaScript(ProductType, producttype);
				    		report.reportPass("Validate that HSI - Add UNEP/TDRL link is clicked or not", "HSI - Add UNEP/TDRL link should be clicked", "HSI - Add UNEP/TDRL link is clicked");
				    		waitForLoader();
				    		waitForLoader();
				    		if(isDisplayed(saleswindow, objectValue, 10))
				    		{
					    	     clickUsingJavaScript(saleswindow, objectValue);
					    	}

					    	waitForLoader();
					    	report.reportPass("Validate that HSI - Add UNEP/TDRL link is clicked or not", "HSI - Add UNEP/TDRL link should be clicked", "HSI - Add UNEP/TDRL link is clicked");

				    	}
				    }
				    	//Gopal 11/10
					    else if(get("ChangeType").contains("StackAddCPE"))
					    {
					    	try
					    	{
					    			waitForElementDisplay(stackdisconnect, objectValue, 60);
						    	
					    			clickUsingJavaScript(stackdisconnect1, "Add CPE");
					    			
					    			report.reportPass("Click Add CPE Button", "Click Add CPE Button if Exists", "Clicking Add CPE Button");
							    
							    	waitForLoader();
							    	waitForLoader();
							    	if(isDisplayed(saleswindow, objectValue, 10)){
								    	clickUsingJavaScript(saleswindow, objectValue);
								    	}
							    	waitForPageToLoad(driver);
							    	waitForLoader();
							    	waitForLoader();
							    	waitForLoader();
							    	waitForLoader();
							    	waitForLoader();
							    	Thread.sleep(10000);
							    	
							  		
					    	}
					    	catch(Exception exe)
					    	{
					    		exe.printStackTrace();
					    	}
					    	
					    }//Gopal 11/10
					    else if(get("ChangeType").contains("StackAddTruckroll"))
					    {
					    	try
					    	{
					    			waitForElementDisplay(stackdisconnect, objectValue, 60);
						    	
					    			clickUsingJavaScript(stackdisconnect1, "Add Truckroll");
					    			
					    			report.reportPass("Click Add Truckroll Button", "Click Add Truckroll Button if Exists", "Clicking Add Truckroll Button");
							    
							    	waitForLoader();
							    	waitForLoader();
							    	if(isDisplayed(saleswindow, objectValue, 2)){
								    	clickUsingJavaScript(saleswindow, objectValue);
								    	}
							    	waitForPageToLoad(driver);
							    	waitForLoader();
							    	waitForLoader();
							    	waitForLoader();
							    	waitForLoader();
							    	waitForLoader();
							    	Thread.sleep(10000);
							    	
							  		
					    	}
					    	catch(Exception exe)
					    	{
					    		exe.printStackTrace();
					    	}
					    	
					    }
				    	//Gopal 11/10
					    else if(get("ChangeType").contains("Equipment Return Option"))
					    {
					    	try
					    	{
					    			if(isDisplayed(EquipReturnOpt))
					    			{
					    				pageScroll(EquipReturnOpt);
					    				clickUsingJavaScript(EquipReturnOpt, objectValue);
					    				report.reportPass("Click Equip Return Option Link", "Equip Return Option Link should be clicked", "Clicking Equip Return Option Link");
					    				waitForLoader();
					    				waitForLoader();
					    			}
					    			
					    			if(isDisplayed(EquipmentReturnTab))
					    			{
					    				if(isDisplayed(AllEquipment))
					    				{
					    					pageScroll(AllEquipment);
					    					clickUsingJavaScript(AllEquipment, objectValue);
					    					report.reportPass("Click SelectAll Check Box", "SelectAll Check Box should be clicked", "Clicking SelectAll Check Box");
					    					waitForLoader();	
					    					waitForLoader();
					    				}
					    				if(isDisplayed(NextBTNEQUIP))
					    				{
					    					pageScroll(NextBTNEQUIP);
					    					clickUsingJavaScript(NextBTNEQUIP, objectValue);
					    					waitForLoader();	
					    					waitForLoader();
					    				}
					    			}
					    			
					    			if(isDisplayed(EquipmentReturnMethodTab))
					    			{
					    				if(isDisplayed(RefusetoDrop))
					    				{
					    					pageScroll(RefusetoDrop);
					    					clickUsingJavaScript(RefusetoDrop, objectValue);
					    					report.reportPass("Click Refuse to Drop Radio Button", "Refuse to Drop Radio Button should be clicked", "Clicking Refuse to Drop Radio Button");
					    					waitForLoader();	
					    					waitForLoader();
					    				}
					    				if(isDisplayed(RbtnBillingAddress))
					    				{
					    					pageScroll(RbtnBillingAddress);
					    					clickUsingJavaScript(RbtnBillingAddress, objectValue);
					    					report.reportPass("Click Billing Address Radio Button", "Billing Address Radio Button should be clicked", "Clicking Billing Address Radio Button");
					    					waitForLoader();	
					    					waitForLoader();
					    				}
					    				if(isDisplayed(NextReturnKit))
					    				{
					    					pageScroll(NextReturnKit);
					    					clickUsingJavaScript(NextReturnKit, objectValue);
					    					waitForLoader();	
					    					waitForLoader();
					    				}
					    				
					    			}
					    			
					    			if(isDisplayed(SendReturnKitTab))
					    			{
					    				if(isDisplayed(SuggestedAddress))
					    				{
					    					pageScroll(SuggestedAddress);
					    					clickUsingJavaScript(SuggestedAddress, objectValue);
					    					report.reportPass("Click Suggested Address Radio Button", "Suggested Address should be clicked", "Clicking Suggested Address Radio Button");
					    					waitForLoader();	
					    					waitForLoader();
					    				}
					    				if(isDisplayed(SendReturnkit))
					    				{
					    					pageScroll(SendReturnkit);
					    					clickUsingJavaScript(SendReturnkit, objectValue);
					    					report.reportPass("Click Send Return kit Button", "Send Return kit should be clicked", "Clicking Suggested Send Return kit Button");
					    					waitForLoader();	
					    					waitForLoader();
					    				}
					    				
					    				if(isDisplayed(OKButton))
					    				{
					    					pageScroll(OKButton);
					    					clickUsingJavaScript(OKButton, objectValue);
					    					report.reportPass("Click on OK Button", "Ok Button should be clicked", "Clicking OK Button");
					    					waitForLoader();	
					    					waitForLoader();
					    				}
					    			}
							  		
					    	}
					    	catch(Exception exe)
					    	{
					    		exe.printStackTrace();
					    	}
					    	
					    }
	    
	    if(get("ChangeType").contains("UNDO")){  //Modified by Anu***UNDO Flow***
			clickUsingJavaScript(undocancel, "");
			report.reportPass("Click Cancel if present", "Cancel should be clicked", "Cancel is clicked");
			System.out.println("undo cancel is clicked");
			waitForLoader();
			
			if(get("CancelType").contains("Yes")){				
			clickUsingJavaScript(cancelyes, "");
			report.reportPass("Click yes if present", "yes should be clicked", "yes is clicked");
			System.out.println("Yes is clicked");
			}
			else
				clickUsingJavaScript(cancelno, "");
			report.reportPass("Click No if present", "No should be clicked", "No is clicked");
			System.out.println("No is clicked");
		}
	    
	    
	  //*************Anu Dhiman****WinBackResold Flow************//////
	    else if (get("ChangeType").equalsIgnoreCase("Winback")) {
	    	 if (isDisplayed(winback, objectValue))
	    		System.out.println("Winback is displayed");
	    	  clickUsingJavaScript(winback, objectValue);
	    	 report.reportPass("Click Winback if present", "winback should be clicked", "Winback is clicked");
	    	 System.out.println("Winback is Clicked");
	    	 waitForLoader();
				        
	        try{
	        
		    if (isDisplayed(nxtbtn, objectValue))
		    	{
		    	clickUsingJavaScript(nxtbtn, objectValue); //page 1 click next
		    	report.reportPass("Click Next in Winback first page", "Next should be clicked", "Next is clicked");
		    	waitForLoader();
		    	
		    	clickUsingJavaScript(nxtbtn, objectValue); //page 2 click next
		    	report.reportPass("Click Next in Winback second page", "Next should be clicked", "Next is clicked");
		    	waitForLoader();
		    	
		    	clickUsingJavaScript(nxtbtn, objectValue); //page 3 click next
		    	report.reportPass("Click Next in Winback third page", "Next should be clicked", "Next is clicked");
		    	waitForLoader();
		    	
		    	}
	        }
		    catch(Exception e)
	    	{
		    	 e.printStackTrace();
		 	 
		 		report.reportFail("Navigate through WinBack Section" + getUrl, "WinBack pages didn't go well", "Failed in WinBack Navigation");
		 		report.updateMainReport("ErrorMessage", strFailed);
	    	
		    }
	    }
	    /********************Mounika 14/03/2018*************************/
          else if(get("ChangeType").contains("ChangeHSIPackage")){		    	
	    	
	    	if(isDisplayed(upshellPopup, objectValue, 10)){
	    		clickUsingJavaScript(closePopup, objectValue);
	    	}
	    		waitForElementDisplay(btnHighSpeedInternet, objectValue, 20);
	    		pageScroll(btnHighSpeedInternet, objectValue, true);
	    		report.reportPass("Check whether High Speed Internet is Displayed", "Verify whether High Speed Internet is Displayed", "High speed Internet is Dispalyed");
	    	clickUsingJavaScript(btnHighSpeedInternet, objectValue);
	    	waitForLoader();
		    waitForLoader();
		    pause();
		    switchToWindowWithURL("HSID2D");
	    }
	    // Gopal 0430
        else if(get("ChangeType").contains("HSI - Add Technician Visit")){	
        	  
        	  try
    	    	{
        		  String  producttype = get("ChangeType").trim();
    		    	
    		    	if(isDisplayed(ProductType, producttype, 5))
    		    	{
    		    		pageScroll(ProductType, producttype, true);
    		    		clickUsingJavaScript(ProductType, producttype);
    		    		report.reportPass("Validate that HSI - Add Technician Visit link is clicked or not", "HSI - Add Technician Visit link should be clicked", "HSI - Add Technician Visit link is clicked");
    		    		waitForLoader();
    		    		waitForLoader();
    		    		if(isDisplayed(saleswindow, objectValue, 2))
    		    		{
    			    	     clickUsingJavaScript(saleswindow, objectValue);
    			    	}

    			    	waitForLoader();
    			    	report.reportPass("Validate that HSI - Add Technician Visit link is clicked or not", "HSI - Add Technician Visit link should be clicked", "HSI - Add Technician Visit link is clicked");

    		    	}
    			    	
    			  		
    	    	}
    	    	catch(Exception exe)
    	    	{
    	    		exe.printStackTrace();
    	    	}
            	  
              }
				    
	    waitForLoader();
	    waitForLoader();

	} catch (Exception exe) {
		 exe.printStackTrace();
 	    if (!isUserDefinedException(exe)) {
 		report.reportFail(strDescription + getUrl, strExpected, strFailed);
 		report.updateMainReport("ErrorMessage", strFailed);
 		captureErrorMsg("Failed in Change Esicting Services/RG page");
 	    }
	 throw exe;  
	}
    }

    /**
     * @author v878795
     * @Description:Pre-Ordering Simplex Dashboard Page.
     * @return: No return type
     * @exception Throws
     *                Exception
     * @ModifiedDate:
     * @ModifiedBY:
     * @Comments:
     */

    public void UIValidation_Simplex_RG_Dashboard_Page() throws Exception {

	if (get("RG_GUI").equalsIgnoreCase("Yes") && (!get("Application").equalsIgnoreCase("C2G"))) {
	    String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	    String getUrl = "";

	    String pageName = "Simplex DashBoard";
	    String RGWindow = driver.getWindowHandle();

	    try {

		// For Expand click + link in Connections TAB

		waitForLoader();

		strDescription = " Validate that + Symbol is present in Connection Tab ";
		strExpected = "+ Symbol Shouls be presented in Connection Tab";
		strActual = "+ Symbol is presented in Connection Tab";
		strFailed = "+ Symbol is not presented in Connection Tab";
		getUrl = ", URL Launched --> " + returnURL();

		if (getAttribute(Connections_Plus_Minus_Link, "", "class").contains("close")) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		} else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// Clicking on Connections link

		clickUsingJavaScript(Connections_Plus_Minus_Link, objectValue);

		// For Shrinking click - link in Connections TAB

		waitForLoader();

		strDescription = " Validate that - Symbol is present in Connection Tab ";
		strExpected = "- Symbol Shouls be presented in Connection Tab";
		strActual = "- Symbol is presented in Connection Tab";
		strFailed = "- Symbol is not presented in Connection Tab";
		getUrl = ", URL Launched --> " + returnURL();

		if (getAttribute(Connections_Plus_Minus_Link, "", "class").contains("open")) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		} else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// Connections info

		strDescription = "Capture the Information of Connections Section of left side of Screens";
		strExpected = "Connections Section Information should be Displayed";
		strActual = "Connections Section Information is Displayed";

		String connections_link = getTextFromElement(Connections_Link, objectValue);

		report.reportPass(strDescription, strExpected, strActual + connections_link);

		// Available Services Link.

		guiValidateVisibility(Connection_Avbl_Services, pageName, "Available_Services_Simplex BashBoard", "Available Services should be present in Simplex DashBoard",
			"Available Services is present in Simplex DashBoard");

		// Click on Available Services Arrow.

		clickUsingJavaScript(Connection_Avbl_Services_Link, objectValue);

		waitForLoader();

		guiValidateVisibility(Avbl_Services_Window, pageName, "Available_Services_Window", "Available Services window should be present in Simplex DashBoard",
			"Available Services window is present in Simplex DashBoard");

		clickUsingJavaScript(Close_Button, objectValue);

		waitForLoader();

		// For Expand click + link in Campaigns TAB

		// waitForLoader();

		strDescription = " Validate that + Symbol is present in Campaigns Tab ";
		strExpected = "+ Symbol Shouls be presented in Campaigns Tab";
		strActual = "+ Symbol is presented in Campaigns Tab";
		strFailed = "+ Symbol is not presented in Campaigns Tab";
		getUrl = ", URL Launched --> " + returnURL();

		if (getAttribute(Campaign_Plus_Link, "", "class").contains("icon-plus-alt")) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		} else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// Clicking on Connections link

		clickUsingJavaScript(Campaign_Plus_Link, objectValue);

		// For Shrinking click - link in Campaigns TAB

		waitForLoader();

		strDescription = " Validate that - Symbol is present in Campaigns Tab ";
		strExpected = "- Symbol Shouls be presented in Campaigns Tab";
		strActual = "- Symbol is presented in Campaigns Tab";
		strFailed = "- Symbol is not presented in Campaigns Tab";
		getUrl = ", URL Launched --> " + returnURL();

		if (getAttribute(Campaign_Plus_Link, "", "class").contains("icon-minus-alt")) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		} else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// Campaign Section Information

		strDescription = "Capture the Information of Campaign Section of left side of Screens";
		strExpected = "Campaign Section Information should be Displayed";
		strActual = "Campaign Section Information is Displayed";

		String campaign_link = getTextFromElement(Campaign_Link, objectValue);

		report.reportPass(strDescription, strExpected, strActual + campaign_link);

		// Validate Search Button in Campaigns window.

		strDescription = "Validate that do we Search icon in Campaign";
		strExpected = "Search icon should be displayed in Campaign";
		strActual = "Search icon is displayed in Campaign";
		strFailed = "Search icon is not displayed in Campaign";
		getUrl = ", URL Launched --> " + returnURL();

		if (isDisplayed(Campaign_Search_Button)) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		}

		else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// Validate Search in Campaign window for all fields

		clickUsingJavaScript(Campaign_Search_Button, objectValue);

		waitForLoader();

		strDescription = "Validate that campaignTFN is displayed in Search Campaigns";
		strExpected = "campaignTFN Should be displayed in Search Campaigns";
		strActual = "campaignTFN is displayed in Search Campaigns";
		strFailed = "campaignTFN is not displayed in Search Campaigns";
		getUrl = ", URL Launched --> " + returnURL();

		if (isDisplayed(campaignTFN)) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		}

		else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		strDescription = "Validate that campaignName is displayed in Search Campaigns";
		strExpected = "campaignName Should be displayed in Search Campaigns";
		strActual = "campaignName is displayed in Search Campaigns";
		strFailed = "campaignName is not displayed in Search Campaigns";
		getUrl = ", URL Launched --> " + returnURL();

		if (isDisplayed(campaignName)) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		}

		else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		strDescription = "Validate that search_Campaigns is displayed in Search Campaigns";
		strExpected = "search_Campaigns Should be displayed in Search Campaigns";
		strActual = "search_Campaigns is displayed in Search Campaigns";
		strFailed = "search_Campaigns is not displayed in Search Campaigns";
		getUrl = ", URL Launched --> " + returnURL();

		if (isDisplayed(search_Campaigns)) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		}

		else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		strDescription = "Validate that close_Campaigns is displayed in Search Campaigns";
		strExpected = "close_Campaigns Should be displayed in Search Campaigns";
		strActual = "close_Campaigns is displayed in Search Campaigns";
		strFailed = "close_Campaigns is not displayed in Search Campaigns";
		getUrl = ", URL Launched --> " + returnURL();

		if (isDisplayed(close_Campaigns)) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		}

		else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		clickUsingJavaScript(close_Campaigns, objectValue);

		// Check for more link for each Campaign

		strDescription = "Validate that do we have more link for each Campaign";
		strExpected = "More link should be for each Campaign";
		strActual = "More link is for each Campaign";
		strFailed = "More link is not there for each Campaign";
		getUrl = ", URL Launched --> " + returnURL();

		System.out.println(EachCampaign_Link.size());
		System.out.println(MoreLink_Campaign.size());

		if (EachCampaign_Link.size() == MoreLink_Campaign.size()) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		}

		else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// If more is Clicked check for Campaign details are displayed.

		for (int i = 0; i < MoreLink_Campaign.size(); i++) {

		    // clickUsingJavaScript(MoreLink_Campaign.get(i), "");
		    try {

			WebElement ele = MoreLink_Campaign.get(i);
			// ele.click();

			JavascriptExecutor executer = (JavascriptExecutor) this.driver;
			executer.executeScript("arguments[0].click();", ele);

			waitForLoader();

		    } catch (Exception e) {
			System.out.print(e.getMessage());
		    }

		    // clickUsingJavaScript(getElement(MoreLink_Campaign.get(i),objectValue)),objectValue);

		    waitForPageToLoad(driver);

		    strDescription = "Validate that Campaign details are displayed after clicked on more link";
		    strExpected = "Campaign details should be displayed after clicked on more link";
		    strActual = "Campaign details are displayed after clicked on more link";
		    strFailed = "Campaign details are not displayed after clicked on more link";

		    if (isDisplayed(Campaign_details)) {

			report.reportPass(strDescription + Campaign_Details.getText(), strExpected, strActual);
		    } else {
			report.reportFail(strDescription + Campaign_Details.getText(), strExpected, strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
		    }

		    waitForLoader();

		    clickUsingJavaScript(Campaign_close_Button, "");
		}

		// For Expand click - link in Competitors TAB

		waitForLoader();

		strDescription = " Validate that + Symbol is present in Competitors Tab ";
		strExpected = "+ Symbol Shouls be presented in Competitors Tab";
		strActual = "+ Symbol is presented in Competitors Tab";
		strFailed = "+ Symbol is not presented in Competitors Tab";
		getUrl = ", URL Launched --> " + returnURL();

		if (getAttribute(Competitors_Plus_Link, "", "class").contains("close")) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		} else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// Clicking on Competitors link

		clickUsingJavaScript(Competitors_Plus_Link, objectValue);

		// For Shrinking click - link in Competitors TAB

		waitForLoader();

		strDescription = " Validate that - Symbol is present in Competitors Tab ";
		strExpected = "- Symbol Shouls be presented in Competitors Tab";
		strActual = "- Symbol is presented in Competitors Tab";
		strFailed = "- Symbol is not presented in Competitors Tab";
		getUrl = ", URL Launched --> " + returnURL();

		if (getAttribute(Competitors_Plus_Link, "", "class").contains("open")) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		} else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		// Capture the Information of Competitors Section.

		strDescription = "Capture the Information of Completitors Section of left side of Screens";
		strExpected = "Completitors Section Information should be Displayed";
		strActual = "Completitors Section Information is Displayed";

		clickUsingJavaScript(Competitors_Plus_Link, objectValue);

		String competitors_link = getTextFromElement(Competitors_Link, objectValue);

		report.reportPass(strDescription, strExpected, strActual + competitors_link);

		// Check for more link for each Competitor items.

		strDescription = "Validate that do we have more link for each Competitor";
		strExpected = "More link should be for each Competitor";
		strActual = "More link is for each Competitor";
		strFailed = "More link is not there for each Competitor";
		getUrl = ", URL Launched --> " + returnURL();

		if (Eachcompetitor_Link.size() == MoreLink_Competitor.size()) {
		    report.reportPass(strDescription + getUrl, strExpected, strActual);
		}

		else {
		    report.reportFail(strDescription + getUrl, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}
		// If more is Clicked check for Competitor details are
		// displayed.

		for (int i = 0; i < MoreLink_Competitor.size(); i++) {

		    try {

			WebElement Comp_ele = MoreLink_Competitor.get(i);
			JavascriptExecutor executer = (JavascriptExecutor) this.driver;
			executer.executeScript("arguments[0].click();", Comp_ele);

			waitForPageToLoad(driver);

		    } catch (Exception e) {
			System.out.print(e.getMessage());
		    }

		    waitForLoader();

		    strDescription = "Validate that Competitors details are displayed after clicked on more link";
		    strExpected = "Competitors details should be displayed after clicked on more link";
		    strActual = "Competitors details are displayed after clicked on more link";
		    strFailed = "Competitors details are not displayed after clicked on more link";

		    // waitForLoader();

		    WebElement comp_frame = Campaign_Details;
		    driver.switchTo().frame(comp_frame);

		    if (isDisplayed(Comp_guide_link)) {
			report.reportPass(strDescription, strExpected, strActual);
		    } else {
			report.reportFail(strDescription, strExpected, strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
		    }

		    switchToDefaultcontent();

		    clickUsingJavaScript(Competitor_close, "");

		    waitForLoader();
		}

		waitForPageToLoad(driver);
		// Check for Check for Competitor Guide – validate

		clickUsingJavaScript(Competitor_Guide, "");

		waitForPageToLoad(driver);

		try {

		    switchToWindow("Certificate Error: Navigation Blocked");
		  //  maximizeBrowserWindow();

		    clickUsingJavaScript(override_link, "");
		    waitForLoader();

		} catch (Exception e) {
		    switchToWindow("verizon.telogical.com");
		}

		// switchToWindow("verizon.telogical.com");

		/*
		 * Alert alert = driver.switchTo().alert(); alert.accept();
		 * 
		 * waitForLoader();
		 * 
		 * Alert alert1 = driver.switchTo().alert(); alert1.accept();
		 */

		strDescription = "Validate that Competitors Guide details are displayed after clicked on Competitors Guide link";
		strExpected = "Competitors Guide details Should be displayed after clicked on Competitors Guide link";
		strActual = "Competitors Guide details are displayed after clicked on Competitors Guide link";
		strFailed = "Competitors Guide details are not displayed after clicked on Competitors Guide link";

		if (isDisplayed(Competitors_Tab)) {
		    report.reportPass(strDescription, strExpected, strActual);
		}

		else {
		    report.reportFail(strDescription, strExpected, strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		}

		for (int i = 0; i < Competitor_Tab.size(); i++) {

		    try {

			WebElement Comp_ele = Competitor_Tab.get(i);
			JavascriptExecutor executer = (JavascriptExecutor) this.driver;
			executer.executeScript("arguments[0].click();", Comp_ele);

			waitForPageToLoad(driver);

		    } catch (Exception e) {
			System.out.print(e.getMessage());
		    }
		}

		driver.close();

		switchToWindow("CoFEE 2.0 New Connect");

		waitForPageToLoad(driver);
		// Check Products & Services Section

		strDescription = "Capture the Information of Products and Services Section in Middle of Screen";
		strExpected = "Products and Services Section in Middle of Screen should be Displayed";
		strActual = "Products and Services Section in Middle of Screen is Displayed";

		waitForLoader();

		String dashboard_ProductsServices = getTextFromElement(Dashboard_ProductsServices, objectValue);

		report.reportPass(strDescription, strExpected, strActual + dashboard_ProductsServices);

	    }

	    catch (Exception exe) {
		exe.printStackTrace();
		report.reportFail("Validate RG page validations", "RG page gui validations should be validated", "Unable to validate GUI validations");
		report.updateMainReport("ErrorMessage", "Unable to validate GUI validations");
		driver.switchTo().window(RGWindow);

	    }
	} else if (get("Application").equalsIgnoreCase("C2G") && (get("RG_GUI").equalsIgnoreCase("Yes")) && get("FlowType").equalsIgnoreCase("Install")) {

		 waitForLoader();
		    waitForLoader();
		    
		    try {

				waitForLoader();
				waitForLoader();
				waitForLoader();
				
				if(get("FlowType").equalsIgnoreCase("Install")){
				waitForElementDisplay(AvailableServicesText, objectValue, pageTimeoutInSeconds);
				String x = getTextFromElement(AvailableServicesText, objectValue);
				System.out.println(x);
				report.reportPass("Display Available Services", "Show Available Services", "Available Services are: " + x);
				}
				waitForElementDisplay(snapshotText, objectValue, pageTimeoutInSeconds);
				String y = getTextFromElement(snapshotText, objectValue);
				System.out.println(y);
				report.reportPass("Display Alerts and Sales Opportunities", "Show Alerts and Sales Opportunities", "Alerts and Sales Opportunities are: " + y);
				
				String z= driver.findElement(By.xpath("//div[@ng-if='isShowCustomerInfo' and @class='ng-scope']")).getText();
				System.out.println(z);
				report.reportPass("Display Customer Info in Dashboard page", "Show Customer Info in Dashboard page", "Customer Info in Dashboard page: " + z);
				
				WebElement a=driver.findElement(By.xpath("//span[@data-open-modal='EditCallingPartyName']"));
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", a);
				waitForLoader();
				report.reportPass("Verify Edit Calling Party Popup is Opened after Clicking Edit Name Link", "Should Open Edit Calling Party Popup post Clicking Edit Name Link", "Edit Calling Party Popup is dispalyed post Clicking Edit Name Link");
				
				
				
				String n= driver.findElement(By.xpath("//div[@ng-if='isShowCustomerInfo']/div/div/span[contains(@class,'calling')]")).getText();
				System.out.println(n);
				
				if(n.equals(get("Calling_Party_Name"))){
					report.reportPass("Verify Calling Party Name", "Verify Calling Party Name in Dashboard page and Calling From Page", "Calling Party Name is same in Dashboard page and Calling From Page");
				}
				else{
					report.reportFail("Verify Calling Party Name", "Verify Calling Party Name in Dashboard page and Calling From Page", "Calling Party Name is not same in Dashboard page and Calling From Page");
				}
				WebElement s=driver.findElement(By.xpath("//button[@ng-click='updateCallingParty()']"));
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", s);
				report.reportPass("Verify Save button is working in Edit Calling Party Popup", "Save button should work in Edit Calling Party Popup", "Save button is working in Edit Calling Party Popup");
				waitForLoader();
				
				
				 if (getAttribute(dashboardbutton, "", "class").contains("active")) {
						clickUsingJavaScript(dashboardbutton, objectValue);

					    }
				 waitForLoader();
				if(!isDisplayed(snapshotText)){
					report.reportPass("Verify SNAPSHOT button is working", "Check Whether SNAPSHOT button is working and Dashboard Section is Displayed", "SNAPSHOT button is working and Dashboard Section is Displayed After clicking on that button");
				}
				
					clickUsingJavaScript(dashboardbutton, objectValue);

				   
				WebElement v=driver.findElement(By.xpath("//div[@class='w_drop-list m_rev text-center']/div/a/span[@aria-hidden='true']"));
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", v);
				report.reportPass("Verify More button is working", "Check Whether More button is working", "More button is working and the fields in that are displayed");
				
				String g= driver.findElement(By.xpath("//div[@class='w_drop-list m_rev text-center']/div[2]/a")).getText();
				System.out.println(g);
				
				
				String q2=driver.findElement(By.xpath("//div[@class='w_snapshot']/div[1]/div[2]")).getText();
				System.out.println(q2);
				String q3=driver.findElement(By.xpath("//div[@class='w_snapshot']/div[1]/div[3]")).getText();
				System.out.println(q3);
				String r=driver.findElement(By.xpath("//div[@class='w_snapshot']/div[2]")).getText();
				System.out.println(r);
				String r2=driver.findElement(By.xpath("//div[@class='w_snapshot']/div[3]")).getText();
				System.out.println(r2);
				
				
			    } catch (Exception e) {
				e.printStackTrace();
				report.reportFail("Validate RG page validations", "RG page gui validations should be validated", "Unable to validate GUI validations");
				report.updateMainReport("ErrorMessage", "Unable to validate GUI validations");
			    }

	}
    }

    public void processRGAlertValidations(String txtAlert) throws Exception {

//	if (txtAlert.contains("location is HFWS") || txtAlert.contains("address already has a pending New Install order")) {
    if (txtAlert.contains("location is HFWS")) {
	    if (isDisplayed(HFWS_existing_services, "", 2)) {
		report.reportPass("Validate HFWS existing services in snapshot section.", "HFWS existing account services should be displayed in snapshot section.",
			"HFWS existing account services are displayed in snapshot section. Existing service: "+getTextFromElement(HFWS_existing_services, ""));
	    } else {
		String strFailed = "Failed in RG page, HWFS existing account services are not displayed in snapshot section for HFWS or pending or address.";
		report.reportPass("Validate HFWS existing services in snapshot section.", "HFWS existing account services should be displayed in snapshot section.", strFailed);
		report.updateMainReport("comments", strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		logger.error(strFailed);
		captureErrorMsg(strFailed);
		throw new UserDefinedException(strFailed);
	    }

	    if (txtAlert.contains("location is HFWS")) {
		if (isDisplayed(linkHFWS, "", 2)) {
		    report.reportPass("verify Click here to View HFWS link is displayed.", "Click here to View HFWS link should be displayed for HFWS address.",
			    "Click here to View HFWS link is displayed.");
		    clickUsingJavaScript(linkHFWS, "");
		    report.reportPass("Click here to View HFWS link ", "Click here to View HFWS link should be clicked.",
			    "Clicked on Click here to View HFWS link.");
		} else {
		    String strFailed = "Failed in RG page, Click here to View HFWS link is not displayed for HFWS address.";
		    report.reportPass("verify Click here to View HFWS link is displayed.", "Click here to View HFWS link should be displayed for HFWS address.", strFailed);
		    report.updateMainReport("comments", strFailed);
		    report.updateMainReport("ErrorMessage", strFailed);
		    logger.error(strFailed);
		    captureErrorMsg(strFailed);
		    throw new UserDefinedException(strFailed);
		}
	    }
	}
    }
    
  //************Edit Contact info-SAC Regression *******************//
    public void editContactInfo() throws Exception {
	 	try{
    	System.out.println("Trying to Edit Address");
    	   getUrl = ", URL Launched --> " + returnURL();
    	 Thread.sleep(3000);
    	waitForElementDisplay(editContact, objectValue, pageTimeoutInSeconds);
    	editContact.click();
    	
    	System.out.println("edit clicked");
       
    	report.reportPass("Verify Contact Info popup", "Edit Clicked", "Edit Contact Info popup opened");
        waitForLoader();
    	if(email.isDisplayed())
    	{
    		System.out.println("edit in");
    	waitForElementDisplay(email, objectValue, pageTimeoutInSeconds);
    	System.out.println("email avail");
    	if(!get("New_MTN").isEmpty())
    	{
    	clearText(mobNumber, objectValue);
    	setText(mobNumber, objectValue, get("New_MTN").trim());
    	report.reportPass("Opened Edit Contact Info Popup", "Enter Mobile NUmber", "New Mobile Number Entered :- "+get("New_MTN"));
    	}
    	clearText(email, objectValue);
    	setText(email, objectValue, get("NewEmail_ID").trim());
    	report.reportPass("Opened Edit Contact Info Popup", "Entered Email", "New Email Entered :- "+get("NewEmail_ID"));
    	waitForElementDisplay(saveInfo, objectValue, pageTimeoutInSeconds);
    	saveInfo.click();
    	
    	/*if(verifyEmailwarning.isDisplayed())
    	{
    		proceedwithEmail.click();
    		waitForElementDisplay(saveStatus, objectValue, pageTimeoutInSeconds);
    		System.out.println("Email Updated");
    	} */
    	waitForElementDisplay(saveStatus, objectValue, pageTimeoutInSeconds);
    	}
    	report.reportPass("Verify Email Saved" + getUrl, "Entered Email"+get("NewEmail_ID"), "Saved Email");
	    waitForLoader();
	    closeContactInfoPg.click();
	    report.reportPass("Verify New details Updated", "Updated Info","New MTN :- " +get("New_MTN") +"  and New Email :- " +get("NewEmail_ID")+ "  are  updated");
	    	    
    	}
    	
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		report.reportFail("Failed to edit Contact info" + getUrl, "Edit Contact info", "Failed to edit Contact info");
    	}
    	
	}
    

    
    
    // Click DoCCAgreement After account search
    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */

    public void clickDoCCAgreement() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	String getUrl = "";
	try {
	    // Give Customer info
	    strDescription = "Clicking on Moving/DoccAgreement button in RG Page";
	    strExpected = "Click Moving/DoccAgreement button in RG Page";
	    strActual = "Moving/DoccAgreement button in RG Page was successfully clicked ";
	    strFailed = "Clicking on Moving/DoccAgreement button in RG Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();

	    waitForLoader();
	    waitForLoader();
	    // DOCC Agreement
	    if (!get("FlowType").equalsIgnoreCase("Install")) {

	    if(isDisplayed(btnYesDoccAgreement, "", 15)){
		if (btnYesDoccAgreementList.size() > 0) {
		    waitForElementDisplay(btnYesDoccAgreement, objectValue, pageTimeoutInSeconds);

		    if (isDisplayed(btnYesDoccAgreement, objectValue)) {
			clickUsingJavaScript(btnYesDoccAgreement, objectValue);
			report.reportPass(strDescription + getUrl, strExpected, strActual);

		    }
		    waitForLoader();
		    waitForLoader();
		    waitForLoader();
		}
	    }
	    }

	} catch (Exception exe) {
	    exe.printStackTrace();
	    report.reportFail(strDescription + getUrl, strExpected, strFailed);
	    report.updateMainReport("ErrorMessage", strFailed);
	    throw exe;
	}
    }
    
    /**************************Mounika*****************************/
    public void  HeaderValidations() throws Exception {
    	try{

		waitForElementDisplay(snapshotText, objectValue, pageTimeoutInSeconds);
	    if(get("Application").equals("C2G") && !get("FlowType").equalsIgnoreCase("Move")){
	    	clickDoCCAgreement();
	    }

		String e1=driver.findElement(By.xpath("//span[@ng-if='custName']")).getText();	
		System.out.println(e1);	
		report.reportPass("Verify Calling Party Name/Customer Name", "Dispaly Calling Party Name/Customer Name", "Calling Party Name/Customer Name is: "+e1);
		WebElement e2=driver.findElement(By.xpath("//span[contains(@class,'AcctNumberIcn ')]"));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", e2);
		
		String e3=driver.findElement(By.xpath("//li/span[contains(text(),'LOB')]/following-sibling::span")).getText();	
		System.out.println(e3);			
		report.reportPass("Verify LOB", "Dispaly LOB", "LOB is: "+e1);
		WebElement e4=driver.findElement(By.xpath("//span[@class='vzicon line-height-tiny icon-profile pointer customer-profile-icon']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", e4);
		String e5=driver.findElement(By.xpath("//div[contains(@class,'customer-address margin-top-zero')]/span[1]")).getText();	
		System.out.println(e5);			
		String e6=driver.findElement(By.xpath("//div[contains(@class,'customer-address margin-top-zero')]/span[2]")).getText();	
		System.out.println(e6);			
		report.reportPass("Verify Billing Address2", "Dispaly Billing Address", "Billing Address is: "+e5+","+e6+"");
		String e7=driver.findElement(By.xpath("//div[@class='inline-block header-c2g-account']//div[@ng-click='launchProfileDetails();']")).getText();	
		System.out.println(e7);			
		report.reportPass("Verify Existing Services", "Dispaly Existing Services", "Existing Services is: "+e7);
		String e8=driver.findElement(By.xpath("//div[contains(@ng-if,'profileServiceShortNames') and contains(@class,'ng-scope')]")).getText();	
		System.out.println(e8);			
		report.reportPass("Verify Detailed Existing Services", "Dispaly Detailed Existing Services", "Detailed Existing Services are: "+e8);
		WebElement e9=driver.findElement(By.xpath("//div[contains(@class,'w_drop')]/div/a/span[contains(@class,'vzicon')]/following-sibling::span[contains(text(),'More options')]"));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", e9);
		List<WebElement> e10=driver.findElements(By.xpath("//div[contains(@class,'w_drop')]/div[contains(@class,'drop')]/a[not(contains(@class,'tool-bar'))]"));	
		for (int i = 0; i < e10.size(); i++) {
		
		    String list1 = e10.get(i).getText();
		    System.out.println(list1);
		    if (!list1.isEmpty()) {
			
			report.reportPass("Verify List in More Options", "Display List in More Options", "More Options: " +e10.get(i).getText());
			System.out.println(list1);
		    }
		}
		
		WebElement b1=driver.findElement(By.xpath("//span[contains(@class,'AcctNumberIcn')]"));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", b1);
		
		
		List<WebElement> e11=driver.findElements(By.xpath("//div[contains(@class,'customer-address')]/ul/li"));	
		for (int i = 0; i < e11.size(); i++) {
		    String list1 = e11.get(i).getText();
		    if (!list1.isEmpty()) {
			report.reportPass("Verify Account Information of Existing services", "Display Account Information of Existing services", "Account Information of Existing services is: " +e11.get(i).getText());
			System.out.println(list1);
		    }
		}
		String e12=driver.findElement(By.xpath("//div[@data-ui-view='rewardsView']")).getText();	
		System.out.println(e12);			
		report.reportPass("Verify Snapshot - My Rewards - Enroll in My Rewards", "Dispaly Snapshot - My Rewards - Enroll in My Rewards", "Billing Address1 is: "+e12);
		String e13=driver.findElement(By.xpath("//div[@ng-click='ConnectionsAvailableServicesPopup();']")).getText();	
		System.out.println(e13);			
		report.reportPass("Verify Whether Available Services is Dispalyed", "Check Whether Available Services is Dispalyed", "Available Services is Dispalyed: "+e13);
		String e14=driver.findElement(By.xpath("//div[@data-ui-view='salesOpportunities']/div/span[1]")).getText();	
		System.out.println(e14);			
		report.reportPass("Verify Whether Sales Opportunities is Dispalyed", "Check Whether Sales Opportunities is Dispalyed", "Sales Opportunities is Dispalyed: "+e14);
		String e15=driver.findElement(By.xpath("//div[@ng-if='HasAnyAlerts']")).getText();	
		System.out.println(e15);			
		report.reportPass("Verify Whether Alerts is Dispalyed", "Check Whether Alerts is Dispalyed", "Alerts is Dispalyed: "+e15);
		String e16=driver.findElement(By.xpath("//div[@data-ui-view='equipmentSnapshotView']")).getText();	
		System.out.println(e16);			
		report.reportPass("Verify Whether Equipment is Dispalyed", "Check Whether Equipment is Dispalyed", "Equipment is Dispalyed: "+e16);
		String e17=driver.findElement(By.xpath("//div[@ng-click='newTab()' and not(contains(@aria-label,'Open'))]/div[2]")).getText();	
		System.out.println(e17);			
		report.reportPass("Verify Whether Open Account is Dispalyed", "Check Whether Open Account is Dispalyed", "Open Account is Dispalyed: "+e17);
		String e18=driver.findElement(By.xpath("//div[@ng-click='CloseAccount()' and not(contains(@ng-hide,'closeAccButtonOrderProgress'))]/div[2]")).getText();	
		System.out.println(e18);			
		report.reportPass("Verify Whether Close Account is Dispalyed", "Check Whether Close Account is Dispalyed", "Close Account is Dispalyed: "+e18);
		String e19=driver.findElement(By.xpath("//div[contains(@class,'customer-profile')]/div/div/span[@ng-click='LaunchSafeGuard()']/span[2]")).getText();	
		System.out.println(e19);			
		report.reportPass("Verify Whether Safeguard is Dispalyed", "Check Whether Safeguard is Dispalyed", "Safeguard is Dispalyed: "+e19);
		
		WebElement e21=driver.findElement(By.xpath("//a[@data-open-modal='quicklinksmodal']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", e21);
		
		waitForLoader();
		
		List<WebElement> e22=driver.findElements(By.xpath("//div[@ng-show='isC2G']/div/div[@class='list-links']/div/div[@data-tabs-content='Consumer']/ul/li"));	
		for (int i = 0; i < e22.size(); i++) {
		    String list1 = e22.get(i).getText();
		    if (!list1.isEmpty()) {
			report.reportPass("Verify Quick Links under More Options", "Display Quick Links under More Options", "Quick Links under More Options are: " +e22.get(i).getText());
			System.out.println(list1);
		    }
		}		
		WebElement e23=driver.findElement(By.xpath("//div[@ng-show='isC2G']/div/div[@class='list-links']/ul/li[@data-tab='Offline']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", e23);
		List<WebElement> e24=driver.findElements(By.xpath("//div[@ng-show='isC2G']/div/div[@class='list-links']/div/div[@data-tabs-content='Offline']/ul/li"));	
		for (int i = 0; i < e24.size(); i++) {
		    String list1 = e24.get(i).getText();
		    if (!list1.isEmpty()) {
			report.reportPass("Verify Quick Links under More Options", "Display Quick Links under More Options", "Quick Links under More Options are: " +e24.get(i).getText());
			System.out.println(list1);
		    }
		}
		WebElement e25=driver.findElement(By.xpath("//div[@ng-show='isC2G']/div/div[@class='list-links']/ul/li[@data-tab='Business']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", e25);
		List<WebElement> e26=driver.findElements(By.xpath("//div[@ng-show='isC2G']/div/div[@class='list-links']/div/div[@data-tabs-content='Business']/ul/li"));	
		for (int i = 0; i < e26.size(); i++) {
		    String list1 = e26.get(i).getText();
		    if (!list1.isEmpty()) {
			report.reportPass("Verify Quick Links under More Options", "Display Quick Links under More Options", "Quick Links under More Options are: " +e26.get(i).getText());
			System.out.println(list1);
		    }
		}
		WebElement e27=driver.findElement(By.xpath("//div[@ng-show='isC2G']/div/div[@class='list-links']/ul/li[@data-tab='Tools']"));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", e27);
		List<WebElement> e28=driver.findElements(By.xpath("//div[@ng-show='isC2G']/div/div[@class='list-links']/div/div[@data-tabs-content='Tools']/ul/li"));	
		for (int i = 0; i < e28.size(); i++) {
		    String list1 = e28.get(i).getText();
		    if (!list1.isEmpty()) {
			report.reportPass("Verify Quick Links under More Options", "Display Quick Links under More Options", "Quick Links under More Options are: " +e28.get(i).getText());
			System.out.println(list1);
		    }
		}
				
    	}
    	
    	catch (Exception e) {
    		
    	    }
}
    
    /*****************Mounika**********************/
    public void  OpenAccount() throws Exception {
    	
    	pause();
	    waitForLoader();
	    switchToDefaultcontent();
	    
	    
    	waitForElementDisplay(openaccntbtn, objectValue, 15);
    	report.reportPass("Verify Whether Open ACcount is Displayed in Rep Dashboard", "Check Whether Open ACcount is Displayed in Rep Dashboard", "Open ACcount is Displayed in Rep Dashboard");
    	clickUsingJavaScript(openaccntbtn, objectValue);
    	waitForLoader();
    	waitForLoader();
    	waitForLoader();
    	System.out.println(driver.getTitle());
    	if(driver.getTitle().contains("Optix Search Account") | driver.getTitle().contains("Optix New Connect")){
    	report.reportPass("Verify Whether Optix New Account/Search Account Window is Opened on Clicking Open Account Button", "Verify Whether Optix New Account/Search Account is Opened on Clicking Open Account Button", "Optix New Account/Search Account Window has been Opened upon Clicking Open Account Button");
    	}
    	else{
    		report.reportFail("Verify Whether Optix New Account/Search Account Window is Opened on Clicking Open Account Button", "Verify Whether Optix New Account/Search Account is Opened on Clicking Open Account Button", "Optix New Account/Search Account Window is not Opened upon Clicking Open Account Button");	
    	}
    }

    /*****************Suman**********************/
    public void  ValidateMoreOption() throws Exception {
    	
    	//pause();
	    waitForLoader();
	    switchToDefaultcontent();
	    
	    
    	waitForElementDisplay(moreOptions, objectValue, 15);
    	report.reportPass("Verify Whether more options is Displayed in Rep Dashboard", "Check Whether more options is Displayed in Rep Dashboard", "more options is Displayed in Rep Dashboard");
    	clickUsingJavaScript(moreOptions, objectValue);
    	waitForLoader();
    	waitForLoader();
    	waitForLoader();
    	clickUsingJavaScript(cofeeBackOffice, objectValue);
    	waitForLoader();
    	waitForLoader();
   		pause();
    	
    	System.out.println(driver.getTitle());
 	
    	switchToWindowWithURL("ssp360");

    	waitForLoader();
    	
    	System.out.println(driver.getTitle());
    	
    	if(driver.getTitle().contains("SSP 360 - Login")){
    	report.reportPass("Verify Whether SSP 360 - Login Window is Opened on Clicking more", "Verify Whether SSP 360 - Login is Opened on Clicking more Button", "SSP 360 - Login Window has been Opened upon Clicking more Button");
    	}
    	else{
    		report.reportFail("Verify Whether SSP 360 - Login Window is Opened on Clicking more", "Verify Whether SSP 360 - Login is Opened on Clicking more Button", "SSP 360 - Login Window has not been Opened upon Clicking more Button");	
    	}
    	
    	if(cofeeBackOfficeLoginTextBox.isDisplayed()){
    		report.reportPass("Verify Whether cofeeBackOffice is Displayed ", "Check Whether cofeeBackOffice is Displayed", "cofeeBackOffice is Displayed");
    	}else{
    		report.reportFail("Verify Whether cofeeBackOffice is Displayed ", "Check Whether cofeeBackOffice is not Displayed", "cofeeBackOffice is not Displayed");
    	}
    	
    	driver.close();
    	
	    waitForLoader();
	    
	    switchToWindowWithTitle("Optix New Connect");
	    
    }
    
    /**
     * @author Naresh
     * @Method: checkETF Charge
     * @DateCreated:March 03,2018
     * 
     * @throws Exception
     */
    public void checkETFCharge() throws Exception{
    	try{
    		
    		 strDescription = "Check whether ETF charge is displayed in RG page for Term order";
    		 strExpected = "ETF must be displayed";
    		 strActual = "ETF must be displayed";
    		 strFailed = "ETF is not displayed";
    		 
    		 String ETFtext=eftContent.getText().trim();
    		 System.out.println("-->> ETF Text is "+ETFtext);
    		 if(ETFtext.contains("$")){
    			 report.reportPass(strDescription, strExpected, strActual);

    		 }
    		 else{
    			 report.reportFail(strDescription, strExpected, strFailed);
    		 }
    		 
    		
    	}catch(Exception e){
    		e.printStackTrace();
			 report.reportFail("Please check whether order is Term or M2M", "If Order is M2M EFT will not be displayed", "Please check the order for Term or M2M");

    	}
    }
	//Added by PRakash for Snowtickets link - --- 1/7/2019
public void OptixBotSearch() throws Exception {
		
		waitForLoader();
		report.reportPass("More Options" + getUrl, "More Options Clicked","More Options clicked");
		clickUsingJavaScript(moreOptions, objectValue);
		  
	    waitForLoader();
	    String RGWindow = driver.getWindowHandle();
	    Set<String> allExistingWindows = driver.getWindowHandles();
		  RGWindow = driver.getWindowHandle();
		  report.reportPass("Issues" + returnURL(), "Issues Link Clicked","Issues Link clicked");
	    clickUsingJavaScript(Issues, objectValue);
	    
	    waitForLoader();
	    
	    Set<String> allWindows = driver.getWindowHandles();
		System.out.println(allWindows.size());
		for (String Child_Window : allWindows) {
			
			System.out.println(driver.getTitle());
			System.out.println(Child_Window.toString());
		//	 if (!allExistingWindows.contains(Child_Window)) {
			 if (!allExistingWindows.contains(Child_Window)) {
					driver.switchTo().window(Child_Window);
					driver.manage().window().maximize();
					waitForLoader();
					 report.reportPass("Optix Bot Window" + returnURL(), "Optix Bot window Opened","Optix Bot window Opened");
					break;
			 }
		}
		
		waitForLoader();
}

void check_EquipmentDropOffEmail_SnapShot() throws Exception {
	System.out.println();
	try {
		
		waitForLoader();
		switchToDefaultcontent();
		try {
			waitForElementDisplay(snapshot, objectValue, 200);
			System.out.println("Snapshot is Loaded");
			report.reportPass("Verify Whether Snapshot is Loaded", "Check Whether Snapshot is Loaded",
					"Snapshot is Loaded");
		} catch (Exception e) {
			System.out.println("Snapshot is not displayed");
			String strFailed = "Snapshot is not Loaded even after 200 seconds";
			report.reportFail("Verify Whether Snapshot is Loaded", "Check Whether Snapshot is Loaded",
					"Snapshot is not Loaded even after 200 seconds");
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);

		}
		waitForLoader();
		waitForLoader();
		if (isDisplayed(AlertMessage, "", 5)) {
			clickUsingJavaScript(AlertMessage, objectValue);

			waitForLoader();

		}

		
		if (isDisplayed(MessageAlert, "", 6)) {
			clickUsingJavaScript(MessageAlert, objectValue);

			waitForLoader();

		}

		waitForLoader();
		waitForLoader();

		if (isDisplayed(NotificationMessage, "", 3)) {
			clickUsingJavaScript(NotificationMessage, objectValue);

			waitForLoader();
		}
		
		if (Return_Option.isDisplayed()) {
			pageScroll(Return_Option, "", false);
			report.reportPass("validate Equipment return option in snap shot",
					"Equipment return option should be available", "Equipment return option not available");

			Return_Option.click();
			report.reportPass("click Equipment return option in snap shot",
					"Equipment return option should be clicked", "Equipment return option is clicked");
			waitForLoader();
			pageScroll(Return_Option_Select_All_chk_box, "", false);

			Return_Option_Select_All_chk_box.click();
			Return_Option_Select_All_Nxt_btn.click();
			report.reportPass("select Equipment to be returned",
					"Equipment to be returned should be selectable", "Equipment to be returned is selectable");
			waitForLoader();
			Return_Option_drop_off_radio_btn.click();
			report.reportPass("select Equipment drop off at store by customer option",
					"'Customer will drop-off at a Verizon Retail Location'-option should be available", "expected option is available");
			waitForLoader();
			clearText(Return_Option_email_box, "");
			Return_Option_email_box.sendKeys(get("Email_ID"));
			report.reportPass("provide customer email addesss",
					"Customer email address -"+get("Email_ID") + "should be entered", "email id is entered");
			Email_Locations_to_Customer_btn.click();
			
			waitForLoader();
			if (Emailing_Locations_sucess_msg.isDisplayed()) {
				pageScroll(Emailing_Locations_sucess_msg, "", false);

				report.reportPass("send store locations to customer",
						"store locations should be sent to customer email address", "store locations is sucessfull send to customer email address");

			}
		} else {
			report.reportPass("validate Equipment return option in snap shot",
					"Equipment return option should be available", "Equipment return option is not available");

		}
	} catch (Exception ex) {
		throw new UserDefinedException("Unable validate Email location to customer while returning Equipment");
	}
}	

}
