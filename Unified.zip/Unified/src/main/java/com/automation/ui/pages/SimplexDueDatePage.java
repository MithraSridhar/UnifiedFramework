package com.automation.ui.pages;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_DueDate_PageObjects;
import com.automation.support.Element;
import com.automation.support.ElementFactory;
import com.automation.utilities.DynamicGlobalDataHandler;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

/**
 * SimplexDueDatePage class represents the DueDate Info Page and interact with
 * the Page
 * 
 */
public class SimplexDueDatePage extends Simplex_DueDate_PageObjects {

    String objectValue = "";
    static boolean windows = InitiateDriver.windows;
    String description = "", expected = "", actual = "", failure = "", getUrl;
    By by;
    int iterator = 0;
    String testId;
    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);
    int counter=0;
    /**
     * SimplexDueDatePage constructor invokes the super class constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     *             
     *             
     */
    @SuppressWarnings("unchecked")
    public SimplexDueDatePage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, windows, report, data);
	this.testId = testId;
    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     */
    public static SimplexDueDatePage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexDueDatePage.class, testId, report, data);
    }

    /**
     * Navigation start for Simplex Due Date Page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void start() throws Exception {

	setIterator();
	System.out.println("Due date page...");

	// To check due date tab is opened or not.. if not click on it
	verifyDueDateTab();

	//vikram script start
	// To validate script for SLIP flow , like router activation steps
	if(get("FlowType").equalsIgnoreCase("Install") && get("Application").equalsIgnoreCase("CoA") && get("SubFlowType").equalsIgnoreCase("SLIP")){
		slipScriptValidation();
	}
	//vikram script end
    
	   if (get("FlowType").toLowerCase().contains("move")) {
	    setDueDateMove();
	} else if (get("StackDisconnectOption").toLowerCase().contains("move") && (get("Application").equalsIgnoreCase("C2G")) ) {
	    setDueDateMove();
	} else if(get("CancelOrder").equalsIgnoreCase("Yes")){
		cancelOrder();
	}else if(get("ChangeType").equalsIgnoreCase("Correct Service Address")){
		waitForLoader();
		waitForLoader();
		waitForLoader();	
		 waitForLoader();
		 waitForLoader();
		 switchToDefaultcontent();
		    // Switch Frame
		    switchToFrame("IfProducts");
		 clickUsingJavaScript(btnCancel, objectValue);
		 report.reportPass("Click Save & Continue in Due Date PAge if Available" , "Save & Continue should be clicked", "Save & Continue is clicked in Due Date Page");
		    waitForLoader();
		    waitForLoader();
			
	}
	
	else {
		 if(!get("ETF").isEmpty()){ 
				clickViewDetails();
				 }
	    setDueDateInfo();
	}
	
		
		

    }

    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void navigateTo() throws Exception {

	// To increment the navigation iteration
	int i = TestIterator.getIterator(testId);
	TestIterator.setIterator(testId, ++i);
	clickUsingJavaScript(dueDateTab, objectValue);
	
	if(isDisplayed(warningYesPopup)){
		clickUsingJavaScript(warningYesPopup, objectValue);
	}
	waitForLoader();
	waitForLoader();
	waitForLoader();
	
		report.reportPass("Switch to Due Date Tab", "Due Date Should be displayed", "Due Date is displayed");
	    
    }

    /**
     * setDueDateInfo method for providing the Customer's DueDate information in
     * DueDate Info Page
     * 
     * @author Shiva Kumar Simharaju -- 28/02/2017
     * @throws Exception
     *             throws exception of type Exception
     */
    protected void setDueDateInfo() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	try {
		

	    // Give Customer Billing info
	    strDescription = "Entering customer DueDate info details";
	    strExpected = "Giving customer DueDate info in details";
	    strActual = "Giving Customer Duedate details in DueDate Info Page was successful";
	    strFailed = "Giving Customer Duedate details in DueDate Info Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();

	    String directShip = get("DirectShip").trim();
	    String selfInstallToTechInstall = get("SelfInstallToTechInstall").trim();
	    String selfInstallOverrideReason = get("selfInstallOverride_Reason").trim();
	    String weekendDate = get("WeekendDate").trim();
	    String vacationSuspend = get("VacationSuspend").trim();
	    String installationflexibility = get("InstallationFlexibility").trim();
	    
	    Select select = new Select(driver.findElement(By.xpath("//*[@id = 'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_ddlDueDateType']")));		
        WebElement option = select.getFirstSelectedOption();
	    waitForLoader();

	    switchToDefaultcontent();
	    // Switch Frame
	    switchToFrame("IfProducts");
	    
	    report.reportPass("Due Date Page should be displayed", "Due Date Page should be displayed", "Due Date Page is displayed");
	    if(isDisplayed(errormessage, objectValue, 3)){
	    	
	    String errormsg=getTextFromElement(errormessage, objectValue);
	    System.out.println(errormsg);
	    strFailed = errormsg;
	    clickUsingJavaScript(DueDateTab, objectValue);
    	waitForLoader();
    	waitForLoader();
    	waitForLoader();
    	switchToDefaultcontent();
	    // Switch Frame
	    switchToFrame("IfProducts");
	    report.reportPass("Due Date Page should be displayed", "Due Date Page should be displayed", "Due Date Page is displayed");
	   
	    }
	    
	    if(get("FlowType").equalsIgnoreCase("Install") && (get("Application").equalsIgnoreCase("C2G"))){
	    String x= driver.findElement(By.xpath("//table[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_tblMessageBlock']")).getText();
    	System.out.println(x);
    	report.reportPass("Verify Popup Text in Due Date Page", "Display Popup Text in Due Date Page", "Popup Text in Due Date Page: " +x);
    	String x2=driver.findElement(By.xpath("//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_ddlDueDateType' ]")).getText();
    	System.out.println(x2);
    	report.reportPass("Verify Popup Text in Due Date Page", "Display Popup Text in Due Date Page", "Popup Text in Due Date Page: " +x2);
	    }	
	     else if((get("ChangeType").equalsIgnoreCase("ChangeAddress")&& (get("FlowType").equalsIgnoreCase("Change")))){ 
			
			 String MissedApp = get("selfInstallOverride_Reason").trim();
			    
				//  Missed appointment
					  
						if (isDisplayed(MissedAppointment, "")) {
						    try {
                            pageScroll(MissedAppointment, MissedApp, true);
							selectDropDownUsingVisibleText(MissedAppointment, objectValue, MissedApp);
							report.reportPass("Select Missed Appointment Code in Due date Page", "Select Missed Appointment Code in Due date Page", "Missed Appointment Code in Due date Page is selected: "+MissedApp);

						    } catch (Exception exe) {

						    }
						}
			
		}
	    if (!selfInstallToTechInstall.isEmpty()) {

		clickUsingJavaScript(Self_Install_override, objectValue);

		clickUsingJavaScript(Self_Install_override_accept, objectValue);

		selectDropDownUsingVisibleText(Self_Install_Reason_drpdn, objectValue, selfInstallOverrideReason);

		clickUsingJavaScript(selfInstallOverrideContinue, objectValue);

		waitForLoader();

		report.reportPass("Override self install to Tech install.", "Install type should be overriden to Tech Install from Self install", "Overriden to Tech install from self install.");
	    }

	    if (directShip.equalsIgnoreCase("Yes")) {
		try {
		    // Click On First Available DueDate
		    pageScroll(fourthAvailableDate, objectValue, true);
		    mouseOver(fourthAvailableDate, objectValue);
		    if (!isDisplayed(lnkTimeSlots, "", 1)) {
			pageScroll(fourthAvailableDate, objectValue, true);
			clickUsingJavaScript(fourthAvailableDate, objectValue);

		    } else {
			// Click On First Available TimeSlots
			clickUsingJavaScript(lnkTimeSlots, objectValue);
		    }
		    report.reportPass("Select direct ship", "Selected date should be more than 3 days from current date.", "4th available date is selected.");
		} catch (Exception e) {
		    report.reportFail("Select direct ship", "Selected date should be more than 3 days from current date.", "Direct ship is not possible 4th available date is not present");
		    throw e;
		}

	    }
	    
	    // //Installation Flexibility - Vijay
	    else if (installationflexibility.contains("setup")) {
			try {
				Element target = null;
				if (installationflexibility.contains("fifty")) {
					target = setupfeewaiverfifty;
				} else if (installationflexibility.contains("hundred")) {
					target = setupfeewaiverhundred;
				}

				pageScroll(target, objectValue, true);
				mouseOver(target, objectValue);

				if (!isDisplayed(lnkTimeSlots, "", 1)) {
					pageScroll(target, objectValue, true);
					clickUsingJavaScript(target, objectValue);
				} else {
					// Click On First Available TimeSlots
					clickUsingJavaScript(lnkTimeSlots, objectValue);
				}
				report.reportPass("Select incentive date",
						"Incentive Date was selected",
						"Set Up Fee Waiver was added.");
			} catch (Exception e) {
				report.reportFail("Select incentive date",
						"Incentive Date was not selected.",
						"Set Up Fee Waiver was added as the incentive date was not qualified");
				throw e;
			}

		}
	  	    
	    else if (weekendDate.equalsIgnoreCase("Yes")) {

			try {
			    // Click On First Available DueDate
			    pageScroll(firstAvailableWeekendDate, objectValue, true);
			    mouseOver(firstAvailableWeekendDate, objectValue);
			    if (!isDisplayed(lnkTimeSlots, "", 1)) {
				pageScroll(firstAvailableWeekendDate, objectValue, true);
				clickUsingJavaScript(firstAvailableWeekendDate, objectValue);
				report.reportPass("Select first Available Weekend Date", "Select first Available Weekend Date", "first Available Weekend Date is Selected");
				if(get("Application").equalsIgnoreCase("C2G")){
	                if(isDisplayed(c2gTimeslots, objectValue, 1)){
	                clickUsingJavaScript(c2gTimeslots, objectValue);
	                }
	              }

			    } else {			    	 
				// Click On First Available TimeSlots
				clickUsingJavaScript(lnkTimeSlots, objectValue);
			    	 
			    }
			    report.reportPass("Select weekend date", "Weekend date should be selected.", "First available weekend date is selected.");
			} catch (Exception e) {
				strFailed = "Failed in Due Date page, Weekend due date is not available";
	    		  report.reportFail("Select weekend date", "Weekend date should be selected.", strFailed);		
	    		report.updateMainReport("comments", strFailed);
	    		report.updateMainReport("ErrorMessage", strFailed);
	    		logger.error(strFailed);
	    		captureErrorMsg(strFailed);
	    		throw new UserDefinedException(strFailed);
			}

		    }  else if (selfInstallToTechInstall.equalsIgnoreCase("Yes")) 
		    {
		    	if(isDisplayed(firstAvailableDate, "", 3))
		    	{
		        
				pageScroll(firstAvailableDate, objectValue, true);
				mouseOver(firstAvailableDate, objectValue);
				clickUsingJavaScript(firstAvailableDate, "");
				report.reportPass("Select first Available Date", "Select first Available Date", "first Available Date is Selected");
				 if(get("Application").equalsIgnoreCase("C2G")){
	                    if(isDisplayed(c2gTimeslots, objectValue, 3)){
	                    clickUsingJavaScript(c2gTimeslots, objectValue);
	                    }
	                  }
				if (!isDisplayed(lnkTimeSlots, "", 1)) {
				    pageScroll(firstAvailableDate, objectValue, true);
				    clickUsingJavaScript(firstAvailableDate, objectValue);
				    if(get("Application").equalsIgnoreCase("C2G")){
	                    if(isDisplayed(c2gTimeslots, objectValue, 3)){
	                    clickUsingJavaScript(c2gTimeslots, objectValue);
	                    }
	                  }


				}

				
				waitForLoader();
				}
				else
				{
				// Click On First Available DueDate
				pageScroll(firstAvailableFutureDate, objectValue, true);
				mouseOver(firstAvailableFutureDate , objectValue);
				if (!isDisplayed(lnkTimeSlots, "", 1)) {
				    pageScroll(firstAvailableFutureDate, objectValue, true);
				    clickUsingJavaScript(firstAvailableFutureDate, objectValue);
				    report.reportPass("Select first Available Date", "Select first Available Date", "first Available Date is Selected");
				    if(get("Application").equalsIgnoreCase("C2G")){
	                    if(isDisplayed(c2gTimeslots, objectValue, 3)){
	                    clickUsingJavaScript(c2gTimeslots, objectValue);
	                    }
	                  }


				}
				else {
				    // Click On First Available TimeSlots
				    clickUsingJavaScript(lnkTimeSlots, objectValue);
				}
				report.reportPass("Select Due date", "Due date should be selected.", "First available due date should be selected.");

			    }
		    }
	    
	    
	    else {

		try {
			//Dinesh-03/16

		    if (!vacationSuspend.isEmpty()) {

				   // 	if(isDisplayed(firstAvailableTodaysDate)) 
				    	if(isDisplayed(firstAvailableDate)) 
					    {
				//		pageScroll(firstAvailableTodaysDate, objectValue, true);
				    		if(isDisplayed(StartDate, objectValue, 0)) 
						    {
				    		pageScroll(StartDate, objectValue, true);
						    }
				    		else{
				    			pageScroll(firstAvailableTodaysDate, objectValue, true);	
				    		}
					    //mouseOver(firstAvailableTodaysDate);
					// click(firstAvailableTodaysDate, objectValue);
				    		click(firstAvailableDate, objectValue);
			System.err.println();
						report.reportPass("Select Due date", "First Due date should be selected.", "First available due date should be selected.");

					    }
				    	if (isDisplayed(futureDate, objectValue, 0)) {
				    		try{
				    			if(isDisplayed(StartDate, objectValue, 0)) 
							    {
					    		pageScroll(EndDate, objectValue, true);
							    }
					    		else{
					    			pageScroll(futureDate, objectValue, true);	
					    		}
						   // mouseOver(endDueDate, objectValue);
						    Actions action = new Actions(driver);
							action.moveToElement(driver.findElement(By.xpath("//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucEVODDArea_calDD')]/tbody/tr/td[@class='blueGradientDates']/following-sibling::td[@class='FutureDate'][1]"))).perform();
							
							click(futureDate, objectValue);
							report.reportPass("Select Due date", "Click Future Dates", "Future Dates should be selected.");
						    waitForLoader();
						    waitForLoader();
						   // pageScroll(selectEndDate, objectValue, true);
						    try{
						    	 click(selectEndDate1, objectValue);
								    report.reportPass("Select Due date", "End Due date should be selected.", "End Due date should be selected.");	
						    }
						    catch(Exception e){
						    click(selectEndDate, objectValue);
						    report.reportPass("Select Due date", "End Due date should be selected.", "End Due date should be selected.");
				    		}
						    }
				    		catch(Exception e){
				    			report.reportFail("Select End Due date", "End Due date should be selected ", "End Due date is not selected");		    
						        strFailed = "End Due date is not selected";			
								report.updateMainReport("comments", strFailed);
								report.updateMainReport("ErrorMessage", strFailed);
								logger.error(strFailed);
								captureErrorMsg(strFailed);
								throw new UserDefinedException(strFailed);	
				    		}
						}
			/*	if(isDisplayed(firstAvailableDate) && !vacationSuspend.isEmpty())
					{
				    pageScroll(firstAvailableDate, objectValue, true);
				    mouseOver(firstAvailableDate, objectValue);
				    if (!isDisplayed(lnkTimeSlots, "", 1)) {
				    	System.out.println("");
					pageScroll(firstAvailableDate, objectValue, true);
					clickUsingJavaScript(firstAvailableDate, objectValue);

				    } else {
					// Click On First Available TimeSlots
					clickUsingJavaScript(lnkTimeSlots, objectValue);
				    }
				    report.reportPass("Select direct ship", "Selected date should be more than 3 days from current date.", "4th available date is selected.");
					
				    }*/

				    }
		    else if(option.getText().contains("Records Only"))		
			   {		
			     waitForLoader();	
			     
			    	if(isDisplayed(firstAvailableDate)) 
				    {

			    		pageScroll(firstAvailableDate, objectValue, true);

			    		click(firstAvailableDate, objectValue);

					report.reportPass("Select Due date", "First Due date should be selected.", "First available due date should be selected.");

				    }
			    	
			     report.reportPass("In Duedate Page Installation Type diplayed as Records only", "Installation Type should be Displayed as Record Only", "Installation Type is Displayed as Record Only");		
			    }
		    else {
                 // Presale Duedate Validation  
		    		    		
		    	if(get("PresaleDate").contains("due date")){ 		

		    		
		    		String Presale_Date= "First available presale date.";
		            String Expected_Presale_DD = "First Presale Duedate should be available as per OFS ECD and Engineering Interval";
		            String Actual_Presale_DD = "First available presale Date is : ";
		            String Presale_date_Failed = "First Presale Duedate was not available as per OFS ECD and Engineering Interval";
		            getUrl = ", URL Launched --> " + returnURL();
		    		
		            String  Presale_Duedate = getTextFromElement(PresaleDate, "");
		             
		            System.out.print(get("PresaleDate"));		
		        
		    		if(Presale_Duedate.equals(get("PresaleDate")))
		    		{
		    			report.reportPass(Presale_Date +getUrl, Expected_Presale_DD, Actual_Presale_DD + Presale_Duedate);
		    			
		    		}
		    		
		    		else
		    		{
		    			report.reportFail(Presale_Date +getUrl, Expected_Presale_DD, Presale_date_Failed);
		    			report.updateMainReport("ErrorMessage", Presale_date_Failed );
						report.updateMainReport("ErrorMessage", Presale_date_Failed);
						logger.error(Presale_date_Failed);
						captureErrorMsg(Presale_date_Failed);
						throw new UserDefinedException(Presale_date_Failed);	
		    		}
		    		
		    		waitForLoader();		    	
		    	 }
		    	
			pageScroll(firstAvailableDate, objectValue, true);
			mouseOver(firstAvailableDate, objectValue);
			 if ((!isDisplayed(lnkTimeSlots, "", 2)) && (!isDisplayed(SetupChargeWaivedSlots, "", 2))) {
			    pageScroll(firstAvailableDate, objectValue, true);
			    clickUsingJavaScript(firstAvailableDate, objectValue);
               
                if(isDisplayed(SingleTimeSlot)){
					
					clickUsingJavaScript(SingleTimeSlot, "");
					 report.reportPass("Select Due date", "Due date should be selected.", "First available Time slot is selected.");
					
				}
			    report.reportPass("Select Due date", "Due date should be selected.", "First available due date is selected.");
               
			    if(get("Application").equalsIgnoreCase("C2G")){
                    if(isDisplayed(c2gTimeslots, objectValue, 3)){
                    clickUsingJavaScript(c2gTimeslots, objectValue);
                    report.reportPass("Select Due date", "Due date should be selected.", "First available Time slot is selected.");
                    }
                  }


			} else {
			    // Click On First Available TimeSlots
				if(isDisplayed(lnkTimeSlots, vacationSuspend, 1)){
			    clickUsingJavaScript(lnkTimeSlots, objectValue);
				}
				else{
					clickUsingJavaScript(SetupChargeWaivedSlots, objectValue);
				}
			    report.reportPass("Select Due date", "Due date should be selected.", "First available Time slot is selected.");
			}
			
		    }

		} catch (Exception e) {
			
			 if(isDisplayed(errormessage, objectValue, 10)){
			    	String errormsg2=getTextFromElement(errormessage, objectValue);
		    		System.out.println(errormsg2);
		    		strFailed = "Failed in Due Date page, Contact info was not displayed post clicking save and continue in Due Date page";
		    		  report.reportFail("Verify Due Date page not displayed", "Due Date page should not be displayed post clicking save and continue in Due Date page.", strFailed);		
		    		report.updateMainReport("comments", "Error: "+errormsg2+ " is displayed in Due date Page");
		    		report.updateMainReport("ErrorMessage", errormsg2);
		    		logger.error(errormsg2);
		    		captureErrorMsg(errormsg2);
		    		throw new UserDefinedException(strFailed);
			    }
			 else{
				 
				 if(isDisplayed(DueDateCalendar, vacationSuspend, 1)){
					 pageScroll(DueDateCalendar, vacationSuspend, true);
				 }
		        report.reportFail("Select First available date", "First available date should be selected ", "Available due is not present");		    
		        strFailed = "Available Due Date is not present or not clickable in Due Date page";			
				report.updateMainReport("comments", strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				logger.error(strFailed);
				captureErrorMsg(strFailed);
				throw new UserDefinedException(strFailed);
			 }
		}

	    }

	    if (isDisplayed(missedAppointmentCode, objectValue,4)) {

		Select dpr = new Select(driver.findElement(By.xpath("//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_ddlMissedAppCode']")));
		dpr.selectByIndex(1);
		waitForLoader();

	    }

	    // Changed for Validating ViewCart Details in DueDate Page
	    if (!get("MarketingOfferType").isEmpty()) {
		MOOfferInViewCart();
	    }
	    
	    String dueDateWindow = driver.getWindowHandle();
		////Today's modification
		try {
	     if (isDisplayed(chkboxConfirmDueDate, "", 1)){
          pageScroll(chkboxConfirmDueDate, "", true);
	    clickUsingJavaScript(chkboxConfirmDueDate, objectValue);
		report.reportPass("click Checkbox if exists", "click Checkbox if exists", "Checkbox if clicked");
	      }
	    } catch (Exception exe) {

	    }
	     //Today's modification
	    try {     

	     
	     if (isDisplayed(chkboxConfirmDueDate1, "", 1)){
			 pageScroll(chkboxConfirmDueDate1, "", true);
	    clickUsingJavaScript(chkboxConfirmDueDate1, objectValue);
        report.reportPass("click Checkbox if exists", "click Checkbox if exists", "Checkbox if clicked");
	    } 
		}
	    catch (Exception exe) {

	    }
	    
	    switchToDefaultcontent();
		switchToFrame("IfProducts");
	    // Click On Save And Continue Button
	    clickUsingJavaScript(btnCancel, objectValue);
	    
	    waitForLoader();
	    waitForLoader();
	    if(isDisplayed(popupframe))
	    {
	   	switchToDefaultcontent();
		switchToFrame("IfProducts");
		switchToFrame("PopupIFrameforAlertPage");
		if(isDisplayed(KeepDuedate))
	    {
	    	pageScroll(KeepDuedate, objectValue, true);
		    clickUsingJavaScript(KeepDuedate, objectValue);
	    }
	    }
	    	   
	    waitForLoader();
	    switchToDefaultcontent();
	    
	    if((isDisplayed(dueDateNegotiateErr, dueDateWindow, 10)) && option.getText().contains("Records Only") ){
	    	mouseOver(firstAvailableDate, objectValue);
			if (!isDisplayed(lnkTimeSlots, "", 1)) {
			    pageScroll(firstAvailableDate, objectValue, true);
			    clickUsingJavaScript(firstAvailableDate, objectValue);
			    if(get("Application").equalsIgnoreCase("C2G")){
                    if(isDisplayed(c2gTimeslots, objectValue, 3)){
                    clickUsingJavaScript(c2gTimeslots, objectValue);
                    
                    }
                    clickUsingJavaScript(btnCancel, objectValue);
                  }
	    }
	    }
	    if(isDisplayed(dueDateTimeSlotNotAvlErr, dueDateWindow, 6)){
	    	clickUsingJavaScript(dueDateTimeSlotNotAvlErr, dueDateWindow);
	    	mouseOver(firstAvailableDate, objectValue);
	    	clickUsingJavaScript(firstAvailableDate, objectValue);
	    	if(get("Application").equalsIgnoreCase("C2G")){
                if(isDisplayed(c2gTimeslots2, objectValue, 3)){
                clickUsingJavaScript(c2gTimeslots2, objectValue);
                }
                else if(isDisplayed(c2gTimeslots, objectValue, 3)){
                    clickUsingJavaScript(c2gTimeslots, objectValue);
                    }
	    	clickUsingJavaScript(btnCancel, objectValue);
	    }
	    }
	 
	    report.reportPass(strDescription + getUrl, strExpected, strActual);
	    waitForLoader();

	    if (!vacationSuspend.isEmpty()) {

		try {
		    
		    switchToWindowWithTitle("Suspend");
		    waitForLoader();
		    Actions builder = new Actions(driver);
		    Action enter = builder.sendKeys(Keys.ENTER).build();
		    enter.perform();
		    waitForLoader();
		    driver.switchTo().window(dueDateWindow);
		    switchToDefaultcontent();
		    // Switch Frame
		    switchToFrame("IfProducts");

		} catch (Exception exe) {
		    exe.printStackTrace();
		}
		waitForLoader();
	    }
	    // PageSync
	    waitForLoader();
	 // DIrect Ship POP UP
	    waitForLoader();
	    waitForLoader();
	    
		// Switch Frame
		switchToDefaultcontent();
		switchToFrame("IfProducts");
         if(isDisplayed(directshipeligibilityoptions,"",5)){
			
			if (isSelected(directshipeligibilityyesoption)) {
			    System.out.println("Direct ship is selected");

			} else {
				

			    clickUsingJavaScript(directshipeligibilityyesoption, objectValue);
				
			  
			}
			clickUsingJavaScript(btnDirectShipContinue, objectValue);

			  waitForLoader();
		}
         
         else if(isDisplayed(c2gdirectshipeligibility,"",2)){
   			
   			if (isSelected(c2gdirectshipeligibility)) {
   			    System.out.println("Direct ship is selected");

   			} else {

   			    clickUsingJavaScript(c2gdirectshipeligibility, objectValue);
   			  
   			}
   			clickUsingJavaScript(btnDirectShipContinue, objectValue);

   			  waitForLoader();
   		}
          else if(isDisplayed(c2gdirectshipeligibility1,"",2)){
    			
    			if (isSelected(c2gdirectshipeligibility1)) {
    			    System.out.println("Direct ship is selected");

    			} else {

    			    clickUsingJavaScript(c2gdirectshipeligibility1, objectValue);
    			  
    			}
    			clickUsingJavaScript(btnDirectShipContinue, objectValue);

    			  waitForLoader();
    		}
         else if (isDisplayed(radDSAnsYes1, "", 2)) {
		    // Click On Direct Ship Continue
		    clickUsingJavaScript(radDSAnsYes1, objectValue);

		    // Click On Close Button
		    clickUsingJavaScript(btnDirectShipContinue, objectValue);
		    waitForLoader();

		}
         else if (isDisplayed(IPTVC2GDirectship," ",2))
		 {
			 clickUsingJavaScript(btnDirectShipContinue, objectValue);
			    waitForLoader();
		 }
         
         waitForLoader();
         waitForLoader();
         waitForLoader();
         waitForLoader();
         waitForLoader();
         switchToDefaultcontent();
	    switchToFrame("IfProducts");
	   
	    if (!isNotDisplayed(activeDueDateTab, 20)) {
	    	
	    	if(isDisplayed(errormessage, objectValue, 2)){
	    		String errormsg=getTextFromElement(errormessage, objectValue);
	    		System.out.println(errormsg);
	    		if(errormsg.contains("Requested Date is not Available")){
	    			
	    			// Click On First Available DueDate
					pageScroll(NextAvailableDate, objectValue, true);
					mouseOver(NextAvailableDate , objectValue);
					if (!isDisplayed(lnkTimeSlots, "", 1)) {
					    pageScroll(NextAvailableDate, objectValue, true);
					    clickUsingJavaScript(NextAvailableDate, objectValue);
					    if(get("Application").equalsIgnoreCase("C2G")){
		                    if(isDisplayed(c2gTimeslots, objectValue, 3)){
		                    clickUsingJavaScript(c2gTimeslots, objectValue);
		                    }
		                  }


					}
					else {
					    // Click On First Available TimeSlots
					    clickUsingJavaScript(lnkTimeSlots, objectValue);
					}
					report.reportPass("Select Due date", "Due date should be selected.", "First available due date should be selected.");
	    			
					
					clickUsingJavaScript(btnCancel, objectValue);
					 report.reportPass(strDescription + getUrl, strExpected, strActual);
					    waitForLoader();
					    waitForLoader();
					    if(isDisplayed(errormessage, objectValue, 10)){
					    	String errormsg2=getTextFromElement(errormessage, objectValue);
				    		System.out.println(errormsg2);
				    		strFailed = "Failed in Due Date page, Contact info was not displayed post clicking save and continue in Due Date page";
				    		  report.reportFail("Verify Due Date page not displayed", "Due Date page should not be displayed post clicking save and continue in Due Date page.", strFailed);		
				    		report.updateMainReport("comments", "Error: "+errormsg2+ " is displayed in Due date Page");
				    		report.updateMainReport("ErrorMessage", errormsg2);
				    		logger.error(errormsg2);
				    		captureErrorMsg(errormsg2);
				    		throw new UserDefinedException(strFailed);
					    }
	    			
	    		}
	    		else if(errormsg.contains("The timeslot you selected")){
	    			
	    			// Click On First Available DueDate
					pageScroll(NextAvailableDate, objectValue, true);
					mouseOver(NextAvailableDate , objectValue);
					if (!isDisplayed(lnkTimeSlots2, "", 1)) {
					    pageScroll(NextAvailableDate, objectValue, true);
					    clickUsingJavaScript(NextAvailableDate, objectValue);
					    if(get("Application").equalsIgnoreCase("C2G")){
		                    if(isDisplayed(c2gTimeslots, objectValue, 3)){
		                    clickUsingJavaScript(c2gTimeslots, objectValue);
		                    }
		                  }


					}
					else {
					    // Click On First Available TimeSlots
					    clickUsingJavaScript(lnkTimeSlots2, objectValue);
					}
					report.reportPass("Select Due date", "Due date should be selected.", "First available due date should be selected.");
	    			
					
					clickUsingJavaScript(btnCancel, objectValue);
					 report.reportPass(strDescription + getUrl, strExpected, strActual);
					    waitForLoader();
					    waitForLoader();
					    if(isDisplayed(errormessage, objectValue, 10)){
					    	String errormsg2=getTextFromElement(errormessage, objectValue);
				    		System.out.println(errormsg2);
				    		strFailed = "Failed in Due Date page, Contact info was not displayed post clicking save and continue in Due Date page";
				    		  report.reportFail("Verify Due Date page not displayed", "Due Date page should not be displayed post clicking save and continue in Due Date page.", strFailed);		
				    		report.updateMainReport("comments", "Error: "+errormsg2+ " is displayed in Due date Page");
				    		report.updateMainReport("ErrorMessage", errormsg2);
				    		logger.error(errormsg2);
				    		captureErrorMsg(errormsg2);
				    		throw new UserDefinedException(strFailed);
					    }
	    			
	    			
	    			
	    			
	    			
	    			
	    		}
	    		else{
	    		 strFailed = "Failed in Due Date page, Contact info was not displayed post clicking save and continue in Due Date page";
	    		  report.reportFail("Verify Due Date page not displayed", "Due Date page should not be displayed post clicking save and continue in Due Date page.", strFailed);		
	    		report.updateMainReport("comments", "Error: "+errormsg+ " is displayed in Due date Page");
	    		report.updateMainReport("ErrorMessage", errormsg);
	    		logger.error(errormsg);
	    		captureErrorMsg(errormsg);
	    		throw new UserDefinedException(strFailed);
	    		}
	    	}
	    	else{
	    		
	    		
		 strFailed = "Failed in Due Date page, Contact info was not displayed post clicking save and continue in Due Date page";
		 report.reportFail("Verify Due Date page not displayed", "Due Date page should not be displayed post clicking save and continue in Due Date page.", strFailed);
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);	
	    	}
	    }
	    if (!isNotDisplayed(activeLoyaltyTab, 3)){
			
	    	 clickUsingJavaScript(LoyaltySaveContinue, objectValue);
	    	 waitForLoader();
	    	 waitForLoader();
		}
	    
	    // For Deposit Page 05/02
	    waitForLoader();
        switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    
	    if(isDisplayed(CollectDepositTAB, "", 9))
	    {
	    	 waitForLoader();
	         switchToDefaultcontent();
	 	     switchToFrame("IfProducts");
	 	    if(isDisplayed(RadioDepositAnsYes))
	 	    {
	 	    	clickUsingJavaScript(RadioDepositAnsYes, "");
	 	    	waitForLoader();
	 	    }
	 	    clickUsingJavaScript(ButtonSaveContinue, "");
	 	   waitForLoader();
	 	   waitForLoader();
	 	   waitForLoader();
	 	   waitForLoader();
	 	 
	    }
	    

	} catch (Exception exe) {
		if (!isUserDefinedException(exe)) {
	 		report.reportFail(strDescription + getUrl, strExpected, strFailed);
	 		report.updateMainReport("ErrorMessage", strFailed);
	 		captureErrorMsg(strFailed);
	 	    }
		 throw exe;
	}
	
	
	
	

    }

    public void setDueDateMove() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	try {
	    // Give Customer Billing info
	    strDescription = "Entering customer DueDate info details";
	    strExpected = "Giving customer DueDate info in details";
	    strActual = "Giving Customer Duedate details in DueDate Info Page was successful";
	    strFailed = "Giving Customer Duedate details in DueDate Info Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();
	  
	   
	    waitForLoader();
	    switchToDefaultcontent();
	    // Switch Frame
	    switchToFrame("IfProducts");
	    String MissedAppointment1 = get("MissedAppointmentOld").trim();
	    String MissedAppointment2 = get("MissedAppointmentNew").trim();

	    // Old Address Missed appointment
	    if (OldMissedAppointmentList.size() > 0) {
		if (isDisplayed(OldMissedAppointment, strFailed)) {
		    try {

			selectDropDownUsingVisibleText(OldMissedAppointment, objectValue, MissedAppointment1);

		    } catch (Exception exe) {

		    }
		}
	    }

	    try{
		    // Clicking First Due Date for Old Address
	        	   if(isDisplayed(dueDateOld, MissedAppointment2, 2)){
		    pageScroll(dueDateOld, MissedAppointment2, true);
	        	   }
		    mouseOver(firstDueDateOld);
		    clickUsingJavaScript(firstDueDateOld, objectValue);
		    if(get("Application").equalsIgnoreCase("C2G")){
	            if(isDisplayed(c2gTimeslots, objectValue, 1)){
	            clickUsingJavaScript(c2gTimeslots, objectValue);
	            }
	          }
		    report.reportPass("click Old Due Date", "click Old Due Date", "Old Due Date is clicked");
	          }
	             catch (Exception exe) {
		strFailed = "Failed in Due Date page, Old Due Date is not available or clickable";
		  report.reportFail("Select Old Due Date", "Old Due Date should be selected.", strFailed);		
		report.updateMainReport("comments", strFailed);
		report.updateMainReport("ErrorMessage", strFailed);
		logger.error(strFailed);
		captureErrorMsg(strFailed);
		throw new UserDefinedException(strFailed);
	        }
	    if (NewMissedAppointmentList.size() > 0) {
		if (NewMissedAppointment.isDisplayed()) {
		    try {

			selectDropDownUsingVisibleText(NewMissedAppointment, objectValue, MissedAppointment2);

		    } catch (Exception exe) {

		    }
		}
	    }
	    // Clicking Due Date for New Address
	  //  if(get("Application").equalsIgnoreCase("COA")){
	    DateComparison();
	  //  }
	   // else{
		/*    if(get("Application").equalsIgnoreCase("C2G")){
	    	if(isDisplayed(firstDueDateNewListc2g, MissedAppointment2, 3)){
	    	pageScroll(firstDueDateNewListc2g,"", true);
			 
				
				clickUsingJavaScript(firstDueDateNewListc2g, "");	
				if(get("Application").equalsIgnoreCase("C2G")){
                   if(isDisplayed(c2gTimeslots, objectValue, 3)){
                   clickUsingJavaScript(c2gTimeslots, objectValue);
                   }
				}
                 }
	    }*/

	    	
	   // }
	    
	   if(isDisplayed(c2gTimeslots, objectValue, 3)){  //Anu DD
            clickUsingJavaScript(c2gTimeslots, objectValue);
            }

	    try {////Today's modification
	     if (isDisplayed(chkboxConfirmDueDate, MissedAppointment2, 1)){
          pageScroll(chkboxConfirmDueDate, "", true);
	    clickUsingJavaScript(chkboxConfirmDueDate, objectValue);
		report.reportPass("click Checkbox if exists", "click Checkbox if exists", "Checkbox if clicked");
	      }
	    } catch (Exception exe) {

	    }
	    
	    try {      //Today's modification

	     
	     if (isDisplayed(chkboxConfirmDueDate1, MissedAppointment2, 1)){
			 pageScroll(chkboxConfirmDueDate1, "", true);
	    clickUsingJavaScript(chkboxConfirmDueDate1, objectValue);
        report.reportPass("click Checkbox if exists", "click Checkbox if exists", "Checkbox if clicked");
	    } 
		}
	    catch (Exception exe) {

	    }

	    // Clicking Save And Continue button

	    clickUsingJavaScript(btnCancel, objectValue);
	    waitForLoader();
	    waitForLoader();
	    waitForLoader();
	    waitForLoader();
	    
	    if(get("Application").equalsIgnoreCase("C2G") && (get("FlowType").equalsIgnoreCase("Move") ||get("FlowType").equalsIgnoreCase("MoveAsIs")))
	    {
		    try
		    {
		    	Alert alert = driver.switchTo().alert();
		    	alert.accept();
		    }
		    catch(Exception e)
		    {
		    	e.printStackTrace();
		    }
	    }
	    
	    
	    // Direct ship
	    switchToDefaultcontent();
	    // Switch Frame
	    switchToFrame("IfProducts");

	    if (isDisplayed(directshipeligibilityoptions, "", 10)) {

		if (isSelected(directshipeligibilityyesoption)) {
		    System.out.println("Direct ship is selected");

		} else {

		    clickUsingJavaScript(directshipeligibilityyesoption, objectValue);
		    waitForLoader();
		}

		clickUsingJavaScript(directshipclose, objectValue);
	    }
	    
	    waitForLoader();
	    
	    if (!isNotDisplayed(activeDueDateTab, 20)) {
	    	
	    	if(isDisplayed(errormessage, objectValue, 2)){
	    		String errormsg=getTextFromElement(errormessage, objectValue);
	    		System.out.println(errormsg);
	    		
                  if(errormsg.contains("The timeslot you selected")){
                	 	
              	    String errormsg2=getTextFromElement(errormessage, objectValue);
              	    System.out.println(errormsg2);
              	    strFailed = errormsg2;
              	    clickUsingJavaScript(DueDateTab, objectValue);
                  	waitForLoader();
                  	waitForLoader();
                  	waitForLoader();
                  	pause();
                  	switchToDefaultcontent();
              	    // Switch Frame
              	    switchToFrame("IfProducts");
              	    report.reportPass("Due Date Page should be displayed", "Due Date Page should be displayed", "Due Date Page is displayed");
              	  counter++;
              	  if(counter<2){
              	    setDueDateMove();
              	  }
                  }
    	 	else{
    	 
    	 		String errormsg2=getTextFromElement(errormessage, objectValue);
	    		System.out.println(errormsg2);
	    		strFailed = "Failed in Due Date page, Contact info was not displayed post clicking save and continue in Due Date page";
	    		  report.reportFail("Verify Due Date page not displayed", "Due Date page should not be displayed post clicking save and continue in Due Date page.", strFailed);		
	    		report.updateMainReport("comments", "Error: "+errormsg2+ " is displayed in Due date Page");
	    		report.updateMainReport("ErrorMessage", errormsg2);
	    		logger.error(errormsg2);
	    		captureErrorMsg(errormsg2);
	    		throw new UserDefinedException(strFailed);
	    	}
	    }
	    	else{
	       	 
	   		 strFailed = "Failed in Due Date page, Contact info was not displayed post clicking save and continue in Due Date page";
	   		 report.reportFail("Verify Due Date page not displayed", "Due Date page should not be displayed post clicking save and continue in Due Date page.", strFailed);
	   			report.updateMainReport("comments", strFailed);
	   			report.updateMainReport("ErrorMessage", strFailed);
	   			logger.error(strFailed);
	   			captureErrorMsg(strFailed);
	   			throw new UserDefinedException(strFailed);	
	   	    	}
	}
	    	
	    report.reportPass(strDescription + getUrl, strExpected, strActual);
	    pause();
	    waitForLoader();

	    switchToDefaultcontent();

	} catch (Exception exe) {
	    exe.printStackTrace();
	    report.reportFail(strDescription + getUrl, strExpected, strFailed);
	    throw exe;
	}

    }

    /**
     * Verifies Due date tab is opened or not, if not clicks on it
     * 
     * @author Shiva Kumar Simharaju
     * @throws Exception
     */
    public void verifyDueDateTab() throws Exception {

	try {
	    waitForLoader();
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    String classValue = getAttribute(dueDateTab, "", "class");

	    if (classValue != null && !classValue.contains("active")) {
		clickUsingJavaScript(dueDateTab, "");
		waitForLoader();
	    }
	} catch (Exception e) {
	    report.reportFail("Verify Due date Tab.", "Due date tab should be displayed.", "Due date tab is not available");
	    throw e;
	}

    }

    //Vikram script start 
    //Validations for SLIP flow 
      public void slipScriptValidation() throws Exception {

      	try {
      	    waitForLoader();   		
      		
      			String video = get("TvPlan").trim();
      			System.out.println("SLIP flow validations");    			
      				if(!video.isEmpty() && video.equals("Deselect")){				
      					if(isDisplayed(slip_data_fdv_script)){
      						String slip__script = slip_data_fdv_script.getText().trim();					
      						System.out.println("SLIP data fdv script"+ slip__script);					
      						if(slip__script.contains("CO Connect.")){
      							report.reportPass("SLIP flow without video service must have CoConnect", "Co Connect must be present", "Co Connect is present");
      						}
      						else{
      							report.reportFail("SLIP flow without video service must have CoConnect", "Co Connect must be present", "Co Connect is not present");						
      						}		
      					}
      					if(isDisplayed(dd_Type, "", 2)){
      						String dueDataType = dd_Type.getText();
      						System.out.println(dueDataType);
      						if(dueDataType.contains("Central Office Change")){
      							pageScroll(dd_Type);
      							report.reportPass("Due date type", "Central Office Change must be due data type", "due date type is Central Office Change");
      						}
      						else{
      							report.reportFail("Due date type", "Central Office Change must be due data type", "due date type is not Central Office Change");
      						}
      					}
      				}
      				
      				
      				if(!video.isEmpty() && !video.equals("Deselect")){
      					if(isDisplayed(dd_Type, "", 2)){
      						String dueDataType = dd_Type.getText();
      						System.out.println(dueDataType);
      						if(dueDataType.contains("Self Install")){
      							report.reportPass("Due date type", "Self Install must be due data type", "due date type is Self Install");
      						}
      						else{
      							report.reportFail("Due date type", "Self Install must be due data type", "due date type is not Self Install");
      						}
      					}
      				}
      				
      				if(!get("InternetPlan").isEmpty()){
      				if(isDisplayed(dd_offerMessageContainer, "", 2)){
      					String act_steps_message = dd_offerMessageContainer.getText().trim();
      					act_steps_message = act_steps_message.trim().replaceAll("\\s|\n", "");
      					System.out.println(("Router activation steps " + act_steps_message).trim());
      					if(act_steps_message.contains("Youmustdiscussthestepsthatthecustomermustperformtoturntheirservicesonattherequestedtime.Thefollowingaretherequiredsteps:Therouterisalreadyattheaddress.Usingacomputer,connecttotheWiFiaddressGetVerizonFiOS.OpenyourbrowserandyouwillbetakentoaVerizonFiOShomepage.Followtheinstructionsonthispagetoactivateservice.")){
      						report.reportPass("Router activation script validation", "Router activation steps must be displayed", "Router activation steps is present");
      					}
      					else{
      						report.reportFail("Router activation script validation", "Router activation steps must be displayed", "Router activation steps is not present");
      					}
      				}		
      				}
      	}catch (Exception e) {
      		report.reportFail("Verify Due date Tab.", "Due date tab should be displayed.", "Due date tab is not available");
      		throw e;
      	}
      }
      //vikram script end
    /**
     * @Name: DateComparison
     * @Description: Used to compare the old calendar and new calendar dates for
     *               selecting suitable date, which is greater than the Old
     *               calendar date.
     * @Parameter: None
     * @author : Yuvaraj
     * @Return Type: No return type
     * @throws Throws
     *             Exception Modified date: 1 March 2017 Modified Code
     *             Description: Added code for selecting future date after 30
     *             days from current date.
     *  @LastModifiedBy SHiva
     */

    public void DateComparison() throws Exception {
    	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	Date endDate = null;
	Date startDate = null;
	String dateScenario = "";// "vacation";//get("DateScenario");
	try {
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    String olddate = firstDueDateOld.getAttribute("onclick");
	    for (String retval1 : olddate.split(",")) {
		try {
		    startDate = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).parse(retval1.replace("'", "").trim());
		     System.out.println("Old selected date:"+startDate);
		    break;
		} catch (ParseException e) {
		}
	    }

	    // comparing the text of cell with date and clicking it.
	    for (int i = 0; i < firstDueDateNewList.size(); i++) {
		Element cell = firstDueDateNewList.get(i);
		
		String var1 = null;
		var1=cell.getAttribute("onclick");
		if(var1==null||var1.trim().isEmpty()){
		    var1=cell.getAttribute("onmouseover");
		}

		if (dateScenario.equalsIgnoreCase("vacation")) {
		    Calendar calendar = new GregorianCalendar();
		    calendar.setTime(startDate);
		    calendar.add(Calendar.DATE, 30);
		    endDate = calendar.getTime();
		    // System.out.println(endDate);

		    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy"); // Set
									       // your
									       // date
									       // format
		    String currentData = sdf.format(endDate);
		    // System.out.println(currentData);
		    if (var1.contains(currentData)) {
			 pageScroll(cell,"", true);
			 mouseOver(cell,"");
			   
			    if (!isDisplayed(lnkTimeSlots, "", 2)) {
				
				clickUsingJavaScript(cell, "");			
				 if(get("Application").equalsIgnoreCase("C2G")){
	                    if(isDisplayed(c2gTimeslots, objectValue, 3)){
	                    clickUsingJavaScript(c2gTimeslots, objectValue);
	                    }
	                  }

			    } else {
				// Click On First Available TimeSlots
				clickUsingJavaScript(lnkTimeSlots, "");
			    }
			break;
		    }
		} else {
		    for (String retval : var1.split(",")) {
			try {
			    endDate = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).parse(retval.replace("'", "").trim());
			    System.out.println(endDate);
			    break;
			} catch (ParseException e) {
			}
		    }

		    if (startDate.compareTo(endDate) < 0) {
			System.out.println("start is before end..");
			System.out.println(cell.getText());
			 pageScroll(cell,"", true);
			 mouseOver(cell,"");
			   
			 if ((!isDisplayed(lnkTimeSlots, "", 2)) && (!isDisplayed(SetupChargeWaivedSlots, "", 2))) {
					
					clickUsingJavaScript(cell, "");		
					if(get("Application").equalsIgnoreCase("C2G")){
	                    if(isDisplayed(c2gTimeslots, objectValue, 3)){
	                    clickUsingJavaScript(c2gTimeslots, objectValue);
	                    }
	                  }

				    }
			    	
			    	else {
				// Click On First Available TimeSlots
			    		if(isDisplayed(lnkTimeSlots, var1, 1)){
				            clickUsingJavaScript(lnkTimeSlots, "");
			    		}
			    		else{
			    			clickUsingJavaScript(SetupChargeWaivedSlots, "");
			    		}
			    }
			
			break;
		    } else if (startDate.compareTo(endDate) == 0) {
			System.out.println("start is equal to end");
			pageScroll(cell,"", true);
			 mouseOver(cell,"");
			   
			 if ((!isDisplayed(lnkTimeSlots, "", 2)) && (!isDisplayed(SetupChargeWaivedSlots, "", 2))) {					
					clickUsingJavaScript(cell, "");		
					
				    }
			    	
			    	else {
				// Click On First Available TimeSlots
			    		if(isDisplayed(lnkTimeSlots, var1, 1)){
				             clickUsingJavaScript(lnkTimeSlots, "");
			    		}
			    		else{
			    			clickUsingJavaScript(SetupChargeWaivedSlots, "");
			    		}
			    }
			break;
		    }
		}
	    }
	} catch (Exception e) {
		 strFailed = "Failed in Due Date page, new Due Date is not available/clickable";
   		 report.reportFail("Verify New Due Date page is selecetd", "New Due Date should be selected", strFailed);
   			report.updateMainReport("comments", strFailed);
   			report.updateMainReport("ErrorMessage", strFailed);
   			logger.error(strFailed);
   			captureErrorMsg(strFailed);
   			throw new UserDefinedException(strFailed);
	}

    }
    
    
    public void DateComparisonWithRetryTimeslot() throws Exception {

    	Date endDate = null;
    	Date startDate = null;
    	String dateScenario = "";// "vacation";//get("DateScenario");
    	try {
    	    switchToDefaultcontent();
    	    switchToFrame("IfProducts");
    	    String olddate = firstDueDateOld.getAttribute("onclick");
    	    for (String retval1 : olddate.split(",")) {
    		try {
    		    startDate = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).parse(retval1.replace("'", "").trim());
    		     System.out.println("Old selected date:"+startDate);
    		    break;
    		} catch (ParseException e) {
    		}
    	    }

    	    // comparing the text of cell with date and clicking it.
    	    for (int i = 0; i < firstDueDateNewList.size(); i++) {
    		Element cell = firstDueDateNewList.get(i);
    		
    		String var1 = null;
    		var1=cell.getAttribute("onclick");
    		if(var1==null||var1.trim().isEmpty()){
    		    var1=cell.getAttribute("onmouseover");
    		}

    		if (dateScenario.equalsIgnoreCase("vacation")) {
    		    Calendar calendar = new GregorianCalendar();
    		    calendar.setTime(startDate);
    		    calendar.add(Calendar.DATE, 30);
    		    endDate = calendar.getTime();
    		    // System.out.println(endDate);

    		    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy"); // Set
    									       // your
    									       // date
    									       // format
    		    String currentData = sdf.format(endDate);
    		    // System.out.println(currentData);
    		    if (var1.contains(currentData)) {
    			 pageScroll(cell,"", true);
    			 mouseOver(cell,"");
    			   
    			    if (!isDisplayed(lnkTimeSlots2, "", 2)) {
    				
    				clickUsingJavaScript(cell, "");			
    				 if(get("Application").equalsIgnoreCase("C2G")){
    	                    if(isDisplayed(c2gTimeslots, objectValue, 3)){
    	                    clickUsingJavaScript(c2gTimeslots, objectValue);
    	                    }
    	                  }

    			    } else {
    				// Click On First Available TimeSlots
    				clickUsingJavaScript(lnkTimeSlots2, "");
    			    }
    			break;
    		    }
    		} else {
    		    for (String retval : var1.split(",")) {
    			try {
    			    endDate = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH).parse(retval.replace("'", "").trim());
    			    System.out.println(endDate);
    			    break;
    			} catch (ParseException e) {
    			}
    		    }

    		    if (startDate.compareTo(endDate) < 0) {
    			System.out.println("start is before end..");
    			System.out.println(cell.getText());
    			 pageScroll(cell,"", true);
    			 mouseOver(cell,"");
    			   
    			    if (!isDisplayed(lnkTimeSlots2, "", 2)) {
    				
    				clickUsingJavaScript(cell, "");	
    				if(get("Application").equalsIgnoreCase("C2G")){
                        if(isDisplayed(c2gTimeslots, objectValue, 3)){
                        clickUsingJavaScript(c2gTimeslots, objectValue);
                        }
                      }

    				

    			    } else {
    				// Click On First Available TimeSlots
    				clickUsingJavaScript(lnkTimeSlots2, "");
    			    }
    			
    			break;
    		    } else if (startDate.compareTo(endDate) == 0) {
    			System.out.println("start is equal to end");
    			pageScroll(cell,"", true);
    			 mouseOver(cell,"");
    			   
    			    if (!isDisplayed(lnkTimeSlots2, "", 2)) {
    				
    				clickUsingJavaScript(cell, "");		
    				

    			    } else {
    				// Click On First Available TimeSlots
    				clickUsingJavaScript(lnkTimeSlots2, "");
    			    }
    			break;
    		    }
    		}
    	    }
    	} catch (Exception e) {
    	    e.printStackTrace();
    	}

        }

    /*
	 * Method Name : Simplex_FnView_Cart_Details
	 * Method Description : This is used to Validate ISOC, Offer Description in View Details Section
	 * @param No
	 * @throws Exception
	 *             throws exception of type Exception
	 * @author Rathna B
	 */
   
   
   public void MOOfferInViewCart() throws Exception{
   
   	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
   	strDescription = "Clicking View CArt Details in Due Date Page";
	    strExpected = "View CArt Details is able to click";
	    strActual = "Clicking View Cart Details link for MO validaiton is successful";
	    strFailed = "Clicking View Cart Details link for MO validaiton is not successful";
	    getUrl = ", URL Launched --> " + returnURL();

	    //Getting values from Input sheet
	    String Scenario=get("MarketingOfferType");
		String ISOC = get("ISOC");
		String[] arr_ISOC = ISOC.split(",");
		
		
	    switchToDefaultcontent();
	    // Switch Frame
	    //switchToFrame("IfProducts");

			try{
				
				//Array list to store bundle details
				ArrayList <String> arrList_bundle = new ArrayList<String>();
				

				//Map to store all ISOC value and its description
				 HashMap<String, ArrayList<String>> hm_ViewDetails = new HashMap<String, ArrayList<String>>();
				
						
				switchToDefaultcontent();
				
				if(ViewCartDetailsList.size()>0){
					
				if(isDisplayed(ViewCartDetails,objectValue,5)){
					
					mouseOver(ViewCartDetails);
					clickUsingJavaScript(ViewCartDetails,objectValue);
					report.reportPass(strDescription+getUrl, strExpected, strActual);				
					waitForLoader();;
					
					switchToDefaultcontent();
					//Switching Frame
					switchToFrame("IfProducts");
					
					//Screenshot
					 
					for (Element view : viewDetailsAllSection) {
						pageScroll(view, objectValue, false);
						waitForLoader();
						report.reportPass(strDescription+getUrl, strExpected, strActual);
						pageScroll( view, objectValue, true);
						waitForLoader();
						report.reportPass(strDescription+getUrl, strExpected, strActual);
					}

				
					//Retrieve bundle value and store it in arraylist
					if(ViewDetailsBundleSection.size()>0){
				
						if(isDisplayed(ViewDetailsBundleText,objectValue,5)){
							String bundle = getTextFromElement(ViewDetailsBundleText, objectValue);
							String[] bundle_list = bundle.split("\n");
							for(String bundleVal: bundle_list  ){
								arrList_bundle.add(bundleVal);
							}
						}
					}
				
				//Retrieve ISOC under FIOS TV and store it in map 'hm_main'
					if(ViewDetailsTVSection.size()>0){
						if(isDisplayed(ViewDetailsTVText,objectValue,5)){
							String FiosTV = getTextFromElement(ViewDetailsTVText, objectValue);
							hm_ViewDetails.putAll(addISOCDetails_To_Map(FiosTV,"FIOS TV"));
						}
					}
				
				//Retrieve ISOC under FiOS Internet and store it in map 'hm_main'
					if(ViewDetailsInternetSection.size()>0){
						if(isDisplayed(ViewDetailsInternetText,objectValue,5)){
							String FiosInternet = getTextFromElement(ViewDetailsInternetText, objectValue);
							hm_ViewDetails.putAll(addISOCDetails_To_Map(FiosInternet,"FIOS DATA"));
						}
					}
				
				//Retrieve ISOC under FiOS Digital Voice and store it in map 'hm_main'
				if(ViewDetailsFDVSection.size()>0){
					if(isDisplayed(ViewDetailsFDVText,objectValue,5)){
						String FiosVoice = getTextFromElement(ViewDetailsFDVText, objectValue);
						hm_ViewDetails.putAll(addISOCDetails_To_Map(FiosVoice,"FIOS VOICE"));
					}
				}
				
				//Retrieve ISOC under LEC Voice and store it in map 'hm_main'
				if(ViewDetailsLECSection.size()>0){
					if(isDisplayed(ViewDetailsLECText,objectValue,5)){
						String LECVoice = getTextFromElement(ViewDetailsLECText, objectValue);
						hm_ViewDetails.putAll(addISOCDetails_To_Map(LECVoice,"LEC Voice"));
					}
				}
				//Storing Hashmap in Global data hashmap.
				//Purpose - to use this hashmap in other pages for Validation
				DynamicGlobalDataHandler.setDynamicGlobalDataHashMap(testId, "ViewDetails", hm_ViewDetails);
				
				if( !hm_ViewDetails.isEmpty()){
					
					//Iterating ISOC value
					for(String ISOC_val: arr_ISOC){
						boolean ISOC_Displayed = false;
						
						//Iterating MAP 
						for(Map.Entry offer_Val:hm_ViewDetails.entrySet()){
							
							//ISOC Validation
							if(!ISOC_val.contains(":")){
								if(offer_Val.getKey().toString().contains(ISOC_val.trim())){
									ISOC_Displayed = true;
									break;
								}
							}
							
							//ISOC and its description Validation
							else if(ISOC_val.contains(":")){
								String ISOC_Id = ISOC_val.split(":")[0].trim();
								String ISOC_Desc = ISOC_val.split(":")[1].trim();
								if(offer_Val.getKey().toString().contains(ISOC_Id.trim()) && offer_Val.getValue().toString().contains(ISOC_Desc.trim())){
									ISOC_Displayed = true;
									break;
								}
								
								
							}
						}
						
						//Updating Results
						if(!ISOC.isEmpty() && ISOC_Displayed && Scenario.equalsIgnoreCase("positive") ){
							report.reportPass(strDescription +"ISOC:"+ISOC_val, strExpected +"ISOC:"+ISOC_val, strActual +"ISOC:"+ISOC_val);
							
						}
						else if(!ISOC.isEmpty() && !ISOC_Displayed && Scenario.equalsIgnoreCase("positive")){
							report.reportFail(strDescription+"ISOC:"+ISOC_val, strExpected+"ISOC:"+ISOC_val, strFailed);
													
						}
						else if(!ISOC.isEmpty() && ISOC_Displayed && Scenario.equalsIgnoreCase("negative") ){
							report.reportFail(strDescription+"ISOC:"+ISOC_val, strExpected+"ISOC:"+ISOC_val, strFailed);
						}
						else if(!ISOC.isEmpty() && !ISOC_Displayed && Scenario.equalsIgnoreCase("negative") ){
							report.reportPass(strDescription +"ISOC:"+ISOC_val, strExpected +"ISOC:"+ISOC_val, strActual +"ISOC:"+ISOC_val);
						}
						
					}
				}	
				}
				else{
					
					strDescription = "Clicking View CArt Details in Due Date Page";
				    strExpected = "View Cart Details is able to click";
				    strFailed = "View Cart Details link is not available";
					report.reportFail(strDescription + getUrl, strExpected, strFailed);
					
				}
			}
		}
		catch(Exception exe){
			exe.printStackTrace();
			report.reportFail(strDescription + getUrl, strExpected, strFailed);
			throw exe;
		}
			
   }
   
   /*
	 * Method Name : addISOCDetails_To_Map
	 * Method Description : This is used to add ISOC value and its description , price, Service type to map 
	 * @param No
	 * @return HashMap to ViewDetailsVAlidation method
	 * @author Rathna B
	 * @throws Exception
	 */
		
	public HashMap<String ,ArrayList <String>> addISOCDetails_To_Map(String Text, String Service) throws Exception{
		
		
		HashMap<String ,ArrayList <String>> hm_sub = new HashMap<String ,ArrayList <String>>();
		
		String[] arr_Text = Text.split("\n");
		for(String text_Val: arr_Text){
			if(text_Val.split(" ")[0].trim().length()==5){
				if(!hm_sub.containsKey(text_Val.substring(0, 5).trim())){
					
					ArrayList <String> arrList_Values = new ArrayList<String>();
					
					//Adding ISOC Value to arraylist
					arrList_Values.add(text_Val.substring(0, 5).trim());
					
					//Adding Description to arraylist
					arrList_Values.add(text_Val.substring(6, text_Val.indexOf("(")).trim());
					
					//Adding Service type to arraylist
					arrList_Values.add(Service);
					
					//Adding price value to arraylist
					arrList_Values.add(text_Val.substring(text_Val.indexOf("(") + 1, text_Val.indexOf(")")));
					hm_sub.put(text_Val.substring(0, 5).trim(), arrList_Values);
				}
				else{
					report.reportFail("Verifying Duplicate ISOC's in view detail page", "ISOC id should not be duplicated", text_Val.substring(0, 5).trim()+" ISOC value duplicated");
				}
			
			}
		}
		return hm_sub;
	}

	
	
	/********************
	 * Description: Added Cancel Order functionality for any order:
	 * Padmini Date: 03/14/2017
	 * 
	 * @throws Exception
	 ********************/

	public void cancelOrder() throws Exception {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		strDescription = "Clicking Cancel Order in Due Date Page";
		strExpected = "Cancel Order is able to click";
		strActual = "Clicking Cancel Order button for MO cancelling order is successful";
		strFailed = "Clicking Cancel Order button for MO cancelling order is not successful";
		getUrl = ", URL Launched --> " + returnURL();

		// Getting values from Input sheet
		String cancelOrder = get("CancelOrder").trim();
		String closingNotes = get("ClosingNotes").trim();

		switchToDefaultcontent();
		// Switch Frame
		switchToFrame("IfProducts");

		try {
			
			if(get("Application").equalsIgnoreCase("COA")){
				clickUsingJavaScript(btnCancelOrder, objectValue);
			}
			else if(get("Application").equalsIgnoreCase("C2G")){
				clickUsingJavaScript(btnC2GCancelOrder, objectValue);
			}
			
			
			report.reportPass("Select Due date", "Cancel Order button should be selected.",
					"Cancel Order button should be selected.");
			waitForLoader();
			// switchToFrame("PopupIFrame");
			if (isDisplayed(cancelOrderPopUp, objectValue)) {

				clickUsingJavaScript(cancelOrderPopUp, objectValue);
				report.reportPass("Select Due date", "Cancel Order should be selected in PopUp.",
						"Cancel Order should be selected in PopUp.");
			}

			waitForLoader();
			waitForLoader();
			waitForLoader();
			waitForLoader();
			switchToDefaultcontent();
			//waitForElementDisplay(closingNotesText, objectValue, 20);
		/*	if (isDisplayed(closingNotesText, objectValue) && (!closingNotes.isEmpty())) {

				setText(closingNotesText, objectValue, closingNotes);

				report.reportPass("Select Due date", "Closing Notes Text should be entered.",
						"Closing Notes Text should be entered..");
				waitForLoader();
				switchToDefaultcontent();

				clickUsingJavaScript(saveandClose, objectValue);
			}
			
         */
		
		}

		catch (Exception exe) {
			exe.printStackTrace();
			report.reportFail(strDescription + getUrl, strExpected, strFailed);
			throw exe;

		}

	}
	/********************
	 * Description:Shipping Return functionality for any order:
	 * Mounika Date: 02/15/2018
	 * 
	 * @throws Exception
	 ********************/
	
	public void ShippingReturn() throws Exception, UserDefinedException{
		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		try {
			strDescription = "Selecting the Shipping Return in checkout page";
			strExpected = "Shipping Return should be selected sucessfully";
			strActual = "Shipping Return was selected sucessfully";
			strFailed = "Shipping Return selection was not successful at checkout page";
			getUrl = ", URL Launched --> " + returnURL();

			waitForLoader();
			waitForLoader();
			waitForLoader();
			switchToDefaultcontent();
			//Switch Frame
			switchToFrame("IfProducts");
		
			if(isDisplayed(ShippingReturnTab, strFailed, 15)){
				report.reportPass("Shipping Return Tab should be displayed" + getUrl, "Shipping Return Tab should be displayed", "Shipping Return Tab is dispalyed in checkout page");
				//Clicking on Save And Continue button
				clickUsingJavaScript(EquipSaveNdContinue, objectValue);
              waitForLoader();
              waitForLoader();
              waitForLoader();
              if(isDisplayed(rdbtnSuggestedAddress, strFailed, 5)){
            	  clickUsingJavaScript(rdbtnSuggestedAddress, objectValue);
            	  report.reportPass("Click Suggested Address Radio button if available" + getUrl, "Suggested Address Radio button should be clicked", "Suggested Address Radio button is clicked");
            	  waitForLoader();
            	  clickUsingJavaScript(EquipSaveNdContinue, objectValue);
                  waitForLoader();
                  waitForLoader();
                  waitForLoader();
                  waitForLoader();
              }
				pause();
				report.reportPass(strDescription + getUrl, strExpected, strActual);
			}
		}
		catch (Exception exe) {
			exe.printStackTrace();
			report.reportFail(strDescription + getUrl, strExpected, strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			throw new   UserDefinedException("Failed in Shipping Return Page");
		}
	}
	
	
	/**
     *In Due Date Page click on View Details 
     * 
     * @author Naresh
     * @throws Exception
     */
    public void clickViewDetails() throws Exception{
    	try{
    		switchToDefaultcontent();
        	click(dueDatePage_ViewDetails,"");
        	waitForLoader();
        	waitForLoader();
            report.reportPass("Capturing View Details in Due Date Page ","screens","View Details Screen");  
            click(viewDetails_popup_bundle,"");
            Thread.sleep(200);
            report.reportPass("Capturing View Details in Due Date Page ","screens","View Details Screen");  
            
    		if( get("Contract").equalsIgnoreCase("M2M") && get("FlowType").equalsIgnoreCase("Change") ||  get("Contract").equalsIgnoreCase("M2M") && get("FlowType").equalsIgnoreCase("Move") )
    		{
    			
    			
    			 if(!get("InternetPlan").isEmpty()){
    				 
    				 if(!get("FlowType").equalsIgnoreCase("Move")){
    	            	pageScroll(fiosInternet_ViewDetails);
    	            	pageScroll(fiosInternet_TermTracker_Removed);
    	            	String internet_etfRemovalText=fiosInternet_TermTracker_Removed.getText();
    	            	if(internet_etfRemovalText.contains("Term Tracker for 24M")){
    	                    report.reportPass("Check whether ETF Removal text is displayed for Fios Internet service is View Details page ","ETF Text must be displayed","ETF text is displayed in View details page for Fios Intennet Service. ETF text displayed is "+internet_etfRemovalText);  

    	            	}
    	            	else{
    	            		report.reportFail("Check whether ETF Removal text is displayed for Fios Internet service is View Details page ", "ETF Text must be displayed", "ETF text is not displayed");
    	            	}
    				 }
    				 
    	            	pageScroll(fiosInternet_MTMAdded);
    	            	String etfAddedText=fiosInternet_MTMAdded.getText();
    	            	if(etfAddedText.contains("Term Tracker for MTM")){
    	                    report.reportPass("Check whether MTM Added text is displayed for Fios Data service is View Details page ","MTM added Text must be displayed","MTM added text is displayed in View details page for Fios Internet Service. MTM text displayed is "+etfAddedText);  

    	            	}
    	            	else{
    	            		report.reportFail("Check whether MTM Added text is displayed for Fios Data service is View Details page ", "MTM Added text must be displayed", "MTM added text is not displayed");

    	            	}

    	            	
    	            }else if(get("InternetPlan").isEmpty() && get("FlowType").equalsIgnoreCase("Move")){

    	            	pageScroll(fiosInternet_ViewDetails);
    	            	pageScroll(fiosInternet_TermTracker_Removed);
    	            	String internet_etfRemovalText=fiosInternet_TermTracker_Removed.getText();
    	            	if(internet_etfRemovalText.contains("Term Tracker for 24M")){
    	                    report.reportPass("Check whether ETF Removal text is displayed for Fios Internet service is View Details page ","ETF Text must be displayed","ETF text is displayed in View details page for Fios Intennet Service. ETF text displayed is "+internet_etfRemovalText);  

    	            	}
    	            	else{
    	            		report.reportFail("Check whether ETF Removal text is displayed for Fios Internet service is View Details page ", "ETF Text must be displayed", "ETF text is not displayed");
    	            	}
    				 
    	            }
    			 
    			 if(!get("TvPlan").isEmpty()){
    				 if(!get("FlowType").equalsIgnoreCase("Move")){
    	            	pageScroll(fiosTV_ViewDetails);
    	            	pageScroll(fiosTV_TermTracker_Removed);
    	            	String tv_etfRemovalText=fiosTV_TermTracker_Removed.getText();
    	            	if(tv_etfRemovalText.contains("Term Tracker for 24M")){
    	                    report.reportPass("Check whether ETF Removal text is displayed for TV service is View Details page ","ETF Text must be displayed","ETF text is displayed in View details page for TV Service. ETF text displayed is "+tv_etfRemovalText);  

    	            	}
    	            	else{
    	            		report.reportFail("Check whether ETF Removal text is displayed for TV service is View Details page ", "ETF Text must be displayed", "ETF text is not displayed");
    	            	}
    				 }
    	            	pageScroll(fiosTV_TermTracker_MTM_Added);
    	            	String etfAddedText=fiosTV_TermTracker_MTM_Added.getText();
    	            	if(etfAddedText.contains("Term Tracker for MTM")){
    	                    report.reportPass("Check whether MTM Added text is displayed for TV service is View Details page ","MTM added Text must be displayed","MTM added text is displayed in View details page for TV Service. MTM text displayed is "+etfAddedText);  

    	            	}
    	            	else{
    	            		report.reportFail("Check whether MTM Added text is displayed for TV service is View Details page ", "MTM Added text must be displayed", "MTM added text is not displayed");

    	            	}
    	            	
    	            }else if(get("TvPlan").isEmpty() && get("FlowType").equalsIgnoreCase("Move")){

    	            	pageScroll(fiosTV_ViewDetails);
    	            	pageScroll(fiosTV_TermTracker_Removed);
    	            	String tv_etfRemovalText=fiosTV_TermTracker_Removed.getText();
    	            	if(tv_etfRemovalText.contains("Term Tracker for 24M")){
    	                    report.reportPass("Check whether ETF Removal text is displayed for TV service is View Details page ","ETF Text must be displayed","ETF text is displayed in View details page for TV Service. ETF text displayed is "+tv_etfRemovalText);  

    	            	}
    	            	else{
    	            		report.reportFail("Check whether ETF Removal text is displayed for TV service is View Details page ", "ETF Text must be displayed", "ETF text is not displayed");
    	            	}
    				 
    	            }
    	            
    			 if(!get("VoicePlan").isEmpty()){
    				 if(!get("FlowType").equalsIgnoreCase("Move")){
    	            	pageScroll(fiosDigitalVoice_ViewDetails);
    	            	pageScroll(fiosDigitalVoice_ETFRemoved);
    	            	String fdv_ETFRemovalText=fiosDigitalVoice_ETFRemoved.getText();
    	            	if(fdv_ETFRemovalText.contains("Term Tracker for 24M")){
    	                    report.reportPass("Check whether ETF Removal text is displayed for FDV service is View Details page ","ETF Text must be displayed","ETF text is displayed in View details page for FDV Service. ETF text displayed is "+fdv_ETFRemovalText);  

    	            	}
    	            	else{
    	            		report.reportFail("Check whether ETF Removal text is displayed for FDV service is View Details page ", "ETF Text must be displayed", "ETF text is not displayed");
    	            	}
    				 }
    	            	pageScroll(fiosDigitalVoice_MTMAdded);
    	            	String etfAddedText=fiosDigitalVoice_MTMAdded.getText();
    	            	if(etfAddedText.contains("Term Tracker for MTM")){
    	                    report.reportPass("Check whether MTM Added text is displayed for FDV service is View Details page ","MTM added Text must be displayed","MTM added text is displayed in View details page for FDV Service. MTM text displayed is "+etfAddedText);  

    	            	}
    	            	else{
    	            		report.reportFail("Check whether MTM Added text is displayed for FDV service is View Details page ", "MTM Added text must be displayed", "MTM added text is not displayed");

    	            	}

    	            }else if(get("VoicePlan").isEmpty() && get("FlowType").equalsIgnoreCase("Move")){

    	            	pageScroll(fiosDigitalVoice_ViewDetails);
    	            	pageScroll(fiosDigitalVoice_ETFRemoved);
    	            	String fdv_ETFRemovalText=fiosDigitalVoice_ETFRemoved.getText();
    	            	if(fdv_ETFRemovalText.contains("Term Tracker for 24M")){
    	                    report.reportPass("Check whether ETF Removal text is displayed for FDV service is View Details page ","ETF Text must be displayed","ETF text is displayed in View details page for FDV Service. ETF text displayed is "+fdv_ETFRemovalText);  

    	            	}
    	            	else{
    	            		report.reportFail("Check whether ETF Removal text is displayed for FDV service is View Details page ", "ETF Text must be displayed", "ETF text is not displayed");
    	            	}
    				 
    	            }
    			 	 
    			
    		}
        
            pageScroll(viewDetails_popup_bundle);
            Robot r=new Robot();
            r.keyPress(KeyEvent.VK_PAGE_DOWN);
            Thread.sleep(200);
            report.reportPass("Capturing View Details in Due Date Page ","screens","View Details Screen");  
            r.keyPress(KeyEvent.VK_PAGE_DOWN);
            Thread.sleep(200);
            report.reportPass("Capturing View Details in Due Date Page ","screens","View Details Screen");  
            r.keyPress(KeyEvent.VK_PAGE_DOWN);
            Thread.sleep(200);
            report.reportPass("Capturing View Details in Due Date Page ","screens","View Details Screen");
            click(viewDetails_close,"");
    		r.keyPress(KeyEvent.VK_PAGE_DOWN);


    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	

        
    }


}
