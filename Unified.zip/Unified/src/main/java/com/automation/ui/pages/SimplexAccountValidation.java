package com.automation.ui.pages;

import java.io.StringReader;
import java.util.HashMap;


import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_Login_PageObjects;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.UserDefinedException;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
/**
 * SimplexLoginPage class represents the Login Page and interact with the Page.
 * 
 */
public class SimplexAccountValidation extends Simplex_Login_PageObjects {
	
	String visionid=get("Search_Value");
	String env=get("Environment");
	
	String objectValue = "";
	static boolean windows = InitiateDriver.windows;
	//int iterator = 0;
	String testId=null;

	final static Logger logger = Logger.getLogger(SimplexAccountValidation.class);

	/**
	 * SimplexLoginPage constructor invokes the super class constructor.
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            repesents the testcase id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @throws Exception
	 *             throws exception of type Exception
	 */
public SimplexAccountValidation(WebDriver driver, String testId,ReportStatus report, HashMap<String, String> data) throws Exception
	
	{
		super(driver, InitiateDriver.windows, report, data);
		this.testId=testId;
      
	}
	

	/**
	 * initialize method used to initialize the page elements for this page and
	 * returns current Page
	 * 
	 * @param driver
	 *            represents the instance of type WebDriver
	 * @param testId
	 *            repesents the testcase id
	 * @param report
	 *            represents the instance of Report Status class
	 * @param data
	 *            represents the data input
	 * @return returns current page class
	 */
	public static SimplexAccountValidation initialize(WebDriver driver, String testId,ReportStatus report, HashMap<String, String> data) 
	{
		return ElementFactory.initElements(driver, SimplexAccountValidation.class,testId, report, data);
	}

	String description = "", expected = "", actual = "", failure = "", getUrl;
	By by;

	/**
	 * Navigation start for simplex login page
	 * 
	 * @param Url
	 *            represents the page url to be open
	 * @throws Exception
	 *             throws exception of type Exception
	 */
	public void start() throws Exception 
	{
		setIterator();
		if(get("getvzfullprofile").equalsIgnoreCase("Yes"))
		{
			JSONObject profileresponse=getvzfullprofileclient();
		    responseparser(profileresponse);	
		}
		
	}


	/** GetVZFullProfile Client **/	
	public JSONObject getvzfullprofileclient() {
		JSONObject jsonResponse = null;
		Client client = Client.create();
		WebResource webResource = client.resource("http://itotaas.ebiz.verizon.com:8080/ValidationMicroservices-v1.0/getvzfullprofile?visionId="+visionid+"&state=MA&env="+env+"");
		ClientResponse response = webResource.accept("application/json").get(ClientResponse.class);
		if (response.getStatus() != 200) { 
			throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());}

		try {
			jsonResponse = new JSONObject(response.getEntity(String.class));} 
		catch (ClientHandlerException | UniformInterfaceException | JSONException e) {
			e.printStackTrace();
		}

		return jsonResponse;

	}	

	/** GetVZFullProfile Response Parser **/	
	public String responseparser(JSONObject profileResponse) throws Exception {
		String strDescription = "", strExpected = "", strActual = "", strFailed = "";

		strDescription = "Account validation - Check GetvzfullprofileResponse";
		strExpected = "Response should receive from NCOG for Getvzfullprofile Service, if Account is Valid";
		strActual = " Response received from NCOG for Getvzfullprofile Service hence account - "+visionid+" is valid";
		strFailed = " Response received from NCOG for Getvzfullprofile Service hence account - "+visionid+" is in valid";

		try {
			org.w3c.dom.Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder()
					.parse(new InputSource(new StringReader((String) profileResponse.get("Response"))));
			NodeList nodeList = document.getElementsByTagName("source");
			for (int i = 0; i < nodeList.getLength(); i++) {
				if (nodeList.item(i).getTextContent().equals("Overall")) {
					Element ele = (Element) nodeList.item(i).getParentNode();
					//System.out.println("Value::"+ele.getElementsByTagName("description").item(0).getTextContent());
					if (ele.getElementsByTagName("description").item(0).getTextContent().equals("Success")) {
						report.reportPass(strDescription, strExpected,
								ele.getElementsByTagName("description").item(0).getTextContent() + strActual);
						report.updateMainReport("status", "Passed");
					} else {
						throw new UserDefinedException(
								ele.getElementsByTagName("description").item(0).getTextContent() + strFailed);
					}
				}
			}
			
		} catch (Exception e) {
			System.out.print(e.getMessage());
			e.printStackTrace();
			report.updateMainReport("status", "Failed");
			report.reportFail(strDescription, strExpected, e.getMessage());
			logger.error("TestCase Failed...");
			throw e;
		}

		return strActual;
	}

}
