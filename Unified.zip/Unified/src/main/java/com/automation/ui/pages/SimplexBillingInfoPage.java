package com.automation.ui.pages;

import java.util.HashMap;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.automation.functionallibrary.CustomDriver;
import com.automation.functionallibrary.InitiateDriver;
import com.automation.pageobjects.Simplex_BillingInfo_PageObjects;
import com.automation.support.Element;
import com.automation.support.ElementFactory;
import com.automation.utilities.ReportStatus;
import com.automation.utilities.TestIterator;
import com.automation.utilities.UserDefinedException;

import org.openqa.selenium.interactions.Actions;

/**
 * SimplexBillingInfoPage class represents the Billing Info Page and interact
 * with the Page
 * 
 */
@SuppressWarnings("unused")
public class SimplexBillingInfoPage extends Simplex_BillingInfo_PageObjects {

    String objectValue = "";
    String description = "", expected = "", actual = "", failure = "", getUrl;
    By by;
    String testId;

    Logger logger = CustomDriver.getThreadLogger(Thread.currentThread(),testId);

    /**
     * SimplexBillingInfoPage constructor invokes the super class constructor.
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @throws Exception
     *             throws exception of type Exception
     *             
     */
    public SimplexBillingInfoPage(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) throws Exception {
	super(driver, InitiateDriver.windows, report, data);
	this.testId = testId;
    }

    /**
     * initialize method used to initialize the page elements for this page and
     * returns current Page
     * 
     * @param driver
     *            represents the instance of type WebDriver
     * @param testId
     *            repesents the testcase id
     * @param report
     *            represents the instance of Report Status class
     * @param data
     *            represents the data input
     * @return returns current page class
     * 
     */
    public static SimplexBillingInfoPage initialize(WebDriver driver, String testId, ReportStatus report, HashMap<String, String> data) {

	return ElementFactory.initElements(driver, SimplexBillingInfoPage.class, testId, report, data);
    }

    /**
     * Navigation start for Simplex Billing info Page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void start() throws Exception {

	setIterator();
	System.out.println("Billing page...");
	// To check billing info tab is opened or not.. if not click on it
    String NY_Municipal_Surcharge = get("Check_NY_Municipal_Surcharge").trim();
    
    if(get("ChangeType").equalsIgnoreCase("PartialDisconnect") || get("ChangeType").equalsIgnoreCase("Disconnect")){
    	DisconnectOrder();
    	}
	verifyBillInfoTab();

	if (!NY_Municipal_Surcharge.isEmpty() && NY_Municipal_Surcharge.equalsIgnoreCase("Yes"))
    {
		CheckNYMunicipalSurcharge();
    
    }
	
	setBillingInfo();
	
	

    }

    /**
     * Navigation to this page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    public void navigateTo() throws Exception {

	// To increment the navigation iteration
	int i = TestIterator.getIterator(testId);
	TestIterator.setIterator(testId, ++i);

	clickUsingJavaScript(billingInfoTab, objectValue);
    }

    /**
     * setBillingInfo method for providing the Customer's Billing information in
     * Billing Info Page
     * 
     * @throws Exception
     *             throws exception of type Exception
     */
    protected void setBillingInfo() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";
	try {
	    // set the Iterator to latest excel count

	    // Give Customer Billing info
	    strDescription = "Entering customer Billing info details";
	    strExpected = "Giving customer Billing info in details";
	    strActual = "Giving Customer Billing details in Billing Info Page was successful";
	    strFailed = "Giving Customer Billing details in Billing Info Page was not successful";
	    getUrl = ", URL Launched --> " + returnURL();

	    
	  
	    // Sync handle
	    waitForLoader();
	    waitForLoader();
	    waitForLoader();
	    
	    if(get("ChangeType").equalsIgnoreCase("Change")){
	    	GUIValidations_ViewDetails();
	    }
	    

    	//Telecommunication service priority
	    
	    if (!get("TSP_PSAN").trim().isEmpty() && get("Application").equalsIgnoreCase("COA")){

	    	EnterPSANDetails();
	    }
	    report.reportPass("Billing Info Page should be displayed", "Billing Info Page should be displayed", "Billing Info Page is displayed");
	    
	    try{
	    
	    if(isDisplayed(Enrolldigitalbilling)){
		     pageScroll(Enrolldigitalbilling);
		     String DBMessage =EnrolldigitalbillingMessage.getText();
		     System.out.println("Digital_billing is enrolled and message is displayed: " +DBMessage);
		report.reportPass("Digital Billing should be enrolled: " + DBMessage, "Digital Billing is enrolled: " + DBMessage, "Digital Billing Enrollment message is " + DBMessage);
		}
	    }
	    catch(Exception e){
		  
		System.out.println("Digital_billing is not enrolled and message is not displayed");
		report.reportFail("Digital Billing should be enrolled ", "Digital Billing is not enrolled " , "Digital Billing message is not displayed ");
		}
	    
	    
	    try{
		    if(isDisplayed(EnrolldigitalbillingScriptMessage)){
		     pageScroll(EnrolldigitalbillingScriptMessage);
		     String DBMessage =EnrolldigitalbillingScriptMessage.getText();
		     System.out.println("Digital Billing Script message is Displayed:" +DBMessage);
		report.reportPass("Digital Billing Script message should be Displayed: " + DBMessage, "Digital Billing Script message is Displayed:" + DBMessage, "Digital Billing script message is " + DBMessage);
		}
	    }
	    catch(Exception e){
		System.out.println("Digital Billing Script message is not Displayed:");
		report.reportFail("Digital Billing Script message should be Displayed: ", "Digital Billing Script message is not Displayed:" , "Digital Billing script message is not displayed");
		}
	  
	    // Switch Frame
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    switchToFrame("PopupIFrame");
	    
	    
	    
	    // Agree to deposit collection for high risk customer.
	    if (isDisplayed(chckBoxAgreeToRefundableDeposit, "", 1)) {

		clickUsingJavaScript(chckBoxAgreeToRefundableDeposit, "");
		pageScroll(DepositSaveAndContinue);
		clickUsingJavaScript(DepositSaveAndContinue, "");
	    } else if (isDisplayed(popupClose, "", 0)) {
		clickUsingJavaScript(popupClose, "");
	    }
	    waitForLoader();
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");

	    // Installment billing.

	    String noOfInstallments = get("NoOfInstallments").trim();

	    if (!noOfInstallments.isEmpty()) {
		clickUsingJavaScript(link_Installment_Billing, "");
		waitForLoader();

		if (!getAttribute(link_Fios_Services, objectValue, "class").contains("active")) {
		    pageScroll(link_Fios_Services, objectValue, true);
		    clickUsingJavaScript(link_Fios_Services, objectValue);

		}

		waitForLoader();
		selectDropDownUsingValue(NoofMonths, "", noOfInstallments);
		report.reportPass("Select no of instsallments", "No of installments should be selected.", "Selected no of installments as " + noOfInstallments);
		waitForPageToLoad(driver);

	    }

	    // Special handling code.
	    String spcl_hndl_cd = get("Special_Handling_Code").trim();

	    // Spoken Language Preference
	    String language = get("Language").trim();

	    if (!spcl_hndl_cd.isEmpty()) {
		clickUsingJavaScript(Billing_Options, "");

		waitForLoader();

		clickUsingJavaScript(General_Tab, "");

		waitForLoader();

		mouseOver(Spl_handl_cd);
		pageScroll(Spl_handl_cd, language, true);

		selectDropDownUsingVisibleText(Spl_handl_cd, "", spcl_hndl_cd.trim());

		report.reportPass("Select special handing code.", "Special handling code should be selected.", "Entered special handling code: " + spcl_hndl_cd);

		waitForLoader();

	    }

	    // Spoken Language Preference
	    if (!language.isEmpty()) {
		clickUsingJavaScript(Billing_Options, "");
		waitForLoader();
		clickUsingJavaScript(General_Tab, "");
		waitForLoader();

		mouseOver(SpokenLanguage);
		pageScroll(SpokenLanguage, language, true);
		selectDropDownUsingVisibleText(SpokenLanguage, "", language.trim());

		report.reportPass("Select Spoken Language PReference.", "Spoken Language PReference should be selected.", "Selected Spoken Language PReference: " + language);

		waitForLoader();

	    }
	    if(get("ChangeBillingAddress").equalsIgnoreCase("Yes")){
	    	String FirstName=get("BillingFirstName");
		    String LastName=get("BillingLastName");
			String Address1=get("StreetAddress");
			String City=get("City");
			String State=get("State");
			String Zipcode=get("Zipcode");
			if(!FirstName.isEmpty() && (!LastName.isEmpty()))
	    	{
	    	clickUsingJavaScript(correction, "");
	    	waitForLoader();
	    	clearText(firstname, objectValue);
	    	setText(firstname, objectValue, FirstName);	    	
	    	clearText(lastname, objectValue);
	    	setText(lastname, objectValue, LastName);
	    	waitForLoader();	    
	    	}
			if(isDisplayed(UseServiceAddress, Zipcode, 1)){
				clickUsingJavaScript(UseServiceAddress, Zipcode);
				
			}
			
			
			if(!Address1.isEmpty() && (!City.isEmpty()) && (!State.isEmpty())){
				clearText(address1, objectValue);
		    	setText(address1, objectValue, Address1);
		    	clearText(city, objectValue);
		    	setText(city, objectValue, City);
		    	selectDropDownUsingVisibleText(state, objectValue, State);
		    	 Actions action = new Actions(driver);
		    	 action.moveToElement(driver.findElement(By.xpath("//input[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucBillingNameAddress_ucAddressInfoEastBNA_txtZipEast']"))).click().build().perform();
	            WebElement e=driver.findElement(By.xpath("//input[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucBillingNameAddress_ucAddressInfoEastBNA_txtZipEast']"));
	            e.clear();
		    	clearText(zipcode, objectValue);
		    	setText(zipcode, objectValue, Zipcode);
		    	waitForLoader();
				}
	    }

	    //Added for prepaid plans
	    if(get("SelectPackage").equalsIgnoreCase("Get Prepaid Plans")){
	    	clearText(PrepaidFname, objectValue);
	    		    	setText(PrepaidFname, objectValue, "Passlow");	    	
	    		    	clearText(PrepaidLname, objectValue);
	    		    	setText(PrepaidLname, objectValue, "Customer");
	    		    	waitForLoader();	    
	    	}

	    
	    // Select Paper free Billing Option No
	    if (isDisplayed(rbtnPaperFreeBilling, objectValue, 0)) {
		clickUsingJavaScript(rbtnPaperFreeBilling, objectValue);
		// Select Reason for Paper free Billing
		if (isDisplayed(lstPaperFreeBillingReason, objectValue)) {
		    selectDropDownUsingVisibleText(lstPaperFreeBillingReason, objectValue, "Other");
		    // pause();
		}
	    }

	
	 

	} catch (Exception exe) {
	    exe.printStackTrace();
	    report.reportFail(strDescription + getUrl, strExpected, strFailed);
	    report.updateMainReport("ErrorMessage", strFailed);
	    throw exe;
	}

	// *****Next Function
	saveAndContinue();

    }

    
    /**
	 * TSP code for entering PSAN details
	 * 
	 * @author Suman Pasupula
	 * @throws Exception
	 */
	public void EnterPSANDetails() throws Exception {

		String strDescription = "", strExpected = "", strActual = "", strFailed = "";
		try {

			if (!get("TSP_PSAN").trim().isEmpty()){



				strDescription = "Entering PSAN details.";
				strExpected = "Enter  PSAN info in details";
				strActual = "Entering PSAN details in the Telecommunication service priority page was successful";
				strFailed = "Entering PSAN details in the Telecommunication service priority page was not successful";
				getUrl = ", URL Launched --> " + returnURL();

				// Sync handle
				waitForLoader();


				switchToDefaultcontent();
				switchToFrame("IfProducts");

				try{

					if(isDisplayed(TelecommunicationServicePriorityButton)){
						pageScroll(TelecommunicationServicePriorityButton);
						clickUsingJavaScript(TelecommunicationServicePriorityButton, "");
						System.out.println("TelecommunicationServicePriorityButton is displayed" );
						report.reportPass("TelecommunicationServicePriorityButton should be displayed ", "TelecommunicationServicePriorityButton is displayed ", "TelecommunicationServicePriorityButton is displayed" );
					}
				}
				catch(Exception e){

					System.out.println("TelecommunicationServicePriorityButton is not displayed");
					report.reportFail("TelecommunicationServicePriorityButton should be displayed ", "TelecommunicationServicePriorityButton is not displayed ", "TelecommunicationServicePriorityButton is not displayed" );
				}

				// Sync handle
				waitForLoader();

				//String strPSAN = "TSP12345I-12";
				String strPSAN = get("TSP_PSAN").trim();
				String strTN = "";
				String strServiceType = "";
				int temp = 2;	

				if(!get("ChangeType").equalsIgnoreCase("Change")){
				System.out.println(strPSAN);

					String tempStr1 =Integer.toString(temp);

					//entering the PSAN
					waitForLoader();
					clearText(txtPSAN, tempStr1);

					setText(txtPSAN, tempStr1, strPSAN);
					waitForLoader();

					txtTSP.click();
					waitForLoader();

					System.out.println("  PSAN  entered  is :   " + strPSAN);
					report.reportPass("PSAN should be entered", "PSAN details have been entered   ", "   PSAN   is :   " + strPSAN );


					if(strPSAN.contains(",")){


						String str = strPSAN;
						String [] arrOfStr = str.split(",");

						waitForLoader();
						clickUsingJavaScript(btnAdditionalTSP, "");


						for(int a=1;a<arrOfStr.length;a++){
							waitForLoader();
							System.out.println(arrOfStr[a]);

							String tempStr =Integer.toString(temp);

							waitForLoader();

							//entering the PSAN
							waitForLoader();
							clearText(txtPSANAddl, tempStr);

							setText(txtPSANAddl, tempStr, arrOfStr[a]);
							waitForLoader();

							txtTSP.click();
							waitForLoader();

							temp=Integer.parseInt(tempStr);  
							temp = temp + 1;
							System.out.println("  PSAN  entered  is :   " + arrOfStr[a]);
							report.reportPass("PSAN should be entered", "PSAN details have been entered   ", "   PSAN   is :   " + arrOfStr[a] );

						}
					} 



					clickUsingJavaScript(PSANApply, "");
					waitForLoader();

					Thread.sleep(2000);
					report.reportPass("Click on Apply button", "Apply button should be clicked   ", " Apply button has been be clicked" );   
					clickUsingJavaScript(PSANApplyAndClose, "");
					report.reportPass("Click on Apply and close button..", "Apply and close button should be clicked   ", " Apply and close button has been be clicked" ); 
					waitForLoader();
				}else{

					if(strPSAN.contains(",")){
						String str = strPSAN;
						String [] arrOfStr = str.split(",");

						waitForLoader();
						clickUsingJavaScript(btnAdditionalTSP, "");


						for(int a=1;a<arrOfStr.length;a++){
							waitForLoader();
							System.out.println(arrOfStr[a]);

							String tempStr =Integer.toString(temp);

							waitForLoader();

							//entering the PSAN
							waitForLoader();
							clearText(txtPSANAddl, tempStr);

							setText(txtPSANAddl, tempStr, arrOfStr[a]);
							waitForLoader();

							txtTSP.click();
							waitForLoader();

							temp=Integer.parseInt(tempStr);  
							temp = temp + 1;
							System.out.println("  PSAN  entered  is :   " + arrOfStr[a]);
							report.reportPass("PSAN should be entered", "PSAN details have been entered   ", "   PSAN   is :   " + arrOfStr[a] );

						}
					}else{
						System.out.println(strPSAN);

						String tempStr1 =Integer.toString(temp);


						//entering the PSAN
						waitForLoader();
						clearText(txtPSANAddl, tempStr1);

						setText(txtPSANAddl, tempStr1, strPSAN);
						waitForLoader();

						txtTSP.click();
						waitForLoader();

						System.out.println("  PSAN  entered  is :   " + strPSAN);
						report.reportPass("PSAN should be entered", "PSAN details have been entered   ", "   PSAN   is :   " + strPSAN );

					}
					clickUsingJavaScript(PSANApply, "");
					waitForLoader();

					Thread.sleep(2000);
					report.reportPass("Click on Apply button", "Apply button should be clicked   ", " Apply button has been be clicked" );   
					//if(isDisplayed(PSANApplyAndClose)){
					clickUsingJavaScript(PSANApplyAndClose, "");
					waitForLoader();

				}

			}

		} catch (Exception exe) {
			exe.printStackTrace();
			report.reportFail(strDescription + getUrl, strExpected, strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			throw exe;
		}

	}
	
   
    protected void saveAndContinue() throws Exception {
    	String strDescription = "", strExpected = "", strActual = "", strFailed = "", getUrl;
    	getUrl = ", URL Launched --> " + returnURL();
	try {
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    if(get("Application").equalsIgnoreCase("COA")){
		     if(isDisplayed(PaymentMethod, objectValue, 5))
		     {
		    String e= PaymentMethod.getText();
		     System.out.println(e);
		     report.reportPass("Verify Popup Text in Billing Info", "Display Popup Text in Billing Info", "Billing Address Details in Billing Info: " +e);
		     }
	     if(get("FlowType").equalsIgnoreCase("Move")){
		     if(isDisplayed(Alertmessage, "", 5))
		     { 
		String x=Alertmessage.getText();
		System.out.println(x);
		report.reportPass("Verify billing Address Changed in Billing Info", "Display Changed Billing Address in Billing Info", "Popup Text in Billing Info: " +x);
		  
		     }
	     }
		    }
	    if (get("SaveOrder").equalsIgnoreCase("Yes")) {
		clickUsingJavaScript(BillingSave, objectValue);
		waitForLoader();
	    }
	    else if (get("FastPassOrder").equalsIgnoreCase("Yes")) {
	    	
	    //	if(get("Application").equalsIgnoreCase("C2G")){
	    		clickUsingJavaScript(cancelOrder, objectValue);
	    		waitForLoader();
	    		waitForLoader();
	    		waitForLoader();
	    		switchToFrame("PopupIFrame");

	    		clearText(fastpassemail, objectValue);
	    		
	    		Thread.sleep(2000);
	    		setText(fastpassemail, objectValue, get("Email_ID").trim());
	    		report.reportPass("Enter Email", "Enter Email for Smart Cart", "Email Entered for Smart Cart");
	    		
	    		clickUsingJavaScript(btnSaveOrder, objectValue);
	    		report.reportPass("Click Save Order", "Click Save Order for Smart Cart", "Clicked Save Order for Smart Cart");
	    		waitForLoader();
	    		waitForLoader();
	    		Thread.sleep(10000);
	    //	}
	    /*	else{
	    	
	    	switchToDefaultcontent();
	    	
	    	String MON = null;
			try{
				MON=getTextFromElement(MON_atbillingpage, objectValue);
				report.reportPass("Extract MON of the Order to be fastPassed", "MON of the Order to be fastPassed should be displayed", "MON" +MON);
				report.updateMainReport("MON", MON);

				}
			catch(Exception ex){
				report.reportFail("Extract MON of the Order to be fastPassed", "MON of the Order to be fastPassed should be displayed", "MON" +MON);
				throw new UserDefinedException("unable to extract the MON" + ex.toString());			

				}
			
			   switchToDefaultcontent();
			   switchToFrame("IfProducts");
			
	    	if(get("Application").equalsIgnoreCase("C2G")){
	    		clickUsingJavaScript(btnFastPassC2G, objectValue);
	    	}
	    	else{
	    			    	
		  clickUsingJavaScript(btnFastPass, objectValue);
	    	}
		waitForLoader();
		switchToFrame("PopupIFrame");

		clearText(fastpassemail, objectValue);
		Thread.sleep(2000);
		setText(fastpassemail, objectValue, get("Email_ID").trim());
		clickUsingJavaScript(yesButton, objectValue);
		waitForLoader();
		clickUsingJavaScript(btnSaveOrder, objectValue);
		waitForLoader();
		waitForLoader();

	    	}
	    	*/

	    } else {
	    	try{
	    	pageScroll(btnSaveAndContinue, objectValue, true);
		clickUsingJavaScript(btnSaveAndContinue, objectValue);
		report.reportPass("Click Save And Continue in Billing Info", "Save And Continue should be clicked in Billing Info", "Save And Continue is clicked in Billing Info");
	    	}
	    	catch (Exception e) {
			    strFailed = "Failed in clicking Save And Continue in Billing Info Page";
			    logger.error(strFailed, e);
			    report.reportFail("Click Save And Continue in Billing Info Page", "Save And Continue should be clicked.", strFailed);
			    report.updateMainReport("comments", strFailed);
			    report.updateMainReport("ErrorMessage", strFailed);
			    captureErrorMsg(strFailed);
			    throw new UserDefinedException(strFailed);
			}

	    waitForLoader();
	    waitForLoader();
	    waitForLoader();
	    waitForLoader();
	    waitForLoader();
	    waitForLoader();
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");

	    if (isDisplayed(btnUsePostalAddress, objectValue, 10)) {
		clickUsingJavaScript(btnUsePostalAddress, objectValue);
		report.reportPass("Click Use Postal Address in Billing Info", "Use Postal Address should be clicked in Billing Info", "Use Postal Address is clicked in Billing Info");
		waitForLoader();
	    }
	    else if (isDisplayed(btnUseSameAddress, objectValue, 2)){
	    	clickUsingJavaScript(btnUseSameAddress, objectValue);
			report.reportPass("Click Use Same Address in Billing Info", "Use Same Address should be clicked in Billing Info", "Use Same Address is clicked in Billing Info");
			waitForLoader();
	    }
		else if (isDisplayed(proceed, objectValue, 2)){
	    	clickUsingJavaScript(proceed, objectValue);
			report.reportPass("Click Use Same Address in Billing Info", "Use Same Address should be clicked in Billing Info", "Use Same Address is clicked in Billing Info");
			waitForLoader();
	    }
	    
	 // Latest Added on 06/23/2017 by Gopal
	    switchToDefaultcontent();
	    
	    if (isDisplayed(rdbtnUsePostalAddress, objectValue, 3))
	    {
	    	clickUsingJavaScript(btnproceed, objectValue);
			waitForLoader();
	    }			    
	    waitForLoader();
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    if(get("ChangeBillingAddress").equalsIgnoreCase("Yes")){
	    	String strDOBMonth = get("BillingCreditDOM").trim();
	    	String strDOBDate = get("BillingCreditDOB").trim();
	    	String strDOBYear = get("BillingCreditDOY").trim();
	    	String FirstName=get("BillingFirstName");
		    String LastName=get("BillingLastName");
	    	  waitForLoader();
	    	  switchToDefaultcontent();
			    switchToFrame("IfProducts");

			    switchToFrame("PopupIFrame");
	    	//  if(!FirstName.isEmpty() && (!LastName.isEmpty())){
	    	  if(isDisplayed(rbtnCreditCheckNo, LastName, 1)){
			   clickUsingJavaScript(rbtnCreditCheckNo, objectValue);
			   waitForLoader();
			   
			// Select DOB Month
			    selectDropDownUsingVisibleText(lstDOBMonth, objectValue, strDOBMonth);

			    // Select DOB Date
			    selectDropDownUsingVisibleText(lstDOBDate, objectValue, strDOBDate);

			    // Select DOB Year
			    setText(txtDOBYear, objectValue, strDOBYear);
			    report.reportPass(strDescription + getUrl, strExpected, strActual);
			    clickUsingJavaScript(btnVerifyCredit, objectValue);
			    waitForLoader();
			    //Added for closing deposit window -- Prakash -- 2/2/19
			    if (isDisplayed(popupClose))
			    {
			    	clickUsingJavaScript(popupClose,objectValue);
			    	waitForLoader();
			    }
	    }
			   
	    	 // }

		   }
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    if(!get("ChangeType").equalsIgnoreCase("Change Billing Name and Address")){	
	    if(!isNotDisplayed(activeBillingInfoTab, pageTimeoutInSeconds)){
		
		    strFailed = "Failed in Billing info page, Due date page was not displayed post clicking save and continue in billing info page.";
		    report.reportFail("Verify billing page not displayed", "Billing info page should not be displayed post clicking save and continue in billing info page.", "Billling info page was displayed.");
			report.updateMainReport("comments", strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			logger.error(strFailed);
			captureErrorMsg(strFailed);
			throw new UserDefinedException(strFailed);			
	    }
	    }
		 
	    }
	} catch (Exception exe) {
		if (!isUserDefinedException(exe)) {
			report.reportFail(strDescription + getUrl, strExpected, strFailed);
			report.updateMainReport("ErrorMessage", strFailed);
			captureErrorMsg("Failed in Billing Info Page");
		    }
		    throw exe;
	    
	}
	
	if (get("FlowType").equalsIgnoreCase("Change") && (get("ChangeType").equalsIgnoreCase("StackDisconnect") || get("ChangeType").equalsIgnoreCase("PartialDisconnect"))) {
	    if(isDisplayed(DisconnectTab, objectValue, 3)){
	    	clickUsingJavaScript(DisSaveNdContinue, objectValue);

	    	report.reportPass("Click Save And Continue in Disconnect Tab", "Save And Continue Should be Clicked" ,"Save And Continue is Clicked in Disconnect Tab");
	    	waitForLoader();
	    }
	}
	
	
	if ((get("FlowType").toLowerCase().contains("move")) || get("FlowType").equalsIgnoreCase("Change") && (get("ChangeType").equalsIgnoreCase("ChangeAddress"))){ //Anu added OR condition
	    DisconnectOrder();
	}

    }

    protected void DisconnectOrder() throws Exception {

	String strDescription = "", strExpected = "", strActual = "", strFailed = "";

	try {
	    waitForLoader();
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");

	    if (DisconnectHeaderTextList.size() > 0) {

		waitForLoader();
		// Give disconnect info
		strDescription = "Selecting the disconnect categroy and reason in disconnect page";
		strExpected = "Disconnect page should be navigated sucessfully";
		strActual = "Disconnect page was navigated sucessfully";
		strFailed = "Disconnect page navigation was not successful";
		getUrl = ", URL Launched --> " + returnURL();

		String Disconnect_Category = get("DisconnectCategory");
		String Dis_Reason = get("DisconnectReason");

		String eqp = DisconnectHeaderText.getText();
		System.out.println(eqp);

		if (!Disconnect_Category.isEmpty()) {
		    try {

			selectDropDownUsingVisibleText(Disconnectcat, objectValue, Disconnect_Category);
			waitForLoader();
		    } catch (Exception exe) {
			throw exe;
		    }
		}

		if (!Dis_Reason.isEmpty()) {
		    try {

			selectDropDownUsingVisibleText(Disconnectreason, objectValue, Dis_Reason);
			waitForLoader();

		    }

		    catch (Exception exe) {
			throw exe;
		    }
		}

		// Clicking on Save And Continue button
		clickUsingJavaScript(DisSaveNdContinue, objectValue);

		report.reportPass(strDescription + getUrl, strExpected, strActual);
		waitForLoader();
		pause();
		
		
		   // For move from HSI to FDV Bundle flow by Gopal 07/19/17
		
				strDescription = "Clicking on Preview Button in OPO Page";
				strExpected = "Preview Button Should be clicked Successfully";
				strActual = "Preview Button is clicked Successfully";
				strFailed = "Preview Button is not clicked Successfully";
				getUrl = ", URL Launched --> " + returnURL();
				
				if(isDisplayed(Preview_Order, ""))
				{
					try
					{
						waitForLoader();
						mouseOver(Preview_Order, "");
						clickUsingJavaScript(Preview_Order, "");
						report.reportPass(strDescription + getUrl, strExpected, strActual);
					}
					catch (Exception exe)
					{
						report.reportFail(strDescription + getUrl, strExpected, strFailed);
						throw exe;
					}
				}

				waitForLoader();
				waitForLoader();
				
				strDescription = "Clicking on Checkout Button in OPO Page";
				strExpected = "Checkout Button Should be clicked Successfully";
				strActual = "Checkout Button is clicked Successfully";
				strFailed = "Checkout Button is not clicked Successfully";
				
				
				if(isDisplayed(btncheckout, ""))
				{
					try
					{
						waitForLoader();
						mouseOver(btncheckout, "");
						clickUsingJavaScript(btncheckout, "");
						report.reportPass(strDescription, strExpected, strActual);
					}
					catch (Exception exe)
					{
						report.reportFail(strDescription, strExpected, strFailed);
						throw exe;
					}
				}
				switchToFrame("IfProducts");
			    String classValue = getAttribute(billingInfoTab, "", "class");
			    if (classValue != null && classValue.contains("active")) {
				
			    	pageScroll(btnSaveAndContinue);
					clickUsingJavaScript(btnSaveAndContinue, objectValue);
					report.reportPass("Click Save And Continue in Billing Info", "Save And Continue should be clicked in Billing Info", "Save And Continue is clicked in Billing Info");


				    waitForLoader();

				    switchToDefaultcontent();
				    switchToFrame("IfProducts");

				    if (isDisplayed(btnUsePostalAddress, objectValue, 3)) {
					clickUsingJavaScript(btnUsePostalAddress, objectValue);
					report.reportPass("Click Use Postal Address in Billing Info", "Use Postal Address should be clicked in Billing Info", "Use Postal Address is clicked in Billing Info");
					waitForLoader();	
					waitForLoader();
			    }
				

	    }

	}
	}catch (Exception exe) {
		 if (!isUserDefinedException(exe)) {
				report.reportFail(strDescription + getUrl, strExpected, strFailed);
				 report.updateMainReport("comments", strFailed);
				report.updateMainReport("ErrorMessage", strFailed);
				captureErrorMsg("Failed in Internet section.");
			    }

			    throw exe;  
	}

    }

    /**
     * Verifies Billing info tab is opened or not, if not clicks on it
     * 
     * @author Shiva Kumar Simharaju
     * @throws Exception
     */
    public void verifyBillInfoTab() throws Exception {

	try {
		waitForLoader();
		waitForLoader();
	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
	    String classValue = getAttribute(billingInfoTab, "", "class");
	    if (classValue != null && !classValue.contains("active")) {
		clickUsingJavaScript(billingInfoTab, "");
		waitForLoader();
	    }
	} catch (Exception e) {
	    report.reportFail("Verify billing info Tab.", "Billing info tab should be displayed.", "Billing info tab is not available");
	    report.updateMainReport("ErrorMessage", "Billing info tab is not available");
	    throw e;
	}

    }
    
    public void GUIValidations_ViewDetails() throws Exception
    {
    	

    	if(get("Application").equalsIgnoreCase("C2G")){
    	
    	clickUsingJavaScript(ViewDetailsLinkC2G, "");
    	waitForLoader();
    	waitForLoader();
    	switchToDefaultcontent();
   	    switchToFrame("IfProducts");
   	 
   	 
		 WebElement table=driver.findElement(By.id("ViewDetailsTbl"));
	 	 java.util.List<WebElement> rows=table.findElements(By.tagName("tr"));
	 	 
	 	 String data1=rows.get(0).getText();
	 	
	 	 System.out.println("Row : " +rows.size());
	 	 if (rows.size() > 0)
	 	 {
	 		 report.reportPass("Cart View Details", "There are " +rows.size()+ "product details displayed", "There are product details displayed");
	 		 report.reportPass("Cart View Details", "The details displayed", data1);
	 	 }
	 	// System.out.println("Row : " +data1);
	 	 
	 	 
	 	 String[] words=data1.split("\\n");
	 	 for(String w:words){  
	 		 System.out.println(w);  
	 		 if (w.contains("Upgrade Fee")) {
	    			 report.reportPass("FTV upgrade fee Validation", "FTV upgrade fee Validation displayed",w);
	    			 System.out.println("FTV upgrade fee offer present");
	    		 }
	 		 
	 		 }  
	 	 
	 	clickUsingJavaScript(CartViewDetails_Close, "");
	 	waitForLoader();
	    }
    	else{
    	
    	Set<String> allExistingWindows = driver.getWindowHandles();
    	switchToDefaultcontent();
    	if(isDisplayed(ViewDetailsLink, objectValue, 3)){
    		clickUsingJavaScript(ViewDetailsLink, "");
    		waitForLoader();
        	waitForLoader();
        	switchToDefaultcontent();
        	 switchToFrame("IfProducts");
        	 try {
        			if (isDisplayed(CartViewDetails)) {
        			    report.reportPass("Cart View Details", "Cart View Details displayed", "Cart View Details  displayed");
        			}
        		    } catch (Exception e) {
        			report.reportFail("Cart View Details", "Cart View Details not displayed", "Cart View Details not displayed");
        		  }


    	    String productsWindow = driver.getWindowHandle();
    	    Set<String> allWindows = driver.getWindowHandles();
    	    	
    	    	
        	/*for (String Child_Window : allWindows) {
        		System.out.println(driver.getTitle());
        	    if (!allExistingWindows.contains(Child_Window)) {
        	    	
        		driver.switchTo().window(Child_Window);
        		
        		waitForLoader();
        		break;
        	    }
        	} */
        	System.out.println(driver.getTitle());
        	waitForLoader();
        	try{
        	switchToDefaultcontent();
        	 switchToFrame("IfProducts");
        	 WebElement table=driver.findElement(By.id("ViewDetailsTbl"));
        	 java.util.List<WebElement> rows=table.findElements(By.tagName("tr"));
        	 
        	 String data1=rows.get(0).getText();
        	
        	 System.out.println("Row : " +rows.size());
        	 if (rows.size() > 0)
        	 {
        		 report.reportPass("Cart View Details", "There are " +rows.size()+ "product details displayed", "There are product details displayed");
        		 report.reportPass("Cart View Details", "The details displayed", data1);
        	 }
        	// System.out.println("Row : " +data1);
        	 
        	 
        	 String[] words=data1.split("\\n");
        	 for(String w:words){  
        		 System.out.println(w);  
        		 if (w.contains("Upgrade Fee")) {
           			 report.reportPass("FTV upgrade fee Validation", "FTV upgrade fee Validation displayed",w);
           			 System.out.println("FTV upgrade fee offer present");
           		 }
        		 
        		 }  
        	 

    	    clickUsingJavaScript(CartViewDetails_Close, "");
    	    } catch(Exception e) {
    			report.reportFail("Cart View Details", "There are no product details  displayed", "There are no product details displayed");
    		  }
    	}
    	else{
    		switchToFrame("IfProducts");
    		System.out.println("Switched Frame");
    		if(isDisplayed(ViewDetailsLink2, objectValue, 3)){
    			clickUsingJavaScript(ViewDetailsLink2, "");
        	
    		
    	
    	waitForLoader();
    	waitForLoader();
    	switchToDefaultcontent();
    	 switchToFrame("IfProducts");
    	 try {
    			if (isDisplayed(CartViewDetails)) {
    			    report.reportPass("Cart View Details", "Cart View Details displayed", "Cart View Details  displayed");
    			}
    		    } catch (Exception e) {
    			report.reportFail("Cart View Details", "Cart View Details not displayed", "Cart View Details not displayed");
    		  }


	    String productsWindow = driver.getWindowHandle();
	    Set<String> allWindows = driver.getWindowHandles();
	    	
	    	
    	/*for (String Child_Window : allWindows) {
    		System.out.println(driver.getTitle());
    	    if (!allExistingWindows.contains(Child_Window)) {
    	    	
    		driver.switchTo().window(Child_Window);
    		
    		waitForLoader();
    		break;
    	    }
    	} */
    	System.out.println(driver.getTitle());
    	waitForLoader();
    	try{
    	switchToDefaultcontent();
    	 switchToFrame("IfProducts");
    	 WebElement table=driver.findElement(By.id("ViewDetailsTbl"));
    	 java.util.List<WebElement> rows=table.findElements(By.tagName("tr"));
    	 
    	 String data1=rows.get(0).getText();
    	
    	 System.out.println("Row : " +rows.size());
    	 if (rows.size() > 0)
    	 {
    		 report.reportPass("Cart View Details", "There are " +rows.size()+ "product details displayed", "There are product details displayed");
    		 report.reportPass("Cart View Details", "The details displayed", data1);
    	 }
    	// System.out.println("Row : " +data1);
    	 
    	 
    	 String[] words=data1.split("\\n");
    	 for(String w:words){  
    		 System.out.println(w);  
    		 if (w.contains("Upgrade Fee")) {
       			 report.reportPass("FTV upgrade fee Validation", "FTV upgrade fee Validation displayed",w);
       			 System.out.println("FTV upgrade fee offer present");
       		 }
    		 
    		 }  
    	 

	    clickUsingJavaScript(CartViewDetails_Close, "");
	    } catch(Exception e) {
			report.reportFail("Cart View Details", "There are no product details  displayed", "There are no product details displayed");
		  }
    		}
    	}
	    	}
	    } 
    

    /**
     * Save and continue in partial disconnect order flow
     * 
     * @author Rashmi
     * @throws Exception
     */
    public void PartialDisSaveandcontinue() throws Exception {

	    switchToDefaultcontent();
	    switchToFrame("IfProducts");
		try{
   			clickUsingJavaScript(btnFiosSaveContinue, objectValue);      			
   			report.reportPass("Click Save And Continue In Disconnect", "Click Save And Continue In Disconnect if Exists", "Click Save And Continue In Disconnect");
   			waitForLoader();
   			}
   			catch(Exception exe){
					 report.reportFail("Click Save And Continue Button", "Click Save And Continue Button if Exists", "Not able to Click Save And Continue Button due to Object not displayed");
	     		    report.updateMainReport("ErrorMessage", "Not able to click Click Save And Continue Button due to Object not displayed");
  	     		    throw exe;
  	
  		}

    }


    /**
     * Description : Check NY munipal charges
     * 
     * @author karthik arumugam
     * @Team   Cofee -SIT
     */  
    

public void CheckNYMunicipalSurcharge() throws Exception {
       
 
       
       
              if((!get("InternetSpeed").trim().isEmpty()) || (!get("PSTN_Package").trim().isEmpty()))
              {
                        System.out.println("Copper Account - HSIFlow");
                        if(!(isDisplayed(HSIViewDetails, objectValue)))
                        {
                              clickUsingJavaScript(Expand_ShoppingCart, "");
                              System.out.println("Shopping Cart Expanded");
                              
                        }
                      
                        waitForLoader();
                        clickUsingJavaScript(HSIViewDetails, "");
                              report.reportPass("View Details Link.", "Click on View Details Link.", "Clicked on View Details Link.");
                              waitForLoader();
                              
                              if (isDisplayed(VZHSI, objectValue))
                               {
                                    if (isDisplayed(NYMunicipalHSI, objectValue) && (isDisplayed(NYMunicipalHSIAdded, objectValue) || isDisplayed(NYMunicipalHSIOnProfile, objectValue) ))
                                      {
                                            pageScroll(NYMunicipalHSI);
                                            report.reportPass("NY Municipal Surcharge in View Details", "NY Municipal Surcharge should be in HSI Section.", "NY Municipal Surcharge got Added/On Profile in HSI Section.");
                                            clickUsingJavaScript(ViewDetails_Close, "");
                                      }
                                     else
                                     {
                                            pageScroll(NYMunicipalHSI);  
                                            report.reportFail("NY Municipal Surcharge in View Details", "NY Municipal Surcharge should be in HSI Section.", "NY Municipal Surcharge not Added/On Profile in HSI Section.");
                                            clickUsingJavaScript(ViewDetails_Close, "");
                                     }
                               }
                              
                              
              }
              else
              {      
                     try {
                        System.out.println("Fios Account / Order Flow");
                        switchToDefaultcontent();
                        clickUsingJavaScript(ViewDetails, "");
                              report.reportPass("View Details Link.", "Click on View Details Link.", "Clicked on View Details Link.");
                              waitForLoader();
                              switchToDefaultcontent();
                        switchToFrame("IfProducts");
                     
                              if (isDisplayed(VZFiOSConsumerInternetPlan, objectValue))
                               {
                                     if (isDisplayed(NYMunicipalData, objectValue) && (isDisplayed(NYMunicipalDataAdded, objectValue) || isDisplayed(NYMunicipalDataOnProfile, objectValue) ))
                                      {
                                            pageScroll(NYMunicipalData);
                                            report.reportPass("NY Municipal Surcharge in View Details", "NY Municipal Surcharge should be in Data Section.", "NY Municipal Surcharge got Added/On Profile in Data Section.");
                                            clickUsingJavaScript(ViewDetails_Close, "");
                                      }
                                     else
                                     {
                                            pageScroll(NYMunicipalData);
                                            report.reportFail("NY Municipal Surcharge in View Details", "NY Municipal Surcharge should be in Data Section.", "NY Municipal Surcharge not Added/On Profile in Data Section.");
                                            clickUsingJavaScript(ViewDetails_Close, "");
                                     }
                               }
                              else if (isDisplayed(VZFiOSDigitalVoice, objectValue))
                                    {
                                     
                                         if (isDisplayed(NYMunicipalVoice, objectValue) && (isDisplayed(NYMunicipalVoiceAdded, objectValue) || isDisplayed(NYMunicipalVoiceOnProfile, objectValue)))
                                             {
                                            pageScroll(NYMunicipalVoice);
                                            report.reportPass("NY Municipal Surcharge in View Details", "NY Municipal Surcharge should be in FDV Section.", "NY Municipal Surcharge got Added/On Profile in FDV Section.");
                                                   clickUsingJavaScript(ViewDetails_Close, "");
                                         
                                             }
                                         else
                                             {
                                            pageScroll(NYMunicipalVoice);
                                            report.reportFail("NY Municipal Surcharge in View Details", "NY Municipal Surcharge should be in FDV Section.", "NY Municipal Surcharge not Added/On Profile in FDV Section.");
                                                   clickUsingJavaScript(ViewDetails_Close, "");
                                             }
                                    }
                     
                                   else if (isDisplayed(VZFiOSTV, objectValue))
                                         {
                                              if (isDisplayed(NYMunicipalTv, objectValue) && (isDisplayed(NYMunicipalTvAdded, objectValue) || isDisplayed(NYMunicipalTvOnProfile, objectValue)))
                                                   {
                                                 pageScroll(NYMunicipalTv);
                                                 report.reportFail("NY Municipal Surcharge in View Details", "NY Municipal Surcharge not applicable for Tv only Account/Order.", "NY Municipal Surcharge not applicable for Tv only account/order, but got Added/On Profile.");
                                                 clickUsingJavaScript(ViewDetails_Close, "");
                                         
                                                   }
                                               else
                                                   {
                                                 pageScroll(NYMunicipalTv);
                                                 report.reportPass("NY Municipal Surcharge in View Details", "NY Municipal Surcharge will apply only when Data and/or FDV on the Account/Order.", "NY Municipal Surcharge not applied.");
                                                 clickUsingJavaScript(ViewDetails_Close, "");
                                                        
                                                   }
                                         }
                              
                     
                  } catch (Exception exe) {
                     throw exe;
                  }
              }
       
 
    
  }  

}
