package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_PSTNBundle_PageObjects class represent the Page Object class.
 * This contains all the identifier for Simplex ProductAndServices Page
 */

public class Simplex_PSTNBundle_PageObjects extends CommonPage {

    /**
     * Simplex_ProductAndServices_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *            represents data input
     */
    public Simplex_PSTNBundle_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }

  //PSTN
    
    @FindBy(xpath = "//table[@id='chkCustomPSTNLec']//label[contains(text(),'<<<>>>')]/preceding-sibling::input")
    protected Element freedomEssentialchkbx;
    
  
    
    @FindBy(xpath = "//*[@id = 'chkCustomData']//label[contains(text(), '<<<>>>')]")
    protected Element internetspeedchkbx;
    
    @FindBy(xpath = "//input[@id='chkCustomDataSelectAll'and @type='checkbox']")
    protected Element internetspeedallchkbx;
  
    @FindBy(xpath = "//*[@id = 'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_btnCustFilterBundles']")
    protected Element btnDispbundnOffrs;
    
    @FindBy(xpath = "//input[@type='submit' and @value='Add Bundle']")
    protected Element btnBundle;
    
    //@FindBy(xpath = "(//tr[contains(@id,'Bundle_trbundle')]//span[contains(@class,'best')]//ancestor::tr[contains(@id,'BundleRow')]/following-sibling::tr)[1]//label[contains(text(),'No Verizon Contract')]/preceding-sibling::input")
    @FindBy(xpath = "(//label[contains(text(),'No Verizon Contract')])[1]/preceding::input[1]")
    protected Element radbtnNoContract;
    
    @FindBy(xpath = "//input[@value='rbtZoneRow']")
    protected Element radbtnCoreBundle;
    
    @FindBy(xpath = "//input[@value='rbtBundlesProductName']")
    protected Element radbtnCoreBundleLabel;
    
    //****************************************************************************************
    //updatded by poovaraj on 14 Mar 2017
    //****************************************************************************************
    	
    @FindBy(xpath = "//label[contains(text(),'Regional Essentials')]/preceding::input[1]")
    protected Element chkRegionalEssentialchkbx;
    
    @FindBy(xpath = "//input[@id='ProceedAsStandAlone']")
    protected Element btnSkipBundle;
    
    //****************************************************************************************
    
}