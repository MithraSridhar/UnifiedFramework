package com.automation.pageobjects;


import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

public class Simplex_EquipmentReturn_PageObjects extends CommonPage{
	
	
	public Simplex_EquipmentReturn_PageObjects(WebDriver driver, boolean windows,ReportStatus report, HashMap<String, String> data) {
		super(driver, windows,report, data);
	}

	@FindBy(xpath = "//input[@id='radCustomerDropoff']")
	protected Element rdDropOff;
	
	@FindBy(xpath = "//input[@id='radCurrentServiceAddress']")
	protected Element rdCurrentAddress;
	
	@FindBy(xpath = "//input[@id='radNewServiceAddress']")
	protected Element rdNewServiceAddress;
	@FindBy(xpath = "//input[@id='radBillingAddress']")
	protected Element rdBillingAddress;
	@FindBy(xpath = "//input[@id='btnCLECSavecont']")
	protected Element EquipSaveNdContinue;
	
	@FindBy(xpath = "//li[@id='checkouttabs']")
	protected Element EquipReturnHeaderText;
	
	@FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ddlReturnType']")
	protected Element DrpdwnreasonReturnType;
	
	@FindBy(xpath = "//ul[@id='tabLinks']/li[@id='checkouttabs']/div/a[contains(@url,'EquipmentReturn')]")
	protected Element ShippingReturnTab;
	
	@FindBy(xpath = "//label[@for='rdoShipmentSuggestedAddress']")
	protected Element rdbtnSuggestedAddress;
	
	
	@FindBy(xpath = "//*[@for = 'radCustomerDropoff']")
	protected Element rdDropOffC2G;
	
	@FindBy(xpath = "//input[@id='txtDropOffEmailSearch']")
	protected Element DropOff_EmailSearch_txtbox;
	
	@FindBy(xpath = "//input[@id='lnkEmailLocToCustSearch']")
	protected Element DropOff_EmailSearch_btn;
	
	@FindBy(xpath = "//label[contains(text(),'Email Sent Successfully!')]")
	protected Element DropOff_Email_success_msg;
	

}
