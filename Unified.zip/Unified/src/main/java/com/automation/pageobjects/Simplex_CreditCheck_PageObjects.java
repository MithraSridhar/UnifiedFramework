package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_CreditCheck_Objects class represent the Page Object class. This
 * contains all the identifier for Simplex CreditCheck Page
 */
public class Simplex_CreditCheck_PageObjects extends CommonPage {

    /**
     * Simplex_CreditCheck_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *            represents data input
     */
    public Simplex_CreditCheck_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }

    @FindBy(xpath = "//iframe[@id='PopupIFrame']")
    protected Element frameCredit;

    @FindBy(xpath = "//input[@id='radCreditHistoryNo']")
    protected Element rbtnCreditCheckNo;
    
    @FindBy(xpath = "//label[@for='chkPriceQuoteCreditCheck']")
    protected Element chkboxpricequote;
    
    @FindBy(xpath = "//*[@id = 'btnCreateNewAccount']")
    protected Element CreateNewAccount;

    @FindBy(xpath = "//input[@id='ucCreditEntry_ucResponsiblePartyEntry_txtFirstName']")
    protected Element txtFirstName;

    @FindBy(xpath = "//input[@id='ucCreditEntry_ucResponsiblePartyEntry_txtLastName']")
    protected Element txtLastName;

    @FindBy(xpath = "//input[@id='ucCreditEntry_ucResponsiblePartyEntry_txtSSN']")
    protected Element txtSSN;

    @FindBy(xpath = "//input[@id='ucCreditEntry_ucResponsiblePartyEntry_txtConfirmSSN']")
    protected Element cnftxtSSN;

    @FindBy(xpath = "//*[@id='btnPerformCredit']")
    protected Element btnVerifyCredit;
    // Failed credit check
    @FindBy(xpath = ".//*[@id='divCreditVerifyEditMessage']/b[contains(text(),'credit verification has failed.')]")
    protected Element btnVerifyCreditErrMsg;

    @FindBy(xpath = ".//*[@id='btnClose']")
    protected Element btnClose;
	
	@FindBy(xpath = "//*[@id='btnVZCancel']")
    protected Element btncancel;

    @FindBy(xpath = "//label[@for='chkdisclaimer']")
    protected Element creditchkBox;

    @FindBy(xpath = "//input[@onclick='CBforCreateQuote();']/following-sibling::label")
    protected Element creditcheckdisclaimer;
    
    @FindBy(xpath = "//select[@id='ucCreditEntry_ucResponsiblePartyEntry_ddlDOBMonth' or @id='ddlDOBMonth']")
    protected Element lstDOBMonth;

    @FindBy(xpath = "//select[@id='ucCreditEntry_ucResponsiblePartyEntry_ddlDOBDate' or @id='ddlDOBDate']")
    protected Element lstDOBDate;

    @FindBy(xpath = "//input[@id='ucCreditEntry_ucResponsiblePartyEntry_txtDOBYear' or @id='txtDOBYear']")
    protected Element txtDOBYear;

    
    //*****************UI Validations ---gopal************************
    
	@FindBy(xpath = "//*[@id = 'btnClose']")
	protected Element Btn_Cancel_Credit;

	@FindBy(xpath = "//*[@id = 'btnYesCancelPopup' and contains(@type, 'submit' )]")
	protected Element Cancel_Credit_Yes;
	@FindBy(xpath = ".//*[@id='ucCreditVerify_lblCreditWorthiness']")
    protected Element lblVerifyCreditErrMsg;
	
	@FindBy(xpath = "//a[@id='CreditVerification']")
    protected Element verifyCredit;
	
	@FindBy(xpath = "//*[@id='divContentCreditPopup']//label[@for = 'chkdisclaimer']")
	protected Element c2ghsicreditchkBox;
	
	@FindBy(xpath = "//*[@id='DisclaimerforCreateQuote']//label[@for = 'CheckBox1']")
	protected Element c2gfdvcreditchkBox;
	
}
