package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

public class Simplex_CollectDeposit_PageObjects extends CommonPage {
	

	public Simplex_CollectDeposit_PageObjects(WebDriver driver, boolean windows,ReportStatus report, HashMap<String, String> data) {
		super(driver, windows,report, data);
	}
	
	
	@FindBy(xpath = "//div[@id='colapp1']")
	protected Element collectDepositTab;
	
	@FindBy(xpath = "//input[@id='btnCollectDeposit' and @value='Collect Deposit']")
	protected Element collectDepositBtn;
	
	@FindBy(xpath = "//*[@id='ddlPObpInfocovCardType']")
	protected Element CreditCardType;
		
	@FindBy(xpath = "//input[@id='txtPObpInfocovNumber']")
	protected Element CreditCardNum;
	
	@FindBy(xpath = "//input[@id='txtPObpInfocovCCNumber']")
	protected Element CreditCardConNum;
	
	@FindBy(xpath = "//input[@id='txtPObpInfocovSecurityCode']")
	protected Element CCSecurityCode;
	
	@FindBy(xpath = "//input[@value='Save']")
	protected Element ColDepoSaveBtn;
	
	@FindBy(xpath = "//a[@id='btnSaveContinue']")
	protected Element btnSaveContinue;
	
	@FindBy(xpath = "//a[@id='btnCancelOrder']")
	protected Element btnCancelOrder;
	
	@FindBy(xpath = "//input[@id='btnCustAlertCancel']")
	protected Element alretOrdCancelBtn;
	
	@FindBy(id = "txtWindowsUserID")
	protected Element vepsUserID;
	
	@FindBy(id = "txtWindowsPwd")
	protected Element vepsPwd;
	
	@FindBy(xpath = "//*[@id = 'ddlCCMonth']")
	protected Element expiryMonth;

	
	@FindBy(id = "Login")
	protected Element vepsLoginBtn;
	
	@FindBy(id = "lnkMsgClickHere")
	protected Element msgLinkClickHere;
	
	@FindBy(id = "chkOPOConfMsg")
	protected Element vepsConfirm;
	
	@FindBy(id = "pwdCC")
	protected Element cardNo;
	
	@FindBy(id = "txtCVV2")
	protected Element cvv2No;
	
	@FindBy(id = "ddlCCYear")
	protected Element expiryYear;
	
	@FindBy(id = "btnProcess")
	protected Element proceedButton;
	
	@FindBy(id = "//*[contains(text(),'Please wait while we process your request...')]")
	protected Element vepsLoader;
	
	@FindBy(xpath = "//input[@id='btnReturn']")
	protected Element saveAndContinue;
	
	@FindBy(xpath = "//label[@for='chkOPOConfMsg']")
	protected Element chxconfirm;
	
	@FindBy(xpath = "//select[@id='ddlPObpInfocovCardExYr']")
	protected Element expyear;
	@FindBy(xpath = "//select[@id='ddlPObpInfocovCardExMonth']")
	protected Element expmonth;
	
	@FindBy(xpath = "//input[@id='OK' and contains(@onclick,'hide')]")
	protected Element OkPopup;
	
	@FindBy(xpath = "//a[@id='LinkButton1']")
	protected Element confirmCancel;
	
	@FindBy(xpath = "//label[@id='lblOPOConfMsg']")
	protected Element DepositConfirm;
	
}
