package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

public class Simplex_Ownership_PageObjects extends CommonPage {
	
	/**
     * Simplex_BillingInfo_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *            represents data input
     */
    public Simplex_Ownership_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }

    
    @FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$ucSupersedureSelection$gnCustomerSelection']")
    protected Element rbtnIncomingOutgoingCustomer;
    @FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$ucSupersedureSelection$txtFiOSOutgoingCallingPartyName']")
    protected Element txtOutgoingcallingparty;
    @FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$ucSupersedureSelection$txtFiOSIncomingCallingPartyName']")
    protected Element txtIncomingcallingparty;
    @FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$ucSupersedureSelection$btnContinue']")
    protected Element btnContinue;
    @FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$ucSupersedureSelection$gnScript']")
    protected Element rbtnYes;
    @FindBy(xpath = "//a[@id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_btnSaveAndContinue']")
    protected Element btnSaveAndContinue;
    
    @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_btnUsePostalAddress']")
    protected Element btnPostalAddress;

	@FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$CustomerContactInformation$txtMobileNumber']")
	protected Element enterMTN;

	@FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$CustomerContactInformation$txtEmail']")
	protected Element enterEmail;

	@FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$CustomerContactInformation$txtAltTelephone']")
	protected Element enterATN;
	
	 @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_btnInvalidUseSameAddress']")
	    protected Element btnUseSameAddress;
    
  	// @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_btnPostalUseSameAddress']")
	  //  protected Element btnUseSameAddress;  
    
    
    
    
    
    
    
    

}
