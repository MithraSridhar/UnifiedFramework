package com.automation.pageobjects;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_CallingFrom_PageObjects class represent the Page Object class. This
 * contains all the identifier for Simplex Calling from Page
 */
public class Simplex_AR_PageObjects extends CommonPage {

    /**
     * Simplex_CallingFrom_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *            represents data input
     */
    public Simplex_AR_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }

   
    //customer info section
    
    @FindBy(xpath = "//input[@id='CallingPartyName']")
    protected Element labelHeaderCallingPartyNew;
    
    @FindBy(xpath = "//*[@ng-attr-title='{{custName}}']")
    protected Element labelHeaderCustomerNameNew;
    
    @FindBy(xpath = "//div[@class='customer-address']/span[3]")
    protected Element labelHeaderEmailNew;
  
    @FindBy(xpath = "//div[@class='customer-address']/span[1]")
    protected Element labelHeaderAddressLine1New;
    
    @FindBy(xpath = "//div[@class='customer-address']/span[2]")
    protected Element labelHeaderAddressLine2New;
    
    //account info section
    
    @FindBy(xpath = "//div/span[contains(@class,'customer-details') and contains(text(),'<<<>>>')]/following-sibling::*[1]")
    protected Element CustomerDetails;
    
   
    //active service section
    
    @FindBy(xpath = "//div[@ng-if='isShowCustomerInfo']//div[contains(@ng-if,'bundleData')]/div")
    protected Element BundleType_Header;
    
    @FindBy(xpath = "//div[@ng-if='isShowCustomerInfo']//ul//span[@title]")
    protected CList<Element> ExistingServices_List;

    
    @FindBy(xpath="//div[@class='customer-agreement']//child::span")
	protected CList<Element> CustomerAgreementDetail;

    @FindBy(xpath = "//*[@ng-if='showCustomerTenure']")
    protected Element LoyaltyYears;

   @FindBy(xpath = "//*[contains(text(),'Term agreement ends on :')]/following-sibling::span")
    protected Element ContractTerm;
   
    //snap shot section
    @FindBy(xpath = "//div[@data-ui-view='connectionsView']//div[contains(@ng-if,'temperature')]/div[1]/div[2]//div[@class='row'][3]/span[1]")
    protected Element Connections_Area;
    
    @FindBy(xpath = "//div[@data-ui-view='connectionsView']//div[contains(@ng-if,'techInstall')]//*[contains(text(),'Tech')]")
    protected Element Connections_TechnicianNeed;

    
    @FindBy(xpath = "//div[@data-ui-view='connectionsView']//div[contains(@ng-if,'techInstall')]//*[contains(text(),'Tech')]/following-sibling::*")
    protected Element Connections_TechnicianNeedCondition;

    @FindBy(xpath = "//div[@ng-if='!salesOpportunity.TitleValue']/child::span")
    protected CList<Element> SalesOppurtunities_Contents;

	
	//Header ICON section

    //final account    
    @FindBy(xpath = "//span[contains(.,'FINAL ACCOUNT')  and contains(@class,'cust-acc-status')]")
    protected Element FinalAccountindicator;
    
    @FindBy(xpath = "//span[@ng-click='LaunchSafeGuard()']")
     protected Element SafeGaurdLabel;
    
    @FindBy(xpath = "//a[@ng-click='OpenChatWindow()']")
    protected Element OpenChatWindowNew;
  
    @FindBy(xpath = "//span[contains(text(),'Cancel Chat')]")
    protected Element Cancel_ChatWindow;

 
    @FindBy(xpath = "//*[contains(@ng-keyup,'SISearchCtrl')]")
    protected Element SearchTextField_SupportInfoPopUp;

    @FindBy(xpath = "//a[@data-reveal-trigger='myfollowup-toolbar' and contains(@class,'close')]")
    protected Element Cancel_FollowUpWindowNew;
   
    @FindBy(xpath = "//*[@data-open-modal='followups']") //Gopal 0308
    protected Element OpenFollowUpWindowNew;

    @FindBy(xpath = "//div[contains(text(),'<<<>>>')]/preceding-sibling::a")   //Gopal 0308
    protected Element HeaderIcon_Dynamic;


    
    
    @FindBy(xpath = "//*[contains(@class,'vzicon icon-close') and @ng-click='SISearchCtrl.hideSISearch()']")
    protected Element CloseButton_SupportInfoPopUp;
  
    @FindBy(xpath = "//textarea[@id='CallNotes']")
    protected Element TextAreaRead_CallNotesPopUp;
    
    @FindBy(xpath = "//textarea[@id='CallNotes']")
    protected Element TextArea_CallNotesPopUp;
 
    @FindBy(xpath = "//a[contains(text(),'Call Notes')]/ancestor::*[contains(@class,'row')]//*[@data-reveal-trigger = 'mynote1' and contains(@class, 'vzicon icon')]")  //Gopal 0308
    protected Element CloseButton_CallNotesPopUp;
    
    
    @FindBy(xpath = "//*[@title='More Options']")
    protected Element DrpdwnMoreopt;
	
    @FindBy(xpath = "//a[contains(@class,'active')and (contains(text(),'Quick Links'))]")
    protected Element lnkquick;
    

    @FindBy(xpath = "//li[contains(@class,'tabs_tab')and (contains(@data-tab,'Most Used'))]")
    protected Element tabMostused;
    
    @FindBy(xpath = "//li[contains(@class,'tabs_tab')and (contains(@data-tab,'Ticket Entry'))]")
    protected Element tabfrequentused;
    
   // @FindBy(xpath = "//a[contains(text(),'<<<>>>')]")
    //@FindBy(xpath = "//div[@class='modal_content quicklinks-modal-cont padding-all-zero']//a[contains(text(),'<<<>>>')]")
    @FindBy(xpath = "//div[@class='quick-links_inner']//a[contains(text(),'<<<>>>')]")
    protected Element mlnks;
    
    @FindBy(xpath = "//button[@data-ng-click='getViewList()']")
    protected Element mlogbook;
    
    @FindBy(xpath = "//a[@data-ng-click='closeLogBookPopup();']")
    protected Element mlogbookpopup;
    
    @FindBy(xpath = "//a[@class='text-normal ng-scope active-other' and contains(text(),'Issues')]")
    protected Element quickissues;
    
    @FindBy(xpath = "//div[@data-ui-view='connectionsView']//div[contains(@class,'snapshot')]/span[@aria-hidden='true']")
    protected Element ConnectionsFlag;
    
    @FindBy(xpath = "//div[@data-reveal-trigger='DashboardConnections']")
    protected Element ConnectionsPage;
    
    @FindBy(xpath = "//ul[@class='w_snapshot-envelope active']")
    protected Element SnapshotIcon;
    
    @FindBy(xpath = "//div[@data-tile-title='salesopp']/span[@aria-hidden='true']")
    protected Element SalesOpportunitiesFlag;
  
    @FindBy(xpath = "//div[not(contains(@class,'hide')) and @ng-hide='IsAutoCallnotesElgibleAgent']/a[@data-reveal-trigger='mynote1']")   //Gopal 0308
    protected Element clickCallNotes;
}
