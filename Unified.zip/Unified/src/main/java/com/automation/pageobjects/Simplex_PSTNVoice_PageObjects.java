package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_PSTNVoice_PageObjects class represent the Page Object class.
 * This contains all the identifier for Simplex ProductAndServices Page
 */

public class Simplex_PSTNVoice_PageObjects extends CommonPage {

    /**
     * Simplex_PSTNVoice_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *            represents data input
     */
    public Simplex_PSTNVoice_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }

  //LEC
    
 // LEC Page
    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_linesAndTnSection_ctl00_ddlNumberOfLines")
    protected Element NoOfLines;
    

@FindBy(xpath = "//td[contains(text(),'<<<>>>')]//preceding-sibling::td//input")
    protected Element ChkBoxUnderFeatures;

    @FindBy(xpath = "//div[@class='formValue']//select//option[contains(@value,'<<<>>>')]")
    protected Element NoCharge;

    @FindBy(xpath = "//label[not(contains(@class,'c_on')) and @for='ctl08_NO_Jack'] | //*[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_NO_Jacks']")
    protected Element ChkbxLECNoJacks;

    @FindBy(xpath = ".//*[@id='ctl08_lnkAdd'] | //*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_lnkAdd']")
    protected Element ADDLinkJack;

    @FindBy(xpath = ".//*[@id='ctl08_lnkJackOK'] | //*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_lnkJackOK']")
    protected Element BtnLECJackOk;
    
    @FindBy(xpath = ".//ul[@id='lineTabs']")
    protected CList<Element> NoOfAddlineTab;
    @FindBy(xpath = "//*[@for='ucGeneralSetupSection_NO_WM']")
    protected Element ChkbxLECNoMaintainance;
    @FindBy(xpath = ".//*[@id='ucGeneralSetupSection_lnkOkGN']")
    protected Element linkOkMaintainanceGN;
    
    // Lec VOice section
    @FindBy(xpath = "//*[@id='ContentPlaceHolder1_ContentPlaceHolder1_btnAddNewln']")
    protected Element BtnLECAddNewLine;
    
    @FindBy(xpath = ".//*[@id='dvCongrats']")
    protected Element AddlineTab;

    @FindBy(xpath = "//*[contains(text(),'Maintenance')]//parent::td//parent::tr//td//span/a")
    protected Element LinkLECMaintenanceDetails;

    @FindBy(xpath = "//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")
    protected Element FrameLECPlans;

    @FindBy(xpath = "//div[@id='ucGeneralSetupSection_divgridMaintenance']//td//label[@for='ucGeneralSetupSection_gvMaintenance_radioBtn_0']")
    protected Element maintainanceDrpDown;
    
    @FindBy(xpath = "//div[@id='dvCongrats' and contains(text(),'Congratulations')]")
    protected Element lecPageDisplay;
    
    
    @FindBy(xpath = "//label[@for='chkDisclosure']")
    protected Element chkDisclosure;

    // @FindBy(xpath =
    // "//*[contains(text(),'Jacks')]//parent::td//parent::tr//td//span/a")
    @FindBy(xpath = "//a[contains(@id,'ContentPlaceHolder1_ContentPlaceHolder1_lcwLineInformationUC_FeaturesUC_gvProducts_lnkPopularSetup') and contains(@onclick,'JK')]")
    protected Element jackVoiceLink;

    @FindBy(xpath = "//a[contains(@id,'ContentPlaceHolder1_ContentPlaceHolder1_lcwLineInformationUC_FeaturesUC_gvProducts_lnkPopularSetup') and contains(@onclick,'VM')]")
    protected Element VoiceMailLink;
    
    @FindBy(xpath = ".//*[@id='ContentPlaceHolder1_ContentPlaceHolder1_btnforward']")
    protected Element BtnLECSaveAndCont;

    @FindBy(xpath = "//li[@id='fdvtabs' and contains(@class,'active')]//div//a[contains(text(),'LEC') and contains(@class,'active')]")
    protected Element ActiveVoiceLecTab;

    @FindBy(xpath = "//*[@id='ucGeneralSetupSection_lnkOkGN')]")
    protected Element linkOkMaintainance;

    @FindBy(xpath = "//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")
    protected Element jackVoiceFrame;

    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_setup1']")
    protected Element Maintenance_Plan_Window;

    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucVoiceBatteryBackupSection_setup1']")
    protected Element Voice_Backup_Power_Window;

    @FindBy(xpath = "//*[@class = 'subCollapsiblePanelTab_pantone' and contains(text(), 'Jacks/Fixed Fee')]")
    protected Element Jacks_Window;  
    
    @FindBy(xpath = "//td[contains(text(),'<<<>>>')]/preceding-sibling::td//input")
    protected Element Jacks_Type;  
  
    @FindBy(xpath = "//td[contains(.,'Maintenance')]/following-sibling::td[2]//label[contains(@id, 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucPopularProductsSection_gvProducts_labellnkProducts')]/a")
    protected Element setup_Maintenance_Plan;   
  
    @FindBy(xpath = "//td[contains(.,'Voice Backup')]/following-sibling::td[2]//label[contains(@id, 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucPopularProductsSection_gvProducts_labellnkProducts')]/a")
    protected Element setup_Voice_Backup_Power;
    
    @FindBy(xpath = "//td[contains(.,'Jacks')]/following-sibling::td[2]//label[contains(@id, 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucPopularProductsSection_gvProducts_labellnkProducts')]/a")
    protected Element setup_Jacks;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_lstProducts']//*[contains(text(), '<<<>>>')]")
    protected Element Inside_Wire_Maintainance;
  
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucVoiceBatteryBackupSection_lstVBBProducts']//*[contains(text(),'<<<>>>')]")
    protected Element Battery_options;

    @FindBy(xpath = ".//*[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_lstProducts']/option[3]")    
    protected Element lstNoMainteancePlan;  

    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_dropdownDCP_new']")
    protected Element Domestic_LD_Plan;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_dropdownPIC_new']")
    protected Element Long_Distance_Carrier;





    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_linesAndTnSection_ctl00_lnkCreateLines")
    protected Element BtnGetLines;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_linesAndTnSection_ctl00_lnkNextForTNAssignment")
    protected Element BtnLinesOk;

    @FindBy(xpath = "//input[@type='checkbox']")
    protected Element CheckboxagainstLines;

    @FindBy(xpath = "//span[contains(text(),'Get Details For Selected Line')]")
    protected Element GetDetailsforLines;
    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_dropdownICP_new")
    protected Element DrpIEPlan;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_lnkApply_CPCI")
    protected Element ApplyCallingPlan;
    
    @FindBy(id = "//label[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_label2']//span")
    protected Element ApplyFeaturePlan;
    //label[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_label2']//span



    //@FindBy(xpath = "//div[@class='formValue']//select//option[contains(@value,'<<<>>>')]")
   // protected Element NoCharge;
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_interceptsSection_ctl00_btnOkMain']")
    protected Element InterceptsOk;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_lnkOkGN")
    protected Element MaintenanceOK;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucVoiceBatteryBackupSection_lnkOkVBB")
    protected Element VoiceBkppowerOK;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_NO_Jacks")
    protected Element NoJack;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_lnkJackOK")
    protected Element NoJackOK;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_LinkDirectoryEdit")
    protected Element DLEdit;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UcDirectoryListingSection_txtMainDirLastName")
    protected Element DLLastName;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UcDirectoryListingSection_txtMainDirFirstName")
    protected Element DLFirstName;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UcDirectoryListingSection_lnkDirectoryListingNext")
    protected Element DLOK;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_lnkNextForFeatures")
    protected Element PlanFeaturesOK;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_nRCsSection_ctl00_NRCOKClick")
    protected Element NRCOK;

    @FindBy(id = "ContentPlaceHolder1_FooterContent_btntabUISaveContinue")
    protected Element LECSaveAndContinue;
    
    // ******************************************************************************************************************
    // added by poovaraj
    // ******************************************************************************************************************
    @FindBy(xpath = "(//td[text()='Maintenance Plan']/parent::tr[1]//input[1])[1]")
    protected Element lnkMaintenancePlanCheckBox;
    
    @FindBy(xpath = "(//td[text()='Jacks']/parent::tr[1]//input[1])[1]")
    protected Element lnkJackCheckBox;

    @FindBy(xpath = "//td[text()='Maintenance Plan']/parent::tr[1]//a[1]")
    protected Element lnkMaintenancePlanSetUp;

    @FindBy(xpath = "//td[contains(text(),'Voice Backup')]/parent::tr[1]//a[1]")
    protected Element lnkVoiceBackUpSetUp;
    
    @FindBy(xpath = "//select[@name='ctl08$lstVBBProducts']/option[not(contains(@selected,'selected')) and contains(text(),'<<<>>>')]")
    protected Element ChkbxLECVoiceBackUpplan;

    @FindBy(xpath = "//td[contains(text(),'Jacks')]/parent::tr[1]//a[1]")
    protected Element lnkJackSetUp;
    
    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_lnkOkGN']")
    protected Element lstApplySelectedLines;    

    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucVoiceBatteryBackupSection_lnkOkVBB']")
    protected Element btnVoiceBackUpOK;
    
    @FindBy(xpath = ".//*[@id='gvAvailable']//following-sibling::validatecheckboxforjacksadd//input")
    protected CList<Element> chkBoxesForVoiceJack;

    @FindBy(xpath = "//table[@id='gvAvailable']//following-sibling::tr//td[3]")
    protected CList<Element> valuesForVoiceJack;
    
    @FindBy(xpath = "//select[@name='ucGeneralSetupSection$lstProducts']/option[not(contains(@selected,'selected')) and contains(text(),'<<<>>>')]")
    protected Element ChkbxLECMaintainanceplan;
    
    @FindBy(xpath = "//select[@name='ctl08$lstBoxVMProd']/option[contains(text(),'Mail')]")
    protected Element ChkbxVoiceMail;
    
    @FindBy(xpath = "//input[@name='ctl08$lnkVMSetUpOk']")
    protected Element ChkbxVoiceMailOK;

    @FindBy(xpath = "//input[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_NO_Jacks']")
    protected Element chkNoJackNeedOption;

    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_lnkJackOK']")
    protected Element btnNoJackOptionOK;

    @FindBy(xpath = "//input[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucPopularProductsSection_gvProducts_chkProducts_7']")
    protected Element chkJackOptionInFeatures;

    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_lnkApply']")
    protected Element btnLECFeaturesApply;
   // ******************************************************************************************************************
    
  //******************************************************************************************************************
    // added by poovaraj  13 Mar 2017
    //******************************************************************************************************************
    @FindBy(xpath = "//select[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_lstProducts']/option[2]")    
    protected Element lstInsideWireMaintenance;   
    
    @FindBy(xpath = "//select[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucVoiceBatteryBackupSection_lstVBBProducts']/option[2]")
    protected Element lstVoiceBackUpSetUpOptions;
    
  
    //******************************************************************************************************************
    
    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_lcwLineInformationUC_lnkEditDirectory']")
    protected Element btnDirectoryListing;
    @FindBy(xpath = "//input[@id='ctl08_txtFirstName']")
    protected Element firstname;
    @FindBy(xpath = "//input[@id='ctl08_txtLastName']")
    protected Element lastname;
    @FindBy(xpath = "//input[@id='ctl08_btnApplyListing']")
    protected Element applyDL;
    @FindBy(xpath = "//input[@id='ctl08_btnDirectoryListingOK']")
    protected Element OkbuttonDL;
  
    @FindBy(xpath = "//*[@id='ContentPlaceHolder1_ContentPlaceHolder1_lcwLineInformationUC_lnkIntercept']")
    protected Element linkIntercept;      
    
    @FindBy(xpath = "//*[@for='ctl08_chkSelectAll']")
    protected Element linkInterceptSelectAll;    
    
    @FindBy(xpath = "//*[@id='ctl08_btnInterceptOkMain']")
    protected Element linkInterceptok;   
    
    @FindBy(xpath = "//*[@id = 'dropdownCallingPackage_new']")
    protected Element Lecvoicepackage;
    

    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_dropdownCallingPackage']")
    protected Element VerizonCallingPackage;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_lnkNewCPCIMore']")
    protected Element Moreoptions;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_lnkApplyForCallingPlan']")
    protected Element ApplytoSelectedLine;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_lnkNextForCallingPlan']")
    protected Element OkButton;
    
    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_linesAndTnSection_PanelEditbtn']")
    protected Element LinesAndTNEdit;
    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_btnSaveActiveSection']")
    protected Element termsok;
    
// For Reverse IRB
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_AllProductsLink']")
    protected Element lnkAllProducts;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UpAllProductsSection_txtSearchByISOCUSOC']")
    protected Element TxtBoxUsoc;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UpAllProductsSection_lnkBtnSearch']")
    protected Element UscoSearchButton;
    
    @FindBy(xpath = "//*[text() = '<<<>>>']/preceding-sibling::td/input[contains(@id, 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UpAllProductsSection_IOSCGrid_chkBoxTNs')]")
    protected Element UsocCheckBox;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UpAllProductsSection_lnkApply']")
    protected Element UsocApplyButton;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_lnkApply']")
    protected Element ProductsApplyButton;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_upAddlProdHeader']")
    protected Element AdditionalProductsHeader;
    
    @FindBy(xpath = "//*[@class = 'subCollapsiblePanelTab_pantone'  and contains(text(), 'Required Product Group')]")
    protected CList<Element> RequiredProductGroups;
        
    @FindBy(xpath = "//*[@class = 'subCollapsiblePanelTab_pantone'  and contains(text(), 'Required Product Group')]")
    protected Element RequiredProductGroup;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_RequiredProductGroupRepeater_ProductsRepeater_<<<>>>_chkAdditionalProduct_0']")
    protected Element RequiredFID;
           
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_PrimaryProductMandatoryFidsRepearter_ctl00_0']")
    protected Element ProductNWTFeatures;
        
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_lnkAdditionalProductOk']")
    protected Element FIDSOK;
    
    @FindBy(xpath = "//*[@name = 'ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$cpciFeaturesDirectorySection$ctl00$ucAdditionalProducts$PrimaryProductMandatoryFidsRepearter$ctl00$ctl00']")
    protected Element FIDCOMM;
  
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UpAllProductsSection_ErrorMessageControler_lblMessage']")
    protected Element ErrorMessage;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UpAllProductsSection_btnClose']")
    protected Element UsocCloseButton;

    @FindBy(xpath = "//*[contains(@id , 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAccountProfileSection_AccountTreeViewt')]//span[contains(text(), 'RJ11W')]")
    protected Element NPDWallJack;
  
    @FindBy(xpath = "//*[@id = 'productMenuforQuantifyUSOC']//a[contains(text(), 'Review Setup')]")
    protected Element ReviewSetup;
  
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_HyperLinkOptionalFidPrimaryPrdocut']")
    protected Element BtnOptionalFIDs;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_PrimaryProductOptionalFidsRepearter_ctl00_0']")
    protected Element FixedFee;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_upAdditionalSaveSection']")
    protected Element ProductPane;
  
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UcDirectoryListingSection_ddlMainDirPubStatus']")
    protected Element PublicationStatus;
    @FindBy(xpath = "//*[contains(text(), '<<<>>>')]/following::input[contains(@id , 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_PrimaryProductOptionalFidsRepearter_ctl00')]")
    protected Element OptionalFIDS;
    
    @FindBy(xpath = "//*[@id = 'availablePlanRow2']/td[contains(text(), 'BTN')]")  
    protected Element ExistingBTN;
}
