package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_LoginPage_Objects class represent the Page Object class. This
 * contains all the identifier for Simplex Login Page
 */
public class Simplex_Change_SerivceAddress_PageObjects extends CommonPage {
	/**
	 * Simplex_Login_PageObject class constructor
	 * 
	 * @param driver
	 *            represents the instances of type WebDriver
	 * @param windows
	 *            represents boolean value either true or false
	 * @param report
	 *            represents report input             
	 * @param windows
	 *            represents data input            
	 */
	public Simplex_Change_SerivceAddress_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
		super(driver, windows, report, data);
	}
	
	@FindBy(xpath = "//*[@id='txtHouseNumber']")
	protected Element HouseNum_Txtbox;
	
	@FindBy(xpath = "//*[@id='ContentPlaceHolder1_ucAddressValidation_ddlStreetDirection']")
	protected Element StreetDirection_Drpdwn;

	@FindBy(xpath = "//*[@id='txtStreetName']")
	protected Element StreetNmae_Txtbox;

	@FindBy(xpath = "//*[@id='ContentPlaceHolder1_ucAddressValidation_ddlStreetType']")
	protected Element StreetType_Drpdwn;
	
	@FindBy(xpath = "//*[@id='ContentPlaceHolder1_ucAddressValidation_ddlDirectionalSuffix']")
	protected Element DirectionalSuffix_Drpdwn;


	@FindBy(xpath = "//*[@id='ddlStructure']")
	protected Element Structure_Drpdwn;

	@FindBy(xpath = "//*[@id='txtStructure']")
	protected Element Structure_Txtbox;
	
	@FindBy(xpath = "//*[@id='ContentPlaceHolder1_ucAddressValidation_txtFloor']")
	protected Element Floor_Txtbox;


	@FindBy(xpath = "//*[@id='ContentPlaceHolder1_ucAddressValidation_ddlUnit1']")
	protected Element Unit_Drpdwn;

	@FindBy(xpath = "//*[@id='txtUnitValue']")
	protected Element Unit_Txtbox;
	
	@FindBy(xpath = "//*[@id='txtCity']")
	protected Element City_Txtbox;

	@FindBy(xpath = "//*[@id='ddlState']")
	protected Element State_Drpdwn;

	@FindBy(xpath = "//*[@id='txtZip']")
	protected Element Zipcode_Txtbox;

	@FindBy(xpath = "//*[@id='ContentPlaceHolder1_ucAddressValidation_btnValidateAddress']")
	protected Element QualifyAddress_Button;
	
	@FindBy(xpath = "//*[@id='rdoNewRoommate']")
	protected Element Newroommate_Radiobtn;
	
	@FindBy(xpath = "//*[@id='btnSaveAndContinue']")
	protected Element SaveandContinue_Button;
	
	@FindBy(xpath = "(//*[@id='pnlErrorMessageHolder'])[2]")
	protected Element Errorsection_Validation;
	
	@FindBy(xpath = "//*[@id='pnlErrorSection']//*[contains(.,'The Service Qualification results for the new address have changed')]")
	protected Element ServicenotMatch_Validation;
	
	
	
	
	

}
