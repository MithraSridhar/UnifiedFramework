package com.automation.pageobjects;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_ProductAndServices_Objects class represent the Page Object class.
 * This contains all the identifier for Simplex ProductAndServices Page
 */

public class Simplex_ProductAndServices_PageObjects extends CommonPage {

    /**
     * Simplex_ProductAndServices_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *            represents data inputallAgreement
     *            
     *            
     *      
     *            
     */
    public Simplex_ProductAndServices_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }

    @FindBy(xpath = "//*[@class='simplex_panel-close-icon active']")
    protected Element lnkCloseActivity;

    @FindBy(xpath = "//*[@ng-click = 'AgreeBatteryBackup()']")
     protected Element Batterybackup_Agreement;

   
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_dropdownDCP_new']")
    protected Element Domestic_LD_Plan;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_dropdownPIC_new']")
    protected Element Long_Distance_Carrier;


    @FindBy(xpath = "//img[@class='opo-internet']")
    protected Element imgInternet;

    @FindBy(xpath = "//img[@class='opo-tv']")
    protected Element imgTV;

    @FindBy(xpath = "//span[@class='accordion-title ng-binding text-black' and contains(text(),'Equipment + Accessories')]")
    protected Element tabEquipmentsAccessoriesRibbon;

    @FindBy(xpath = "//div[@si-section-name='ActivityTimeline']")
    protected Element tabActivity;

    @FindBy(xpath = "//div[@data-section-trigger='dashboard']")
    protected Element tabDashboard;

    @FindBy(xpath = "//span[text()='50M/35M']")
    protected Element internet5035;

    @FindBy(xpath = "//input[@id='alternateNumber']")
    protected Element txtAlternatePhoneNumber;

    @FindBy(xpath = "//input[@id='addressZipCode']")
    protected Element zipcode;

    @FindBy(xpath = "//input[@id='addressAddress']")
    protected Element address;

    @FindBy(xpath = "//input[@id='infoEmail']")
    protected Element txtEmail;
    
    @FindBy(xpath = "//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_idAlert_ctl00_AlertMessage']")
    protected Element VASAlertmsg;
    

    @FindBy(xpath = "//iframe[@id='IfProducts']")
    protected Element IfProducts;

    @FindBy(xpath = "//button[@name='next']")
    protected Element btnNext;
    
    @FindBy(xpath = "//div[@id='dvCongrats' and contains(text(),'Congratulations')]")
    protected Element lecPageDisplay;

    @FindBy(xpath = "//button[@id='Preview_Order']")
    protected Element btnReviewOrder;

    @FindBy(xpath = "//li[@data-accordion='internet']/following-sibling::li[1]//div[contains(@ng-repeat,'product') and not(contains(@class,'hide'))]//*[starts-with(text(),'<<<>>>')]")
    protected Element lnkInternetPlans;

    @FindBy(xpath = "//div[contains(@id,'Equipment_Rec_Storage_')]//*[contains(text(),'<<<>>>')]")
    protected Element lnkRecordingOptions;

    @FindBy(xpath = "//div[not(contains(@class,'ng-hide'))]/div[contains(@ng-click,'ProcessRouterSelection')]//*[contains(.,'<<<>>>')]")
    protected Element lnkRouterOptions;

    @FindBy(xpath = "//div[@data-equal-height='Battery']/p/*[contains(text(),'<<<>>>')]")
    protected Element lnkBatteryBackupOptions;

    @FindBy(xpath = "//*[contains(@ng-click,'ProceedWithOrder()')]")
    protected Element btnCheckout;

    @FindBy(xpath = "//li[@id='bundletabs']/a[contains(text(),'Products')] ")
    protected Element productTab;

    @FindBy(xpath = "/li[@id='bundletabs']/a")
    protected Element productTab1;

    @FindBy(xpath = "//span[contains(text(),'<<<>>>')]")
    protected Element tabEquipmentsAccessoriesRibbon_1;

    @FindBy(xpath = "//*[@id='divNewProductsContainerContent']/div[3]/div[1]/div[1]/div[3]/div[3]/div[1]/div/span")
    protected Element unbundle;

    
    
    @FindBy(xpath = "//*[@id='divNewProductsContainerContent']/div[3]/div[1]/div[1]/div[1]/div[3]/div[2]/span[2]")
    protected Element bundle;

    @FindBy(xpath = " //*[@id='Cancel_Order']")
    protected Element btnCancelOrder;

    @FindBy(xpath = "//a[contains(text(),'Apply tax')]")
    protected Element btnApplyTax;

    @FindBy(xpath = "//div[@class='price-flip-card']/div/span[2]")
    protected Element txtOrderTotal;

    @FindBy(xpath = "//*[text() ='New Estimated Monthly Subtotal']/../../div[3]")
    protected Element txtNewEstimatedMonthlySubTotal;

    @FindBy(xpath = "//*[text() ='New Estimated Monthly Charges']/../../div[3]")
    protected Element txtNewEstimatedMonthlyCharges;

    @FindBy(xpath = "//*[@id='opo_nav_links']/li[1]/div/span[2]")
    protected Element txtOneTimeFee;

    @FindBy(xpath = "//button[@id='Make_Changes']")
    protected Element btnMakeChanges;
	 
    @FindBy(xpath = "//div[@data-close-customtip='sharedcart']//span[contains(@class,'close')]")
    protected Element Smartcartpopup;
    
    @FindBy(xpath = "//select[@id='ContentPlaceHolder1_ContentPlaceHolder1_lcwLineInformationUC_callingplanuc_dropdownCallingPackage']")
    protected Element callingPackageLECVoice;
    
    @FindBy(xpath = "//select[@name='ucGeneralSetupSection$lstProducts']/option[(contains(@selected,'selected')) and contains(text(),'<<<>>>')]")
    protected Element ChkbxLECMaintainanceplan;
    
    @FindBy(xpath = "//select[@name='ucGeneralSetupSection$lstProducts']/option[contains(text(),'<<<>>>')]")
    protected Element notChkbxLECMaintainanceplan;
    
    @FindBy(xpath = "//select[@name='ctl08$lstVBBProducts']/option[contains(text(),'<<<>>>')]")
    protected Element ChkbxLECVoiceBackUpplan;


    
   @FindBy(xpath = "//*[@id='divNewProductsContainerContent']//div[contains(text(),'TV Equipment')]//following::div//p[contains(text(),'Set-Top Box Fios Prepaid')]//parent::div")    
    protected Element setTopFiosPrepaidTV;

    ///////////////////////////////////////////////////////////

    @FindBy(xpath = "(//div[@data-panel='products']//div[@class='row w_pendingorder-tiles m_accordion-summary' and (@aria-expanded='true' or @aria-expanded='false')] )/div/div[contains(text(),'Move Order')]")
    protected Element expandMovePending;

    @FindBy(xpath = "//div[contains(text(),'Move')]/parent::div/parent::div/following::div[1]//button[contains(text(),'Update Order')]")
    protected Element BtnupdateMove;
	
	 
    @FindBy(xpath = "//*[@ng-click='SuppOrderSubmit(order)']")
    protected Element BtnupdateMoves;
	
	@FindBy(xpath = "//button[@ng-click='salesRequiredCheck()']")
    protected Element salesProfileSave;

    @FindBy(xpath = "//div[contains(text(),'Move')]/parent::div/parent::div/following::div[1]//div[3]/div[contains(text(),'New')]/following::div[3]//a[contains(text(),'Change Due Date')]")
    protected Element ChangeDueDateMove;
	
	@FindBy(xpath = "//*[@ng-click='SuppDueDateOrderSubmit(order)']")
    protected Element ChangeDueDateMoves;

    @FindBy(xpath = "//input[@onclick='OnCAOk();']")
    protected Element btnOkMakeChanges;

    // ******************c2g Frame
    @FindBy(xpath = "//iframe[@id='IfProducts']")
    protected Element c2gFrame;

    // ******************c2g Frame

    @FindBy(xpath = "//li[@data-accordion='vasip']")
    protected Element tabVAS;

    @FindBy(xpath = "//*[@id = 'VASIP_View_More']")  //* Gopal0315
    protected Element MoreVAS;
    
    @FindBy(xpath = "//*[@id = 'VASIP_View_More']/a")  //* Prakash - 2/7
    protected Element MoreVASC2G;

    @FindBy(xpath = "//table[@class='groupHeader' and contains(.,'Verizon Cloud')]/following-sibling::div[@class='normalText']//td[contains(.,'<<<>>>')]/preceding-sibling::td/input")
    protected Element VASProduct;

    @FindBy(xpath = "//*[@value='Save Changes']")
    protected Element VASSaveandContinue;

    // Objects for Simplex Product Internet
    @FindBy(xpath = "//li[@data-accordion='internet']")
    protected Element lnkDataInternet;

    @FindBy(xpath = "//li[@data-accordion='internet']/following-sibling::li[1]//span[contains(text(),'<<<>>>')]")
    protected Element lnkInstallDataViewPrices;

    @FindBy(xpath = "//div[contains(text(),'<<<>>>')]")
    protected Element lnkAgreementSpeed;

  

    @FindBy(xpath = "//li[@data-accordion='internet']/following-sibling::li[1]//product-tile-list/div//span[starts-with(text(),'<<<>>>')]")
    protected Element lnkSelectedExistingData;

    // Objects for Simplex Product TV

    @FindBy(xpath = "//li[@data-accordion='video']")
    protected Element lnkTV;

    @FindBy(xpath = "//li[@data-accordion='video']/following-sibling::li[1]//span[text()='<<<>>>']")
    protected Element lnkInstallTVViewPrices;



    @FindBy(xpath = "//li[@data-accordion='video']/following-sibling::li[1]//product-tile-list/div//span[contains(text(),'<<<>>>')]")
    protected Element lnkSelectedExistingTV;

    // Objects for Simplex Product Voice

    @FindBy(xpath = "//li[@data-accordion='voice']")
    protected Element lnkVoice;

    @FindBy(xpath = "//div[@class='row ng-scope']//div[contains(text(),'Voice')]//following-sibling::div")
    protected Element txtSelectedHP;


    @FindBy(xpath = "//div//p/span[contains(text(),'<<<>>>')]")
    protected Element lnkBundleVoice;

    @FindBy(xpath = "//li[@data-accordion='voice']/following-sibling::li//product-tile-list//*[contains(text(),'<<<>>>')]")
    protected Element lnkStandaloneVoice;

    @FindBy(xpath = "//li[@data-accordion='voice']/following-sibling::li[1]//span[text()='<<<>>>']")
    protected Element lnkInstallVoicePrices;

    // Objects for review checkout

    @FindBy(id = "Preview_Order")
    protected Element btnPreviewOrder;

    @FindBy(xpath = "//button[contains(text(),'Checkout')]")
    protected Element btnReviewCheckout;

    // Extras and Equipment

    @FindBy(xpath = "//li[@data-accordion='<<<>>>']//div[contains(@class,'ng-binding')]")
    protected Element productSelection_Validation;

    @FindBy(xpath = "//li[@data-accordion='video']//div[contains(@class,'ng-binding')]")
    protected Element simplex_SelectedTV;

    @FindBy(xpath = "//li[@data-accordion='internet']//div[contains(@class,'ng-binding')]")
    protected Element simplex_SelectedData;

    @FindBy(xpath = "//li[@data-accordion='voice']//div[contains(@class,'ng-binding')]")
    protected Element simplex_SelectedVoice;

    // Equipment section

    @FindBy(xpath = "//li[@data-accordion='video']/following-sibling::li[1]//span[contains(text(),'<<<>>>')]")
    protected Element lnkTVPlans;

    @FindBy(xpath = "//div[contains(@class,'no-of-tvs-wrapper') or contains(@class,'no-of-iptvs-wrapper')]//div[(contains(.,'<<<>>>')) and (not(contains(@class,'hide')))]")
    protected Element lnkNoOfTvs;

    @FindBy(xpath = "//div[contains(@class,'no-of-tvs-wrapper') or contains(@class,'no-of-iptvs-wrapper')]//div[(contains(@class,'no-of-tvs') or contains(@class,'no-of-iptvs')) and (@data-tv-select='active')]")
    protected Element lnkNoOfTvs_Selected;

    @FindBy(xpath = "//div[@class='no-of-tvs-wrapper']//div[contains(@class,'no-of-tvs ')and not(@data-tv-select='active')][<<<>>>]")
    protected Element lnkNoOfTvs_Selected_Data;

    @FindBy(xpath = "//div[@class='no-of-tvs-wrapper']//div[contains(@class,'no-of-tvs ')and not(@data-tv-select='active')][<<<>>>]")
    protected Element lnkNoOfTvs_NotSelected_Data;

    @FindBy(xpath = "//div[contains(@id,'Equipment_Rec_Storage_') and  contains(@class,'selected')]//span[contains(text(),'<<<>>>')]")
    protected Element lnkRecordingOptions_Selected_Data;

    @FindBy(xpath = "//div[contains(@class,'selected') and contains(@ng-repeat,'equipment')]//div[contains(@ng-click,'ShopRecordingItem')]//p[contains(@class,'title')]")
    protected Element lnkRecordingOptions_Selected;

    @FindBy(xpath = "//div[not(contains(@class,'ng-hide'))]/div[contains(.,'<<<>>>') and contains(@ng-click,'ShopRecordingItem')]")
    protected Element lnkRecordingOptions_NotSelected_Data;

    @FindBy(xpath = "//div[contains(@id,'Router') and contains(@class,'selected')]//div//p[contains(@class,'title')]")
    protected Element lnkRouterOptions_Selected;

    @FindBy(xpath = "//div[contains(@id,'Router') and contains(@class,'selected')]//span[contains(text(),'<<<>>>')]")
    protected Element lnkRouterOptions_Selected_Data;

    @FindBy(xpath = "//div[contains(@id,'Router') and not(contains(@class,'selected'))]//span[contains(text(),'<<<>>>')]")
    protected Element lnkRouterOptions_NotSelected_Data;

    @FindBy(xpath = "//div[@data-equal-height='Battery']/p/span[contains(text(),'<<<>>>')]")
    protected Element lnkBatteryBackupOptions_Data;

    @FindBy(xpath = "//div[contains(@class,'selected') and not(contains(@class,'ng-hide'))]/div[@data-equal-height='Battery' or @data-equal-height='C2GBattery']")
    protected Element lnkBatteryBackupOptions_Selected;

    @FindBy(xpath = "//div[@data-equal-height='Battery']/../div[@id and not(contains(@class,'selected'))]")
    protected Element lnkBatteryBackupOptions_NotSelected;

    @FindBy(xpath = "//div[not(contains(@class,'ng-hide'))]/div[@data-equal-height='C2GBattery' or @data-equal-height='Battery']//*[contains(text(),'<<<>>>')]")
    protected Element selectBatteryBackupOptions;

    // streaming option

    @FindBy(xpath = "//li[@data-accordion='streaming']")
    protected Element tabStreamingOptionsSection;

    @FindBy(xpath = "//div[contains(@id,'Router')]//span[contains(text(),'<<<>>>')]")
    protected Element tabStreamingOption;

    @FindBy(xpath = "//div[not(contains(@class,'selected'))]/div[contains(@ng-click,'StreamingItemClick') and contains(.,'<<<>>>')]")
    protected Element lnkStreamingOptions_notSelected;

    @FindBy(xpath = "//div[contains(@class,'selected')]/div[contains(@ng-click,'StreamingItemClick') and contains(.,'<<<>>>')]")
    protected Element tabStreamingOption_Selected;

    // permium channnels

    @FindBy(xpath = "//li[@data-accordion='premium']")
    protected Element Premium_Section;

    @FindBy(xpath = "//li[@data-accordion='premium']//div[@class='tiny-8 ng-binding']")
    protected Element Selected_Premium;

    @FindBy(xpath = "//*[contains(text(),'More Premium Channels')]")
    protected Element More_Permium_channel;

    @FindBy(xpath = "//div[not(contains(@class,'disabled'))]/div[@data-equal-height='more-premium-channel']//p[contains(text(),'<<<>>>')]")
    protected Element Premium_channel_tile;

    @FindBy(xpath = "//li[@data-tab='payPerView-tab']")
    protected Element PayPerView_Tab;

    @FindBy(xpath = "//div//p/span[contains(text(),'Enable Pay Per View')]")
    protected Element Enable_PayPerView;

    @FindBy(xpath = "///div//p/span[contains(text(),'Enable Pay Per View')]/parent::P/parent::div/parent::div")
    protected Element Enable_PPV_isSelected;

    @FindBy(xpath = "//div//p/span[contains(text(),'Disable Pay Per View')]")
    protected Element Disable_PayPerView;

    @FindBy(xpath = "//div//p/span[contains(text(),'Disable Pay Per View')]/parent::P/parent::div/parent::div")
    protected Element Disable_PPV_isSelected;

    @FindBy(xpath = "//a[@data-ng-click='UpdateCart()']")
    protected Element PremiumChannel_Update;
    
    @FindBy(xpath = "//span[conatins(text()='Broadband Essentials and Extras')]")
    protected Element BBEpageload;

    @FindBy(xpath = "//li[@data-tab='<<<>>>-tab']")
    protected Element MoreChannelType;

    // setup install

    @FindBy(xpath = "//li[@data-accordion='setup']")
    protected Element Setup_section;

    @FindBy(xpath = "//li[@data-accordion='setup']//div[@class='tiny-8 ng-binding'][2]")
    protected Element Selected_Outlets;

    @FindBy(xpath = "//div[@data-equal-height='setup']//*[contains(text(),'<<<>>>')]")
    protected Element Outlet_Tile;

    // voice section

    @FindBy(xpath = "//li[@data-accordion='phoneoptions']")
    protected Element Phone_Product_section;

    @FindBy(xpath = "//li[@data-accordion='phoneoptions']//div[@class='tiny-8 ng-binding']")
    protected Element Selected_phone_product;

    @FindBy(xpath = "//product-tile-list[@productlist='insideWireMaintenancePlans' or @productlist='VzCallingPlans']//div//p/span[contains(text(),'<<<>>>')]")
    protected Element IP_WM_Tile;

    @FindBy(xpath = "//span[contains(text(),'More Options')]")
    protected Element Phone_More_Options_link;

    @FindBy(xpath = "//span[contains(text(),'Directory Listing Options')]")
    protected Element Phone_Directory_Listing;

    @FindBy(id = "FDV_Listing_FirstName")
    protected Element Txt_Listing_Firstname;

    @FindBy(id = "FDV_Listing_LastName")
    protected Element Txt_Listing_Lastname;

    @FindBy(xpath = "//span[contains(text(),'Update Listing')]")
    protected Element Update_Listing;

    @FindBy(xpath = "//a[contains(text(),'Save')]")
    protected Element Save_Listing;

    @FindBy(xpath = "//div[@id='lcwPunchout']/span[contains(text(),'LEC Voice Option')]")
    protected Element Lec_Voice_Option;

    @FindBy(xpath = "//li[@data-accordion='<<<>>>']")
    protected Element ServiceBar;

    @FindBy(xpath = "//li[@data-accordion='<<<>>>' and not(contains(@class,'open'))]")
    protected Element ServiceBar_Collapsed;

    @FindBy(xpath = "//li[@data-accordion='internet']")
    protected Element ServiceBar_Internet;

    @FindBy(xpath = "//li[@data-accordion='<<<>>>']/following-sibling::li[@ng-controller][1]//div[@ng-repeat and contains(@class,'selected')]/div[@ng-click]")
    protected Element SelectedService;

    //// c2g change//

    /////////////////////// new/////////////////

    @FindBy(xpath = "//li[@data-accordion='voice']/following-sibling::li[1]//span[text()='View Standalone Prices']")
    protected Element clickSAVoice;

    @FindBy(xpath = "//li[@data-accordion='voice']/following-sibling::li[1]//span[text()='View Bundle Prices']")
    protected Element clickBundleVoice;

    @FindBy(xpath = "//li[@data-accordion='internet']")
    protected Element expandInternet;
    
    @FindBy(xpath = "//li[@ng-controller='DataCtrl']//div[@ng-repeat and not(contains(@class,'hide'))]")
    protected Element allInternetSpeeds;
    
    @FindBy(xpath = "//div[@data-equal-height='add-tv']")
    protected Element allTvs;
    
    @FindBy(xpath = "//div[@data-equal-height='offer' or @data-equal-height='more-offer']")
    protected CList<Element> allAgreements;

    @FindBy(xpath = "//li[@data-accordion='video']")
  
    protected Element expandTv;

    @FindBy(xpath = "//li[@data-accordion='voice']")
    protected Element expandVoice;

    @FindBy(xpath = "//li[@data-accordion='equipments']")
    protected Element expandEquipment;

    @FindBy(xpath = "//li[@id='Equipment_Delivery_Header']")
    protected Element expandEquipmentDeliveryReturn;

    @FindBy(xpath = "//li[@data-accordion='internet']//li[@aria-expanded='false']")
    protected Element expandInternetsection;

    @FindBy(xpath = "//li[@data-accordion='voice']/following-sibling::li[1]//span[contains(text(),'<<<>>>')]")
    protected Element lnkVoicePlans;

    @FindBy(xpath = "//li[@data-accordion='internet']/following-sibling::li[1]//span[text()='View Standalone Prices']")
    protected Element lnkViewStandaone;

    @FindBy(xpath = "//li[@data-accordion='internet']/following-sibling::li[1]//span[text()='View Bundle Prices']")
    protected Element lnkViewBundle;



    @FindBy(xpath = "//li[@data-accordion='internet']/following-sibling::li[1]//product-tile-list/div/div[not(contains(@class,'hide-imp'))]//span[@class='block ng-binding ng-scope']")
    protected Element DataPackagesList;

    @FindBy(xpath = "//tr[contains(.,'<<<>>>')]/td/input[@type='radio' or @type='checkbox']")
    protected Element BBEOptions;

    @FindBy(xpath = "//div[contains(@ng-bind-html,'NoAgreementTileText')]")
    protected Element contractM2M;

    //vikram start script
    @FindBy(xpath = "//div[@class='w_contract-blocks margin-bottom-medium']//span[contains(text(),'Month to Month')]")
    protected Element contractSAM2M;
    
    @FindBy(xpath = "//p[contains(text(),'Great news! A Fios Quantum Gateway Router is already at your location, provided at no charge.')]")
    protected Element routerSectionSlipScript;
    
    //vikram end script
    
    @FindBy(xpath = "//div[contains(@ng-bind-html,'NoAgreementTileText') and contains(@ng-bind-html,'2-Year')]")
    protected Element contract2Year;
    @FindBy(xpath = "//li[contains(@ng-click,'ToggleSectionVisibility') and contains(@ng-click,'Contract')]")
    protected Element expandContract;
    @FindBy(xpath = "//div[@data-equal-height='offer' or @data-equal-height='more-offer']")
    protected Element allAgreement;
    // TV Section

    @FindBy(xpath = "//li[@data-accordion='video']/following-sibling::li[1]//span[text()='View Standalone Prices']")
    protected Element C2GTVSAPrice;

    @FindBy(xpath = "//li[@data-accordion='video']/following-sibling::li[1]//span[text()='View Bundle Prices']")
    protected Element C2GTVBundlePrice;

    @FindBy(xpath = "//li[@data-accordion='video']")
    protected Element C2GTVSectionexpand;

    @FindBy(xpath = "//li[contains(@ng-show,'equipmentDetails')]//div[contains(text(),'TV Equipment')]")
    protected Element tvEquipmentSection ;

    @FindBy(xpath = "//li[contains(@ng-show,'equipmentDetails')]//*[contains(text(),'Recording Options')]")
    protected Element recordingSection;

    @FindBy(xpath = "//div[@class='row padding-vert-micro margin-bottom-tiny ng-scope'][1]")
    protected Element routerSection;
    
    @FindBy(xpath = "//li[contains(@ng-show,'equipmentDetails')]//*[contains(text(),'Battery Backup options')]")
    protected Element batterySection;
    
    @FindBy(xpath = "//li[contains(@ng-show,'equipmentDetails.length>0')]")
    protected Element equipmentDetails;

 
    @FindBy(xpath = "//li[@data-accordion='equipments']")
    protected Element expandEquipmentsAccessoriesRibbon;

    @FindBy(xpath = "//li[@data-accordion='equipments']//div[@class='w_blocks selected']")
    protected Element selectedRouter;

    @FindBy(xpath = "//li[@ng-controller='ContractsCtrl']//div[contains(text(),'View ONLY 2-Year Agreement Offers')]")
    protected Element contractViewOnly2YrTerm;

    @FindBy(xpath = "//li[@ng-controller='ContractsCtrl']//div[contains(text(),'View No Agreement Offers')]")
    protected Element contractViewOnlyM2MTerm;

    @FindBy(xpath = "//li[@ng-controller='ContractsCtrl']//div[not(contains(@class,'hide')) and contains(@class,'agreement')]//*[contains(text(),'No Contract') or contains(text(),'No Agreement') or contains(text(),'Month to Month')]")
    protected Element contractM2MTerm;
    
    @FindBy(xpath = "//li[@ng-controller='ContractsCtrl']//*[contains(text(),'No Contract') or contains(text(),'No Agreement') or contains(text(),'Month to Month')]")
    protected Element contractNoContract;
    
    

    @FindBy(xpath = "//li[@ng-controller='ContractsCtrl']//*[contains(text(),'2-Year Agreement')]")
    protected CList<Element> contract2YearTerm;
    
    
    @FindBy(xpath = "//input[@id='chkAutopayofferPromo']")
    protected Element AutoPaychkDeclineorAccept;
    
    @FindBy(xpath = ".//input[@ng-model='maskedMailID']")
    protected Element emailText;
    
    @FindBy(xpath = "//*[@ng-click='TriggerEmail()']")
    protected Element btnSendQuote;

    // Selected Contract

    @FindBy(xpath = "//input[contains(@id,'Contract_Term_TwoYearMoveB') and contains(@ng-checked,'true')]/parent::div//label[contains(text(),'2-Year Agreement (Move As Is)')]")
    //// input[contains(@id,'Contract_Term_TwoYearMoveB') and
    //// contains(@ng-checked,'true')]/label[contains(text(),'2-Year Agreement
    //// (Move As Is)')]"
    protected Element contract2YearTerm_Selected;

    @FindBy(xpath = "//label[@for='Contract_Term_MonthToMonthRestartB']")
    protected Element contractRenewM2MBundle;

    @FindBy(xpath = "//label[@for='Contract_Term_TwoYearRestartB']")
    protected Element contractRenew2YearBundle;
    
    @FindBy(xpath = "//*[contains(text(),'<<<>>>')]")
    protected Element contractRenew2YearBundleOffer;
    
    @FindBy(xpath = "//label[@for='Contract_Term_TwoYearFutureB']")
    protected Element contractRenew2YearBundleFuture;
    
    @FindBy(xpath = "//label[@for='Contract_Term_MonthToMonthRestartS']")
    protected Element contractRenewM2MStandalone;
    
    

    @FindBy(xpath = "//label[@for='Contract_Term_TwoYearRestartS']")
    protected Element contractRenew2YearStandalone;
	
	@FindBy(xpath = "//a[@class='vzicon icon-close medium text-grey-3']") // Anu
    protected Element okbtn;

    @FindBy(xpath = "//div[@data-open-modal='tv-more-equipment']")
    protected Element tvEquipmentMoreOption;

    @FindBy(id = "Equipemnt_TV_More_SaveChanges")
    protected Element tvEquipmentSaveOption;

    @FindBy(xpath = "//li[@id='Equipment_Delivery_Header']")
    protected Element expandEquipmentReturnOption;

    @FindBy(xpath = "//div[@class='blocks_equipment-choices']//p[1]//span[contains(text(),'<<<>>>')]")
    protected Element EquipmentReturnOption;

    @FindBy(xpath = "//div[not(contains(@class,'ng-hide'))]/div[contains(@ng-click,'ShopRecordingItem') and not(contains(@class,'selected')) and not(contains(@class,'ng-hide'))]//*[contains(.,'<<<>>>')]") //// div[contains(@id,'Equipment_Rec_Storage_')
																									     //// and
																									     //// not(contains(@class,'selected'))
																									     //// and
																									     //// not(contains(@class,'ng-hide'))]//span[contains(text(),'<<<>>>')]
    protected Element lnkRecordingOptions_notSelected;

    @FindBy(xpath = "//*[@id='lcwPunchout' or @id='PhoneOptions']")
    protected Element MoreOptions;

    @FindBy(xpath = "//span[contains(text(),'Telephone Number Assignment')]")
    protected Element TNNumberAssign;

    @FindBy(xpath = "//label[contains(text(),'Manual Assignment')]")
    protected Element ManualAssign;

    @FindBy(xpath = "//input[@id='txtManualTN']")
    protected Element TNNumber;

    @FindBy(xpath = "//button[contains(text(),'Check Availability')]")
    protected Element checkAvailability;

    @FindBy(xpath = "//span[contains(text(),'Assign Number')]")
    protected Element assignNumber;

    @FindBy(xpath = ".//*[@id='FDV_Phone_Options_SaveChanges']")
    protected Element saveChanges;

    // Listingsave
    @FindBy(xpath = "//a[@ng-click='ApplyDirectoryInfo(DirectoryInfoEdit)']")
    protected Element ListingsaveChanges;

    @FindBy(xpath = "//div[@class='no-of-tvs' or @class='no-of-iptvs']")
    protected Element TotalNoOfTvs;

    @FindBy(xpath = "//div[@data-equal-height='C2GBattery']/p/span[contains(text(),'<<<>>>')]")
    protected Element lnkBatteryC2GBackupOptions;

    // Price Comparison - Product Page

    @FindBy(xpath = "//span[text()='Monthly']/following-sibling::span")
    protected Element ProductPage_MonthlyPricewithoutTax_Installflowonly;

    @FindBy(xpath = "//div[@id='monthlyCart']/p/span")
    protected Element ProductPage_MonthlyPricewithoutTax_Changeflowonly;

    @FindBy(xpath = "//span[text()='Monthly']/following-sibling::span")
    protected Element ProductPage_MonthlyPricewithTax_Installflowonly;

    @FindBy(xpath = "//div[@id='monthlyCart']/p/span")
    protected Element ProductPage_MonthlyPricewithTax_Changeflowonly;

    @FindBy(xpath = "//a[@ng-click='showTaxes()']")
    protected Element ProductPage_lnkApplyTax;

    @FindBy(xpath = "//span[text()='Monthly']/parent::div/div/span/span")
    protected Element ProductPage_Tax_amount_Installflowonly;

    @FindBy(xpath = "//div[@id='monthlyCart']/div/span")
    protected Element ProductPage_Tax_amount_Changeflowonly;

    // Price comparison- Review order Page

    @FindBy(xpath = "//span[contains(.,'Monthly Subtotal')]/../following-sibling::div")
    protected Element ReviewOrderPage_MonthlyPricewithoutTax;

    @FindBy(xpath = "//span[contains(.,'Monthly Charges')]/../following-sibling::div")
    protected Element ReviewOrderPage_MonthlyPricewithTax;

    // LEC Page
    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_linesAndTnSection_ctl00_ddlNumberOfLines")
    protected Element NoOfLines;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_linesAndTnSection_ctl00_lnkCreateLines")
    protected Element BtnGetLines;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_linesAndTnSection_ctl00_lnkNextForTNAssignment")
    protected Element BtnLinesOk;

    @FindBy(xpath = "//input[@type='checkbox']")
    protected Element CheckboxagainstLines;
    @FindBy(xpath = "//input[@id='ContentPlaceHolder1_ContentPlaceHolder1_linesAndTnSection_ctl00_RPIGrid_btnDelLine_0']")
    protected Element DeleteLine;
    

    @FindBy(xpath = "//span[contains(text(),'Get Details For Selected Line')]")
    protected Element GetDetailsforLines;
    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_dropdownICP_new")
    protected Element DrpIEPlan;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_lnkApply_CPCI")
    protected Element ApplyCallingPlan;

    @FindBy(xpath = "//td[contains(text(),'<<<>>>')]//preceding-sibling::td//input")
    protected Element ChkBoxUnderFeatures;

    @FindBy(xpath = "//div[@class='formValue']//select//option[contains(@value,'<<<>>>')]")
    protected Element NoCharge;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_lnkOkGN")
    protected Element MaintenanceOK;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucVoiceBatteryBackupSection_lnkOkVBB")
    protected Element VoiceBkppowerOK;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_NO_Jacks")
    protected Element NoJack;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_lnkJackOK")
    protected Element NoJackOK;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_LinkDirectoryEdit")
    protected Element DLEdit;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UcDirectoryListingSection_txtMainDirLastName")
    protected Element DLLastName;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UcDirectoryListingSection_txtMainDirFirstName")
    protected Element DLFirstName;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UcDirectoryListingSection_lnkDirectoryListingNext")
    protected Element DLOK;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_lnkNextForFeatures")
    protected Element PlanFeaturesOK;

    @FindBy(id = "ContentPlaceHolder1_ContentPlaceHolder1_nRCsSection_ctl00_NRCOKClick")
    protected Element NRCOK;

    @FindBy(id = "ContentPlaceHolder1_FooterContent_btntabUISaveContinue")
    protected Element LECSaveAndContinue;
    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_interceptsSection_PanelEditbtn']")
    protected Element Intercepts;
    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_linesAndTnSection_PanelEditbtn']")
    protected Element LinesAndTNEdit;
    @FindBy(xpath = "//input[@id='ContentPlaceHolder1_ContentPlaceHolder1_interceptsSection_ctl00_chkSelectAll']")
    protected Element SelectIntercept;
    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_interceptsSection_ctl00_btnOkMain']")
    protected Element OkIntercept;
    
  

    //// Voice plan//

    @FindBy(xpath = "//select[@id='FDV_Select_Number']")
    protected Element selectNumber;
    
    @FindBy(xpath = "//div[@ng-if='!voiceModel.IsFdvInterceptView && !voiceModel.IsSuperSedureOrder']")
    protected Element internationalPlanSection;
    
    
    @FindBy(xpath = "//div[contains(text(),'Inside Wire Maintenance Plan')]")
    protected Element wireMaintainanceSection;
    
    
    @FindBy(xpath = "//select[@id='FDV_Select_Number']/option[contains(.,'Unassigned Line')]")
    protected CList<Element> unAssignedLinesNumbers;
    
    @FindBy(xpath = "//label[contains(text(),'Please select a number')]")
    protected Element PleaseSelectnumber;
    @FindBy(xpath = "//span[contains(text(),'Directory Listing Options')]")
    protected Element DirectorylistingOptions;

    // Update Listing
    //@FindBy(xpath = "//span[contains(text(),'Update Listing')]")
    @FindBy(xpath = "//*[contains(text(),'Update Listing')]")
    protected Element UpdatelistingOptions;
    
    @FindBy(xpath = "//li[@aria-expanded='true']/span[contains(text(),'Directory Listing Options ')]")
    protected Element directoryListingOptions;
    
    @FindBy(xpath = "//li/span[contains(text(),'Directory Listing Options ')]")
    protected Element directoryListing;
    
    @FindBy(xpath = "//button[contains(text(),'Add new directory')]")
    protected Element addDirectory;
    @FindBy(xpath = ".//*[@id='FDV_Listing_FirstName']")
    protected Element txtFirstName;
    @FindBy(xpath = ".//*[@id='FDV_Listing_LastName']")
    protected Element txtLastName;
    @FindBy(xpath = ".//*[@id='FDV_Listing_Publication_Status']")
    protected Element publicationStatus;
    @FindBy(xpath = "//label[@for='FDV_Listing_Style_Individual_1']")
    protected Element listingStyle;
    @FindBy(xpath = "//input[@id='FDV_Listing_Address']")
    protected Element fdvListingAddress;
    @FindBy(xpath = "//a[@ng-click='ApplyDirectoryInfo(DirectoryInfoEdit)']")
    protected Element applyDirectoryInfo;
    @FindBy(xpath = "//button[@ng-click='SelectFDVMigrate()']")
    protected Element selectMigrate;

    // Lec VOice section
    @FindBy(xpath = "//*[@id='ContentPlaceHolder1_ContentPlaceHolder1_btnAddNewln']")
    protected Element BtnLECAddNewLine;
    
    @FindBy(xpath = ".//*[@id='dvCongrats']")
    protected Element AddlineTab;

    @FindBy(xpath = "//a[contains(@id,'ContentPlaceHolder1_ContentPlaceHolder1_lcwLineInformationUC_FeaturesUC_gvProducts_lnkPopularSetup') and contains(@onclick,'WM')]")
    protected Element LinkLECMaintenanceDetails;

    @FindBy(xpath = "//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")
    protected Element FrameLECPlans;

    @FindBy(xpath = "//div[@id='ucGeneralSetupSection_divgridMaintenance']//td//label[@for='ucGeneralSetupSection_gvMaintenance_radioBtn_0']")
    protected Element maintainanceDrpDown;

    // @FindBy(xpath =
    // "//*[contains(text(),'Jacks')]//parent::td//parent::tr//td//span/a")
    @FindBy(xpath = "//a[contains(@id,'ContentPlaceHolder1_ContentPlaceHolder1_lcwLineInformationUC_FeaturesUC_gvProducts_lnkPopularSetup') and contains(@onclick,'JK')]")
    protected Element jackVoiceLink;

    @FindBy(xpath = ".//*[@id='ContentPlaceHolder1_ContentPlaceHolder1_btnforward']")
    protected Element BtnLECSaveAndCont;


    @FindBy(xpath = "//span[contains(text(),'Voice Service Must Migrate to Fiber for this Order')]/ancestor::div[1]//input[@value='OK']")
    protected Element Service_Must_Migrate_to_Fiber_OKbtn;
    
    @FindBy(xpath = "//li[@id='fdvtabs' and contains(@class,'active')]//div//a[contains(text(),'LEC') and contains(@class,'active')]")
    protected Element ActiveVoiceLecTab;

    @FindBy(xpath = "//*[@id='ucGeneralSetupSection_lnkOkGN')]")
    protected Element linkOkMaintainance;

    @FindBy(xpath = "//iframe[contains(@src,'LCWD2D/Pages/D2DContainer.aspx')]")
    protected Element jackVoiceFrame;

    @FindBy(xpath = "//span[@class='bold margin-top-micro left margin-left-micro ng-scope']")
    protected Element viewBundleText;

    @FindBy(xpath = "//p[@ng-click='ToggleDataStandAlone()']")
    protected Element viewStandaloneText;

    @FindBy(xpath = "//p[@ng-click='ToggleVideoStandAlone()']")
    protected Element viewStandaloneTVText;

    @FindBy(xpath = "//*[@ng-click='ToggleVoiceStandAlone()']")
    protected Element viewStandaloneVoiceText;

    @FindBy(xpath = "//li[@data-accordion='voice']/following-sibling::li[1]//span[text()='View Standalone Prices']")
    protected Element C2GVoiceStandalonePrice;

    @FindBy(xpath = "//li[@data-accordion='voice']/following-sibling::li[1]//span[text()='View Bundle Prices']")
    protected Element C2GVoiceBundlePrice;

    @FindBy(xpath = "//li[@data-accordion='internet']/following-sibling::li[1]//span[text()='View Standalone Prices']")
    protected Element lnkDataViewStandaone;

    @FindBy(xpath = "//li[@data-accordion='internet']/following-sibling::li[1]//span[text()='View Bundle Prices']")
    protected Element lnkDataViewBundle;

    @FindBy(xpath = "//li[@data-accordion='video']/following-sibling::li[1]//span[text()='View Standalone Prices']")
    protected Element C2GTVStandalonePrice;

    @FindBy(xpath = "//span[contains(text(),'Voice Options')]")
    protected Element clkVoiceOptions;

    @FindBy(xpath = "//div[@id='lcwPunchout']")
    protected Element clkLecVoiceButton;

    @FindBy(xpath = "//*[contains(text(),'Voice Backup')]//parent::td//parent::tr//td//span/a")
    protected Element HyperlinkVoicebackupLEC;

    @FindBy(xpath = "//*[@id='ucGeneralSetupSection_gvMaintenance_radioBtn_0']")
    protected Element MaintainanceOptionSelection;

    @FindBy(xpath = ".//*[@id='gvAvailable']//following-sibling::validatecheckboxforjacksadd//input")
    protected CList<Element> chkBoxesForVoiceJack;

    @FindBy(xpath = "//*[@for='ctl08_gvAvailable_chkbox_0']")
    protected Element JackWorkPhone;
    
    @FindBy(xpath = "//table[@id='gvAvailable']//following-sibling::tr//td[3]")
    protected CList<Element> valuesForVoiceJack;
   
    @FindBy(xpath = "//*[@id='ctl08_lnkOkVBB']")
    protected Element linkOk;
    // Selected bbe
    @FindBy(xpath = "//span[contains(text(),'Security, Support & Storage')]/parent::div/following-sibling::div//div")
    protected Element bbeselected;

    // DisConnect Page'
    @FindBy(xpath = "//select[@id='ddlVzCatgoryReason']")
    protected Element DisconnectCategory;

    @FindBy(xpath = "//select[@id='ddlRCWVerzionDisconnectReasons']")
    protected Element DisconnectReason;

    @FindBy(xpath = "//*[@id='Button1g']")
    protected Element DisconnectSaveContinueBtn;

    @FindBy(xpath = "//div[@class='blocks_equipment-choices left']")
    protected Element getTNNumber;

    @FindBy(xpath = "//li[@data-accordion='internet']/following-sibling::li[1]//product-tile-list/div/div[not(contains(@class,'hide-imp'))]//span[@class='block ng-binding ng-scope']")
    protected CList<Element> productlistInternet;

    @FindBy(xpath = "//li[@data-accordion='video']/following-sibling::li[1]//product-tile-list/div/div[not(contains(@class,'hide-imp'))]//span[@class='block ng-binding ng-scope']")
    protected CList<Element> productlistTv;

    @FindBy(xpath = "//li[@data-accordion='equipments']//div[@class='tiny-8 ng-binding']")
    protected Element selectedEqpText;

    @FindBy(xpath = "//div[@id='tv-more-equipment-holder']//div[contains(@class,'selected')]/div/p[@class='blocks_equipment-title ng-binding']")
    protected Element deselectTvEquipm;

    @FindBy(xpath = "//div[@data-modal='tv-more-equipment']//div[not(contains(@class,'selected'))]/div[contains(@ng-click,'SetSelectedShopItem')]/p[@class='blocks_equipment-title ng-binding'][normalize-space(text())='<<<>>>']")
    protected Element selectTvEquip;
    
    @FindBy(xpath = "//div[@id='tv-more-equipment-holder']//div[contains(@class,'selected')]/div/p[@class='blocks_equipment-title ng-binding']")
    protected CList<Element> noOfEquipmentsDeselect;

    @FindBy(xpath = "//li[@id='Equipment_Delivery_Header']//div[@class='ng-scope']")
    protected Element OneTime;

    @FindBy(xpath = ".//div[@ng-repeat='options in VoiceTelephoneNumbers']")
    protected CList<Element> TNLines;

    @FindBy(xpath = "//div[contains(@ng-click,'AddLine') and contains(.,'<<<>>>')]")
      protected Element selectNoOfTNs;
    
    @FindBy(xpath = "//div[@ng-if='!voiceModel.IsFdvInterceptView']//div[@data-equal-height='internet-FNE' and contains(.,'Unassigned Line')]")
    protected CList<Element> noOfUnAssignedLines;
    
    @FindBy(xpath = "//div[@ng-if='!voiceModel.IsFdvInterceptView']//div[@data-equal-height='internet-FNE' and contains(.,'MAIN')]")
    protected Element mainLine;
    // CoA Install voice options

    @FindBy(xpath = "//li[@data-accordion='phoneoptions']")
    protected Element VoiceOptionsBar;

    @FindBy(xpath = "//li[@data-accordion='phoneoptions']/following-sibling::li//*[@ng-click='OpenLECPopup();']")
    protected Element VoiceMoreOptions;

    @FindBy(xpath = "//product-tile-list[@productlist='annualInternetData']//div[contains(@class,'selected')]/preceding-sibling::div[1]/descendant::span")
    protected Element internetUpgrade;
    @FindBy(xpath = "//product-tile-list[@productlist='annualInternetData' or @productlist='StandaloneInternetData']//div[contains(@class,'selected')]/preceding-sibling::div[1]/descendant::span[2]")
    protected Element internetUpgrade2;

    @FindBy(xpath = "//product-tile-list[@productlist='annualInternetData']//div[contains(@class,'selected')]/following-sibling::div[1]/descendant::span")
    protected Element internetDowngrade;
    @FindBy(xpath = "//product-tile-list[@productlist='annualInternetData' or @productlist='StandaloneInternetData']//div[contains(@class,'selected')]/following-sibling::div[1]/descendant::span[2]")
    protected Element internetDowngrade2;
  

    @FindBy(xpath = "  //product-tile-list[@productlist='videoData']//div[contains(@class,'selected')]/preceding-sibling::div[1]/descendant::span")
    protected Element tvUpgrade;
   

    @FindBy(xpath = "//product-tile-list[@productlist='videoData']//div[contains(@class,'selected')]/following-sibling::div[1]/descendant::span")
    protected Element tvDowngrade;
  
                   @FindBy(xpath = "//a[@data-add-quotes='editQuote']")
           		   protected Element btnChkt;
   

    // ********************UI Validations ****************************

    // Prakash

    @FindBy(xpath = "//div//p[contains(text(),'Internet Equipment')]")
    protected Element Internet_Equipment;

    @FindBy(xpath = "//a[contains(text(),'details')]")
    protected Element Router_Tile_Details_link;

    @FindBy(xpath = "//div//p/span[contains(text(),'TV Equipment')]")
    protected Element TV_Equipment_Window;

    @FindBy(xpath = ".//*[@id='VASIP_Tile_446267']/div")
    protected Element VASIP_ISSuite;;

    @FindBy(xpath = "//div[contains(text(),'Battery Backup Shipping Method')]")
    protected Element Battery_Backup_Shipping;

    @FindBy(xpath = "//span[contains(text(),'Voicemail Options')]")
    protected Element Voicemail_option;

    @FindBy(xpath = "//span[contains(text(),'Virtual Lines')]")
    protected Element Virtual_Lines;

    @FindBy(xpath = "//span[contains(text(),'Bring Your Own Number')]")
    protected Element BYON;

    @FindBy(xpath = "//div[@data-equal-height='BatteryShipment']/p/span[contains(text(),'<<<>>>')]")
    protected Element Batteryshipmentmethod;

    @FindBy(xpath = ".//*[@id='J5730']")
    protected Element Battery_Backup_StandardShipping_Price;

    @FindBy(xpath = ".//*[@id='J5727']/div")
    protected Element Battery_Backup_2DaysShipping_Price;

    @FindBy(xpath = ".//*[@id='J5726']/div")
    protected Element Battery_Backup_1DayShipping_Price;

    @FindBy(xpath = ".//*[@id='Basic_FDV_Y8266']/div")
    protected Element IP_VW300;

    @FindBy(xpath = ".//*[@id='Basic_FDV_Y8265']/div")
    protected Element IP_VW500;

    @FindBy(xpath = ".//*[@id='Basic_FDV_O1457']/div")
    protected Element IP_IntCallingPlan;

    @FindBy(xpath = ".//*[@id='Equipemnt_Internet_More_Cancel']")
    protected Element Internet_Accessories_Close;

    @FindBy(xpath = ".//*[@id='Equipemnt_TV_More_Cancel']")
    protected Element TVEquip_Cancel;

    @FindBy(xpath = ".//*[@id='Basic_FDV_H6724']/div")
    protected Element IWMP;

    @FindBy(xpath = ".//*[@id='FDV_Phone_Options_Popup']")
    protected Element Phone_Options_Close;

    @FindBy(xpath = "//span[contains(@class,'accordion-title') and contains(text(),'Equipment + Accessories')]/ancestor::li//div[contains(@ng-bind-html,'titleRC')]")
    protected Element Eq_ExtraProduct_Display_Header;

    @FindBy(xpath = "//span[contains(@class,'accordion-title') and contains(text(),'Equipment + Accessories')]/ancestor::li//*[contains(@class,'price-text')]")
    protected Element Eq_ExtraProduct_Display_Header_Price;

    @FindBy(xpath = "//span[contains(@class,'accordion-title') and contains(text(),'Voice Options')]/ancestor::li//div[contains(@ng-bind-html,'titleRC')]")
    protected Element Voice_Options_Display_Header;

    @FindBy(xpath = "//span[contains(@class,'accordion-title') and contains(text(),'Voice Options')]/ancestor::li//*[contains(@class,'price-text')]")
    protected Element Voice_Options_Display_Header_Price;

    @FindBy(xpath = "//span[contains(@class,'accordion-title') and contains(text(),'ecurity, Support & Storage')]/ancestor::li//div[contains(@ng-bind-html,'titleRC')]")
    protected Element VAS_Products_Display_Header;

    @FindBy(xpath = "//span[contains(@class,'accordion-title') and contains(text(),'Security, Support & Storage')]/ancestor::li//*[contains(@class,'price-text')]")
    protected Element VAS_Products_Display_Header_Price;

    @FindBy(xpath = "//span[contains(@class,'accordion-title') and contains(text(),'Equipment + Accessories')]/ancestor::li/following-sibling::li[1]//*[contains(text(),'Internet Accessories')]")
    protected Element Internet_Accessories_Open;

    @FindBy(xpath = "//*[@data-open-modal='tv-more-equipment']")
    protected Element OtherTV_Equip;

    @FindBy(xpath = "//div[@data-reveal-content='routerSalesScript']")
    protected Element Script_Above_Router;

    @FindBy(xpath = "//div[@ng-show='equipmentAdditionalInfo.ShowBatteryBackupscript']")
    protected Element Script_Battery_Backup;
    // -------------------------------------------------------------
    // Shilpa
    @FindBy(xpath = "//*[contains(text(),'Premium Channels')]")
    protected Element PremiumChannelsTile;

    @FindBy(xpath = "//li[@ng-controller='PremiumHeaderCtrl']")
    protected Element PremiumChannelsTileExpand;

    @FindBy(xpath = "//div[@data-equal-height='premium-channel']//p[contains(@class,'blocks_equipment-title')]")
    protected CList<Element> PremiumChannels_List;

    @FindBy(xpath = "//div[@ng-click='ShopItem(channel, channelList)']/p/span[contains(@class,'sprite')]")
    protected CList<Element> PremiumChannels_List2;

    @FindBy(xpath = "//li[@data-tab='specialty-tab']")
    protected Element specialty_tab;

    @FindBy(xpath = "//div[contains(@ng-click,'special')]//div[@data-equal-height='more-premium-channel']//p[contains(@class,'blocks_equipment-title')]")
    protected CList<Element> specialtyChannels;

    @FindBy(xpath = "//li[@data-tab='movies-tab']")
    protected Element movies_tab;

    @FindBy(xpath = "//li[@data-tab='international-tab']")
    protected Element international_tab;

    @FindBy(xpath = "//li[@data-tab='sports-tab']")
    protected Element sports_tab;

    @FindBy(xpath = "//div[contains(@ng-click,'internationalChannel')]//div[@data-equal-height='more-premium-channel']//p[contains(@class,'blocks_equipment-title')]")
    protected CList<Element> internationalChannels;

    @FindBy(xpath = "//div[contains(@ng-click,'sportsChannel')]//div[@data-equal-height='more-premium-channel']//p[contains(@class,'blocks_equipment-title')]")
    protected CList<Element> sportsChannels;

    @FindBy(xpath = "//a[@data-ng-click='Cancel()']")
    protected Element btncancel;

    @FindBy(xpath = "//div[contains(@data-equal-height,'setup')]")
    protected Element setupInfo;

    // ***************************GUI_Validations_CheckoutPage*************************//

    @FindBy(xpath = "//*[contains(@ng-if ,'ShowFooterMonthlyPrice')]/span[contains(@class,'text-xxlarge bold ng-binding')]")
    protected Element mtly_chrgs_OPO;

    @FindBy(xpath = "//*[contains(@ng-if ,'ShowFooterMonthlyPrice')]/span[2]/span[1]")
    protected Element mtly_chrgs_OPO2;
  
    @FindBy(xpath = "//*[contains(@class, 'column tiny-3 text-right text-xlarge padding-right-zero ng-binding')]")
    protected Element mtly_chrgs_Checkout;

    @FindBy(xpath = "//*[@ng-if = 'BillingEstimateShown']")
    protected Element Product_details_checkout;

    @FindBy(xpath = "//*[@id = 'Make_Changes']")
    protected Element mk_chngs_btn;

    @FindBy(xpath = "//*[@ng-click='ProceedWithOrder()']")
    protected Element checkout_btn;

    @FindBy(xpath = "//*[@ng-model='maskedMailID']")
    protected Element mailid_checkout;

    @FindBy(xpath = "//*[@ng-click='TriggerEmail()']")
    protected Element sendquote;

    @FindBy(xpath = "//*[@ng-repeat='component in Bundle.Components track by $index']")
    protected CList<Element> bndl_components;

    @FindBy(xpath = "//*[@ng-repeat ='product in EstimatedMonthlyProducts track by $index']")
    protected CList<Element> bndl_EstimatedMonthlyProducts;
    
    @FindBy(xpath = "//*[@ng-repeat ='product in EstimatedMonthlyProducts track by $index'][<<<>>>]/div[2]/div[1]")
    protected Element ProductsAndPromotionsName;
    
    @FindBy(xpath = "//*[@ng-repeat ='product in EstimatedMonthlyProducts track by $index'][<<<>>>]/div[1]")
    protected Element ProductsAndPromotionsNameStatus;

    @FindBy(xpath = "//*[@ng-click='CloseBillingEstimatePopup()' and @tabindex = '0']")
    protected Element close_btn_checkout;

    @FindBy(xpath = "//*[@id = 'Preview_Order']")
    protected Element Review_btn;

    @FindBy(xpath = "//div[@class='vert-top inline-block padding-right-small padding-bottom-small update-internet-accessories']//a[@ng-click='UpdateCartNonBundleManualOffers()']")
    protected Element loyaltyUpdate;
    
    @FindBy(xpath = "//div[@id='ManualPromotions']//p")
    protected Element manualOffers;

    @FindBy(xpath = "//li[@data-accordion='combo']")
    protected Element tabRecommendation;

    @FindBy(xpath = "//span[contains(text(),'More Recommendations')][1]")
    protected Element moreRecommendation;

    @FindBy(xpath = "//div[@id='dv_Recommendations']//div[@class='hero-tile']")
    protected CList<Element> platinumOffers;

    @FindBy(xpath = "//li[@ng-controller='ContractsCtrl']//div//span[contains(text(),'Coupon')]")
    protected Element btnCoupon;

    @FindBy(xpath = "//div[@id='Coupon_Code_0']//input[@ng-model='coupon.Code']")
    protected Element enterCoupon;

    @FindBy(xpath = "//div[@class='margin-top-medium verify-coupon-section']//span[@ng-click='ValidateCoupon();']")
    protected Element verifyCoupon;

    @FindBy(xpath = "//button[@id='Coupon_Apply']")
    protected Element applyCoupon;

    @FindBy(xpath = "//button[@ng-click='getDynamicTNs()']")
    protected Element getNumbers;

    @FindBy(xpath = "//label[contains(text(),'Dynamic Assignment')]")
    protected Element DynamicAssignment;

    @FindBy(xpath = "//div[@ng-repeat='coupon in Coupons']//div[@class='text-black text-normal normal-weight margin-bottom-tiny ng-binding']")
    protected Element selectCoupon;

    // Added for MO validation
    // Changed by - Jeevitha S
    @FindBy(xpath = "//input[@id='btnClose']")
    protected Element ClickOnCancelCredit;

    @FindBy(xpath = "//input[@id='btnYesCancelPopup']")
    protected Element ClickonYes;

 
    
    @FindBy(xpath = "//div[contains(text(),'View No Agreement Offers')][1]")
    protected CList<Element> NoagreementOfferList;

    @FindBy(xpath = "//div[contains(text(),'View No Agreement Offers')][1]")
    protected Element NoagreementOffer;



    
    @FindBy(xpath = "//div[@class='w_tiles margin-left-tiny']//div[@name = 'offerTiles' and not(contains(@class,'ng-hide'))]//div[contains(@data-open-modal, 'MyOfferDetails')]/a")
    protected CList <Element> OfferDetailLinkInstall;
    
  
    @FindBy(xpath = "//div[@class='w_tiles padding-left-medium']//div[@name = 'offerTiles' and not(contains(@class,'ng-hide'))]//div[contains(@data-open-modal, 'MyOfferDetails')]/a")
    protected CList <Element> OfferDetailLinkChange;

    @FindBy(xpath = "//div[@data-modal='MyOfferDetails']/div[1]/div[2]")
    protected Element MOInDetails;

    @FindBy(xpath = "//div[@class='vert-top inline-block margin-bottom-large']/a")
    protected Element DetailsClose;
    
  //Added by Rathana
    //For Pricecompare valdiation
        
    @FindBy(xpath="//li[@data-accordion='internet']//span[contains(@class, 'price-text')]/span")
    protected Element InternetPrice;
    
    @FindBy(xpath="//li[@data-accordion='video']//span[contains(@class, 'price-text')]/span")
    protected Element VideoPrice;
    
    @FindBy(xpath="//li[@data-accordion='voice']//span[contains(@class, 'price-text')]/span")
    protected Element VoicePrice;
    
    @FindBy(xpath="//li[@ng-controller='ContractsHeaderCtrl']//div[contains(@class, 'price-text')]")
    protected Element AgreementPrice;
    
    @FindBy(xpath="//span[contains(@class, 'bundlepricewidth')]/span")
    protected Element BundlePrice;
    
    @FindBy(xpath="//span[contains(@class, 'bundlepricewidth')]/span")
    protected CList<Element> BundlePriceList;
    
    @FindBy(xpath="//li[@data-accordion='equipments']//span[contains(@class, 'price-text')]")
    protected Element Equip_AccessPrice;
    
    @FindBy(xpath="//li[@data-accordion='premium']//span[contains(@class, 'price-text')]")
    protected Element PremiumChannelPrice;
    
    @FindBy(xpath="//li[@data-accordion='vasip']//span[contains(@class, 'price-text')]")
    protected Element SecuritySupportPrice;
    
    @FindBy(xpath="//li[@data-accordion='phoneoptions']//span[contains(@class, 'price-text')]")
    protected Element VoiceOptionPrice;
    
    @FindBy(xpath="//li[@data-accordion='setup']//span[contains(@class, 'price-text')]")
    protected Element SetupOptionPrice;
    
    @FindBy(xpath="//li[@data-accordion='NBManualOffers']//span[contains(@class, 'price-text')]")
    protected Element LoyaltyPrice;
    
    @FindBy(xpath="//div[contains(@ng-if, 'ShowAddToCart')]//p[contains(text(), 'Equipment & Extras')]/following-sibling::p/span")
    protected Element EquipExtrasPrice;
    
    @FindBy(xpath="//span[text()='Monthly']/following-sibling::span[1]")
    protected Element MonthlyChargesPrice;
    
    @FindBy(xpath="//div[@data-modal='MyOfferDetails']/div[1]/div[2]//p[contains(@ng-repeat, 'offer')]")
    protected CList<Element> OfferPopupDetails;
    
    @FindBy(xpath="//div[@data-modal='MyOfferDetails']/div[1]/div[2]//div[@class='ng-scope']//div[@class='ng-scope']")
    protected CList<Element> OfferDetailsPrice;
    
    @FindBy(xpath="//a[contains(text(), 'Get Totals')]")
    protected Element GetTotals;
    
    @FindBy(xpath="//a[contains(text(), 'Get Totals')]")
    protected CList<Element> GetTotalsList;
    
    @FindBy(xpath="//span[text()='Monthly']//following-sibling::span[2]/span/span[contains(text(), '$')]")
    protected Element TaxAmount;

    @FindBy(xpath = "//div[@class='column padding-vert-xlarge']//div/div[contains(@class,'column tiny-2')]")
     protected Element reviewBundlePrice;
        
    @FindBy(xpath = "//*[text() ='New Estimated Monthly Subtotal']/../../div[3]")
    protected Element reviewMonthlyChargewoTax;
        
    @FindBy(xpath = "//*[text() ='New Estimated Monthly Charges']/../../div[3]")
    protected Element reviewMonthlyChargeWithTax; 

    
//************************For extender .. Gopal 15 March 2017 ********************//
    
     @FindBy(xpath = "//div[contains(@ng-repeat,'product in equipment.Products') and (contains(@id,'FNE') or contains(@id,'NETGEARWIFI')) and (not(contains(@class,'hide')))]/div[contains(.,'<<<>>>')]")    
     protected Element Extenders;

    //***********************************************************************************************************************
    
    //Added by Jeevitha
    //Premium section MO validaiton
    @FindBy(xpath="//li[@ng-controller='PremiumCtrl']//div[@id='premiumPriceInfo']//span[contains(text(),'channel')]")
    protected CList<Element> PremiumMO; 
    
    @FindBy(xpath="//li[@ng-controller='PremiumCtrl']//div[@id='premiumPriceInfo']//span[contains(text(),'channel')]//following-sibling::span[contains(text(),'$')][1]")
    protected CList<Element> ChannelPriceWOOff;
    
    @FindBy(xpath="//li[@ng-controller='PremiumCtrl']//div[@id='premiumPriceInfo']//span[contains(text(),'channel')]//parent::div")
    protected CList<Element> PremiumMOValidTill;
    
    @FindBy(xpath="//li[@ng-controller='PremiumCtrl']//div[@id='premiumPriceInfo']//b")
    protected CList<Element> PremiumMOCondition;
    
    @FindBy(xpath="//li[@ng-controller='PremiumCtrl']//div[@id='premiumPriceInfo']")
    protected Element PremiumPricemapping;
    
    @FindBy(xpath="//li[@ng-controller='VideoCtrl']//div[@ng-repeat and contains(@class,'selected')]")
    protected Element SelectedTVTile;

    // ******************************************************************************************************************
    // added by poovaraj
    // ******************************************************************************************************************
    @FindBy(xpath = "(//td[text()='Maintenance Plan']/parent::tr[1]//input[1])[1]")
    protected Element lnkMaintenancePlanCheckBox;

    @FindBy(xpath = "//td[text()='Maintenance Plan']/parent::tr[1]//a[1]")
    protected Element lnkMaintenancePlanSetUp;

    @FindBy(xpath = "//td[contains(text(),'Voice Backup')]/parent::tr[1]//a[1]")
    protected Element lnkVoiceBackUpSetUp;

    @FindBy(xpath = "//td[contains(text(),'Jacks')]/parent::tr[1]//a[1]")
    protected Element lnkJackSetUp;
    
    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_lnkOkGN']")
    protected Element lstApplySelectedLines;    

    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucVoiceBatteryBackupSection_lnkOkVBB']")
    protected Element btnVoiceBackUpOK;

    @FindBy(xpath = "//input[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_NO_Jacks']")
    protected Element chkNoJackNeedOption;

    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_lnkJackOK']")
    protected Element btnNoJackOptionOK;

    @FindBy(xpath = "//input[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucPopularProductsSection_gvProducts_chkProducts_7']")
    protected Element chkJackOptionInFeatures;

    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_lnkApply']")
    protected Element btnLECFeaturesApply;
   // ******************************************************************************************************************
    
  //******************************************************************************************************************
    // added by poovaraj  13 Mar 2017
    //******************************************************************************************************************
    @FindBy(xpath = "//select[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_lstProducts']/option[2]")    
    protected Element lstInsideWireMaintenance;   
    
    @FindBy(xpath = "//select[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucVoiceBatteryBackupSection_lstVBBProducts']/option[2]")
    protected Element lstVoiceBackUpSetUpOptions;
    
    @FindBy(xpath = ".//*[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_lstProducts']/option[2]")    
    protected Element lstNoMainteancePlan;
  
    //******************************************************************************************************************
    @FindBy(xpath = "//div[@id='StreamingChat']//label[@for='streaming-chat-yes']")    
    protected Element Yesbutton;
    
    
   //IP TV
    
    @FindBy(xpath = "//div[@class='no-of-iptvs-wrapper']//div[@data-tv-select='active']")    
    protected Element lnkNoOfIPTvs_Selected;
  
    @FindBy(xpath = "//div[@class='no-of-iptvs-wrapper']//div[<<<>>>]")
    protected Element lnkNoOfIPTvs_ToSelect;
	
    //Prepaid Plan selection
    //@FindBy(xpath = "//*[@id='PrepaySwitchBtn']//span[contains(text(),'Get Traditional Plans') or contains(text(),'Get Prepaid Plans')]")
    @FindBy(xpath = "//div[not(contains(@class,'hide'))]/div/div/span[contains(text(),'Get Traditional Plans') or contains(text(),'Get Prepaid Plans') or contains(text(),'View fios IPTV') or contains(text(),'View IPTV Products') or contains(text(),'Classic Products')]")
    protected Element getPrepaidPlan;
	
    //Prepaid Plan selection
    //@FindBy(xpath = "//*[@id='PrepaySwitchBtn']//span[contains(text(),'Get Traditional Plans') or contains(text(),'Get Prepaid Plans')]")
    @FindBy(xpath = "//span[contains(text(),'Get Traditional Plans') or contains(text(),'Get Prepaid Plans') or contains(text(),'View fios IPTV')]")
    protected Element getPrepaidPlanIPTV;
    
    @FindBy(xpath = "//div[@ng-click='ShowOfferDetails(promoSet.PromosetID);']")
    protected Element viewOfferDetails;
    @FindBy(xpath = "//div[@ng-if='promoSet.PromosetID==OfferDetailsId']//div[@class='row']")
    protected Element availableOffersDetails;
    @FindBy(xpath = "//a[contains(text(),'Close')]")    
    protected Element closeButton;
    
    @FindBy(xpath = ".//ul[@id='lineTabs']")
    protected CList<Element> NoOfAddlineTab;
    @FindBy(xpath = "//*[@for='ucGeneralSetupSection_NO_WM']")
    protected Element ChkbxLECNoMaintainance;
    @FindBy(xpath = ".//*[@id='ucGeneralSetupSection_lnkOkGN']")
    protected Element linkOkMaintainanceGN;
    
    
    @FindBy(xpath = "//tr[contains(.,'<<<>>>')]/td/span/input[@type='radio' or @type='checkbox']")
    protected Element BBEOptionsC2G;
    
    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl246_0']")
    protected Element BBEOptionsTOSTvProtectionPlan;
  
    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl66_0']")
    protected Element BBEOptionsTOSTotalProtectionPak250GB;
    
    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl88_0']")
    protected Element BBEOptionsTOSTotalProtectionPak1TB;
    
    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl145_0']")
     protected Element BBEOptionsTOSPremiumTechnicalSupportPerUse;
    
    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl202_0']")
     protected Element BBEOptionsTOSPremiumDeviceProtectionPlan;
    
    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl224_0']")
    protected Element BBEOptionsTOSDeviceProtectionPlan;
    
    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl173_0']")
    protected Element BBEOptionsTOSWholeHomeProtectionPlan;
    
    //***********************************************************************************************
    //Added new object on 21 Apr 2017
  //***********************************************************************************************
    
    
    @FindBy(xpath = ".//*[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_lstProducts']/option[3]")    
    protected Element lstWMRInsideWireMaintenance;

    
    @FindBy(xpath = "//div[@ng-if='!IsEquipmentDeliveryEligible && !EquipmentDeliveryLoading']")
    protected Element EquipmentReturnOptionTextList;
    
    
//**********************LEC Features -- Gopal************************************
    @FindBy(xpath = "//label[not(contains(@class,'c_on')) and @for='ctl08_NO_Jack'] | //*[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_NO_Jacks']")
    protected Element ChkbxLECNoJacks;

   
    
    //@FindBy(xpath = ".//*[@id='ctl08_lnkAdd'] | //*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_lnkAdd']")
    @FindBy(xpath = "//a[@id='ctl08_lnkAdd']")
    protected Element ADDLinkJack;

    @FindBy(xpath = ".//*[@id='ctl08_lnkJackOK'] | //*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucJacksSection_lnkJackOK']")
    protected Element BtnLECJackOk;

    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_setup1']")
    protected Element Maintenance_Plan_Window;

    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucVoiceBatteryBackupSection_setup1']")
    protected Element Voice_Backup_Power_Window;

    @FindBy(xpath = "//*[@class = 'subCollapsiblePanelTab_pantone' and contains(text(), 'Jacks/Fixed Fee')]")
    protected Element Jacks_Window;  
    
    @FindBy(xpath = "//td[contains(text(),'<<<>>>')]/preceding-sibling::td//input")
    protected Element Jacks_Type;  
  
    @FindBy(xpath = "//td[contains(.,'Maintenance')]/following-sibling::td[2]//label[contains(@id, 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucPopularProductsSection_gvProducts_labellnkProducts')]/a")
    protected Element setup_Maintenance_Plan;	
  
    @FindBy(xpath = "//td[contains(.,'Voice Backup')]/following-sibling::td[2]//label[contains(@id, 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucPopularProductsSection_gvProducts_labellnkProducts')]/a")
    protected Element setup_Voice_Backup_Power;
    
    @FindBy(xpath = "//td[contains(.,'Jacks')]/following-sibling::td[2]//label[contains(@id, 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucPopularProductsSection_gvProducts_labellnkProducts')]/a")
    protected Element setup_Jacks;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucGeneralSetupSection_lstProducts']//*[contains(text(), '<<<>>>')]")
    protected Element Inside_Wire_Maintainance;
  
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucVoiceBatteryBackupSection_lstVBBProducts']//*[contains(text(),'<<<>>>')]")
    protected Element Battery_options;
    
    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_btnSaveActiveSection']")
    protected Element termsok;
    
    
  //**********************C2G LEC Features -- Suman************************************
    
    @FindBy(xpath = "//*[@id='ContentPlaceHolder1_ContentPlaceHolder1_lcwLineInformationUC_lnkEditDirectory']")
    protected Element MainDirectoryListingEdit;
     
    @FindBy(xpath = "//*[@id='ctl08_txtFirstName']")
    protected Element txtMainDirectoryFirstName;
    
    @FindBy(xpath = "//*[@id='ctl08_txtLastName']")
    protected Element txtMainDirectoryLastName;
    
    @FindBy(xpath = "//*[@id='ctl08_btnApplyListing']")
    protected Element btnMainDirectoryApplyListing;   
    
    @FindBy(xpath = "//*[@id='ctl08_btnDirectoryListingOK']")
    protected Element btnMainDirectoryApplyListingok;    
    
    @FindBy(xpath = "//*[@id='ContentPlaceHolder1_ContentPlaceHolder1_lcwLineInformationUC_lnkIntercept']")
    protected Element linkIntercept;      
    
    @FindBy(xpath = "//*[@for='ctl08_chkSelectAll']")
    protected Element linkInterceptSelectAll;    
    
    @FindBy(xpath = "//*[@id='ctl08_btnInterceptOkMain']")
    protected Element linkInterceptok;   
    

    //For Standalone Marketing offer
    @FindBy(xpath = "//div[@name = 'offerTiles' and @ng-if='<<<>>>']//div")
    protected Element standAloneOfferTile;
    
    @FindBy(xpath = "//div[@name = 'offerTiles' and @ng-if='<<<>>>']//div[@data-open-modal='MyOfferDetails']")
    protected Element standAloneOfferDetailsLink;
    
    @FindBy(xpath = "//div[@class='w_tiles margin-left-tiny']//div[@name = 'offerTiles' and not(contains(@class,'ng-hide'))]/a")
    protected CList<Element> InstallOfferTileList;
    
    @FindBy(xpath = "//div[@class='w_tiles padding-left-medium']//div[@name = 'offerTiles' and not(contains(@class,'ng-hide'))]/a")
    protected CList<Element> ChangeOfferTileList;
    
    @FindBy(xpath="//span[@id='monthlyCart']//span[contains(text(),'includes')]//span")
    protected Element ChangeTaxAmount;
    
    @FindBy(xpath="//span[@id='monthlyCart']//span[@data-new-tax-price]")
    protected Element NewMonthlyCharges;
    
    @FindBy(xpath = " //input[@id='Contract_Term_TwoYearRetainB']")
    protected Element contractCurrentTerm;
    
    @FindBy(xpath = "//label[@for='Agree_BatteryBackup' and (contains(text(),'<<<>>>'))]")
    protected Element batterycustomer;
    @FindBy(xpath = "//li[contains(@ng-controller,'PhoneOptionsBaseCtrl')]//div[@ng-if='$parent.SectionVisible.PhoneOption']")
    protected Element voiceDetails;
    
    @FindBy(xpath = "//product-tile-list[@productlist='annualInternetData' or @productlist='StandaloneInternetData']/div/div[not(contains(@class,'hide')) and not(contains(@class,'selected'))][1]/div/div[1]/p[1]")
    protected Element firstHighSpeedInternet;
    
    @FindBy(xpath = "//div[@data-equal-height='Internet']/p[1]/span[contains(@ng-if,'MonthToMonth') or contains(@ng-if,'2-Year Agreement')]")
    protected Element firstHighSpeedInternetUpgrade;

    
    @FindBy(xpath = "//product-tile-list[@productlist='videoData']//div[not(contains(@class,'selected'))]/div[1]/div/p[1]")
    protected Element firstHighestVideo;

	//locators - Surya for equipments sync
    @FindBy(xpath = "//img[not(contains(@id,'equipmentLoading'))]")
    protected WebElement EquipmentLoading;

    @FindBy(xpath = "//img[not(contains(@class,'vzrf-loader-page-overlay active'))]")
    protected WebElement OPOLoading;
    
    @FindBy(xpath = "//input[@name='txtxpsEmail']")
    protected Element fastpassemail;
    @FindBy(xpath = "//div[contains(@ng-click,'LaunchXPSSaveOrder()')]/button")
    protected Element btnFastPassC2G;
    @FindBy(xpath = "//input[@id='btnYes']")
    protected Element yesButton;
    @FindBy(xpath = "//input[@id='btnSaveOrder']")
    protected Element btnSaveOrder;
    @FindBy(xpath = "//span[@id='ContentPlaceHolder1_ucOrderConfirmation_lblXPSMON']")
    protected Element Mon;
    
    @FindBy(xpath = "//label[@for='chkDisclosure']")
    protected Element chkDisclosure;
    
    @FindBy(xpath = "//div[contains(text(),'Invalid')]")
    protected Element invalidCoupon;
    @FindBy(xpath = "//div[@data-panel='products' and contains(@class,'active')]")
    protected Element enableProducts;
    @FindBy(xpath = " //div[contains(@ng-if,'Battery') and (not(contains(@class,'hide')))]")
    protected Element batterybcp;
    @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAccountProfileSection_AccountTreeViewt1i']")
    protected Element ExistingBTN;
    @FindBy(xpath = "//div[contains(@ng-repeat,'product in productlist') and (not(contains(@class,'hide')))]/*[contains(text(),'Show Custom TV Options')]")
    protected Element showCustomTvLink;
    @FindBy(xpath = "//div[@ng-show='ShowCustomSection']//*[contains(@ng-repeat,'product in productlist')][1]")
    protected Element clickCustomTv;
    @FindBy(xpath = "//div[@ng-show='headerResponse.Response.IsRequiredTag' and (not(contains(@class,'hide')))]/preceding-sibling::div[1]")
    protected CList<Element> RequiredList;
    @FindBy(xpath = "//div[@ng-show='ShowCustomSection']//*[contains(@ng-repeat,'product in productlist')]/div/p/span[contains(text(),'<<<>>>')]")
    protected Element selectCustomTv;

	// port out TN assignment by Gopal on 07/12/2017
	
    @FindBy(xpath = "//*[@id = 'liOwnNumberid']")
    protected Element BringYourOwnNumber;
    
    @FindBy(xpath = "//*[@ng-model = 'PortTN']")
    protected Element PortTN;
		
    @FindBy(xpath = "//*[@ng-click = 'getWinback(this)']")
    protected Element btnchkavailability;
  
    @FindBy(xpath = "//*[@for = 'custslamN']")
    protected Element Slammed;
 
    @FindBy(xpath = "//*[@ng-model = 'returnReasonId']")
    protected Element Reasonforverizon;
    
    @FindBy(xpath = "//*[@id = 'nameonBill']")
    protected Element billingname;
  
    @FindBy(xpath = "//*[@id = 'accNum']")
    protected Element accNum;
    
    @FindBy(xpath = "//*[@id = 'pswPin']")
    protected Element pswPin;
    
    @FindBy(xpath = "//*[@for = 'addressY']")
    protected Element rbtnyes;
    
    @FindBy(xpath = "//*[@ng-click = 'SaveWinbackDetails(this)']")
    protected Element btnSaveWinbackDetails;
  
    @FindBy(xpath = "//*[@ng-click = 'setAssignedPortedTN(tn)']")
    protected Element AssignNumber;
        
    @FindBy(xpath = "//*[@id = 'FDV_Phone_Options_SaveChanges']")
    protected Element FDVsavechanges;
    
    @FindBy(xpath ="//div[@class='no-of-tvs-wrapper' or @class='no-of-iptvs-wrapper']//div[(contains(@class,'no-of-tvs') or contains(@class,'no-of-iptvs')) and (@data-tv-select='active')]")
    protected Element SelectedTv1;
    
    
    //*************Xpaths for Central Alarm router by Mounika*****************//
    @FindBy(xpath = "//label[@for='rdbCentralAlarmSelectedYes']")
    protected Element AlaramYes;
    @FindBy(xpath = "//label[@for='rdbCentralAlarmSelectedNo']")
    protected Element AlaramNo;
    @FindBy(xpath = "//div[not(contains(@class,'hide'))]/div[@data-equal-height='internet-FNE']/p[contains(.,'<<<>>>')]")
    protected Element AlaramRouter;
    
// Transport from Copper to Fiber
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_lnkNewCPCIMore']")
    protected Element Moreoptions;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_dropdownTransportMethod']")
    protected Element TransportMethod;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_lnkApplyForCallingPlan']")
    protected Element ApplytoSelectedLine;
    
    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_lnkNextForCallingPlan']")
    protected Element OkButton;
    
    @FindBy(xpath = "//*[@id = 'dropdownCallingPackage_new']")
    protected Element Lecvoicepackage;
    

    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_dropdownCallingPackage']")
    protected Element VerizonCallingPackage;
    
    @FindBy(xpath = "//*[@id = 'FNE_Quantity_P4511']//a[@class = 'vzicon icon-plus left margin-left-tiny ']")
    protected Element Boosters;
    
    @FindBy(xpath = "//div[contains(@class,'active')]//div[@ng-repeat='reason in RWHSReasons']/label[contains(text(),'<<<>>>')]")
    protected Element reasonForMigration;
    
    @FindBy(xpath = "//a[@ng-click='MakeIPTVSwitchCall()']")
    protected Element continuebtn;
    @FindBy(xpath = "//label[@for='CCPNone']")
    protected Element customerCurrentProvider;
    @FindBy(xpath = "//*[@ng-click = 'ToggleNoAgreementOffer()']")
    protected Element NoAgreementOffers;
    @FindBy(xpath = "//li[@ng-controller='ContractsCtrl']//div/p[contains(text(),'Try')]")
    protected Element contractTryMe2year;
    

 // For Reverse IRB
     
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_AllProductsLink']")
     protected Element lnkAllProducts;
     
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UpAllProductsSection_txtSearchByISOCUSOC']")
     protected Element TxtBoxUsoc;
     
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UpAllProductsSection_lnkBtnSearch']")
     protected Element UscoSearchButton;
     
     @FindBy(xpath = "//*[text() = '<<<>>>']/preceding-sibling::td/input[contains(@id, 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UpAllProductsSection_IOSCGrid_chkBoxTNs')]")
     protected Element UsocCheckBox;
     
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UpAllProductsSection_lnkApply']")
     protected Element UsocApplyButton;
     
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_lnkApply']")
     protected Element ProductsApplyButton;
     
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_upAddlProdHeader']")
     protected Element AdditionalProductsHeader;
     
     @FindBy(xpath = "//*[@class = 'subCollapsiblePanelTab_pantone'  and contains(text(), 'Required Product Group')]")
     protected CList<Element> RequiredProductGroups;
         
     @FindBy(xpath = "//*[@class = 'subCollapsiblePanelTab_pantone'  and contains(text(), 'Required Product Group')]")
     protected Element RequiredProductGroup;
     
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_RequiredProductGroupRepeater_ProductsRepeater_<<<>>>_chkAdditionalProduct_0']")
     protected Element RequiredFID;
            
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_PrimaryProductMandatoryFidsRepearter_ctl00_0']")
     protected Element ProductNWTFeatures;
         
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_lnkAdditionalProductOk']")
     protected Element FIDSOK;
     
     @FindBy(xpath = "//*[@name = 'ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$cpciFeaturesDirectorySection$ctl00$ucAdditionalProducts$PrimaryProductMandatoryFidsRepearter$ctl00$ctl00']")
     protected Element FIDCOMM;
   
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UpAllProductsSection_ErrorMessageControler_lblMessage']")
     protected Element ErrorMessage;
     
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UpAllProductsSection_btnClose']")
     protected Element UsocCloseButton;

     @FindBy(xpath = "//*[contains(@id , 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAccountProfileSection_AccountTreeViewt')]//span[contains(text(), 'RJ11W')]")
     protected Element NPDWallJack;
   
     @FindBy(xpath = "//*[@id = 'productMenuforQuantifyUSOC']//a[contains(text(), 'Review Setup')]")
     protected Element ReviewSetup;
   
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_HyperLinkOptionalFidPrimaryPrdocut']")
     protected Element BtnOptionalFIDs;
     
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_PrimaryProductOptionalFidsRepearter_ctl00_0']")
     protected Element FixedFee;
     
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_upAdditionalSaveSection']")
     protected Element ProductPane;
   
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_UcDirectoryListingSection_ddlMainDirPubStatus']")
     protected Element PublicationStatus;
     @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_callingplanuc_SupervisorOverrideChkBoxNew']")
     protected Element Override;
     @FindBy(xpath = "//*[contains(text(), '<<<>>>')]/following::input[contains(@id , 'ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucAdditionalProducts_PrimaryProductOptionalFidsRepearter_ctl00')]")
     protected Element OptionalFIDS;
     @FindBy(xpath = "//input[@id='VZWDataOffer']")
     protected Element affinitycoupon;
     
     @FindBy(xpath = "//span[contains(@ng-click,'ValidateVZWDataOffer()')]")
     protected Element verifyoffercode;
    
    
     // CoHo Products
  // CoHo Products ----------- @Author Siva Ram Lanka -----------------
 
     @FindBy(xpath = "//*[@ng-click = 'qtyCurrentItemIndex=qtyCurrentItemIndex + ((qtyCurrentItemIndex+1)==qtyValues.length?0:1);selectedValue=qtyValues[qtyCurrentItemIndex].Value;$parent.SetSelectedDVRItem(productObject,productList,productSelectType,selectedValue,equipmentDetails)']")
     protected Element NumberofDVRs;
     
     @FindBy(xpath = "//div[not(contains(@class,'ng-hide'))]/div[contains(@ng-click,'ShopRecordingItem') and not(contains(@class,'selected')) and not(contains(@class,'ng-hide'))]//*[text()='<<<>>>']")
     protected Element DVRRecordingOption;
     
     // CoHo Products ----------- @Author Siva Ram Lanka-----------------
     @FindBy(xpath = "//*[contains(text(), 'Smart Home Accessories + Security, Support & Storage')]")
     protected Element SmartHomeAccessoriesSecuritySupportStorage;
     
     @FindBy(xpath = "//*[contains(text(),'GethrHome Nest Starter Kit _LN')]")
     protected Element GethrHomeNestStarterKitLN;
     
     @FindBy(xpath = "//*[contains(text(),'GethrHome Nest Security Starter Kit_LN')]")
     protected Element GethrHomeNestSecurityStarterKitLN;
     
     @FindBy(xpath = "//*[text()='Smart Home Accessories']")
     protected Element SmartHomeAccessories;
     
     @FindBy(xpath = "//*[contains(text(),'Equipment Delivery and Return')]")
     protected Element EquipmentDeliveryandReturn;
     
     @FindBy(xpath = "//*[@ng-controller = 'EquipmentDeliveryHeaderCtrl']//*[text() = 'Accessories']")
     protected Element Accessories;
     
     @FindBy(xpath = "//*[contains(text(),'<<<>>>')]")
     protected Element AccessoriesShipping;
     
     //-------------------------------Edit PIN------------- @Author Bharathi-----------------//
     @FindBy(xpath="//a[contains(text(),'Edit PIN')]")
     protected Element editPIN;
     
     @FindBy(xpath="/html/body/div[13]")
     protected Element editPINPopup;
     
     @FindBy(id="PinNumber")
     protected Element pinNumber;
     
     @FindBy(xpath="/html/body/div[14]/div/div[3]/div/div[3]/button")
     protected Element savePIN;
     
     @FindBy(xpath="//div[contains(text(), 'PIN')]")
     protected Element getPIN;
     
     @FindBy(xpath="//*[@id='ContainerKnobs']/section/div[2]/div[3]/div[1]/ul[1]/li[2]/a")
     protected Element productTools;

     //-------------------------------Change Password------------- @Author Bharathi-----------------//
     @FindBy(xpath="//a[contains(text(),'Change Password')]")
     protected Element changePwd;
     
     @FindBy(xpath="/html/body/div[13]")
     protected Element Popup;
     
     @FindBy(xpath="//div/input[@ng-model='NewPassword']")
     protected Element passwordTextbox;
     
     @FindBy(xpath="//div/button[contains(text(),'Change')]")
     protected Element changePwdBtn;
     
     @FindBy(xpath = "//*[@ng-controller = 'DataHeaderCtrl']//*[text() = 'please review']")
     protected Element PleaseReview;
     //-------------------------------Digital COupon----------------------//

     @FindBy(xpath = "//div[not(contains(@data-agreement-selection,'active')) and @data-equal-height='offer']")
     protected Element notselectedcontract;
     
     @FindBy(xpath = "//div[contains(text(),'Coupon offer is not qualified')]")
     protected Element invalidDigitalCoupon;
     
     @FindBy(xpath = "//div[ @ng-repeat='coupon in DigitalCoupons']//div[@id='Coupon_Code_0']//input[@ng-model='coupon.Code']")
     protected Element Digitalcoupon;
    
     
     @FindBy(xpath = "//div[contains(text(),'Coupon offer is qualified')]")
     protected Element ValidDigitalCoupon;
     
     @FindBy(xpath = "//div[@class='margin-top-medium verify-coupon-section']/span[@ng-click='ValidateDigitalCoupon();']")
     protected Element verifyDigitalCoupon;
     
     @FindBy(xpath = "//product-tile-list[@typeofprd='Battery']/div/div[2 and not(contains(@class,'hide'))][2]")
     protected Element declinebatterybackup;
     
     @FindBy(xpath = "//product-tile-list[@typeofprd='Battery']/div/div[2 and not(contains(@class,'hide'))][2]/div")
     protected Element textbatterybackup;
//---------------------Digital Billing Update By Mithra G--------------------------------------
     
     @FindBy(xpath = "//p[@ng-click='CallDataEnrollDigiScripts()']")
     protected Element  Digital_billing_enrollment;
     
     @FindBy(xpath = "//b[contains(text(),'Please read to the customer')]")
     protected Element  Digital_billing_enrollment_Message;
     
     @FindBy(xpath = "//label[@for='EnrollDigitalBill']")
     protected Element  Digital_billing_enrollment_NJCheckbox;
     
     @FindBy(xpath = "//div[contains(text(),'please review')]")
     protected Element  Digital_billing_enrollment_review;
     
     @FindBy(xpath = "//button[@id='Preview_Order' and not(contains(@disabled,'disabled'))]")
     protected Element revbtn;
     
     // Mandatory Battery option updated by Gopal on 01/28

     @FindBy(xpath = "//*[@for = 'ContentPlaceHolder1_ContentPlaceHolder1_lcwLineInformationUC_FeaturesUC_gvProducts_chkProducts_2' and  @class = 'label_check']")
     protected Element MandatoryBatteryBackup;
     
     @FindBy(xpath = "//div[contains(@ng-if,'TwoYearRestart')][1]/div[@data-agreement-selection='active']")
     protected Element SelectedcontractRenew2Year;
     
     @FindBy(xpath = "//div[contains(@ng-if,'TwoYearRestart')][1]/div[1]")
     protected Element RenewContract;
   
     @FindBy(xpath = "//*[text() = 'Migration to Fios']")
     protected Element MigrationtoFiosButton;
     
     @FindBy(xpath = "//*[@ng-click = 'SelectFDVMigrate()']")
     protected Element SelectFDVMigrateButton;
     
     @FindBy(xpath = "//div[contains(text(),'Error sending mail. Please try again')]")
     protected Element SendQuoteresponse;
     
     @FindBy(xpath = "//div[@data-agreement-selection='active']")
     protected Element selectedContarct;
     
     @FindBy(xpath = "//div[@data-equal-height='offer']/p[contains(@ng-repeat,'offer')][1]/span[contains(text(),'$10')]")
     protected Element autoPayM2MAccept;
     @FindBy(xpath = "//div[@data-equal-height='offer']/p[contains(@ng-repeat,'offer')][2]/span[contains(text(),'$10')]")
     protected Element autoPay2YearAccept;
     @FindBy(xpath = "//div[@name='offerTiles'][4]/div[@data-equal-height='offer']/p[contains(@ng-repeat,'offer')]/span[contains(text(),'Declined')]")
     protected Element autoPayM2MDecline;
     @FindBy(xpath = "//div[@name='offerTiles'][2]/div[@data-equal-height='offer']/p[contains(@ng-repeat,'offer')]/span[contains(text(),'Declined')]")
     protected Element autoPay2YearDecline;
     
     @FindBy(xpath = "//label[@for='Contract_Term_TwoYearRetainB' or @for='Contract_Term_TwoYearRetainS']")
     protected Element keepCurrentTerm;
	 
	 @FindBy(xpath = "//div[@id='ContentPlaceHolder1_ContentPlaceHolder1_ErrorMessages_lblMessage']")
     protected Element lecErrorMessgage;
	 
	 @FindBy(xpath = "//div[@ng-show='contractsData.length>0' and not(contains(@class,'hide'))]")
     protected Element Offers;
	 
	 @FindBy(xpath = "//a[contains(@ng-click,'GetMonthlyPrice()')]")
     protected Element getTotals;
	 
	//Added by Naresh
     @FindBy(xpath = "//span[contains(text(),'New Estimated Monthly Subtotal')]")
     protected Element scrollToViewRegionalSportsFee;
     
     @FindBy(xpath = "//*[@class='column padding-vert-xlarge']/div[@class='row margin-bottom-micro ng-scope']/div[contains(text(),'Regional Sports Network Fee')]/following-sibling::div")
     protected Element getRegionalSportsFee;
     
     @FindBy(xpath = "//*[@class='column padding-vert-xlarge']/div[@class='row margin-bottom-micro ng-scope']/div[contains(text(),'Fios TV Broadcast Fee')]/following-sibling::div")
     protected Element getFiosTVBroadcastFee;
     
     //Soham - AP = PFB Np
     @FindBy(xpath="//div[@name='offerTiles']/div[@class='tiles_content']/span/span[contains(text(),'2-Year Agreement')]//parent::span//parent::div/p/span[contains(text(),'Auto Pay Offer')]")
     protected Element contractAPPFB_2yr;
     @FindBy(xpath="//li[contains(text(),'24 Month Bundle Early Termination Fee')]")
     protected Element oneTimeCharges_EarlyTerminationFee;
     @FindBy(xpath="//div[contains(text(),'One-Time Charges and Credits')]")
     protected Element oneTimeCharges;
     @FindBy(xpath="//div[contains(text(),'One-Time Charges and Credits')]//parent::div//parent::div[@class='padding-bottom-small padding-top-tiny']/div[2]")
     protected Element oneTimeCharges_list;
     
     
     //Mounika-Disconnect Flow
     
     @FindBy(xpath = "//li[contains(@class,'panel-options-dynamic') and contains(@ng-show,'IsOrderStartedFromQnA')]")
     protected Element clickQA;
	 
	 @FindBy(xpath = "//div[@data-ui-view='repGuidance']//*[contains(.,'<<<>>>')]")
	    protected Element getQuestionerType;
	 
	 @FindBy(xpath = "//div[@class='qa_set']/ul[contains(@class,'qa_answers')]//label[starts-with(.,'<<<>>>')]")
	    protected Element RGQuestions;
	 @FindBy(xpath = "//div[@class='qa_set']//button[contains(text(),'Next Step')]")
	    protected Element btnRGNext;
	    @FindBy(xpath = "//div[@class='qa_set']//button[contains(text(),'Next Step')]")
	    protected CList<Element> btnRGNextList;
	    
	    @FindBy(xpath = "//*[@id='switchType']")
	    protected Element txtBTN;
	    @FindBy(xpath = "//*[@id='switchType']")
	    protected CList<Element> txtBTNList;

	    @FindBy(xpath = "//*[@id='divLoadPortEligibility']/div[3]/button")
	    protected Element btnBTNxt;

	    @FindBy(xpath = "//*[@id='divLoadPortEligibility']/div[3]/button")
	    protected CList<Element> btnBTNxtList;
	    
	    protected By addressValidated = By.xpath("//div[@data-ui-view='repGuidance']//b[contains(.,'Address Validated')]");
	    protected By Disconnect = By.xpath("//div[@data-ui-view='repGuidance']//*[contains(.,'LOYAL')]");
	    @FindBy(xpath = "//button[@ng-click='salesRequiredCheck()']")
	    protected Element saleswindow;
	    
	    //@FindBy(xpath = "//button[@data-ng-click='CancelOrdercall()']")
  		@FindBy(xpath = "//ul[@class='tiny-block-grid-1 small-block-grid-2 margin-top-tiny p-70']/li[2]/button")
	    protected Element confirmYes;
	    
	    @FindBy(xpath = "//input[@id='cbxRCWETFConfirmation']")
	    protected Element checkbxConfirm;

	    @FindBy(xpath = "//input[@id='btnSaveAndContinue']")
	    protected Element btnSaveContinue;
	    @FindBy(xpath = "//input[@id='Button3']")
	    protected Element btnproceed;
	    @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_interceptsSection_ctl00_btnOkMain']")
		protected Element InterceptsOK;
	    @FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$FooterContent$btntabUISaveContinue']")
	    protected Element btnFiosSaveContinue;
	    @FindBy(xpath = "//input[@id='SaveAndContinue']")
	    protected Element btnFDVSaveContinue;
	    @FindBy(xpath = "//input[@id='Button1g']")
	    protected Element disconnectSaveContinue;
	    @FindBy(xpath = "//body[@onunload='OPOUnLoad()']")
	    protected Element OPOPage;
	    
	 // DisConnect Page'
	    @FindBy(xpath = "//select[@id='ddlRCWVerizonReasonCategory']")
	    protected Element DisconnectLoyaltyCategory;

	    @FindBy(xpath = "//select[@id='ddlRCWVerzionDisconnectReasons']")
	    protected Element DisconnectLoyaltyReason;
	    
	    @FindBy(xpath = "//div[@data-modal='phone-options' and contains(@class,'active')]")
	    protected Element phoneOptions;
	    
	    //getting all displayed internet
	    @FindBy(xpath = "//li[@data-accordion='internet']/following-sibling::li[1]//div[contains(@ng-repeat,'product') and not(contains(@class,'hide'))]")
	    protected CList<Element> listInternet;
	 
	    @FindBy(xpath = "//select[@id='ContentPlaceHolder1_ContentPlaceHolder1_cpciFeaturesDirectorySection_ctl00_ucVoiceBatteryBackupSection_lstVBBProducts']/option[2]")
	    protected Element batteryoptions;
	    
	  
	 // Techsure - Added by Naresh
	    
		  //@FindBy(xpath="//*[@id='txtParentFirstName']")
		    @FindBy(xpath="//*[@id='PrimaryFName_0']")
		    protected Element VAS_FirstName;
		    
		    //@FindBy(xpath="//*[@id='txtParentLastName']")
		    @FindBy(xpath="//*[@id='PrimaryLName_0']")
		    protected Element VAS_LastName;
		    
		    @FindBy(xpath="//div[@ng-repeat='vasDetail in vasProductsData' and @class='w_blocks selected ']/div/p[1]")
		    protected Element VASProductedSelectedTile;
		    
		    //@FindBy(xpath="//*[@id='chkDGAdultSubscription']")
		    @FindBy(xpath="//a[@ng-click='IncreaseAdult();']")
		    protected Element VAS_LifeLock_Adult;
		    
		    //@FindBy(xpath="//*[@id='chkDGChildSubscription']")
		    @FindBy(xpath="//a[@ng-click='IncreaseChild();']")
		    protected Element VAS_LifeLock_Junior;
		    
		    //@FindBy(xpath="//*[@id='txtAdultFirstName']")
		    @FindBy(xpath="//input[@id='AdultFName_0']")
		    protected Element VAS_LifeLock_Adult_FirstName;
		    
		    //@FindBy(xpath="//*[@id='lnkAddAdultSubscription']")
		    @FindBy(xpath="//label[contains(text(),'Add another subscription')]")
		    protected Element VAS_LifeLock_Adult_AddSubscription;
		   
		    //@FindBy(xpath="//*[@id='txtAdultLastName']")
		   
		    @FindBy(xpath="//input[@id='AdultLName_0']")
		    protected Element VAS_LifeLock_Adult_LastName;
		    
		    @FindBy(xpath="//input[@id='AdultEmail_0']")
		    protected Element VAS_LifeLock_Adult_Email;
		    
		    //@FindBy(xpath="//tr[@class='trAdultUserInfo']/following-sibling::tr/td/input[contains(@id,'txtAdultFirstName2')]")
		    @FindBy(xpath="//input[@id='AdultFName_1']")
		    protected Element VAS_LifeLock_Adult_FirstName_2;
		    
		   // @FindBy(xpath="//tr[@class='trAdultUserInfo']/following-sibling::tr/td/input[contains(@id,'txtAdultLastName2')]")
		    @FindBy(xpath="//input[@id='AdultLName_1']")
		    protected Element VAS_LifeLock_Adult_LastName_2;
		    
		   // @FindBy(xpath="//tr[@class='trAdultUserInfo']/following-sibling::tr/td/input[contains(@id,'txtAdultEmail2')]")
		    @FindBy(xpath="//input[@id='AdultEmail_1']")
		    protected Element VAS_LifeLock_Adult_Email_2;

		    @FindBy(xpath="//*[@id='lnkAddChildSubscription']")
		    protected Element VAS_LifeLock_Junior_addSubLink;
		    
		   // @FindBy(xpath="//tr[@class='trChildUserInfo']/following-sibling::tr/td/input[contains(@id,'txtChildFirstName2')]")
		    @FindBy(xpath="//input[@id='ChildFName_1']")
		    protected Element VAS_LifeLock_Child_FirstName_2;
		    
		    //@FindBy(xpath="//tr[@class='trChildUserInfo']/following-sibling::tr/td/input[contains(@id,'txtChildLastName2')]")
		    @FindBy(xpath="//input[@id='ChildLName_1']")
		    protected Element VAS_LifeLock_Child_LastName_2;

		    
		    @FindBy(xpath="//input[@id='ChildFName_0']")
		    protected Element VAS_LifeLock_Junior_FirstName;
		    
		    @FindBy(xpath="//input[@id='ChildLName_0']")
		    protected Element VAS_LifeLock_Junior_LastName;
		    
		    @FindBy(xpath="//input[@pppname='TechSure']")
		    protected Element VASProduct_TechSure_ProductsPage;
		    
		    @FindBy(xpath="//input[@pppname='TechSure Premium']")
		    protected Element VASProduct_TechSurePremium_ProductsPage;
		    
		    @FindBy(xpath="//input[@pppname='TechSure Plus']")
		    protected Element VASProduct_TechSurePlus_ProductsPage;
		    
		    @FindBy(xpath="//div[@ng-repeat='vasDetail in vasProductsData']/div/p[contains(text(),'<<<>>>')]")
		    protected Element VASProduct_OPOPage;
		    
		    @FindBy(xpath="//label[@for='fullcoverage']")
		    protected Element VASProduct_TechSurePremium_Coverage;
		    
		    @FindBy(xpath="//div[@ng-repeat='vasDetail in vasProductsData']/div/p[contains(text(),'<<<>>>')]")
		    protected Element VASProduct_defaultProducts;
		    
		 
		     //TechSure -Added by Naresh
		     @FindBy(xpath = "//div[contains(text(),'New')]/following-sibling::div/div[contains(text(),'TechSure')]")
		     protected Element scrollToViewTechSure;
		     
		     @FindBy(xpath = "//div[contains(text(),'New')]/following-sibling::div/div[contains(text(),'TechSure')]/following-sibling::ul/li")
		     protected CList<Element> getTechSureProducts;
		     
		     @FindBy(xpath = "//div[contains(text(),'New')]/following-sibling::div/div[contains(text(),'LifeLock Select Adult')]/parent::div/following-sibling::div")
		     protected Element getLifeLockAdultCharges;
		     
		     @FindBy(xpath = "//div[contains(text(),'New')]/following-sibling::div/div[contains(text(),'LifeLock Select Junior')]/parent::div/following-sibling::div")
		     protected Element getLifeLockJuniorCharges;

		     @FindBy(xpath = "//input[@value='Standalone_0_20']")
		     protected Element wholeHomeDeviceProtectionPlan;
		     
		     @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl270_0']")
		     protected Element WHDPP_Accep_terms;
	     
             @FindBy(xpath = "//label[@class='saveClick']")
		     protected Element VASSaveandContinueTechSure;
   
     
             
        	 // **********Lakshmi*********Auto Pay Renewal************//
        	 	 
        		 @FindBy(xpath = "//label[@for='chkAutopayofferPromo']")
        		 protected Element clickAutoPayCheckbox;
        		 
        		 @FindBy(xpath = "//label[@for='chkAutopayofferPromo' and @aria-checked='true']")
        		 protected Element autopayCheckboxChecked;

        		 @FindBy(xpath = "//label[@for='chkAutopayofferPromo' and @aria-checked='false']")
        		 protected Element autopayCheckboxUnchecked;
        		 	 
        		 @FindBy(xpath = "//input[@id='chkAutopayofferPromo' and @checked='checked']")
        		 protected Element autoPayChecked;	 
        		 
        		 @FindBy(xpath = ("//div[@name='offerTiles'][1]/a/span"))
        		 protected Element autopayOfferClk;	 
        		 
        		 @FindBy(xpath ="//a[@class='vzicon icon-close medium text-grey-3']")
        		 protected Element closeDetailsLink;
        		 
        		 @FindBy(xpath ="//div[@class='modal_footer padding-vert-medium text-grey-2 bold']/div/div/div/a")
        		 protected Element clDetailsLink;
        		 
        		 
        		 @FindBy(xpath ="//div[@name='offerTiles'][2]/a/div/div")
        		 protected Element saAutopayOffSel;
        		 		 
        		 //*************Bharathi**** Customer Value Added offer*************//
        		    @FindBy(xpath = "//*[contains(text(),'Valued Customer + Additional offers')]")
        		    protected Element Valueaddedoffersection;
        		    
        		    @FindBy(xpath="//div[not(contains(@class,'ng-hide'))]/div[contains(@ng-click,'SetSelectedShopItemForRetainOffers_MRC')]//*[contains(.,'<<<>>>')]")
        		    protected Element SelectRetainOffer;
        		    
        		    @FindBy(xpath="//div[not(contains(@class,'ng-hide'))]//*[@id='NonBundleRetainPromotions_NRC']//*[contains(.,'<<<>>>')]")
        		    protected Element NRCRetainOffer;
        		 
        		  //*************Lakshmi**** Customer Value Added offer*************//
             
        		    @FindBy(xpath="//select[@ng-change='selectSecondaryReason()']")
        		    protected Element disReason;
             
        		  //*************Lakshmi**** Digital offer code*************//
        		    
        		    @FindBy(xpath="//span[@ng-bind-html='offer.Name | sanitize' and contains(text(),'Ground Shipping')]")
        		    protected Element couponOffTile;

        		    @FindBy(xpath = "//input[@pppname='<<<>>>' and @checked='true']")
       		     protected Element RemoveBBE;
                    
                  
            
                    @FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ddlPrimaryReasonVAS']")
       		     protected Element reasonForRemoval;
                    
                    @FindBy(xpath = "//a[contains(@id,'ChangeLnk')]")
       		     protected Element ChangeBtn;
                    
                    @FindBy(xpath = "//input[@id='btnCrmmSubmit']")
       		     protected Element Submitbtn;
                    
                    @FindBy(xpath = "//input[@type='radio' and contains(@value,'Yes')]")
       		     protected Element YesButton;
        		    
                    
                    @FindBy(xpath = "//li[@data-accordion='voice']//div[contains(text(),'Will be Removed') and not(contains(@class,'hide'))]")
            	    protected Element FDVRemoved;
                    
                    @FindBy(xpath = "//li[@data-accordion='phoneoptions']//a[contains(text(),'please review')]")
            	    protected Element InterceptsPleaseReview;
                    
                    @FindBy(xpath = "//li[@data-accordion='video']//span[contains(@ng-if,'headerResponse.Response.ProfileProduct')]//span[contains(@class,'text')]")
            	    protected Element ExistingTV;
                    
                    @FindBy(xpath = "//label[@for='satellite_no']")
            	    protected Element SetupSatelliteNo;
                    
                    @FindBy(xpath = "//li[@data-accordion='setup']//a[contains(text(),'required') and not(contains(@class,'hide'))]")
                    protected Element RequiredSetupInstall;
                    
                    @FindBy(xpath = "//a[contains(text(),'required') and not(contains(@class,'hide'))]/ancestor::li//div/span[contains(@class,'accordion-title')][1]")
                    protected Element RequiredTiles;
                    
                    @FindBy(xpath = "//a[contains(text(),'required') and not(contains(@class,'hide'))]/ancestor::li//div/span[contains(@class,'accordion-title')][1]")
                    protected CList<Element> RequiredReviewOrder;
                    
                    @FindBy(xpath = "//div[@ng-if='EmailStatus.ShowMessage' and contains(@class,'red')]")
                    protected Element sendQuoteerror;
                    
                    @FindBy(xpath = "//button[@ng-click='SavePriceQuote()']")
                    protected Element btnAddToCart;
                    
                    @FindBy(xpath = "//a[contains(@ng-click,'checkout')]")
                    protected Element btnPriceQuoteCheckout;
                    
                  //Naresh added 23/07/2018 - IWMP
                    @FindBy(xpath = "//p[contains(text(),'Inside Wire Maintenance')]//following-sibling::br//..")
                    protected Element IndieViewMaintenance;
                    
                    @FindBy(xpath = "//div[@ng-if='BillingEstimateShown']/div//div[contains(text(),'Inside Wire Maintenance')]")
                    protected Element IWMPValidationReviewOrder;
                    
                    @FindBy(xpath = "//div[@class='errorBox']")
                    protected Element LecEdit;
                    
                    @FindBy(xpath = "//select[@ng-change='selectSecondaryReason()']")
                    protected Element DisReason;
              		    
                   @FindBy(xpath = "//label[@for='boltonRemove']")
           		   protected Element deselectTestDrive;
                   
                   @FindBy(xpath = "//div[contains(@ng-if,'parent.SectionVisible.Vasip')]//div[contains(@class,'w_blocks') and contains(@class,'disabled') and contains(@class,'selected')]//p[contains(text(),'Home Network Protection')]")
                   protected Element HNP_selected_disabled;
                   
                   @FindBy(xpath = "//div[contains(text(),'+') and contains(@ng-click,'ShowAdditionalTVPlan')]")
                   protected CList<Element> ExpandadditionalTVoption;
  
                   @FindBy(xpath = "//div[(contains(@class,'autoPayRadio'))]//label[(contains(text(),'Yes'))]")
           		   protected Element rdAutoPayYes;
                   @FindBy(xpath = "//div[(contains(@class,'autoPayRadio'))]//label[@for='no']")
           		   protected Element rdAutoPayNo;
                   @FindBy(xpath = "//*[@header-response = 'DataHeaderContent']//span[@class= 'block text-small normal-weight ng-binding']")
           		   protected Element Existingdataproduct;
                   
                   @FindBy(xpath = "//*[@header-response = 'DataHeaderContent']//span[@ng-if= 'headerResponse.Response.total']")
           		   protected Element Currentdataspeed;
                   
                   @FindBy(xpath = "//*[@header-response = 'VideoHeaderContent']//span[@class= 'block text-small normal-weight ng-binding']")
           		   protected Element Existingtvproduct;
                   
                   @FindBy(xpath = "//*[@header-response = 'VideoHeaderContent']//span[@ng-if= 'headerResponse.Response.total']")
           		   protected Element Currenttvproduct;
                   
                   @FindBy(xpath = "//*[@header-response = 'VoiceHeaderContent']//span[@class= 'block text-small normal-weight ng-binding']")
           		   protected Element Existingvoiceproduct;
                   
                   @FindBy(xpath = "//*[@header-response = 'VoiceHeaderContent']//span[@ng-if= 'headerResponse.Response.total']")
           		   protected Element Currentvoiceproduct;
                   
                   @FindBy(xpath = "//*[@ng-controller = 'EquipmentHeaderCtrl']")
           		   protected Element Equipmentdetails;
                   
                   @FindBy(xpath = "//li[@ng-repeat='component in Bundle.Components track by $index' and contains(text(),'Internet')]")
                   protected Element ReviewOrderDetailsInternet;
                   
                   @FindBy(xpath = "//li[@ng-repeat='component in Bundle.Components track by $index' and contains(text(),'TV')]")
                   protected Element ReviewOrderDetailsTV;
                   @FindBy(xpath = "//li[@ng-repeat='component in Bundle.Components track by $index' and (contains(text(),'Voice') or contains(text(),'FREEDOM'))]")
                   protected Element ReviewOrderDetailsVoice;
                   @FindBy(xpath = "//div[not(contains(@class,'hide'))]/div[@class='column padding-right-zero']/div")
                   protected CList<Element> ReviewEquipmentAccessories;
                   
                   @FindBy(xpath = "//div[not(contains(@class,'hide'))]/div[@class='column padding-right-zero']//div[contains(text(),'Router')]")
                   protected Element getRouterDetails;
                   @FindBy(xpath = "//div[not(contains(@class,'hide'))]/div[@class='column padding-right-zero']//div[contains(text(),'Service')]")
                   protected Element getRecordingOptions;
                   
                   @FindBy(xpath = "//div[not(contains(@class,'hide'))]/div[@class='column padding-right-zero']//div[contains(text(),'Box')]")
                   protected Element getSTB;
                  
                   @FindBy(xpath = "//div[contains(@ng-repeat,'product in EstimatedMonthlyProducts')]//div[contains(text(),'Internet') or contains(text(),'Cons')]")
                   protected Element ReviewOrderDetailsInternet2;
                   @FindBy(xpath = "//div[contains(@ng-repeat,'product in EstimatedMonthlyProducts')]//div[contains(text(),'TV')]")
                   protected Element ReviewOrderDetailsTV2;
                   @FindBy(xpath = "//div[contains(@ng-repeat,'product in EstimatedMonthlyProducts')]//div[contains(text(),'Voice') or contains(text(),'LEC')]")
                   protected Element ReviewOrderDetailsVoice2;
                   
                   @FindBy(xpath = "//li[@data-accordion='video']/following-sibling::li[1]//div[contains(@ng-repeat,'product in productlist') and not(contains(@class,'hide'))]//span[contains(text(),'<<<>>>')]")
                   protected Element lnkTVPlansCustomTv;
  
                   @FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_lcwLineInformationUC_divMDUBattery911AgreementDisclosure_ScriptHeader']")
                   protected Element Disclosure;
                   
                   @FindBy(xpath = "//*[@id = 'chkDisclosure' and @type = 'checkbox']")
                   protected Element CustomerAcceptance;
                   
                   @FindBy(xpath = "//div[contains(@data-open-modal,'exchangeEquipmentOptions')]//*[contains(text(),' Exchange Options')]")
                   protected Element clickExchangeOptions;
                   
                   @FindBy(xpath = "//label[@for='exchangeVdos']")
                   protected Element chxboxVmsToLegacy;
                   
                   @FindBy(xpath = "//input[@id='txtSupervisorId']")
                   protected Element supervisorVzid;
                   
                   @FindBy(xpath = "//input[@id='txtPassword']")
                   protected Element supervisorPasswd;
                   
                   @FindBy(xpath = "//button[contains(@ng-click,'UpdateExchangeEquipmentDetails')]")
                   protected Element UpdateVMSBtn;
                   
                   @FindBy(xpath = "//label[@id='ContentPlaceHolder1_ContentPlaceHolder1_labellnkInitialEditOK_West']/a")
                   protected Element VoiceMailClose;
                   
                   //Addec code for E911 disclosure - Prakash - 2/2/19
                   @FindBy(xpath = "//*[@id='chkDisclosure']")
                   protected Element E911Disclosure;
                   
                   //Addec code for E911 disclosure C2G - Prakash - 2/2/19
                   @FindBy(xpath = "//*[@for='chkDisclosure']")
                   protected Element E911DisclosureC2G;
                   
                 //Added By Naresh,Madipelly -- VMS  Exchange Options
                   @FindBy(xpath = "//span[contains(text(),'Exchange Options')]")
           		   protected Element vmsClickOnExchangeOptions;
                   @FindBy(xpath = "//li[contains(text(),'<<<>>>')]")
           		   protected Element vmstoWifiVoiceRemote;
                   @FindBy(xpath = "//label[@for='VMSSeriesSwap']")
           		   protected Element vmsReadExchangeOptionsTermsToCustomer;
                   @FindBy(xpath = "//button[@ng-click='UpdateExchangeEquipmentDetails(equipmentAdditionalInfo)']")
           		   protected Element vmsUpdateExchangeOptions;
                   @FindBy(xpath = "//div[@ng-if='equipmentAdditionalInfo.IsVMSSeriesSwapSelected']")
           		   protected Element isVMSSelected;
                   @FindBy(xpath = "//div[@class='no-of-tvs relative text-xxlarge ng-binding ng-scope']/span")
           		   protected Element getExistingSelectedTVCount;
                   @FindBy(xpath = "//div[@id='Equipment_Delivery_Options_Tile_Q2386']/div")
           		   protected Element deliveryOptions_tvEquipTechnicialInstall;
                   @FindBy(xpath = "//span[@class='left' and contains(text(),'Total')]/following-sibling::span")
           		   protected CList<Element> getItemsToBeReturned;
                   @FindBy(xpath = "//li[@ng-controller='NonBundleManualOffersHeaderCtrl']")
           		   protected Element LoyaltyAdditionalOffers;
                   @FindBy(xpath = "//div[@ng-click='setHeightViewMoreOffersManualPopup();']")
           		   protected Element MoreOfffers;
                   @FindBy(xpath = "//div[@id='ManualPromotions']/div/p[contains(.,'Q2423')]")
           		   protected Element FionQuantumGateway_Data;
                   @FindBy(xpath = "//a[@id='OffersMore_SaveChanges']")
           		   protected Element UpdateManualOffers;
                   @FindBy(xpath = "//div[@ng-click='toggleSOCDetail(SOCDetailItem);']/div[@quotesection='EQUIPMENT']/div/div[contains(text(),'Router')]/following-sibling::div")
           		   protected Element getRouterPriceInCheckout;
                   
                   @FindBy(xpath = "//div[@ng-click='toggleSOCDetail(SOCDetailItem);']/div[@quotesection='OFFERS_SUMMARY']/div/div[3]")
           		   protected CList<Element> getTVPriceInCheckout;
                   
                   @FindBy(xpath = "//div[not(contains(@class,'hide'))]/div[@data-equal-height='internet-FNE']/p[contains(.,'<<<>>>')]/following-sibling::p[2]/span[1]")
           		   protected Element getRouterPriceFromPorductPage;
                   
                   @FindBy(xpath = "//div[@quotesection='ONETIME_CHARGES']/div/div[2]")
           		   protected CList<Element> getTVEquipmentFeeWaived;
                   
                   @FindBy(xpath = "//div[@class='padding-bottom-small padding-top-tiny']/div[2]/div[3]/ul/li[1]")
           		   protected Element TVFeeWaivedInReviewpage;
                   
                   //Pega //
                   
                   @FindBy(xpath = "//div[contains(@class,'columns tiny-11 alignleft padding-left-zero')]")
                   protected Element pegaRecommendation;
                   
                   @FindBy(xpath = "//div[@ng-show='flags.showList && combo.show']")
                   protected CList<Element> pegaTiles;
                   
                   @FindBy(xpath = "//li[@class='m_accordion-details border-none']//div[@ng-show='flags.showList && combo.show']")
                   protected CList<Element> PrepositionTiles;
                   
                   @FindBy(xpath = "//span[@class='inline-block vert-top pointer']")
                   protected Element RGQA;
                   
                   @FindBy(xpath = "(//div[@class='row padding-bottom-micro fluid-grid']//button[@ng-click='rejectCombo();'])[1]")
                   protected Element Rejectbutton; 
                   
                   @FindBy(xpath = "(//ul[@class='no-bullet padding-top-small ng-scope']//label[contains(text(),'Price')])[1]")
                   protected Element Radioobutton;
                   
                   @FindBy(xpath = "//button[@class='button no-icon margin-bottom-micro']")
                   protected Element ctnbutton;
                   
                   @FindBy(xpath = "//li[@data-accordion='phoneoptions']")
                   protected Element voiceoptions;
                   
                   @FindBy(xpath="//div[contains(@class,'bundle_expanded-discount ng-binding ng-scope')][2]")
                   protected Element equipmentprice;
                   
                   @FindBy(xpath = "//li[@data-accordion='internet']//span[contains(@ng-if,'headerResponse.Response.ProfileProduct')]//span[contains(@class,'text')]")
                   protected Element ExistingData;
                   
                   @FindBy(xpath = " //a[@data-agreement-selection='active']")
                   protected Element AgreementActiveTile;
                   
                   @FindBy(xpath=" //a[@data-agreement-selection='active']/parent::*//a[contains(@class,'details')]")
                   protected Element ActiveTile_Details;
                   
                   @FindBy(xpath = "//a[@data-equal-height='premium-channel']//span[contains(@class,'<<<>>>')]")
                   protected Element premiumChannelToSelect;
                   
                   @FindBy(xpath="//span[@ng-if='ShowPriceMismatchHeaderChange']//span[contains(@ng-bind-html, 'BundlePrice')]")
                   protected Element ProductBundlePrice;
                   
                   @FindBy(xpath="//div[@ng-if='EnablePanelHeaderChanges']//div[contains(@class,'active m_dashboard-sizer-rg')]")
                   protected Element rgSection;
                   
                   @FindBy(xpath = "(//div[@data-ui-view='Compass']//div[@ng-click='selectPegaTile(combo);'])[1]")
                   protected Element Firsttile;
                   
                   @FindBy(xpath = "//div[@class='columns tiny-11 alignleft padding-left-zero  margin-top-tiny']")
                   protected Element Tile2;
                   
                   @FindBy(xpath="(//div[@data-ui-view='Compass']//button[@ng-if='!EnableViewAgain'])[1]")
                   protected Element btnAddtoCart1;
                   
                  @FindBy(xpath = "//div[@class='columns tiny-11 alignleft padding-left-zero  margin-top-tiny']")
                  protected Element pegaRecommendation1;
                   
                  @FindBy(xpath = "(//div[@class='row padding-bottom-micro']//a[@ng-click='GetCharges(currentCombo)'])[1]")
                  protected Element pegaGetTotals;
                  
                  @FindBy(xpath="//div[@ng-controller='PegaPh2Controller']//div[contains(@class,'bundle_expanded-charge')]")
                  protected Element pegaBundlePrice;
                  
                  @FindBy(xpath="//div[@ng-controller='PegaPh2Controller']//div[contains(@class,'bundle_expanded-charge')]/following-sibling::div")
                  protected Element pegaOptixTotal;
                  
                  @FindBy(xpath="//div[contains(@class,'bundle_expanded-discount ng-binding ng-scope')][1]")
                  protected Element BPWithDisc;
                  
                  @FindBy(xpath="//div[@ng-controller='PegaPh2Controller']//div[contains(text(),'Taxes')]//following::div[1]")
                  protected Element taxes;
                  
                  @FindBy(xpath="//div[@ng-controller='PegaPh2Controller']//li[1]//ul[@class='bundles_details-notes']")
                  protected Element pegaBundleOffers;
                  
                  @FindBy(xpath = "//li[@data-accordion='voice']//span[contains(@ng-if,'headerResponse.Response.ProfileProduct')]//span[contains(@class,'text')]")
                  protected Element ExistingVoice;
                  
                  @FindBy(xpath="//div[@ng-controller='PegaPh2Controller']//button[text()='Add to Cart']")
                  protected Element btnAddtoCart;
                  
                  @FindBy(xpath="//input[@id='Button1g']")
                  protected Element Disconnectsave;
                  
            	@FindBy(xpath = "//input[contains(@ng-model,'EquipDeliveryAdditionalInfo.storeListMailID')]")
            	protected Element DropOff_EmailSearch_txtbox;
            	
            	@FindBy(xpath = "//button[contains(text(),'Email Location to Customer')]")
            	protected Element DropOff_EmailSearch_btn;
            	
            	@FindBy(xpath = "//*[contains(text(),'Email sent successfully!')]")
            	protected Element DropOff_Email_success_msg;
            	
            	@FindBy(xpath = "//label[@for = 'boltonAddScript']")
            	protected Element ChkFiosTVTestDrive ;
            	 //update for FCP
                //Added by Mithra for decline reason FCP
                @FindBy(xpath = "//label[contains(text(),'<<<>>>')]")
                protected Element selectBatteryBackupDeclineReason;
              //update for FCP
                //Added By Meena for streaming services
                @FindBy(xpath = "//li[@data-accordion='Ott']")
            	protected Element expandstreamingServ ;
                @FindBy(xpath = "//li[@data-accordion='Ott']/following-sibling::li[1]//span[contains(text(),'<<<>>>')]")
            	protected Element clickYoutubeTv ;
                @FindBy(xpath = "//div[contains(@id,'Basic_TV_Q7963')]/div[1]")
            	protected Element clickYoutubeTv2 ;
                

        	    
        	    @FindBy(xpath = "//span[@ng-if='!offer.HideFromTile ']//span[contains(text(),'<<<>>>')]")

        	    protected Element offerSectionOfferValidation;
        	    
        	    @FindBy(xpath = "//span[contains(text(),'Offer Summary')]/..")

        	    protected Element reviewOrderOfferSUmmaryExpand;
/*
   @FindBy(xpath = "//a[@data-agreement-selection='active']/..//span[contains(text(),'Details')]/..")
                protected Element selectedofferViewDetail ;*/
                
   @FindBy(xpath = "//a[@data-agreement-selection='active']/..//span[contains(text(),'Details')]/.. | //a[@data-agreement-selection='active']/..//a[contains(@class,'tiles_details')]") 
   protected Element selectedofferViewDetail ;             
                @FindBy(xpath = "//div[@data-modal='MyOfferDetails']//p[contains(@ng-repeat, 'offer')]//span[contains(@ng-bind-html,'offer.Name') and contains(text(),'<<<>>>')]")
                protected Element offeronDisplay_OfferDetailPopUp ;
                
                @FindBy(xpath = "//span[contains(text(),'Get FCP Plans')]")
                protected Element opoGetFCPButton ;
                
                @FindBy(xpath = "//span[@ng-bind-html='setFcpEtfMessage | sanitize']")
                protected Element opoFCPETFMessage ;
              //Vikram script start FCP
                @FindBy(xpath = "//img[(contains(@src,'<<<>>>'))]")
                protected Element fiosFiveChannel;
                @FindBy(xpath = "//h6[contains(text(),'Fios Five')]")
                protected Element fiosFivePopUp;
                @FindBy(xpath = "//b[contains(text(),'All Local channels are included')]")
                protected Element f5PopUpText;
                @FindBy(xpath = "//button[@ng-click='SaveFiosFiveProducts()']")
                protected Element SaveFiosFiveProducts;
        
        	  
}
//h6[contains(text(),'Fios Five')]