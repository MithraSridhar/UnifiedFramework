package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_BillingInfo_Objects class represent the Page Object class. This
 * contains all the identifier for Simplex BillingInfo Page
 */
public class Simplex_BillingInfo_PageObjects extends CommonPage {

    /**
     * Simplex_BillingInfo_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *            represents data input
     */
    public Simplex_BillingInfo_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }

    @FindBy(xpath = "//input[@id='radInterestedPaperfreeBillNo']")
    protected Element rbtnPaperFreeBilling;
    
    @FindBy(xpath = "//*[@id= 'Preview_Order']")
    protected Element Preview_Order;
    
    @FindBy(xpath = "//*[@ng-click = 'ProceedWithOrder()']")
    protected Element btncheckout;

    @FindBy(xpath = "//select[@id='ddlPaperfreeBillReason']")
    protected Element lstPaperFreeBillingReason;

    @FindBy(xpath = "//input[@id='radInterestedAutopayNo']")
    protected Element rbtnAutoPay;

    @FindBy(xpath = "//select[@id='ddlAutopayDeclinedReason']")
    protected Element lstAutoPayReason;

    @FindBy(xpath = "//input[@id='SaveContinue']")
    protected Element btnSaveAndContinue;

    @FindBy(xpath = "//input[@id='btnUsePostalAddress' or @id='btnInvalidUseSameAddress']")
    protected Element btnUsePostalAddress;
    
    @FindBy(xpath = "//input[@id='btnPostalUseSameAddress']")
    protected Element btnUseSameAddress;
	
	@FindBy(xpath = "//*[@id='btnProceed']")
    protected Element proceed;

     @FindBy(xpath = "//input[@id='chkSetAutoPayNonTab']")
    protected Element chkBoxAutoPay;

    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucPaymentMethods_ucAutomaticPaymentTypes_btnPayByDirectDebit']")
    protected Element clickBankAcct;

    @FindBy(xpath = "//*[@id='txtWindowsUserID']")
    protected Element autopayWindowUserId;

    @FindBy(xpath = "//*[@id='txtWindowsPwd']")
    protected Element autopayWindowPwd;

    @FindBy(xpath = "//*[@id='Login']")
    protected Element autopayLogin;

    @FindBy(xpath = "//div[@id='PaymentGatewayPopupDiv']/div[@id='PaymentGatewayPopupTitle']/a/img")
    protected Element autopayPopUpClose;

    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucPaymentMethods_ucAutomaticPaymentTypes_btnPayByDirectDebit")
    protected Element autopayDebitCardOpt;

    @FindBy(xpath = "//*[@id='txtBankAccountNbr")
    protected Element autopayDebitCardNo;

    @FindBy(xpath = "//*[@id='txtRoutingNbr")
    protected Element AutopayRouterNo;

    @FindBy(xpath = "//*[@id='btnProcess")
    protected Element AutopaySave;

    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucPaymentMethods_ucAutomaticPaymentTypes_btnPayByCreditCard")
    protected Element AutopayCreditCardOption;

    @FindBy(xpath = "//*[@id='txtCC")
    protected Element AutopayCreditNo;

    @FindBy(xpath = "//*[@id='txtCVV2")
    protected Element AutoPayCreditCVV;

    @FindBy(xpath = "//*[@id='ddlCardType")
    protected Element AutopayCreditType;

    @FindBy(xpath = "//*[@id='ddlCCYear")
    protected Element AutoPayCreditYear;

    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucPaymentMethods_ucAutomaticPaymentTypes_btnLaunchCCI")
    protected Element AutopayEmail;
    
    @FindBy(xpath = "//a[contains(.,'BILLING INFO')]")
    protected Element billingInfoTab;
   
    protected By activeBillingInfoTab =By.xpath("//a[contains(.,'BILLING INFO') and contains(@class,'active')]");

    @FindBy(xpath = "//a[@id='ctl00_ctl00_ContentPlaceHolder1_rptTabs_ctl03_lbtnTab']")
    protected Element DisconnectHeaderText;
    
    @FindBy(xpath = "//li[@class='first active']/a[@id='ctl00_ctl00_ContentPlaceHolder1_rptTabs_ctl03_lbtnTab']")
    protected CList<Element> DisconnectHeaderTextList;

    @FindBy(xpath = "//select[@id='ddlVzCatgoryReason']")
    protected Element Disconnectcat;

    @FindBy(xpath = "//select[@id='ddlVzReason']")
    protected Element Disconnectreason;

    @FindBy(xpath = "//input[@id='Button1g']")
    protected Element DisSaveNdContinue;
    
    @FindBy(id = "btnClose")
    protected Element popupClose;
    
    @FindBy(xpath = "//input[@id='chkDeposit']")
    protected Element chckBoxAgreeToRefundableDeposit;
    
    @FindBy(xpath = "//input[@id='chkNoDepositOffer']")
    protected Element chkBoxNoDepositOffer;
    
    @FindBy(xpath = "//input[@id='btnCreditNextSaveandContinue']")
    protected Element DepositSaveAndContinue;
    
    @FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$FooterContent$btnBillingSave']")
    protected Element BillingSave;
    
    //Save order
    
    
    @FindBy(xpath = "//label[@class='input_buttons']//img[@alt='ButtonFiOSFastPass']")
    protected Element btnFastPass;
    
    @FindBy(xpath = "//input[@name='txtxpsEmail']")
    protected Element fastpassemail;
    
    @FindBy(xpath = "//input[@id='btnYes']")
    protected Element yesButton;
    
    
    @FindBy(xpath = "//*[@id='monDisplay']")
    protected Element MON_atbillingpage;
    
    @FindBy(xpath = "//input[@id='btnSaveOrder']")
    protected Element btnSaveOrder;
    
// ********************* for special handling code*******************//
    
    @FindBy(xpath = "//*[@id = 'BillingOptions']")
    protected Element Billing_Options;
    
    @FindBy(xpath = "//*[@id = 'divTabGeneral']")
    protected Element General_Tab;
    
    @FindBy(xpath = "//*[@id = 'ddlCodes']")
    protected Element Spl_handl_cd;
    
    @FindBy(xpath = "//*[@id = 'ddlSpokenLangPrefer']")
    protected Element SpokenLanguage;

//******************Gopal 03/16/2017 Installment Billing*******************************//
    
    
    @FindBy(xpath = "//*[@id = 'lnkInstallmentBilling']")
    protected Element link_Installment_Billing;
       
    @FindBy(xpath = "//*[@id = 'divBroadbandTab']")
    protected Element link_Fios_Services;
    
    @FindBy(xpath = "//*[@id = 'ddlFiOSNoOfMonths']")
    protected Element NoofMonths;

/*************prakash gui validations******************/
    
    @FindBy(xpath = ".//ul[@id='MON']//div[contains(text(),'View Details')]")
    protected Element ViewDetailsLink;

    @FindBy(xpath = ".//*[@id='CartViewDetailsDiv']")
    protected Element CartViewDetails;
    @FindBy(xpath = ".//*[@id='CartDetailsPopupTitle']/div")
    protected Element CartViewDetails_Close;
    
    @FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$disconnect$Button1g']")
    protected Element btnFiosSaveContinue;
    
    @FindBy(xpath = "//span[@id='ctl00_ctl00_ContentPlaceHolder1_custSvcInfo_Label1']")
    protected Element ViewDetailsLinkC2G;
    
    @FindBy(xpath = "//input[@id='btnLaunchXPS']")
    protected Element btnFastPassC2G;

    @FindBy(xpath = "//span[@id='lblBillingShippingAddressPopUpTitle']")
    protected Element rdbtnUsePostalAddress;
    
    @FindBy(xpath = "//*[@id= 'btnProceed']")
    protected Element btnproceed;
    
    /***********************Billing Page Objects**********************************/
    
    @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucBillingNameAddress_lnkROChange']")
    protected Element correction;
    @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucBillingNameAddress_txtFirstName']")
    protected Element firstname;
    @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucBillingNameAddress_txtLastName']")
    protected Element lastname;
    @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucBillingNameAddress_ucAddressInfoEastBNA_txtAddress1']")
    protected Element address1;
    @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucBillingNameAddress_ucAddressInfoEastBNA_txtCityEast']")
    protected Element city;
    @FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucBillingNameAddress_ucAddressInfoEastBNA_ddlStateEast']")
    protected Element state;
    @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucBillingNameAddress_ucAddressInfoEastBNA_txtZipEast']")
    protected Element zipcode;
    @FindBy(xpath = "//input[@id='radCreditHistoryNo']")
    protected Element rbtnCreditCheckNo;
    @FindBy(xpath = "//select[@id='ucCreditEntry_ucResponsiblePartyEntry_ddlDOBMonth' or @id='ddlDOBMonth']")
    protected Element lstDOBMonth;

    @FindBy(xpath = "//select[@id='ucCreditEntry_ucResponsiblePartyEntry_ddlDOBDate' or @id='ddlDOBDate']")
    protected Element lstDOBDate;

    @FindBy(xpath = "//input[@id='ucCreditEntry_ucResponsiblePartyEntry_txtDOBYear' or @id='txtDOBYear']")
    protected Element txtDOBYear;
    @FindBy(xpath = "//*[@id='btnPerformCredit']")
    protected Element btnVerifyCredit;
    
    
    
    /* Description :NY municipal Charges
       Author      :karthik Arumugam
       Team        :Cofee-SIT
   
    */
    /****** Fios View Details PopUp  ******/
    @FindBy(xpath = "//div[contains(text(), 'View Details')]")
    protected Element ViewDetails;

    @FindBy(xpath = "//tbody[@id='dv_VZFiOSConsumerInternetPlan']")
    protected Element VZFiOSConsumerInternetPlan;

    @FindBy(xpath = "//tbody[@id='dv_VZFiOSConsumerInternetPlan']//td[contains(text(),'NY Municipal Construction Surcharge')]")
    protected Element NYMunicipalData;

    @FindBy(xpath = "//tbody[@id='dv_VZFiOSConsumerInternetPlan']//td[contains(text(),'NY Municipal Construction Surcharge')]/preceding-sibling::td[1]/child::img[@alt='Added']")
    protected Element NYMunicipalDataAdded;

    @FindBy(xpath = "//tbody[@id='dv_VZFiOSConsumerInternetPlan']//td[contains(text(),'NY Municipal Construction Surcharge')]/preceding-sibling::td[1]/child::img[@alt='OnProfile']")
    protected Element NYMunicipalDataOnProfile;

    @FindBy(xpath = "//tbody[@id='dv_VZFiOSDigitalVoice']")
    protected Element VZFiOSDigitalVoice;
    
    @FindBy(xpath = "//tbody[@id='dv_VZFiOSDigitalVoice']//td[contains(text(), 'NY Municipal Construction Surcharge')]")
    protected Element NYMunicipalVoice;

    @FindBy(xpath = "//tbody[@id='dv_VZFiOSDigitalVoice']//td[contains(text(), 'NY Municipal Construction Surcharge')]/preceding-sibling::td[1]/child::img[@alt='Added']")
    protected Element NYMunicipalVoiceAdded;
    
    @FindBy(xpath = "//tbody[@id='dv_VZFiOSDigitalVoice']//td[contains(text(), 'NY Municipal Construction Surcharge')]/preceding-sibling::td[1]/child::img[@alt='OnProfile']")
    protected Element NYMunicipalVoiceOnProfile;
    
    @FindBy(xpath = "//tbody[@id='dv_FiOS TV']")
    protected Element VZFiOSTV;
    
    @FindBy(xpath = "//tbody[@id='dv_FiOS TV']//td[contains(text(), 'NY Municipal Construction Surcharge')]")
    protected Element NYMunicipalTv;

    @FindBy(xpath = "//tbody[@id='dv_FiOS TV']//td[contains(text(), 'NY Municipal Construction Surcharge')]/preceding-sibling::td[1]/child::img[@alt='Added']")
    protected Element NYMunicipalTvAdded;
    
    @FindBy(xpath = "//tbody[@id='dv_FiOS TV']//td[contains(text(), 'NY Municipal Construction Surcharge')]/preceding-sibling::td[1]/child::img[@alt='OnProfile']")
    protected Element NYMunicipalTvOnProfile;
    
    @FindBy(xpath = ".//*[@id='CartDetailsPopupTitle']/div")
    protected Element ViewDetails_Close;
    
    /****** HSI View Details PopUp  ******/
    
    @FindBy(xpath = "//a[@id='cart_exp_coll']")
    protected Element Expand_ShoppingCart;
    
    @FindBy(xpath = "//input[@id='ctl00_btn_ViewDetail']")
    protected Element HSIViewDetails;

    @FindBy(xpath = "//tbody[@id='dv_HSI']")
    protected Element VZHSI;

    @FindBy(xpath = "//tbody[@id='dv_HSI']//td[contains(text(),' NY Municipal Construction Surcharge')]")
    protected Element NYMunicipalHSI;

    @FindBy(xpath = "//tbody[@id='dv_HSI']//td[contains(text(),' NY Municipal Construction Surcharge')]/preceding-sibling::td[1]/child::img[@alt='Added']")
    protected Element NYMunicipalHSIAdded;

    @FindBy(xpath = "//tbody[@id='dv_HSI']//td[contains(text(),' NY Municipal Construction Surcharge')]/preceding-sibling::td[1]/child::img[@alt='OnProfile']")
    protected Element NYMunicipalHSIOnProfile;
    @FindBy(xpath = "//td[@id='tdMON']/label[contains(text(),'View Details')]")
    protected Element ViewDetailsLink2;
    @FindBy(xpath = "//li[@id='DisconnectTabs' and contains(@class,'active')]/a[@id='ctl00_ctl00_ContentPlaceHolder1_rptTabs_ctl03_lbtnTab']")
    protected Element DisconnectTab;
    @FindBy(xpath = "//div[@id='divEnrollDigitalBilling']")
    protected Element Enrolldigitalbilling;
    
    @FindBy(xpath = "//div[@id='divEnrollDigitalBilling']//b")
    protected Element EnrolldigitalbillingMessage;
    
    @FindBy(xpath = "//div[@id='divDigitalEnrollScript']")
    protected Element EnrolldigitalbillingScriptMessage;

     
    @FindBy(xpath = "//div[@id='divAlertMessage']")
    protected Element Alertmessage;
    
    @FindBy(xpath = "//div[@id='divInnerPaymentMethod']")
    protected Element PaymentMethod;
    
    //Telecommunication service priority
    @FindBy(id = "btnTSP")
    protected Element TelecommunicationServicePriorityButton;
    
    @FindBy(id = "ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_gvTSP_ctl0<<<>>>_chkRow")
    protected Element ChkBoxAddRemovePSAN;
    
    @FindBy(id = "ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_gvTSP_ctl0<<<>>>_txtTN")
    protected Element txtTN;
    
    @FindBy(name = "ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$gvTSPNew$ctl0<<<>>>$txtPSANNew")   
    protected Element txtPSAN;
    
    @FindBy(name = "ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$gvTSPAddlNew$ctl0<<<>>>$txtPSANAddlNew")   
    protected Element txtPSANAddl;
    
    @FindBy(id = "LinkButton1")
    protected Element PSANApply;
    
    @FindBy(name = "ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$Button1")
    protected Element PSANApplyAndClose;
     
    @FindBy(id = "ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_gvTSP_ctl02_lblType")
    protected Element ServiceType;
    
    
    @FindBy(id = "ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_gvTSP_ct102_txtTN")
    protected WebElement weTN;
    
    @FindBy(id = "lnkAddlTSP")
    protected Element btnAdditionalTSP;
    
    @FindBy(xpath = "//*[contains(text(),('Telecom Service Priority (TSP)'))]")
    protected WebElement txtTSP;
    
    @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_Cancel']")
    protected Element cancelOrder;
    
    @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucBillingNameAddress_chkUseServiceAddress' and contains(@checked,'checked')]")
    protected Element UseServiceAddress;
    
    //Added for Prepaid plan    
    @FindBy(xpath = "//input[@id='txtFirst_Name']")
    protected Element PrepaidFname;    
   
    @FindBy(xpath = "//input[@id='txtLast_Name']")
    protected Element PrepaidLname;
    
    
}
