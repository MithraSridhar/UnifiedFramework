package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_LoginPage_Objects class represent the Page Object class. This
 * contains all the identifier for Simplex Login Page
 */
public class Simplex_Login_PageObjects extends CommonPage {
	/**
	 * Simplex_Login_PageObject class constructor
	 * 
	 * @param driver
	 *            represents the instances of type WebDriver
	 * @param windows
	 *            represents boolean value either true or false
	 * @param report
	 *            represents report input             
	 * @param windows
	 *            represents data input            
	 */
	public Simplex_Login_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
		super(driver, windows, report, data);
	}
	
	@FindBy(xpath = "//*[@id='WinAlertMsg']")
	protected Element winAlert;
	
	@FindBy(xpath = "//div[not(contains(@class,'Hidden'))]/input[(@id='txtAgentId1' or @id='txtAgentId' or @id='IDToken1' or @id='USERID1')]")
	protected Element userID;

	@FindBy(xpath = "//div[not(contains(@class,'Hidden'))]/input[@id='Text2' or @type='password' or @id='IDToken2' or @id='PASSWORD1']")
	protected Element password2;

	
	@FindBy(xpath = "//div[not(contains(@class,'Hidden'))]/input[@id='btnProceed1' or @id='btnProceed' or @id='Button1' or @id='Button2']")
	protected Element logIn;
	
	@FindBy(xpath = "//input[@id='USERID']")
	protected Element ebizuserID;

	@FindBy(xpath = "//input[@id='PASSWORD']")
	protected Element ebizpassword;

	@FindBy(xpath = "//button[@id='Button1']")
	protected Element ebizlogIn;
	
	@FindBy(xpath = "//h2[contains(text(),'Clearing browser cache... Click ')]/a")
	protected Element clearCacheMsg;

	@FindBy(xpath = "//*[@id='lblWinErrMsg1' or @id='errlabel1']")
	protected Element errorMsg;
	
	@FindBy(xpath = "//div[@id='main-frame-error']")
	protected Element siteCannotbeReached;

}
