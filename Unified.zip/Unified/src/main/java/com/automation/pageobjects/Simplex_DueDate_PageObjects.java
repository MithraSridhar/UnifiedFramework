package com.automation.pageobjects;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_Duedate_Objects class represent the Page Object class. This contains
 * all the identifier for Simplex Duedate Page
 */
public class Simplex_DueDate_PageObjects extends CommonPage {

    /**
     * Simplex_DueDate_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *            represents data input
     *  
     *            
     */
    public Simplex_DueDate_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }

    @FindBy(xpath = "(//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_calDD')]//td[@class='blueGradientDates' or @class='TodayDate' or @class='HoverDates' or @class = 'installPrimiumDate1'])[1]")
    protected Element firstAvailableDate;

    @FindBy(xpath = "(//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_calDD')]//td[@class='FutureDate'])[1]")
    protected Element firstAvailableFutureDate;

    @FindBy(xpath = "(//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_calDD')]//td[position()!=1 and position()!=7][@class='blueGradientDates'])[4]")
    protected Element fourthAvailableDate;

    // Written by shiva, Handled for weekend date
    @FindBy(xpath = "(//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_calDD')]//td[position()=1 or position()=7][@class='blueGradientDates'])[1]")
    protected Element firstAvailableWeekendDate;

    @FindBy(xpath = "//div[@class='timeSlots']//tr[2]//a[1]")
    protected Element lnkTimeSlots;

    @FindBy(xpath = "//input[@id='btnCancel' or @id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_btnCancel']")
    protected Element btnCancel;
    
    @FindBy(xpath = "//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_divTimeslotsContainer']//label[@for='grpTimeSlots0']")
    protected Element c2gTimeslots;


    @FindBy(xpath = "//input[@id='radDSQuestionOnlyAnsNo']")
    protected Element radDSAnsYes1;

    @FindBy(xpath = "//input[@id='btnDirectShipContinue']")
    protected Element btnDirectShipContinue;

    @FindBy(xpath = "//input[@id='btnCancel']")
    protected Element btnSaveAndContinue;

    @FindBy(xpath = "//a[contains(.,'DUE DATE')]")
    protected Element dueDateTab;
    protected By activeDueDateTab =By.xpath("//a[contains(.,'DUE DATE') and contains(@class,'active')]");
    
    //vikram script start  SLIP flow in DD
    
    @FindBy(xpath = "//b[contains(text(),'CO Connect')]")
    protected Element slip_data_fdv_script;
    
    @FindBy(xpath = "//*[@id='divAlertOfferMessageContainer']")
    protected Element dd_offerMessageContainer;
    
    @FindBy(xpath = "//*[@id='divAlertOfferMessage']")
    protected Element dd_offerMessage;      
    
    @FindBy(xpath = "//*[@alt='Due Date Type']")
    protected Element dd_Type; 
    //vikram script end
    
    @FindBy(xpath = "(//table[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_calDDLeft']//td[@class='blueGradientDates'])[2]")
    protected Element firstDueDateNew;

    @FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucMODDArea_ddlMissedAppCode']")

    protected Element OldMissedAppointment;
    @FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucMODDArea_ddlMissedAppCode']")

    protected CList<Element> OldMissedAppointmentList;

    @FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_ddlMissedAppCode']")
    protected Element NewMissedAppointment;

    @FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_ddlMissedAppCode']")
    protected CList<Element> NewMissedAppointmentList;
    
    @FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_ddlMissedAppCode']")
    protected Element MissedAppointment;

    @FindBy(xpath = "//input[@id='chkMoveOrderAlert']")
    protected Element chkboxConfirmDueDate;

    @FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_ddlMissedAppCode']")
    protected Element missedAppointmentCode;

    @FindBy(xpath = "//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucEVODDArea_DivCallendisplay']//table//td[@class='FutureDate' ]/preceding-sibling::td[@class='blueGradientDates'][1]")
    protected Element endDueDate;

    // DueDate comparison

    // @FindBy(xpath =
    // "(//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucMODDArea_DivCallendisplay']/table//td[@class='blueGradientDates'])[1]")
    @FindBy(xpath = "(//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucMODDArea_DivCallendisplay' or @id = 'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucCrossMoveDDArea_DivCallendisplay']/table//td[contains(@onclick,'SetSelectedDateOnClick') and @class='TodayDate' or @class='blueGradientDates'])[1]")
    protected Element firstDueDateOld;

    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_upnlDuDate']/table//td[@class='blueGradientDates' or @class = 'installPrimiumDate1']")
    protected CList<Element> firstDueDateNewList;

    @FindBy(xpath = "//label[@for='radDSAnsYes1']")
    protected Element directshipeligibilityoptions;

    @FindBy(xpath = "//input[@id='radDSAnsYes1']")
    protected Element directshipeligibilityyesoption;

    @FindBy(xpath = "//input[@id='btnDirectShipContinue']")
    protected Element directshipclose;

    @FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_ddlDueDateType']")
    protected Element selectDueDateType;

    // For Self Install

    @FindBy(xpath = "//*[@id = 'chkSIOverride']")
    protected Element Self_Install_override;

    @FindBy(xpath = "//*[@id = 'ddlSelectReason']")
    protected Element Self_Install_Reason_drpdn;

    @FindBy(xpath = "//*[@id = 'txtcustomReason']")
    protected Element Self_Install_Reason_Text;

    @FindBy(xpath = "//*[@id = 'btnContinueOverride']")
    protected Element selfInstallOverrideContinue;

    @FindBy(xpath = "//*[@for = 'chkSIOverride']")
    protected Element Self_Install_Reason_msg;

    @FindBy(xpath = "//*[@id= 'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_Button1']")
    protected Element Self_Install_override_accept;

    @FindBy(xpath = "(//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_calDD')]//td[@class='TodayDate'])")
    protected Element firstAvailableTodaysDate;


    
    
    /**************************
     * Added For: Added Element for MO validaiton in View Cart Author: Jeevitha
     * S Date: 02/21/2017
     ***************************/
    @FindBy(xpath = "//ul[@id='MON']//div[contains(text(),'View')]")
    protected CList<Element> ViewCartDetailsList;

    @FindBy(xpath = "//*[@id='monDisplay']")
    protected Element ViewCartDetails;
    
  ///Shobana
  	@FindBy(xpath="//div[@class='vdSection']")
  	protected CList<Element> viewDetailsAllSection;

    
    //cancel order
    @FindBy(xpath = "//input[@id='btnCancelOrder']")
    protected Element btnCancelOrder;
    
   // @FindBy(xpath = "//textarea[@id='txtCloseNotes']")//li[@id='closeNotesAccordian']//following-sibling::div//textarea[@id='txtCloseNotes']
    @FindBy(xpath = "//div[@class='w_notes']//textarea[@id='txtCloseNotes']")
    protected Element closingNotesText;
    
    @FindBy(xpath = "//li/button[contains(@ng-click,'save')]")
    protected Element saveandClose;
    
    @FindBy(xpath = "//a[@onclick='return CancelnCloseManageObjection();']")
    protected Element cancelOrderPopUp;
    
    @FindBy(xpath = "//input[@onclick='OnCAOk();']")
    protected Element warningYesPopup;
    
    @FindBy(xpath = "//a[contains(.,'DUE DATE') and contains(@class,'active')]")
    protected Element activeDueDate;

    @FindBy(xpath = "//label[@for='radDSAnsYes1']")
    protected Element c2gdirectshipeligibility1;
	@FindBy(xpath = "//label[@for='radDSQuestionOnlyAnsYes']")
    protected Element c2gdirectshipeligibility;
        
    /***************************
	 * Added for View details Validation
	 * Author: Rathna B
	 * Date 02/27/2017
	 *******************************/
	@FindBy(xpath="//img[@alt='Bundle']")
	protected CList<Element> ViewDetailsBundleSection;
	
	@FindBy(xpath="//tbody[@id='dv_Bundle']")
	protected  Element ViewDetailsBundleText;
	
	@FindBy(xpath="//img[@alt='FiOS Internet']")
	protected CList<Element> ViewDetailsInternetSection;
	
	@FindBy(xpath="//tbody[@id='dv_FiOS Internet']")
	protected Element ViewDetailsInternetText;
	
	@FindBy(xpath="//img[@alt='FiOS TV']")
	protected CList<Element> ViewDetailsTVSection;
	
	@FindBy(xpath="//tbody[@id='dv_FiOS TV']")
	protected Element ViewDetailsTVText;
	
	@FindBy(xpath="//img[@alt='FiOS Digital Voice']")
	protected CList<Element> ViewDetailsFDVSection;
	
	@FindBy(xpath="//tbody[@id='dv_FiOS Voice']")
	protected Element ViewDetailsFDVText;
	
	@FindBy(xpath="//img[@alt='LEC Voice']")
	protected CList<Element> ViewDetailsLECSection;
	
	@FindBy(xpath="//tbody[@id='dv_LEC Voice']")
	protected Element ViewDetailsLECText;
	
    
    @FindBy(xpath="//div[@id='CartDetailsPopupTitle']/div[@class='modalrightClose divClose']")
    protected Element ViewCartClose;
    
    @FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_upnlDuDate']/table//td[@class='blueGradientDates'][1]")
    protected Element firstDueDateNewListc2g;
    
    protected By activeLoyaltyTab =By.xpath("//a[contains(.,'LOYALTY OFFERS') and contains(@class,'active')]");
    @FindBy(xpath = "//input[@id='btnSaveAndContinue']")
    protected Element LoyaltySaveContinue;
    
    @FindBy(xpath = "//td[contains(@class,'redboxes')]")
    protected Element errormessage;
    
    @FindBy(xpath = "//*[contains(text(),'This order has a due date restriction through')]")
    protected Element PresaleDate;
    
    @FindBy(xpath = "//*[@id='divDSBasicBlueMsg']")
    protected Element IPTVC2GDirectship;

    @FindBy(xpath = "//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_divTimeslotsContainer']//label[@for='grpTimeSlots4']")
    protected Element c2gTimeslots2;
     
    
    @FindBy(xpath = "//table[@class='pageErrorList pad_10']//td[contains(text(),'Please negotiate a due date for at least one service.')]")
    protected Element dueDateNegotiateErr;
    
    @FindBy(xpath = "//table[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_tblRESERVEError']//date[contains(text(),'  is not available. Other times may be available on that day. Select a different time and/or date.')]")
    protected Element dueDateTimeSlotNotAvlErr;
    
    @FindBy(xpath="//input[@value='Cancel Order']")
    protected Element btnC2GCancelOrder;
    
    @FindBy(xpath = "//ul[@id='tabLinks']/li[@id='checkouttabs']/div/a[contains(@url,'DueDate')]")
    protected Element DueDateTab;
    
    @FindBy(xpath = "(//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_calDD')]//td[@class='blueGradientDates' or @class='TodayDate' or @class='HoverDates'])[2]")
    protected Element NextAvailableDate;
	
    @FindBy(xpath = "//ul[@id='tabLinks']/li[@id='checkouttabs']/div/a[contains(@url,'EquipmentReturn') and contains(text(),'SHIPPING / RETURN')]")
	protected Element ShippingReturnTab;
	
	@FindBy(xpath = "//label[@for='rdoShipmentSuggestedAddress']")
	protected Element rdbtnSuggestedAddress;
	
	@FindBy(xpath = "//input[@id='btnCLECSavecont']")
	protected Element EquipSaveNdContinue;
	
	@FindBy(xpath = "//*[@id = 'btnOk']")
	protected Element KeepDuedate;
	
	@FindBy(xpath = "//iframe[@id='PopupIFrameforAlertPage']")
    protected Element popupframe;
	
	//Soham - Feb Release
    @FindBy(xpath="//*[@id='monDisplay']")
    protected Element dueDatePage_ViewDetails;
    @FindBy(xpath="//*[@id='ViewDetailsPopup']")
    protected Element viewDetails_popup;
    @FindBy(xpath="//*[@id='ctl00_rpViewDetails_ctl00_lnkSvcHeader']")
    protected Element viewDetails_popup_bundle;
    @FindBy(xpath="//*[@id='CartDetailsPopupTitle']/div")
    protected Element viewDetails_close;
    
    //Soham  - March Release
    @FindBy(xpath="//img[@alt='FiOS TV']")
    protected Element fiosTV_ViewDetails;
    @FindBy(xpath="//img[@alt='FiOS TV']//parent::a//parent::div//following::div/table/tbody//following::tbody/tr/td/table/tbody[@id='dv_VZFiosTVSHE(Overlay)']/tr/td/table/tbody/tr/td/child::img[@alt='Removed']/parent::td//following-sibling::td[contains(text(),'Term Tracker for 24M')]")
    protected Element fiosTV_TermTracker_Removed;
    @FindBy(xpath="//img[@alt='FiOS TV']//parent::a//parent::div//following::div/table/tbody//following::tbody/tr/td/table/tbody[@id='dv_VZFiosTVSHE(Overlay)']/tr/td/table/tbody/tr/td/child::img[@alt='Added']/parent::td//following-sibling::td[contains(text(),'Term Tracker for MTM')]")
    protected Element fiosTV_TermTracker_MTM_Added;
    
    @FindBy(xpath="//img[@alt='FiOS Internet']")
    protected Element fiosInternet_ViewDetails;
    
    @FindBy(xpath="//img[@alt='FiOS Internet']//parent::a//parent::div//following::div/table/tbody//following::tbody/tr/td/table/tbody[@id='dv_VZFiOSConsumerInternetPlan']//tr/td/table/tbody/tr/td/child::img[@alt='Removed']/parent::td//following-sibling::td[contains(text(),'Term Tracker for 24M')]")
    protected Element fiosInternet_TermTracker_Removed;
    
    @FindBy(xpath="//img[@alt='FiOS Internet']//parent::a//parent::div//following::div/table/tbody//following::tbody/tr/td/table/tbody[@id='dv_VZFiOSConsumerInternetPlan']//tr/td/table/tbody/tr/td/child::img[@alt='Added']/parent::td//following-sibling::td[contains(text(),'Term Tracker for MTM')]")
    protected Element fiosInternet_MTMAdded;
    
    @FindBy(xpath="//img[@alt='FiOS Digital Voice']")
    protected Element fiosDigitalVoice_ViewDetails;
    
    
    @FindBy(xpath="//img[@alt='FiOS Digital Voice']//parent::a//parent::div//following::div/table/tbody//following::tbody/tr/td/table/tbody[@id='dv_VZFiOSDigitalVoice']//tr/td/table/tbody/tr/td/child::img[@alt='Added']/parent::td//following-sibling::td[contains(text(),'Term Tracker for MTM')]")
    protected Element fiosDigitalVoice_MTMAdded;
    
    @FindBy(xpath="//img[@alt='FiOS Digital Voice']//parent::a//parent::div//following::div/table/tbody//following::tbody/tr/td/table/tbody[@id='dv_VZFiOSDigitalVoice']//tr/td/table/tbody/tr/td/child::img[@alt='Removed']/parent::td//following-sibling::td[contains(text(),'Term Tracker for 24M')]")
    protected Element fiosDigitalVoice_ETFRemoved;
	
	@FindBy(xpath = "//input[@id='chkPeakTimeAgreement']") 
    protected Element chkboxConfirmDueDate1;
	
	@FindBy(xpath = "//div[@class='timeSlots']//tr[3]//a[1]")
    protected Element lnkTimeSlots2;
	
	@FindBy(xpath = "//tr[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_trAllServiceTab']")
    protected Element DueDateCalendar;
	
	@FindBy(xpath = "//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucEVODDArea_calDD')]/tbody/tr/td[@class='blueGradientDates']/following-sibling::td[@class='FutureDate'][1]")
    protected Element futureDate;
	

	
	@FindBy(xpath = "//div[@id = 'fixedtipdiv']/table/tbody/tr[3]/td/a[@class = 'timeSlots']")
    protected Element SetupChargeWaivedSlots;
	@FindBy(xpath = "//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucMODDArea_upnlDuDate']")
    protected Element dueDateOld;
	
 // Installation Flexibility - Vijay
    
    @FindBy(xpath = "(//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_calDD')]//td[@class='installPrimiumDate2'])[1]")
    protected Element setupfeewaiverfifty;
    
    @FindBy(xpath = "(//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_calDD')]//td[@class='installPrimiumDate1'])[1]")
    protected Element setupfeewaiverhundred;
    @FindBy(xpath = "//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucEVODDArea_calDDLeft')]//td[@class='FutureDate']/preceding-sibling::td[@class='blueGradientDates'][1]")
    protected Element selectEndDate;
    @FindBy(xpath = "//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucEVODDArea_calDDLeft')]//td[@class='FutureDate']/following-sibling::td[@class='blueGradientDates'][1]")
    protected Element selectEndDate1;
	
	@FindBy(xpath = "//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_DivCallendisplay']")
    protected Element StartDate;
	@FindBy(xpath = "//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucEVODDArea_DivCallendisplay']")
    protected Element EndDate;
  
    @FindBy(xpath = "//div[@class='timeSlots']//tr[1]//a[1]")
    protected Element SingleTimeSlot;
    
    // For Deposit Page 05/02
    
    @FindBy(xpath = "//div[contains(text() ,'Collect Deposit')]")
    protected Element CollectDepositTAB;
    
    @FindBy(xpath = "//*[@id = 'rdoDepositAnsYes']")
    protected Element RadioDepositAnsYes;
    
    @FindBy(xpath = "//*[@id = 'btnSaveContinue']")
    protected Element ButtonSaveContinue;
    
}
