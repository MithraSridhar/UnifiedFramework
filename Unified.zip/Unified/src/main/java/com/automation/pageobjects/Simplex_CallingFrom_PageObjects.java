package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_CallingFrom_PageObjects class represent the Page Object class. This
 * contains all the identifier for Simplex Callingfrom Page
 */
public class Simplex_CallingFrom_PageObjects extends CommonPage {

    /**
     * Simplex_CallingFrom_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *      
     *            represents data input
     */
    public Simplex_CallingFrom_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }
    
    //Page Patterns
    @FindBy(xpath = "//button[contains(text(),'<<<>>>')]")
    protected Element Button_SimplexUX;

    // *************New Account********************
    // New Account
    @FindBy(xpath = "//input[@id='infoParty']")
    protected Element txtNewACCallingPartyName;
    
    @FindBy(xpath = "//*[@id='sfinfoParty']")
    protected Element txtNewACCallingPartyName1;
    
    @FindBy(xpath = "//*[@for='infoEmail']")
    protected Element LabelEmail;


    // New Account
    @FindBy(xpath = "//input[@id='callBackNum']")
    protected Element txtNewACCallBackNo;

    // New Account
    @FindBy(xpath = "//select[@id='infoReasonCall']")
    protected Element dropdwnNewACReasonForCall;

    // *********Account Search*********************
    @FindBy(xpath = "//input[@id='sfinfoParty']")
    protected Element txtSearchCallingPartyName;

    @FindBy(xpath = "//input[@id='callBackNum2']")
    protected Element txtSearchCallBackNo;

    @FindBy(xpath = "//select[@id='sfinfoReasonCall']")
    protected Element dropdwnSearchReasonForCall;
    
    @FindBy(xpath = "//li[contains(text(),'Serve Customer Without Safeguarding')]")
    protected Element WOsafeGuardingTab;

    // ********Common for New Account & Account Search***********

    @FindBy(xpath = "//input[@id='alternateNumber']")
    protected Element txtAlternatePhoneNumber;

    @FindBy(xpath = "//input[@id='infoEmail']")
    protected Element txtEmail;

    @FindBy(xpath = "//button[@ng-click='moveNextPage()']")
    protected Element btnNext;

    @FindBy(xpath = "//button[@ng-click='salesRequiredCheck()']")
    protected Element salesProfileSave;
    @FindBy(xpath = "//input[@id='addressZipCode']")
    protected Element zipCode;

    @FindBy(xpath = "//div[@class='clearfix']/div//span[@ng-click='LaunchSafeGuard()']")
    protected Element safeGuardIconCoA;
    
    @FindBy(xpath = "//button[@name='failedToSafeguardBtn']")
    protected Element safeGuardFailureButton;

    @FindBy(xpath = "//textarea[@ng-model='dataSet.note']")
    protected Element safeGuardFailureMsg;
    
    @FindBy(xpath = "//a[@ng-click='saveAndClose()']")
    protected Element safeGuardFailureSaveandCont;
    
    @FindBy(xpath = "//input[@id='addressAddress']")
    protected Element address;

    @FindBy(xpath = "//label[contains(text(),'Address')]")
    protected Element addressLabel;

    @FindBy(xpath = "//div[contains(@ng-repeat,'multipleAddress')]//p")
    protected Element firstMultipleAddress;

    @FindBy(xpath = "//div[contains(@ng-repeat,'address in addressDetails')]//p")
    protected Element SingleAddress;
    
    @FindBy(xpath = "//div[@class='customer-module_switch']//div[@si-section-name='ProductsandServices' and @class='w_switch']")    //"//div[@data-panel-trigger='products']"
    protected Element tabProduct;

    @FindBy(xpath = "//div[@si-section-name='ProductsandServices' and contains(@class,'w_switch')]")    //"//div[@data-panel-trigger='products']"
    protected Element ordersTab;
    
    @FindBy(xpath = "//select[@id='agencyDD']")
    protected Element selectAgencyID;
    
    @FindBy(xpath = "//div[not(contains(@class,'ng-hide'))]/ol/li[contains(@data-steps-tab,'<<<>>>') and contains(@class,'active')]")
    protected Element currentActiveTab;
    
    @FindBy(xpath = "//*[contains(text(),'Sales Profile Information')]")
    protected Element salesProfileInformationTab;
    
    @FindBy(xpath = "//select[@id='lineOfBusiness']")
    protected Element lineOfBusiness;
    
    @FindBy(xpath = "//select[@id='marketcode']")
    protected Element marketCode;
    
    @FindBy(xpath = "//*[@ng-click='openSalesProfile()']")
	protected Element acstSearch_SalesProfile;

    // Account search

    @FindBy(xpath = "//span[contains(text(),'<<<>>>')]")
    protected Element callingFormData;

    @FindBy(xpath = "//p[contains(text(),'Address Found')]")
    protected Element txtAddressFound;

    @FindBy(xpath = "//a[contains(text(),'Edit')]")
    protected Element btnEdit;

    @FindBy(xpath = "//label[@for='AgencyID']")
    protected Element agencyDD;

    @FindBy(xpath = "//span[contains(text(),'Drop Type')]")
    protected Element lnkDropType;

    @FindBy(xpath = "//input[@id='advancedSearch']")
    protected Element txboxAccountsearch;

    @FindBy(xpath = "//button[text()='Open']")
    protected Element btnOpenSearchResult;

    @FindBy(xpath = "//button[text()='Open']")
    protected CList<Element> btnOpenSearchResultList;
    
    @FindBy(xpath = "//li[contains(.,'Final Account')]")
    protected Element SearchResultforFinalAccount;
  
    @FindBy(xpath = "//li[contains(.,'Final Account')]/following-sibling::li//button[text()='Open']")
    protected Element btnOpenSearchResultforFinalAccount;

    @FindBy(xpath = "//*[@id='divDOCC']//button[contains(text(),'Yes')]")
    protected CList<Element> btnYesDoccAgreementList;

    @FindBy(xpath = "//button[contains(@data-modal-action,'YES')]")
    protected Element btnYesDoccAgreement;
    @FindBy(xpath = "//a[contains(@class,'ng-binding') and contains(.,'Moving')]")
    protected Element btnMoving;

    @FindBy(xpath = "//li[contains(@ng-repeat,'ServiceRelated')]//a[(contains(@class,'ng-binding') or contains(@class,'m_next')) and contains(.,'Moving')]")
    protected Element btnRGMoving; // Gopal 0408

    @FindBy(xpath = "//a[contains(text(),'Moving')]")
    protected Element btnMovingList;
    
    @FindBy(xpath = "//a[contains(.,'PRODUCT TOOLS')]")
    protected Element IWantTolink;

    @FindBy(xpath = "//a[contains(text(),'Advanced Search')]")
    protected Element AdvancedSearchLink;
    
    @FindBy(xpath = "//div[text()='<<<>>>']")
    protected Element OptionforAdvanceSearch;
    
    @FindBy(xpath = "//input[contains(@id,'<<<>>>') and  contains(@id,'<<<>>>')]")
    protected Element BillAccountType;
    
  
    @FindBy(xpath = "//a[@ng-click='<<<>>>']/preceding-sibling::input")
    protected Element SearchinputTextfield;

    @FindBy(xpath = "//a[@ng-click='<<<>>>']")
    protected Element Searchbutton;
    
    @FindBy(xpath = "//*[@ng-click='InstallPage()']")
    protected Element newaccount;
    
    @FindBy(xpath = "//*[@ng-click='SearchPage()']")
   	protected Element searchtab;
    
    
    // *******************C2G*************************************

    @FindBy(xpath = "//li[@ng-click='InstallPage()']")
    protected Element btnNewAccount;

    @FindBy(xpath = "//input[@id='callBackNum']")
    protected Element installCallBackNo;

    @FindBy(xpath = "//input[@id='infoEmail']")
    protected Element installEmail;

    @FindBy(xpath = "//input[@id='sfinfoParty']")
    protected Element SearchCallingPartyName;

    @FindBy(xpath = "//input[@id='infoParty']")
    protected Element installCustomerName;

    @FindBy(xpath = "//input[@id='callBackNum2']")
    protected Element SearchCallBackNo;

    @FindBy(xpath = "//select[@id='sfinfoReasonCall']")
    protected Element Searchreasonforcall;

    @FindBy(xpath = "//a[contains(text(),'Advanced Search')]")
    protected Element linkAdvancedSearch;

    @FindBy(xpath = "//*[@data-reveal-hint-trigger='FiOSTV']")
    protected Element serviceValidation_FiosTV;

    @FindBy(xpath = "//*[@data-reveal-hint-trigger='FiOSInternet']")
    protected Element serviceValidation_FiosInternet;

    @FindBy(xpath = "//*[@data-reveal-hint-trigger='LECVoice']")
    protected Element serviceValidation_LecVoice;

    @FindBy(xpath = "//*[@data-reveal-hint-trigger='FiOSDigital Voice']")
    protected Element serviceValidation_FiosDigitalVoiceTV;

    @FindBy(xpath = "//*[@id='IfProducts']")
    protected Element swtch_frame;

    //// C2g Change ////
    @FindBy(xpath = "//button[@ng-click='searchCandidateAccount(accountDetails)']")
    protected Element OpenButton;

    @FindBy(xpath = "//button[@class='button  secondary p-100']")
    protected Element NoAgreementButton;

    @FindBy(xpath = "//p[contains(text(),'Select Company & Location')]")
    protected Element selectCompany;

    @FindBy(xpath = "//select[@id='selectedCompany']")
    protected Element drpdwn_SelectCompany;

    @FindBy(xpath = "//select[@id='selectedLocation']")
    protected Element drpdwn_SelectLocation;

    @FindBy(xpath = "//button[contains(text(),'Continue')]")
    protected Element btnContinue;

    @FindBy(xpath = "//input[@id='sfinfoParty']")
    protected Element SearchC2GCallingPartyName;
    
    
    
    
    
    
    
    

    // ************************GUI
    // Vliadations*******************************************************

    // Shilpa***

    @FindBy(xpath = "//li[@data-steps-tab='customerInfo']")
    protected Element customerInfoTab;

    @FindBy(xpath = "//li[@data-tab='newAccount']")
    protected Element NewAccount;

    @FindBy(xpath = "//li[@data-steps-tab='address-search']")
    protected Element AddressSearch;

    @FindBy(xpath = "//*[contains(@ng-show,'SingleLineSearchEnhancements')]")
    protected Element AddressSearchAlert;

    @FindBy(xpath = "//li[@data-steps-tab='verify-address']")
    protected Element VerifyAddress;

    @FindBy(xpath = "//input[@id='addressAddress']")
    protected Element addressDisabled;

    @FindBy(xpath = "//li[@data-steps-tab='availableServices']")
    protected Element AvailableServices;

    @FindBy(xpath = "//div[@ng-if='!isWirelessOffer && !$parent.isWinback' or @ng-if='!isWirelessOffer && !$parent.isWinback && !isBusiness']")
    protected Element AlertMsg;

    @FindBy(xpath = "//*[@ng-click='openSalesProfile()']")
    protected Element AgencyLink;

    @FindBy(xpath = "//button[@ng-click='salesRequiredCheck()']")
    protected Element AgencySave;
    
    @FindBy(xpath = "//*[contains(text(),'Is this Customer Name correct?')]")
    protected Element NextErrorCustomerInfo;

    @FindBy(xpath = "//*[contains(text(),'Required Fields missed')]")
    protected Element NextError;

    @FindBy(xpath = "//*[contains(text(),'Invalid Email. Please try again.')]")
    protected Element InvalidEmailError;

    @FindBy(xpath = "//button[@name='connecttocall']")
    protected Element ConnectToCall;

    @FindBy(xpath = "//a[contains(text(),'Advanced Search')]")
    protected Element AdvancedSearch;

    @FindBy(xpath = "//div[@data-ui-view='addressview']")
    protected Element AddressView;

    @FindBy(xpath = "//span[@ng-click='closeAdvancedSearch()']")
    protected Element CloseAddressView;

    @FindBy(xpath = "//button[@name='back']")
    protected Element backButton;

    @FindBy(xpath = "//select[@ng-model='salesCodeDD']")
    protected Element Salecode;

    @FindBy(xpath = "//select[@ng-model='salesCodeDD']/descendant::*[1]")
    protected Element DefaultSalecode;

    @FindBy(xpath = "//select[@ng-model='agencyDD']")
    protected Element AgencyList;

    @FindBy(xpath = "//select[@ng-model='agencyDD']/descendant::*[1]")
    protected Element AgencyListDefaultValue;

    @FindBy(xpath = "//select[@ng-model='jurisdictionDD']")
    protected Element jurisdiction;

    @FindBy(xpath = "//select[@ng-model='languageDD']")
    protected Element Language;

    @FindBy(xpath = "//*[contains(text(),'Alternate/Subsequent Sales ID')]")
    protected Element AlternateSalesID;

    @FindBy(xpath = "//ul[@ng-show='showAlternateSalesView']/li[@aria-expanded='true']")
    protected Element AlternateSalesIDExpand;

    @FindBy(xpath = "//ul[not(contains(@class,'hide'))]/li[@id='AlternateSalesSection']")
    protected Element AlternateSalesSection;

    @FindBy(xpath = "//*[contains(text(),'Cancel and ReIssue')]")
    protected Element CancelReissue;

    @FindBy(xpath = "//li[@id='CancelReissueSection']")
    protected Element CancelReissueSection;

    @FindBy(xpath = "//ul[@id='Cancel_ReissueView']/li[@aria-expanded='true']")
    protected Element CancelReissueExpand;

    @FindBy(xpath = "//button[@ng-click='salesRequiredCheck()']")
    protected Element Save;

    // Gopal***

    // New Account
    @FindBy(xpath = "//*[@data-steps-tab = 'customerInfo']")
    protected Element Customer_Info_Tab;

    // New Account
    @FindBy(xpath = "//*[@data-steps-tab = 'address-search']")
    protected Element Address_Search;

    // New Account
    @FindBy(xpath = "//*[@data-steps-tab = 'verify-address']")
    protected Element Verify_Address;

    // New Account
    @FindBy(xpath = "//*[@data-steps-tab = 'availableServices']")
    protected Element Available_Services;



    @FindBy(xpath = "//*[@ng-click = 'openSalesProfile()']")
    protected Element AgencyID;

    @FindBy(xpath = "//*[@ng-click = 'salesRequiredCheck()']")
    protected Element SaveAgency;



    @FindBy(xpath = "//*[@ng-disabled= 'IsUBBQualified || disableNextC2gHoa']")
    protected Element NextButton_Enable;

    @FindBy(xpath = "//*[@id= 'lineOfBusiness']")
    protected CList<Element> lob_dropdown;

    @FindBy(xpath = "//*[@id= 'lineOfBusiness']")
    protected Element Lob;

    @FindBy(xpath = "//*[@name = 'back']")
    protected Element Back_Button;

    @FindBy(xpath = "//*[@data-steps-tab = 'availableServices']")
    protected Element Active_availableServices_Tab;

    @FindBy(xpath = "//*[text() = 'Fios TV']")
    protected Element FTV;

    @FindBy(xpath = "//*[text() = 'Fios Internet']")
    protected Element FInternet;

    @FindBy(xpath = "//*[@data-reveal-content = 'FiosInternet']")
    protected Element Internet_Details;

    @FindBy(xpath = "//*[text() = 'LEC Voice']")
    protected Element Lec_Voice;

    @FindBy(xpath = "//*[text() = 'Fios Digital Voice']")
    protected Element FD_Voice;

    @FindBy(xpath = "//*[@class =  'clear margin-all-zero w_metrics-grid m_icons padding-top-micro']")
    protected Element Available_Products_Services;

    @FindBy(xpath = "//*[@class =  'w_metrics-grid m_icons padding-left-small']")
    protected Element Address_Details;

    @FindBy(xpath = "//span[@ng-click='editSearch()']")
    protected Element Editlink2;

    @FindBy(xpath = "//*[contains(text(),'Sales Profile Information')]")
    protected Element Sales_Profile_Info;

    @FindBy(xpath = "//*[@data-tab= 'newAccount']")
    protected Element New_Account_Tab;

    @FindBy(xpath = "//*[@ng-if = 'nydmaCreditEnable']")
    protected Element NYDMA_Capable;
    
    @FindBy(xpath = "//label[@for = 'infoVerizonWireLessNumber']")
    protected Element labelNewACCallBackNo;
    
    //******************UI Vlidations by surya*******
    
    //@FindBy(xpath = "//div[contains(@ng-if,'acountSummary')]/p[1]")
    @FindBy(xpath = "//li[contains(@ng-class,'acountSummary')]//*[contains(text(),'Live Account')]/../following-sibling::li//div[contains(@ng-if,'acountSummary')]/p[1]")
    protected Element labelSearchResultCustomerName_LiveAccount;
    
    @FindBy(xpath = "//li[contains(@ng-class,'acountSummary')]//*[contains(text(),'Live Account')]/../following-sibling::li//div[contains(@ng-if,'acountSummary')]/p[2]")
    protected Element labelSearchResultCustomerAddress_LiveAccount;
    
//    @FindBy(xpath = "(//div[@title='Click to copy address']//*[string-length(text())>0])[1]")
    @FindBy(xpath = "(//div[@ng-if='isShowCustomerInfo']//div[contains(@class,'p-')])[1]//span[1]")
    protected Element labelHeaderCustomerName;
    
    @FindBy(xpath = "//div[@title='Click to copy address']//*[contains(text(),'Tenure')]")
    protected Element labelHeaderTenure;
    
    @FindBy(xpath = "(//div[@title='Click to copy address']//div[string-length(text())>0])[3]")
    protected Element labelHeaderAddressLine1;
    
    @FindBy(xpath = "(//div[@title='Click to copy address']//div[string-length(text())>0])[4]")
    protected Element labelHeaderAddressLine2;
    
    @FindBy(xpath = "//div[@ng-if='!emailToolTip']")
    protected Element labelHeaderEmail;
    
    @FindBy(xpath = "//span[@data-open-modal='EditCallingPartyName']")
    protected Element labelHeaderCallingParty;
    
    @FindBy(xpath = "//div[@data-modal='EditCallingPartyName']")
    protected Element PopupHeaderCallingPartyEdit;
    
    @FindBy(xpath = "//input[@id='CallingPartyName']")
    protected Element PopupHeaderCallingPartyEdit_NameTextbox;
    
    @FindBy(xpath = "//div[contains(@class,'w_modal') and contains(@class,'active')]//button[contains(text(),'ave')]")
    protected Element SaveButton_PopupHeaderCallingPartyEdit;
    
    @FindBy(xpath = "//div[@data-modal='EditCallingPartyName']//button[contains(text(),'Cancel')]")
    protected Element CancelButton_EditCallingPartyPopup;
    
    @FindBy(xpath = "//a[@ng-click='OpenChatWindow()']")
    protected Element OpenChatWindow;
    
    @FindBy(xpath = "//iframe']")
    protected WebElement ChatWindowOuterFrame;
    
    @FindBy(xpath = "//span[contains(text(),'Cancel Chat')]")
    protected Element Cancel_ChatWindow;
    
    @FindBy(xpath = "//a[@data-ui-sref='followuppanel']")
    protected Element OpenFollowUpWindow;
    
    @FindBy(xpath = "//span[@id='SampleB']")
    protected Element SelectType_FollowUpWindow;
    
    @FindBy(xpath = "//span[@href='#/dummy']")
    protected Element Cancel_FollowUpWindow;
    
    @FindBy(xpath = "//div[contains(@class,'toolbar_charm')]//span[@class='block padding-top-tiny']/span[contains(text(),'MORE')]/ancestor::div[@data-drop-list][1]/a")
    protected Element MoreOptions_Header;
    
    @FindBy(xpath = "//div[contains(@class,'toolbar_charm')]//span[@class='block padding-top-tiny']/span[contains(text(),'MORE')]/ancestor::div[contains(@class,'toolbar')][1]/following-sibling::div[contains(@class,'drop-list_list')]//a[text()='Links']")
    protected Element Links_Header;
    
    @FindBy(xpath = "//div[contains(@class,'toolbar_charm')]//span[@class='block padding-top-tiny']/span[contains(text(),'MORE')]/ancestor::div[contains(@class,'toolbar')][1]/following-sibling::div[contains(@class,'drop-list_list')]//a[contains(text(),'How To')]")
    protected Element HowTo_Link_Header;
    
    @FindBy(xpath = "//a[text()='Consumer CoFEE 2.0 Handouts']")
    protected Element HowTo_Window_CoFEEHandout;
    
    @FindBy(xpath = "//div[@data-ui-view='modal']/div[contains(@class,'active')]")
    protected Element Links_PopUp;
    
    @FindBy(xpath = "//div[@data-ui-view='modal']/div[contains(@class,'active')]//div[contains(@class,'modal_header')]//*[contains(@class,'modal-title')]")
    protected Element Header_Links_PopUp;
    
    @FindBy(xpath = "//div[@data-ui-view='modal']/div[contains(@class,'active')]")
    protected Element PopUp_VerticalModal;
    
    @FindBy(xpath = "//div[@data-ui-view='modal']/div[contains(@class,'active')]//div[contains(@class,'modal_header')]//*[contains(@class,'modal-title')]")
    protected Element Title_PopUp_VerticalModal;
    
    @FindBy(xpath = "//div[@data-ui-view='modal']/div[contains(@class,'active')]//div[contains(@class,'modal_header')]//*[contains(@ng-click,'closeBtn()')]")
    protected Element CloseX_PopUp_VerticalModal;
    
    @FindBy(xpath = "//li[@data-accordion and @ng-click]//*[contains(@class,'text') and contains(text(),'<<<>>>')]")
    protected Element Dynamic_DataAccordian_ExpandableHeader;
    
    @FindBy(xpath = "//li[@data-accordion and @ng-click]//*[contains(@class,'text') and contains(text(),'<<<>>>')]//ancestor::li[1]/following-sibling::li[contains(@class,'m_accordion-details')]")
    protected Element Dynamic_DataAccordian_DetailsSection;
    
    @FindBy(xpath = "//li[@data-accordion and @ng-click]//*[contains(@class,'text') and contains(text(),'<<<>>>')]")
    protected WebElement Dynamic_DataAccordian_ExpandableHeader_WebElement;
    
    @FindBy(xpath = "//li[@data-accordion and @ng-click]//*[contains(@class,'text') and contains(text(),'<<<>>>')]//ancestor::li[1]/following-sibling::li[contains(@class,'m_accordion-details')]")
    protected WebElement Dynamic_DataAccordian_DetailsSection_WebElement;
    
    @FindBy(xpath = "//div[@class='action-nav_controls']//div[@data-ng-click and contains(@si-section-name,'<<<>>>')]")
    protected Element ToggleButton_Dynamic;
    
    @FindBy(xpath = "//div[@class='action-nav_controls']//div[@data-ng-click and contains(@si-section-name,'ActivityTimeline')]")
    protected Element Activity_ToggleButton;
    
    @FindBy(xpath = "//div[@data-panel='timeline']")
    protected Element AcitivityTimeline;
    
    @FindBy(xpath = "//ul[@id='ActivityTimelineList']")
    protected Element AcitivityTimelineList;
    
    //*************Account Search Left Pane Tiles
    @FindBy(xpath = "//div[@data-ui-view='fiosDetailsView']")
    protected Element BundleTile_LeftPane;
    
    @FindBy(xpath = "//a[@ng-click='launchProfileDetails();']")
    protected Element BundleTile_BundleLink;
    
    @FindBy(xpath = "//div[contains(@class,'w_modal') and contains(@class,'active')]//span[text()='Account Number']/following-sibling::div")
    protected Element ProfileDetails_PopUp_AccountNumber;
    
    @FindBy(xpath = "//div[contains(@class,'w_modal') and contains(@class,'active')]//button[text()='Close']")
    protected Element ProfileDetails_PopUp_Cancel;
    
    @FindBy(xpath = "//div[@data-ui-view]//div[@data-reveal-trigger and contains(text(),'<<<>>>')]")
    protected Element TileDynamic_LeftPane;
    
    @FindBy(xpath = "//div[@data-ui-view='salesOpportunities']")
    protected Element SalesOppurtunities_LeftPane;
    
    @FindBy(xpath = "//div[@data-ui-view='insightsView']")
    protected Element InsightsView_LeftPane;
    
    @FindBy(xpath = "//div[@data-ui-view='connectionsView']")
    protected Element ConnectionsView_LeftPane;
    
    
    //******************New UI Validation Locators*******
    
    //@FindBy(xpath = "//div[contains(@ng-if,'acountSummary')]/p[1]")
    @FindBy(xpath = "//li[contains(@ng-class,'acountSummary')]//*[contains(text(),'Live Account')]/../following-sibling::li//div[contains(@ng-if,'acountSummary')]/p[1]")
    protected Element labelSearchResultCustomerName_LiveAccountNew;
    
    @FindBy(xpath = "//li[contains(@ng-class,'acountSummary')]//*[contains(text(),'Live Account')]/../following-sibling::li//div[contains(@ng-if,'acountSummary')]/p[2]")
    protected Element labelSearchResultCustomerAddress_LiveAccountNew;
    
    
    @FindBy(xpath = "(//div[@ng-if='isShowCustomerInfo']//div[contains(@class,'p-')])[1]//div[1]")
    protected Element labelHeaderCustomerNameNew;
    
    @FindBy(xpath = "//span[contains(@class,'customer-profile-icon')]")
    protected Element CutomerProfileIconNew;
    
    @FindBy(xpath = "//div[@title='Click to copy address']//*[contains(text(),'Tenure')]")
    protected Element labelHeaderTenureNew;
    
    @FindBy(xpath = "//div[@class='customer-address']/span[1]")
    protected Element labelHeaderAddressLine1New;
    
    @FindBy(xpath = "//div[@class='customer-address']/span[2]")
    protected Element labelHeaderAddressLine2New;
    
    @FindBy(xpath = "//div[@class='customer-address']/span[3]")
    protected Element labelHeaderEmailNew;
    
    @FindBy(xpath = "//span[contains(@class,'calling-party-name')]")
    protected Element labelHeaderCallingPartyNew;
    
    @FindBy(xpath = "//div[contains(@class,'customer-info ')]//span[contains(text(),'Edit Name')]")
    protected Element EditCallingPartyNew;
    
    @FindBy(xpath = "//div[@data-modal='EditCallingPartyName']")
    protected Element PopupHeaderCallingPartyEditNew;
    
    @FindBy(xpath = "//input[@id='CallingPartyName']")
    protected Element PopupHeaderCallingPartyEdit_NameTextboxNew;
    
    @FindBy(xpath = "//div[@data-modal='EditCallingPartyName']//button[contains(text(),'Cancel')]")
    protected Element CancelButton_EditCallingPartyPopupNew;
    
    @FindBy(xpath = "//a[@ng-click='OpenChatWindow()']")
    protected Element OpenChatWindowNew;
    
    @FindBy(xpath = "//iframe']")
    protected WebElement ChatWindowOuterFrameNew;
    
    @FindBy(xpath = "//span[contains(text(),'Cancel Chat')]")
    protected Element Cancel_ChatWindowNew;
    
    @FindBy(xpath = "//a[@data-ui-sref='followuppanel']")
    protected Element OpenFollowUpWindowNew;
    
    @FindBy(xpath = "//span[@id='SampleB']")
    protected Element SelectType_FollowUpWindowNew;
    
    @FindBy(xpath = "//span[@href='#/dummy']")
    protected Element Cancel_FollowUpWindowNew;
    
    @FindBy(xpath = "//div[@class='tool-bar_text']//span[contains(text(),'<<<>>>')]/ancestor::div[(contains(@class,'tool-bar')) and (@ng-click or @data-ui-sref or @data-repdashboard-tooltip)]")
    protected Element HeaderIcon_Dynamic;
    
    @FindBy(xpath = "//*[contains(@ng-keyup,'SISearchCtrl')]")
    protected Element SearchTextField_SupportInfoPopUp;
    
    @FindBy(xpath = "//div[@ng-click='SISearchCtrl.toggleSearchFilter()']/p")
    protected Element SearchFilterLabel_SupportInfoPopUp;
    
    @FindBy(xpath = "//span[contains(text(),'Support Info Search')]/following-sibling::*[contains(@class,'vzicon icon-close')]")
    protected Element CloseButton_SupportInfoPopUp;
    
    @FindBy(xpath = "//span[contains(text(),'Call Notes')]/ancestor::div[contains(@class,'row')]//*[contains(@class,'vzicon icon-close')]")
    protected Element CloseButton_CallNotesPopUp;
    
    @FindBy(xpath = "//textarea[@id='CallNotes']")
    protected Element TextArea_CallNotesPopUp;
    
    @FindBy(xpath = "//textarea[@id='CallNotes']")
    protected Element TextAreaRead_CallNotesPopUp;
    
    @FindBy(xpath = "(//span[contains(text(),'More options')]/preceding-sibling::span)[2]")
    protected Element MoreOptions_HeaderNew;
    
    @FindBy(xpath = "//div[contains(@class,'w_drop-list') and contains(@class,'')]//a[contains(text(),'Links')]")
    protected Element Links_HeaderNew;
    
    @FindBy(xpath = "//div[contains(@class,'w_drop-list') and contains(@class,'')]//a[contains(text(),'How To')]")
    protected Element HowTo_Link_HeaderNew;
    
    @FindBy(xpath = "//a[text()='Consumer CoFEE 2.0 Handouts']")
    protected Element HowTo_Window_CoFEEHandoutNew;
    
    @FindBy(xpath = "//div[@data-ui-view='modal']/div[contains(@class,'active')]")
    protected Element Links_PopUpNew;
    
    @FindBy(xpath = "//div[@data-ui-view='modal']/div[contains(@class,'active')]//div[contains(@class,'modal_header')]//*[contains(@class,'modal-title')]")
    protected Element Header_Links_PopUpNew;
    
    @FindBy(xpath = "//div[@data-ui-view='modal']/div[contains(@class,'active')]")
    protected Element PopUp_VerticalModalNew;
    
    @FindBy(xpath = "//div[@data-ui-view='modal']/div[contains(@class,'active')]//div[contains(@class,'modal_header')]//*[contains(@class,'modal-title')]")
    protected Element Title_PopUp_VerticalModalNew;
    
    @FindBy(xpath = "//div[@data-ui-view='modal']/div[contains(@class,'active')]//div[contains(@class,'modal_header')]//*[contains(@ng-click,'closeBtn()')]")
    protected Element CloseX_PopUp_VerticalModalNew;
    
    @FindBy(xpath = "//li[@data-accordion and @ng-click]//*[contains(@class,'text') and contains(text(),'<<<>>>')]")
    protected Element Dynamic_DataAccordian_ExpandableHeaderNew;
    
    @FindBy(xpath = "//li[@data-accordion and @ng-click]//*[contains(@class,'text') and contains(text(),'<<<>>>')]//ancestor::li[1]/following-sibling::li[contains(@class,'m_accordion-details')]")
    protected Element Dynamic_DataAccordian_DetailsSectionNew;
    
    @FindBy(xpath = "//li[@data-accordion and @ng-click]//*[contains(@class,'text') and contains(text(),'<<<>>>')]")
    protected WebElement Dynamic_DataAccordian_ExpandableHeader_WebElementNew;
    
    @FindBy(xpath = "//li[@data-accordion and @ng-click]//*[contains(@class,'text') and contains(text(),'<<<>>>')]//ancestor::li[1]/following-sibling::li[contains(@class,'m_accordion-details')]")
    protected WebElement Dynamic_DataAccordian_DetailsSection_WebElementNew;
    
    @FindBy(xpath = "(//div[contains(@class,'switch-label') and contains(text(),'<<<>>>')])[last()]/preceding-sibling::*[contains(@class,'w_switch')]")
    protected Element ToggleButton_DynamicNew;
    
    //@FindBy(xpath = "//div[contains(@class,'simplex_panel') and contains(@class,'active')]//*[contains(@class,'heading')]/*[contains(@class,'simplex_action-panel-icon')]/following-sibling::*[contains(text(),'<<<>>>')]")
    @FindBy(xpath = "//div[contains(@class,'simplex_panel') and contains(@class,'active')]//*[contains(@class,'heading')]//*[contains(text(),'<<<>>>')]")
    protected Element Title_PanelNew;
    
    //@FindBy(xpath = "//*[contains(@class,'heading')]/*[contains(@class,'simplex_action-panel-icon')]/following-sibling::*[contains(text(),'<<<>>>')]/ancestor::*[contains(@class,'simplex_panel-heading')]/following-sibling::*")
    @FindBy(xpath = "//div[contains(@class,'simplex_panel') and contains(@class,'active')]//*[contains(@class,'heading')]//*[contains(text(),'<<<>>>')]/ancestor::*[contains(@class,'simplex_panel-heading')]/following-sibling::*")
    protected Element Content_PanelNew;
    
    @FindBy(xpath = "(//div[contains(@class,'switch-label') and contains(text(),'ACTIVITY')])[last()]/preceding-sibling::*[contains(@class,'w_switch')]")
    protected Element Activity_ToggleButtonNew;
    
    @FindBy(xpath = "//div[@data-panel='timeline']")
    protected Element AcitivityTimelineNew;
    
    @FindBy(xpath = "//ul[@id='ActivityTimelineList']")
    protected Element List_AcitivityTimelinePaneNew;
    
    @FindBy(xpath = "//ul[@id='ActivityTimelineList']")
    protected Element Content_BillingPaneNew;
    
    //*************Account Search Left Pane Tiles
    @FindBy(xpath = "//*[@ng-click='launchProfileDetails();']//ancestor::div[contains(@class,'column')]")
    protected Element BundleTile_LeftPaneNew;
    
    @FindBy(xpath = "//*[@ng-click='launchProfileDetails();']")
    protected Element BundleTile_BundleLinkNew;
    
    @FindBy(xpath = "//div[contains(@class,'w_modal') and contains(@class,'active')]//*[text()='Account Number']/following-sibling::div")
    protected Element ProfileDetails_PopUp_AccountNumberNew;
    
    @FindBy(xpath = "//div[contains(@class,'w_modal') and contains(@class,'active')]//button[text()='Close']")
    protected Element ProfileDetails_PopUp_CancelNew;
    
    @FindBy(xpath = "//div[@id='CustomerDashboardSection']//div[@data-ui-view]//div[contains(@class,'header')]/span[contains(text(),'<<<>>>')]")
    protected Element TileLabelDynamic_LeftPaneNew;
    
    @FindBy(xpath = "//div[@id='CustomerDashboardSection']//div[@data-ui-view]//div[contains(@class,'header')]/span[contains(text(),'<<<>>>')]/following-sibling::*[contains(@class,'vzicon')]")
    protected Element TileIconDynamic_LeftPaneNew;
    
    @FindBy(xpath = "//div[@data-ui-view='salesOpportunities']")
    protected Element SalesOppurtunities_LeftPaneNew;
    
    @FindBy(xpath = "//div[@data-ui-view='insightsView']")
    protected Element InsightsView_LeftPaneNew;
    
    @FindBy(xpath = "//div[@data-ui-view='connectionsView']")
    protected Element ConnectionsView_LeftPaneNew;
    
    //Safeguard
    
    @FindBy(xpath = "//*[@id='SimplexWrap']//span[@ng-click='LaunchSafeGuard()' and @data-safeguard='false']")
    protected Element safeGuardIcon;
    
    @FindBy(xpath = "//*[@id='SafeguardHomeContent']//label[contains(text(),'<<<>>>')]")
    protected Element safeGuardOptionRB;
    
    @FindBy(xpath = "//*[@id='SafeguardHomeContent']//label[contains(text(),'<<<>>>')]")
    protected Element WOsafeGuardingOptionsRB;
    
    @FindBy(xpath = "//div[contains(@ng-if,'noSafeguardSelectedOption')]//label[contains(text(),'<<<>>>')]")
    protected Element WOsafeGuardingOptionsLink;

    @FindBy(xpath = "(//*[@id='SafeguardHomeContent']//label[contains(text(),'<<<>>>')]//following::div//input)[1]")
    protected Element safeGuardOptionInputField;

    @FindBy(xpath = "//*[@id='csvVerifyBtn']")
    protected Element safeGuardVerifyButton;

    @FindBy(xpath = "//*[@id='SafeguardHomeContent']//span/b[contains(text(),'Failed Attempt:')]")
    protected Element safeGuardWarningMsg;
    
    @FindBy(xpath = "//*[@id='SafeguardHomeContent']//span/b[contains(text(),'Failed Attempt:')]//following::span[1]")
    protected Element safeGuard_FullWarningMsg;
    
    @FindBy(xpath = "//div[@data-ui-view='safeguardview']//div/p[contains(text(),'Customer Validation Screen')]")    
    protected CList<Element> safeGuard_CustomerValidationScreen;
    
    @FindBy(xpath = "(//*[@id='ContainerKnobs']//div[@si-section-name='ProductsandServices'])[1]")    
    protected Element sg_ProductServicesIcon;

    // IPTV
    @FindBy(xpath = "//*[contains(text(),'Available Products & Services')]//following::*[contains(text(),'Fios TV- IPTV') or contains(text(),'fios IPTV') or contains(text(),'IPTV')]")    
    protected Element availableServ_Iptv;
    
    @FindBy(xpath = "//a[@ng-click='editSearch()']")
    protected Element Editlink;
    
    @FindBy(xpath = "//p[@ng-hide='isCallBackNumberError']")
    protected Element AccsearchReqfielderrormsg;
    
    @FindBy(xpath = "//div[@ng-if='accountNotFound']")
    protected Element AccountNtFound;
    @FindBy(xpath = "//section[@ng-if='EnableSkinnyDashboard' and contains(@class,'active')]")
    protected Element dashboardSection;
    
    @FindBy(xpath = "//span[contains(text(),'Connection')]")
    protected Element snapshot;
    // Stack Disconnect
    @FindBy(xpath = "//div[@class='pendingorder-droplist_title']")
    protected Element stackdisconnect;

    @FindBy(xpath = "*//div[@class='w_pendingorder-droplist']/ul/li/a[contains(text(),'<<<>>>')]")
    protected Element stackdisconnect1;
    
    @FindBy(xpath = "//p[contains(.,'Advanced Search')]")
    protected Element AdvancsearchNew;
    
    @FindBy(xpath = "//*[@id='addressHouseNumber']")
    protected Element AddressretryHN;
    
    @FindBy(xpath = "//*[@id='addressStreetDirection']")
    protected Element AddressretryDirc;
    
    @FindBy(xpath = "//*[@id='addressStreetName']")
    protected Element AddressretryStrnm;
    @FindBy(xpath = "//*[@id='addressStreetType']")
    protected Element AddressretryStty;
    
    @FindBy(xpath = "//div[@data-ui-view='verifyaddressview']/div/p[contains(text(),'NTAS')]")
    protected Element NTASError;
    
    @FindBy(xpath = "//*[@ng-bind-html='PresaleMsg|trustAsHtml']")
    protected Element PresaleMsg;
    
    @FindBy(xpath = "//textarea[@id='txtNotes_2']")    
    protected Element sg_txtnoSafeguardtab;
    
    @FindBy(xpath = "//label[@for='A_Thing' and contains(text(),'Mail Duplicate')]")   
    protected Element sg_mailchkboxoption;
    
    @FindBy(xpath = "//button[@ng-click='onContinueClick()']")   
    protected Element btnContinueNoSG;
    
    @FindBy(xpath = "//input[@ng-model='getTicketStatusDataSet.ticketNumber']")   
    protected Element ticketNoWithoutSG;
    
  
    @FindBy(xpath = "//span/a[contains(text(),'<<<>>>')]")   
    protected Element optionLinkDisplayed;
    
    @FindBy(xpath = "//div[@id='divMailBillmsg']//p")   
    protected Element NoSGText;
    
    @FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_ddlMissedAppCode']")   
    protected Element missedAppointmentCOde;
    
    @FindBy(xpath = "//Button[@ng-click='onClose()']")   
    protected Element sg_BtnClose;
    
    @FindBy(xpath = "(//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_calDD')]//td[@class='blueGradientDates' or @class='TodayDate' or @class='HoverDates'])[1]")
    protected Element firstAvailableDate;

    @FindBy(xpath = "(//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_calDD')]//td[@class='FutureDate'])[1]")
    protected Element firstAvailableFutureDate;

    @FindBy(xpath = "(//table[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucOODD_calDD')]//td[position()!=1 and position()!=7][@class='blueGradientDates'])[4]")
    protected Element fourthAvailableDate;
    
    @FindBy(xpath = "//div[@class='timeSlots']//tr[2]//a[1]")
    protected Element lnkTimeSlots;
    
    @FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$FooterContent$btnCancel']")
    protected Element btnSubmitDueDate;
    
    @FindBy(xpath = "//button[text()='Open' and contains(@ng-click,'searchCandidateAccount')]")
    protected Element btnOpenLiveAccount;
    @FindBy(xpath = "//*[@ng-click = 'LoadAdvancedSearch()']")
    protected Element advancedsearch;
    
    @FindBy(xpath = "//*[text() = 'Saved Alt Channel Order']")
    protected Element SavedAltChannelOrder;
    
    @FindBy(xpath = "//*[@id = 'acvSearchInput']")
    protected Element TxtSavedAlternateChannelOrder;
    
    @FindBy(xpath = "//*[@id = 'acvSearchInput']/following-sibling::a[@ng-click = 'ACVSearch()']")
    protected Element btnSavedAlternateChannelOrder;
  
    @FindBy(xpath = "//*[@id = 'btnOpenCancelOrder']")
    protected Element btnOpenCancelOrder;
    
    @FindBy(xpath = "//*[@id = 'cancelReason']")
    protected Element drpcancelreason;
    
    @FindBy(xpath = "//*[@data-ng-click= 'CancelOrder()']")
    protected Element btnCancelOrder;
  
    @FindBy(xpath = "//*[@class = 'padding-horiz-medium']//*[@class = 'button p-auto']")
    protected Element btnClose;

  
    @FindBy(xpath = "//*[@id = 'btnResumeOrder']")
    protected Element ResumeOrder;

    //Advance address search  optix install
    // Vikram script start    
      
      @FindBy(xpath = "//*[@id='addressHouseNumber']")
      protected Element addressHouseNumber;
      
      @FindBy(xpath = "//*[@id='addressStreetDirection']")
      protected Element addressStreetDirection;
      
      @FindBy(xpath = "//*[@id='addressStreetName']")
      protected Element addressStreetName;
      
      @FindBy(xpath = "//*[@id='addressStreetType']")
      protected Element addressStreetType;
      
      @FindBy(xpath = "//*[@id='addressDirectionalSuffix']")
      protected Element addressDirectionalSuffix;
      
      @FindBy(xpath = "//*[@id='addressStructure']")
      protected Element addressStructure;
      
      @FindBy(xpath = "//*[@id='addressBuildingDetails']")
      protected Element addressBuildingDetails;
      
      @FindBy(xpath = "//*[@id='addressFloor']")
      protected Element addressFloor;
      
      @FindBy(xpath = "//*[@id='addressUnit']")
      protected Element addressUnit;
      
      @FindBy(xpath = "//*[@id='addressUnitDetails']")
      protected Element addressUnitDetails;
      
      @FindBy(xpath = "//*[@id='addressCity']")
      protected Element addressCity;
      
      @FindBy(xpath = "//*[@id='addressState']")
      protected Element addressState;
      
      @FindBy(xpath = "//*[@id='addressZipCode']")
      protected Element addressZipCode;
      // Vikram script End
    
    //AdvancedSearch
    //Search by Service Address
    @FindBy(xpath = "//input[@ng-model='advancedSearchModel.addrHouseNumbr']")
    protected Element HouseNumber;
    
    @FindBy(xpath = "//input[@ng-model='advancedSearchModel.addrStreetName']")
    protected Element StreetName;
    
    @FindBy(xpath = "//input[@ng-model='advancedSearchModel.addrCity']")
    protected Element City;
    
    @FindBy(xpath = "//select[@ng-model='advancedSearchModel.addrState']")
    protected Element State;
    
    @FindBy(xpath = "//input[@ng-model='advancedSearchModel.addrZipCode']")
    protected Element ZipCode;
     
    @FindBy(xpath = "//a[@ng-click='SvcAddressSearch()']")
    protected Element Adv_ServiceAddress_Continue;
    
    @FindBy(xpath = " //div[contains(text(),'No account found')]")
    protected Element AccountNotfounderror;
    
    @FindBy(xpath = "//li[@ng-class='acountSummary.bgColor']")
    protected Element ExpandPendingOrder;
    
    @FindBy(xpath = "//input[@id='safeguardAccountRadioC']")
    protected Element OTPusingMTNHeightened;
    
    @FindBy(xpath = "//input[contains(@ng-model,'mtnValidation')]")
    protected Element EnterMtnOTP;
    
    @FindBy(xpath = "//button[@id='csvVerifyBtn']")
    protected Element sendTemporaryPIN;
    
    @FindBy(xpath = "//input[@id='safeguardAccountRadioD']")
    protected Element OTPusingEmailHeightened;
    
    @FindBy(xpath = "//input[contains(@ng-model,'emailValidation')]")
    protected Element EnterEmailOTP;
    
    @FindBy(xpath = "//label[@for='NoSafeguardAccountRadioC']")
    protected Element MyTech;
    
    @FindBy(xpath = "//label[@for='wheresMyTechRadioB']")
    protected Element masterOrderNumber;
    
    @FindBy(xpath = "//input[contains(@ng-model,'ticketOrMasterOrderNumber')]")
    protected Element enterMON;
    
    @FindBy(xpath = "//input[contains(@ng-model,'zipCode')]")
    protected Element enterZipCode;
    
    @FindBy(xpath = "//a[contains(text(),'Get Tech Details')]")
    protected Element getTechDetails;
  
    @FindBy(xpath = "//*[@data-modal = 'customerNewConnectModal']//*[contains(text() , 'Calling From:')]")
    protected Element Callingfrompage;
    
    @FindBy(xpath = "//*[@aria-expanded = 'true']/*[text() = 'Live Account(s)']")
    protected Element LiveAccountDeatils;
    
    @FindBy(xpath = "//*[@aria-hidden = 'false']//*[@ng-click = 'searchCandidateAccount(accountDetails)']")
    protected Element LiveAccount;
    
    @FindBy(xpath = "//div[contains(@ng-if,'retryMtnMesg')]")
    protected Element ErrorMsgMtn;
    @FindBy(xpath = "//div[contains(@ng-if,'retryEmailMesg')]")
    protected Element ErrorMsgEmail;
    @FindBy(xpath = "//div[@id='emailSearchResultHolder']/ul")
    protected Element emailSugg;
    @FindBy(xpath = "//li[contains(@ng-repeat,'ServiceRelated')]//a[contains(@class,'ng-binding') and contains(.,'Loyalty Flow / Disconnect')]")
    protected Element btn_LoyaltyFlow_Disconnect;
    @FindBy(xpath = "//*[@class = 'services-tooltip active']//span")  
    protected Element NotificationMessage;
	
	@FindBy(xpath = "//div[@data-close-customtip='alertNotify' and contains(@class,'active')]/div/div/a[contains(@class,'close') and @aria-hidden='true']") 
    protected Element MessageAlert;

}
