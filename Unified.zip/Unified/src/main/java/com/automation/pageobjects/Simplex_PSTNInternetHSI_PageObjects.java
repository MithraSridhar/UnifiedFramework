package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_PSTNBundle_PageObjects class represent the Page Object class.
 * This contains all the identifier for Simplex ProductAndServices Page
 */

public class Simplex_PSTNInternetHSI_PageObjects extends CommonPage {

    /**
     * Simplex_ProductAndServices_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *            represents data input
     */
    public Simplex_PSTNInternetHSI_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }

  //InternetHSI
    
    @FindBy(xpath = "//div[@id='divModemMeg_ScriptSection']/following-sibling::table//label[contains(.,'<<<>>>')]")
    protected Element modemNo;
    
    @FindBy(xpath = "//div[@id='ucEquipment1_divProductModem']//tbody//td//input[@id='ucEquipment1_rptProductModem_rdbProductModem_1']")
    protected Element modemSelect;
    
    @FindBy(xpath = "//div[@id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_pnlFooter']//label/following-sibling::label//input[contains(@name,'btnSaveAndContinue')]")
    protected Element btnHsisaveandContinue;
    
    @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_btnSaveContinue']")
    protected Element btnBBEsaveandContinue;  
  
  //****************************************************************************************************************
    @FindBy(xpath = "//td[contains(text(),'TN')]/following::input[1]")
    protected Element rdoLineSelection;
    
    @FindBy(xpath = "//td[contains(text(),'HSI Type')]/following::select[1]")
    protected Element lstHSIType;
    
    @FindBy(xpath = "//td[contains(text(),'IP Address Type')]/following::select[2]")
    protected Element lstIPAddressType;
    
    @FindBy(xpath = "//td[contains(text(),'Term')]/following::select[3]")
    protected Element lstTerm;
    
    @FindBy(xpath = "//td[contains(text(),'Package')]/following::select[4]")
    protected Element lstPacakge; 
    
    @FindBy(xpath = "//input[@value='rdbVasip']")
    protected Element rdoBBEOptions;
    
    @FindBy(xpath = "//input[@value='Add HSI Package to Selected Line']")
    protected Element btnAddHSIPackage;
    
    @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_btnSaveAndContinue']")
    protected Element btnSaveAndContinueButton;
	
	@FindBy(xpath = "//label[@for = 'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_chkHSIDeposit']")
    protected Element refundablecheck; 
    
    @FindBy(xpath="//input[@id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_btnSaveContinue']")
    protected Element btnsaveContinue;
    
    @FindBy(xpath = "//label[@for='rdbModemYes']")
    protected Element rdoModemYes;
    
    @FindBy(xpath = "(//span[contains(text(),'Verizon HSI Wireless Gateway')])[1]/preceding::input[1]")
    protected Element rdoHSILine;
    
    @FindBy(xpath = "//label[@for='ucEquipment1_rptProductModem_rdbProductModem_0']")
    protected Element rdoHSILineC2G;
    
    @FindBy(xpath = "(//td[text()='Verizon Expert Care equipment protection']/following::input[@value='none'])[1]")
    protected Element rdoEquipmentProtectionOptions;
    
    @FindBy(xpath = "//input[@value='Save and Continue']")
    protected Element btnBBESaveAndContinue;
    
    
	
	// for HBO NOW 
	
	//@FindBy(xpath = "//label[@for ='chkStreamingOption']")
    @FindBy(xpath = "//*[@id='ucStreamingOption1_rptStreamingOptions_ctl01_chkStreamingOption']")
	protected Element HBONOW;
	
	
	//For BBE TAB
	
    @FindBy(xpath = "//*[@id = 'bbeetabs']//*[@id = 'ctl00_ctl00_ContentPlaceHolder1_rptTabs_ctl14_lbtnTab' or @id = 'ctl00_ctl00_ContentPlaceHolder1_rptTabs_ctl12_lbtnTab' or @id = 'ctl00_ctl00_ContentPlaceHolder1_rptTabs_ctl13_lbtnTab']")
	protected Element BBETAB;  // Gopal 
	
	@FindBy(xpath = "//input[@pppname = '<<<>>>']")
	protected Element BBEProduct;
	
	@FindBy(xpath = "//label[contains(@for,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl439')]")
	protected Element NOBBEProduct;
    
    //********************************************************
    
	@FindBy(xpath = "//*[@class = 'jtabs']/li")
	protected Element SelectedHSILine;

	
	@FindBy(xpath = "//*[@id = '0']")
	protected Element NOBBEProduct2;
	
	@FindBy(xpath = "//a[@id='lnkLoopQual']")
	protected Element checkSpeeds;
	
	@FindBy(xpath = "//*[@id = 'btnAddEquipment']")
	protected Element BtnAddEquipment;

	@FindBy(xpath = "//*[@id = 'ddlStandAloneCPE']")
	protected Element AddCPEDropDown;

	@FindBy(xpath = "//*[@id = 'btClose']")
	protected Element BTNOK;

	@FindBy(xpath = "//*[@id='ucInstallation1_rptProductTruckRoll_rdbProductTruckRoll_<<<>>>']")
	protected Element TruckRollProduct;

	@FindBy(xpath = "//*[@id = 'btnAddTechnician']")
	protected Element BtnAddTech;

	@FindBy(xpath = "//*[@id = 'ddlStandAloneCPE']")
	protected Element DropdwnStandaoleCPE;
	@FindBy(xpath = "//*[@class = 'lnkAjax']")
	protected Element HSIBTN;
	
	@FindBy(xpath = "//*[@id='btnAddTechnician']")
    protected Element AddTechButton;
	
	@FindBy(xpath = "//*[@id='ddlStandAloneCPE']")
		protected Element TruckRollDropdown1;
	
	@FindBy(xpath = "//*[contains(@url,'Vasip') and contains(@id,'ctl00_ctl00_ContentPlaceHolder1_rptTabs_ctl15_lbtnTab')]")
	protected Element BBETABC2G;
	@FindBy(xpath = "//input[@id='ContentPlaceHolder1_ContentPlaceHolder1_btnforward']")
    protected Element LecSaveAndCont;
	
	@FindBy(xpath = "//*[@id = 'rdbTechInstall']")
    protected Element TechInstall;
	
	@FindBy(xpath = "//*[@id = 'ucInstallation1_rptProductTruckRoll_ProductTruckRollRow_0']")
    protected Element TruckrollProduct;
	
	@FindBy(xpath = "//*[@id = 'rdbTechInstall']")
    protected Element InstallationType;
	
	//For changepackage clicking - Prakash - 1/28/2019
		@FindBy(xpath = "//*[@value='Change Package']")
	    protected Element ChangePackage;
	
}