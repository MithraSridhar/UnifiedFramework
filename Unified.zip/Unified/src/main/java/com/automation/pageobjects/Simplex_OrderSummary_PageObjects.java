package com.automation.pageobjects;


import java.util.HashMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_OrderSummary_Objects class represent the Page Object class. This
 * contains all the identifier for Simplex Order Summary Page
 */
public class Simplex_OrderSummary_PageObjects extends CommonPage {
	/**
	 * Simplex_OrderSummary_PageObject class constructor
	 * 
	 * @param driver
	 *            represents the instances of type WebDriver
	 * @param windows
	 *            represents boolean value either true or false
	 * @param report
	 *            represents report input             
	 * @param windows
	 *            represents data input            
	 */
	public Simplex_OrderSummary_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
		super(driver, windows,report, data);
	}

	@FindBy(xpath = "//span[contains(text(),'MON')]/../following-sibling::div/span")
	protected Element lblMon;
	
	@FindBy(id = "txtCloseNotes")
	protected Element txtClosingnotes;
	
	@FindBy(xpath = "//*[contains(text(),'Closing Notes')]")
	protected Element lblClosingnotessmall;
	
	@FindBy(xpath = "//span[contains(text(),'Closing Notes')]")
	protected Element lblClosingnotes;
	
	@FindBy(xpath = "//button[contains(text(),'Save and Close')]")
	protected Element btnSaveAndClose;

}
