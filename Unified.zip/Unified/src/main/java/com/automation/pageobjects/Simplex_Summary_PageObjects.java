package com.automation.pageobjects;


import java.util.HashMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_Summary_Objects class represent the Page Object class. This
 * contains all the identifier for Simplex Summary Page
 */
public class Simplex_Summary_PageObjects extends CommonPage {
	/**
	 * Simplex_Summary_PageObject class constructor
	 * 
	 * @param driver
	 *            represents the instances of type WebDriver
	 * @param windows
	 *            represents boolean value either true or false
	 * @param report
	 *            represents report input             
	 * @param windows
	 *            represents data input    
	 *                    
	 */
	public Simplex_Summary_PageObjects(WebDriver driver, boolean windows,ReportStatus report, HashMap<String, String> data) {
		super(driver, windows,report, data);
	}

	@FindBy(xpath = "//input[@id='RbtSocEmail']")
	protected Element RbtSocEmail;

	@FindBy(xpath = "//input[@id='btnSendMailWTC']")
	protected Element btnSendMailWTC;

	@FindBy(xpath = "//label[@for='ChkOfflineRep']")
	protected Element ChkOfflineRep;
	
	@FindBy(xpath = "//input[@id='btnTOSCATS']")
	protected Element btnTOSCATS;
	
	@FindBy(xpath = "//input[@id='chkVerbalAcceptance']")
	protected Element btnVerbalAcceptance;
	
	
	@FindBy(xpath = "//input[@id='btnRelease']")
	protected Element btnRelease;
	
	@FindBy(xpath = "//a[contains(.,'SUMMARY')]")
    protected Element summaryTab;
	
	@FindBy(xpath = "//a[contains(.,'SUMMARY') and contains(@class,'active')]")
	    protected Element activeSummaryTab;
	
	@FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_MonthlyChargesSubtotal']/b")
	protected Element txtOrderSummaryMonthlySubTotal;
	
	@FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_trEstimatedMC']/td[2]/b")
	protected Element txtOrderSummaryMonthlyCharges;
	
	@FindBy(id = "rbPaperfreeBillNo")
	protected Element noPaperfreeBilling ;
	
	@FindBy(id = "ddlPaperfreeBillReason")
	protected Element noPaperfreeBillingReason ;
	
	@FindBy(id = "rbPaperfreeBillYes")
	protected Element yesPaperfreeBilling;
	
	@FindBy(xpath = "//input[contains(@onclick,'OSClosePaperFreeWindow')]")
	protected Element pageFreeBillWindowClose ;
	
	@FindBy(id = "rbInterestedAutopayYes")
	protected Element autoPaymentYes;
	
	@FindBy(id = "rbInterestedAutopayNo")
	protected Element autoPaymentNo;
	
	@FindBy(id = "ddlAutopayDeclinedReason")
	protected Element autoPayDeclinedReason ;
	
	@FindBy(id = "VerbalbundleAcceptance")
	protected Element fiosBundleAcceptance  ;
	
	@FindBy(id = "btnReadTos")
	protected Element iHaveReadToCustomer  ;
	
	@FindBy(id = "CheckToschkd")
	protected Element certifyChckBox  ;
	
	//vikram script start
	@FindBy(xpath = "//*[@id='btnValidateSubmitOrder']")
	protected Element validateSubmitOrder ;
	
	@FindBy(xpath = "//*[@id='divStatusMessage']")
	protected Element StatusMessage ;
//vikram script end
	
	@FindBy(id = "btnValidateSubmitOrder")
	protected Element validateSubmitOrder1  ;
	
	@FindBy(xpath = "//textarea[@id='txtCloseNotes']")
	protected Element txtClosingnotes;
	
	@FindBy(xpath = "//*[contains(text(),'Closing Notes')]")
	protected Element lblClosingnotessmall;
	
		
	@FindBy(xpath = "//button[contains(text(),'Save and Close')]")
	protected Element btnSaveAndClose;
	
	@FindBy(xpath = "//li[@id='closeNotesAccordian']")
	protected Element lblClosingnotes;
	
	@FindBy(xpath = "//*[@id='sysClosenotesDiv']")
	protected Element lblClosingnotesTxt;
	
	
	//****************** UI Validations*******************
	
	// Prakash
	@FindBy(xpath = ".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle_ctl01_rptBundleServices_ctl01_lnkBundleServices']")
	protected Element txtOrderSummaryfirstproduct;
	
	@FindBy(xpath = ".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle_ctl01_rptBundleServices_ctl02_lnkBundleServices']")
	protected Element txtOrderSummarysecondproduct;
	
	@FindBy(xpath = ".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle_ctl01_rptBundleServices_ctl03_lnkBundleServices']")
	protected Element txtOrderSummarythirdproduct;
	
	@FindBy(xpath = ".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle_ctl01_rptBundleServices_ctl01_hlnkBundleServices']")
	protected Element product_link1;
	
	@FindBy(xpath = ".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle_ctl01_rptBundleServices_ctl02_hlnkBundleServices']")
	protected Element product_link2;
	
	@FindBy(xpath = ".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle_ctl01_rptBundleServices_ctl03_hlnkBundleServices']")
	protected Element product_link3;
	
	@FindBy(xpath = ".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle_ctl01_rptBundleServices_ctl01_rptBundleServiceProducts_ctl01_tcBundleServiceProductsMC']")
	protected Element txtOrderSummaryfirstproductprice;
	                           
	
	@FindBy(xpath = ".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle_ctl01_rptBundleServices_ctl02_rptBundleServiceProducts_ctl01_tcBundleServiceProductsMC']")
	protected Element txtOrderSummarysecondproductprice;

	
	@FindBy(xpath = ".//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle_ctl01_rptBundleServices_ctl03_rptBundleServiceProducts_ctl01_tcBundleServiceProductsMC']")
	protected Element txtOrderSummarythirdproductprice;
	
	@FindBy(xpath = "//div[@id='divEstimatedMonthlyChargeInfo']")
	protected Element SOC_section;	
	
	//Auto Payment -- shiva
	@FindBy(xpath = "//input[contains(@onclick,'LaunchManageAutoPay')]")
	protected Element manageAutopay;
	
	@FindBy(xpath = "//input[@id='MainContent_btnDenroll']")
	protected Element deEnrollAutopay;
	@FindBy(xpath = "//input[@id='MainContent_btnDenroll']")
	protected Element deEnrollAutopay2;
	
	@FindBy(xpath = "//input[@id='MainContent_btnDeEnrYes']")
	protected Element deEnrollAutopayConfirmYes;
	
	@FindBy(xpath = "//input[@id='MainContent_btnDeEnrNo']")
	protected Element deEnrollAutopayConfirmNo;
	
	@FindBy(xpath = "//input[@id='txtUsername']")
	protected Element autoPayUserID;
	
	@FindBy(xpath = "//input[@id='TxtPassword']")
	protected Element autoPayPWD;
	
	@FindBy(xpath = "//a[@id='OSPaymentGatewayPopupClose']/img")
	protected Element autoPayClose;
	
	@FindBy(xpath = "//a[@title='Sign-On']")
	protected Element autoPaySignOn;
	
	@FindBy(xpath = "//div[@data-reveal-trigger='AddCard']")
	protected Element autoPayAccordion;
	
	@FindBy(xpath = "//label[@for='rbCreditcard']")
	protected Element creditCardRdBtn;
	
	@FindBy(xpath = "//label[@for='rbDebitcard']")
	protected Element debitCardRdBtn ;
	
	@FindBy(xpath = "//input[@id='txtCardNumber_mask']")
	protected Element cardNumber;
	
	@FindBy(xpath = "//input[@id='txtSecurityCode']")
	protected Element securityCode;
	
	@FindBy(xpath = "//select[@id='ddlCardMonth' or @id='ddlCardExpMonth']")
	protected Element selectExpiryMonth;
	
	@FindBy(xpath = "//select[@id='ddlCardyear' or @id='ddlCardExpYear']")
	protected Element selectExpiryYear;
	@FindBy(xpath = "//select[@id='ddlCardExpMonth']")
	protected Element selectExpiryMonth2;
	
	@FindBy(xpath = "//select[@id='ddlCardExpYear']")
	protected Element selectExpiryYear2;
	
	@FindBy(xpath = "//input[@id='txtFirstNameCreditDebit']")
	protected Element payerFirstName;
	
	@FindBy(xpath = "//input[@id='txtLastNameCreditDebit']")
	protected Element payerLastName;
	
	@FindBy(xpath = "//input[@id='txtAddress1CreditDebit']")
	protected Element payerAddress;
	
	@FindBy(xpath = "//input[@id='txtBusinessNameCreditDebit']")
	protected Element payerName;
	
	@FindBy(xpath = "//input[@id='txtCityCreditDebit']")
	protected Element payerCity;
	
	@FindBy(xpath = "//input[@id='txtStateCreditDebit']")
	protected Element payerState;
	
	@FindBy(xpath = "//input[@id='txtZipCodeCreditDebit']")
	protected Element payerZipCode;
	
	@FindBy(xpath = "// input[@id='BMPmtsMainContent_vPmtInsPaymentMethod_btnContinue']")
	protected Element autoPaySubmit;
	
	@FindBy(xpath = "// input[@id='BMPmtsMainContent_vPmtInsPaymentConfirmation_btnClose']")
	protected Element autopayConfirmationClose;
	
	@FindBy(xpath="//*[@id='BillSummaryGrid']/tbody[@class='togard'][<<<>>>]/tr")
	protected Element summaryProducts;

	//Sravya changes for MO Offers

		@FindBy(xpath="//*[contains(text(),'Expand All')]")
		protected Element summaryExpand;
		@FindBy(xpath="//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle_ctl01_tcMC']/b")
		protected Element summary_BundlePrice;
		@FindBy(xpath="//*[@id='BillSummaryGrid']/tbody[1]//td[contains(@id,'tcMC')]")
		protected Element MonthlyAmount;
		@FindBy(xpath="//*[@id='BillSummaryGrid']/tbody[1]//td[contains(@id,'tcMWP')]")
		protected Element MonthlyWOPromos;
		@FindBy(xpath="//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_MonthlyChargesSubtotal']")
		protected Element MonthlyWOTax;
		@FindBy(xpath="//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_trEstimatedMC']/td[2]")
		protected Element MonthlywithTax;
		@FindBy(xpath="//*[contains(@id,'tcAdditionalDetailsMC')]")
		protected CList<Element> EquipDetails;
		@FindBy(xpath="//*[@id='BillSummaryGrid']//*[contains(@id,'lnkBundlePromos')]")
		protected CList<Element> PromoOffersList;
		
		@FindBy(xpath = "//table[@id='BillSummaryGrid']//tbody[@class='togard' and contains(@style,'row-group')]")
    	protected CList<Element> summaryScreen;

	
	/******************
	 * description: Added for MO validation
	 * Author: Jeevitha S
	 * Date: 02/21/2017
	 ******************/
	@FindBy(id="BillSummaryGrid")
	protected Element BillSummary;
	
	
	//*************UI Validations 	For Close account window Gopal  on 03/22/17
	
	@FindBy(xpath = "//*[@data-modal = 'closeAccountModal']")
	protected Element CloseAccount_Window;
	
	@FindBy(xpath = "//div[@class='timeline_author-avatar']/ancestor::li//p[contains(@class,'ng-binding')]/..")
	protected Element Duedate_userid;
	
	@FindBy(xpath = "//*[@id = 'txtCloseNotes']")
	protected Element Closing_Notes;
	
	@FindBy(xpath = "//li[@ng-if = 'showSaveAndContinue']/button[contains(@ng-click, 'save')]")
	protected Element Save_and_Continue;
	
	@FindBy(xpath = "//li[not(contains(@ng-if, 'showSaveAndContinue'))]/button[contains(@ng-click, 'save')]")
	protected Element Save_and_Close;
	
	@FindBy(xpath = "//label[@for='chkActFeesAck']")
	protected Element chxAcknowledge;
	
	@FindBy(xpath = "//label[@for='chkVerbalAcceptance']")
	protected Element c2gbtnVerbalAcceptance;
	
	@FindBy(xpath = "//input[@id='btnGetSignature']")
	protected Element getsignature;
	
	@FindBy(xpath = "//label[@for='chkCommonTos']")
	protected Element c2gsign1;
	@FindBy(xpath = "//label[@for='chkPaperFree']")
	protected Element c2gsign2;
	
	@FindBy(xpath = "//label[@for='chkSameAsCustomer']")
	protected Element c2gsignascustomer;

	@FindBy(xpath = "//label[@for='chkBoxVFTF']")
	protected Element c2gVF2F;
	
	@FindBy(xpath = "//*[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_bdyFBE')]")
	protected CList<Element> SOCText;
	
	
	//Added Zero-Rated
	//By Shobana
	 //  @FindBy(xpath="//div[contains(text(),'SHOW ZERO-RATED')]")
	  @FindBy(xpath="//a[contains(text(),'SHOW ZERO-RATED PRODUCTS')]")
	   protected Element zeroRated;
     
      @FindBy(xpath="//tr[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptStandaloneFiosTVOtherProds_ctl02_trStandaloneFiosTVOtherProds']//following-sibling::tr//td[2]/b")
      protected Element summary_WTaxEle;
      
      
      
      
     //Added for Bank Account Details By Mounika
     @FindBy(xpath = "//input[@id='txtBusinessRoutingNumber_mask']")
  	protected Element RoutingNum;
  	
  	@FindBy(xpath = "//input[@id='txtBusinessAccountNumber_mask']")
  	protected Element AccountNum;
  	@FindBy(xpath = "//input[@id='BMPmtsMainContent_vPmtInsPaymentMethod_btnACHContinue']")
  	protected Element SubmitButton;
  	
  	@FindBy(xpath = "//div[@data-reveal-trigger='AddAccount']")
	protected Element bankautoPayAccordion;
  	@FindBy(xpath = "//a[@id='BMPmtsMainContent_vPmtInsPaymentMethod_aACHSSPRecall']")
	protected Element linkrefresh;
  	
  	//Madhu
    
    @FindBy(xpath = "//label[@for='CheckVoice']")
    protected Element Signchkvoice;
    
    @FindBy(xpath = "//label[@for='CheckFreedom']")
    protected Element SignchkFree;
    
    @FindBy(xpath = "//label[@for='CheckFiOSTV']")
    protected Element SignchkAgree;
    
    @FindBy(xpath = "//canvas[@class='jSignature']")
    protected Element enterSignature ;
    
    @FindBy(xpath = "//label[@for='chkFiosBundleAgreement']")
    protected Element SignchkBdlAgree;
    
    @FindBy(xpath = "//label[@for='chkFiosBundleServices']")
    protected Element SignchkbdlServices;
    
	@FindBy(xpath = "//label[@for='chkDigitalBillingTOS']")
	protected Element c2gChkDBTOS;
	
	@FindBy(xpath = "//label[@for='chkInternetStandalone']")
	protected Element c2gChkInternetStandalone;
    
    @FindBy(xpath = "//span[contains(text(),'Proceed')]")
    protected Element Btnprcd;
    
    @FindBy(xpath = "//input[@id='btnSOCEmailND2']")
    protected Element Btnsendpreview;
    
@FindBy(xpath = "//input[@id='btnSOCEmailND2']")

protected Element btnSOCEmailND2;
@FindBy(xpath = "//a[@id='dataAccepatnce']")
protected Element fiosInternetAcceptance  ;

//Madhu

@FindBy(xpath = "//input[@id='MainContent_btnModify' and not(contains(@disabled,'disabled'))]")
protected Element BtnEnroll  ;

@FindBy(xpath = "//input[@id='lbtnCloseWindow']")
protected Element Btnclose  ;

@FindBy(xpath = "//*[@data-id = 'dbankdraft']")
protected Element SavingsAccount  ;


// Gopal 11/08

@FindBy(xpath = "//*[@id = 'chkboxACOrder']")
protected Element ACHCheckBox  ;

@FindBy(xpath = "//div[@id='InfoPanel']/table[1]")
protected Element s1  ;

@FindBy(xpath = "//div[@id='InfoPanel']/table[2]")
protected Element s2  ;

@FindBy(xpath = "//div[@id='divAutopaymentSection']")
protected Element paymentMethod;

//input[@id='lbtnCloseWindow']

//************LOFFlowAutopay*************////Anu

@FindBy(xpath="//*[@id='txtEmailLOF']")
protected Element lofEmail;

@FindBy(xpath="//*[@id='rdbMobileYesLOF']")
protected Element billNoticeYes;

@FindBy(xpath="//*[@id= 'rdbMobileNoLOF']")
protected Element billNoticeNo;

@FindBy(xpath="//*[@id='btnSendMailWTC']")
protected Element sendEmail;

@FindBy(xpath="//*[@id='RbtSocEmail']")
protected Element selectEmail;

@FindBy(xpath = "//*[@id='rbInterestedAutopayYesLOF']")
protected Element lofautoPaymentYes;

	@FindBy(xpath = "//*[@id='rbInterestedAutopayNoLOF']")
protected Element lofautoPaymentNo;

@FindBy(xpath = "//*[@id='rbPaperfreeBillYesLOF']")
protected Element paperFreeYes;

@FindBy(xpath = "//*[@id='rbPaperfreeBillNoLOF']")
protected Element paperFreeNo;


@FindBy(xpath ="//*[@id='zipCode']")
protected Element zip;

@FindBy(xpath ="//*[@id='SubmitButton']")
protected Element zipContinue;

@FindBy(xpath ="//*[@class='button marketing m_button']")
protected Element summContinue;

@FindBy(xpath ="//*[@id='paymentOptions']")
protected Element Selectpay;


@FindBy(xpath ="//*[@id='firstName']")
protected Element LofpayerName;

@FindBy(xpath ="//*[@id='lastName']")
protected Element LofLastName;

@FindBy(xpath ="//*[@id='cardNumber']")
protected Element LofCrdNum;

@FindBy(xpath ="//*[@id='cardType']")					
protected Element selectcard;

@FindBy(xpath ="//*[@id='cardType']/option[contains(text(),'<<<>>>')]")					
protected Element cardopt;	

@FindBy(xpath ="//*[@id='cardNickName']")
protected Element Lofnick;

@FindBy(xpath ="//*[@id='expirationDate']")
protected Element expMonth;	

@FindBy(xpath ="//*[@id='expirationDateYear']")
protected Element expYear;

@FindBy(xpath ="//*[@id='cvv']")
protected Element cvv;

@FindBy(xpath ="//*[@id='zipcode']")
protected Element Lofzip;

@FindBy(xpath ="//*[@id='routingNumber']")
protected Element rtnnum;

@FindBy(xpath ="//*[@id='bankAccountNumber']")
protected Element bnknum;

@FindBy(xpath ="//*[@id='nickName']")
protected Element nickname;

@FindBy(xpath ="//*[@id='continueBtn']")
protected Element enrollContinue;

@FindBy(xpath ="//*[@id='iAgreeBtn']")
protected Element agreebtn;

//Switch to main page
@FindBy(xpath="//button[contains(text(), 'Search for accounts')]")
protected Element srchBtn;
//----------------Digital Billing Update By Mithra G---------------------------------------------

@FindBy(xpath = "//b[contains(text(),'Does the customer want to enroll in Paperfree Billing?')]")
protected Element DigitalbillingrequiredNotbutton;

@FindBy(xpath = "//input[@id='rbPaperfreeBillNo']")
protected Element DigitalbillingRadioButtonNo;

@FindBy(xpath = "//select[@id='ddlPaperfreeBillReason']")
protected Element DigitalbillingRadioButtonNoDropdownReason;

@FindBy(xpath = "//label[contains(text(),'Yes-Required with the products selected')]")
protected Element Digitalbillingrequiredbutton;

@FindBy(xpath = "//span[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucAutoPaymentMethod_Span2']")
protected Element DigitalbillingMobileTextMessage;

@FindBy(xpath = "//input[@id='rdbMobileYes']")
protected Element Digitalbillingmobilerediobuttonyes;

@FindBy(xpath = "//input[@id='rdbMobileNo']")
protected Element DigitalbillingmobilerediobuttonNo;

@FindBy(xpath = "//*[@id='RbtSocOther']")
protected Element rdoBtnLiveOrder  ;

@FindBy(xpath = "//*[@id='chkNonLOFMTN']")
protected Element chkbxMTN  ;

@FindBy(xpath = "//*[@id='chkNonLOFEMail']")
protected Element chkbxEmail  ;

@FindBy(xpath = "//*[@id='DigitalBillingTOSAcceptance']")
protected Element lnkDBTOS  ;

@FindBy(xpath = "//*[@id='btnDigiReadTos']")
protected Element btnDBReadTOS  ;

@FindBy(id = "rbInterestedAutopayYesLOF")
protected Element LOFautoPaymentYes;

@FindBy(id = "rbInterestedAutopayNoLOF")
protected Element LOFautoPaymentNo;

@FindBy(id = "ddlAutopayDeclinedReasonLOF")
protected Element LOFautoPayDeclinedReason ;

//---- Added by Naresh

@FindBy(xpath = "//td[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptStandaloneFiosTVOtherProds_ctl02_tcStandaloneFiosTVOtherProdsMC']")
protected Element RegionalSportsNetworkFees  ;

@FindBy(xpath = "//td[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptStandaloneFiosTVOtherProds_ctl01_tcStandaloneFiosTVOtherProdsMC']")
protected Element FiosBroadCastFees  ;

@FindBy(xpath = "//a[@id='monDisplay']")
protected Element MONDisplay  ;

@FindBy(xpath = "//td[contains(text(),'Regional Sports Network Fee')]")
protected Element ViewDetailsRSNFee  ;

@FindBy(xpath = "//td[contains(text(),'Fios TV Broadcast Fee')]")
protected Element ViewDetailsBCFee  ;

@FindBy(xpath = "//div[@id='CartDetailsPopupTitle']/div")
protected Element closeViewDetailsPopup  ;


@FindBy(xpath = "//td[contains(text(),'Regional Sports Network Fee')]/preceding-sibling::td/img[@alt='Added']//parent::td/following-sibling::td[contains(text(),'Regional Sports Network Fee')]")
protected Element getViewDetailsRSNAddedValue ;

@FindBy(xpath = "//td[contains(text(),'Fios TV Broadcast Fee')]/preceding-sibling::td/img[@alt='Added']//parent::td/following-sibling::td[contains(text(),'Fios TV Broadcast Fee')]")
protected Element getViewDetailsBCAddedValue ;


//----------------Verbal Tos acceptance - Soham   ---------------------------------------------
//Verbal Tos acceptance checkbox
@FindBy(xpath="//*[@id='lbltos']/b/b")
protected Element verbalTosAcceptance;

@FindBy(xpath="//td/b[text()=\"One-Time Charges and Credits\"]//parent::td//parent::tr//parent::tbody//following-sibling::tr[2]/td/b//following-sibling::a[contains(text(),'24 Month')]")
protected Element etfText;

@FindBy(xpath = "//span[contains(text(),'Estimated Monthly Subtotal')]")
protected Element estimatedMonthlyBill  ;

@FindBy(xpath = "//div[contains(@class,'w_message m_error')]")
protected Element LOFError  ;

//---- Added by Naresh



@FindBy(xpath = "//tbody[@id='dv_Package']//td[@class='bg_EBEBEB' and @align='left' and contains(text(),'Adult')]")
protected Element getTechsureAdult ;

@FindBy(xpath = "//tbody[@id='dv_Package']//td[@class='bg_EBEBEB' and @align='left' and contains(text(),'Junior')]")
protected Element getTechsureJunior;

@FindBy(xpath = "//td[@class='bg_EBEBEB']/b[contains(text(),'BBE & E   ')]")
protected Element ViewTechSureFees;




@FindBy(xpath = "//img[@alt='Product']/following-sibling::a[contains(text(),'TechSure')]")
protected Element scrollTillTechSure;

@FindBy(xpath = "//a[contains(text(),'LifeLock Select Adult')]")
protected Element lifelockAdult;

@FindBy(xpath = "//a[contains(text(),'LifeLock Select Junior')]")
protected Element lifelockJunior;

@FindBy(xpath = "//input[@id='rbInterestedAutopayNo' and @disabled='disabled']")
protected Element Autopaydisabled;

//*************Lakshmi***********Optix on summary billing name and address to get Zipcode for LOF flow**********//

@FindBy(xpath = "//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_divBillNameAddr']")
protected Element billingNameAndAddress ;

//*************Lakshmi***********in LOF flow to select the New payment method radio button for Enroll in Auto pay*********//
@FindBy(xpath = "//label[@for='newPmt']")
protected Element payMeth;

//*************Lakshmi***********Digital code offer*********//
@FindBy(xpath = "//td[contains(text(),'Fios Remote Control 2-Device')]")
protected Element viewDetailsRemoteCon;

@FindBy(xpath = "//td[contains(text(),'UPS Ground No Charge Shipping')]")
protected Element viewDetailsUPSGroShi;

@FindBy(xpath = "//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_Pnl2']")
protected Element BBEProducts;

@FindBy(xpath = "//*[@id = 'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_OrderSummary_FiOSEarlyAccess_Div_panelFiOSEarlyAccess']")
protected Element FiosTVappEarlyAccess;


@FindBy(xpath = "//*[@id = 'rdbtnFEAYes']")
protected Element MTNYes;

//Installation Flexibility - Vijay

	@FindBy(xpath = "//*[contains(text(),'Fios Setup Discount')]/following-sibling::div[@class='div_Right_Text']")
	protected Element setupfeewaiver1;
	
	@FindBy(xpath = "//*[contains(text(),'Fios Setup @  $99')]/following-sibling::div[@class='div_Right_Text']")
	protected Element setupfeewaiver2;
	@FindBy(xpath = "//div[@id='OSPaymentGatewayPopupDiv']")
	protected Element PaymentGateway;
	
	@FindBy(xpath = "//button[@id='iagree']")
	protected Element IAgreebtn;
	
	//-----------------Naresh ---------- IWMP in Summary page
	@FindBy(xpath = "//img[@src='../Includes/images/ico_ExistServ_BBE.gif']//following-sibling::a[contains(text(),'Inside Wire Maintenance')]")
	protected Element IWMPInSummaryPage;
  
    @FindBy(xpath = "//div[@data-modal='closeAccountModal' and contains(@class,'active')]")
	protected Element closePopup;
    
    @FindBy(xpath = "(//a[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle') and contains(text(),'Internet')])[1]")
	protected Element FiosInternet;
    
    @FindBy(xpath = "(//a[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle_ctl01_rptBundleServices') and contains(text(),'TV')])[1]")
	protected Element FiosTV;
    
    @FindBy(xpath = "(//a[contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle') and (contains(text(),'Voice') or contains(text(),'FREEDOM'))])[1]")
	protected Element FiosDigitalVoice;
    @FindBy(xpath = "//a[(contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle') or contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptStandaloneServices')) and contains(text(),'Router')]")
  	protected Element RouterOption;
      @FindBy(xpath = "//a[(contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle') or contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptStandaloneServices')) and contains(text(),'Service')]")
  	protected Element getRecordingOption;
      @FindBy(xpath = "//a[(contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle') or contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptStandaloneServices')) and contains(text(),'Box')]")
  	protected Element TVStb;
    
    @FindBy(xpath = "(//a[(contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle') or contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptStandalone')) and (contains(text(),'Internet') or contains(text(),'Cons'))])[1]")
	protected Element FiosInternet2;
    @FindBy(xpath = "(//a[(contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle') or contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptStandalone')) and contains(text(),'TV')])[1]")
	protected Element FiosTV2;
    @FindBy(xpath = "(//a[(contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptBundle') or contains(@id,'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_rptStandalone')) and (contains(text(),'Voice') or contains(text(),'LEC'))])[1]")
	protected Element Fiosvoice2;

//Prakash -- Restore products
    @FindBy(xpath = "//thead[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_thdSOCHeader']/../tbody/tr/td[contains(text(),'RESTORED')]/..")
    protected CList<Element> RestoreZeroRated;
    
    @FindBy(xpath = "//*[@id = 'lblMonText']")
    protected Element MasterOrderNumber;
    
    @FindBy(xpath = "//*[@id='CartDetailsPopupTitle']/div")
    protected Element CloseViewDetails;
    
    
    //Naresh , for LOF
    
    	 // Added By 'Naresh,Madipelly' , LOF Registration and Validations
    	  
    	    
    	    @FindBy(xpath = "//button[@id='skipBtn']")
    	    protected Element SkipAutoPay;
    	    
    	    @FindBy(xpath = "//p[contains(text(),'Your Order Number: <<<>>>')]")
    	    protected Element verifyMON;
    	    
    	    @FindBy(xpath = "//input[@id='userName']")
    	    protected Element UserId;
    	    
    	    @FindBy(xpath = "//input[@id='pwd']")
    	    protected Element pwd;
    	    
    	    @FindBy(xpath = "//input[@id='rePwd']")
    	    protected Element rePwd;
    	    
    	    @FindBy(xpath = "//a[@id='ContinueButton']")
    	    protected Element submit;
    	    
    	    @FindBy(xpath = "//h1[contains(text(),'Registration completed.')]")
    	    protected Element registrationCompleted;
    	    
    	    @FindBy(xpath = "//li[@id='createProfileM']//span")
    	    protected Element registrationStatus;
    	    
    	    @FindBy(xpath = "//label[@for='eAutoPay']")
    	    protected Element eAutoPay;
    	    
    	    @FindBy(xpath = "//button[@id='continueBtn']")
    	    protected Element contBtn;
    	    
    	    @FindBy(xpath = "//li[@id='autoPaytos']")
    	    protected Element autoPaytos;
    	  
    	  
    	    @FindBy(xpath="//p[@id='usenameError']")
    		public Element usernameErrMsg;
    	    
    	    @FindBy(xpath="//p[@id='pwdError']")
    		public Element pwdErrMsg;
    	    
    	    @FindBy(xpath="//div[@id='rePwdError']")
    		public Element rePwdErr;
    	  
    	  
    	  
    	    @FindBy(xpath="//main[@class='main']//h1")
    		public Element welcomeCustomer;
    	  
    	    
    	    @FindBy(xpath = "//div[@class='section-total-block']/div/div[2]")
    	    protected CList<Element> Monthlybills;
    	    
    	    @FindBy(xpath = "//tr[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_trEstimatedMC']/td[2]/b")
    	    protected Element EstimatedCharges;
    	    
    	    @FindBy(xpath = "//tbody[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucSOCGridDisplay_bdyFBE9']//td[3]/b")
    	    protected Element EstimatedBill;
    	  
    	    @FindBy(xpath = "//label[@for='newPmt']")
    	    protected Element newPaymentMetod;
    	    
    	    @FindBy(xpath = "//span[@id='lblAutopayYes']")
    	    protected Element changeAutoPayYES;
    	    
    	    @FindBy(xpath = "//b[contains(text(),'Thank you for your order.')]")
    	    protected Element ThankYouOrder;
    	  

}
