package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_Dashboard_Objects class represent the Page Object class. This
 * contains all the identifier for Simplex Dashboard Page
 */
public class Simplex_Dashboard_PageObjects extends CommonPage {

    /**
     * Simplex_Dashboard_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *            represents data input
     */
    public Simplex_Dashboard_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }

    // **************************COA*********************

    @FindBy(xpath = "//*[contains(@data-ng-click,'Newaccount')]")
    protected Element btnNewAccount;

    @FindBy(xpath = "//*[contains(@data-ng-click,'newTab') and contains(@data-ng-click,'search')]")
    protected Element btnSearch;

    // **************************C2G*********************

    @FindBy(xpath = "//*[@data-ng-click='CompanyLocClick()']")
    protected Element btnCompanyLocation;

    @FindBy(xpath = "//select[@ng-model='selectedCompany']")
    protected Element LstCompanyName;
    
    @FindBy(xpath = "//div[@class='modal_header welcome-modal_header']")
    protected Element DashBoardPopUpC2G;

    @FindBy(xpath = "//select[@ng-model='selectedLocation']")
    protected Element LstCompanyLocation;

    @FindBy(xpath = "//button[@ng-click='closeClick();']")
    protected Element btnContinue;
    
    @FindBy(xpath = "//label[@for='company']")
    protected Element companysection;

    @FindBy(xpath = "//select[@ng-model='selectedLocation']")
    protected Element LstLocationName;
    
    @FindBy(xpath = "//span[contains(text(),'Click to open new account')]/../span[contains(@class,'vzicon middle sx-icon-account-open text-grey-3')]")  
    protected Element OpenAccount;
}
