//Added Space, checking permissions
package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import com.automation.functionallibrary.CustomDriver;
import com.automation.support.Element;
import com.automation.utilities.ReportStatus;



/**
 * Common Object repository across all pages
 * 
 *
 */
public class CommonOR extends CustomDriver
{
	@FindBy(xpath="//div[contains(@id,'dvOPOLoader') and contains(@class,'active')]")
	protected Element pageLoading2;
	@FindBy(xpath="//div[contains(@id,'dvOPOLoader')]")
	protected Element pageLoading;
	
	public CommonOR(WebDriver driver,boolean mobile, HashMap<String,String> data,ReportStatus report) 
	{
		super(driver,mobile,data,report);
	}
	
	
	    @FindBy(xpath = "//div[@data-ui-view='modal']/div[not(contains(@class,'active'))]/../preceding-sibling::main/div[contains(@class,'page-overlay')]")
	    protected Element pageOverlayWithoutModel;

	    @FindBy(id = "dvSimplexLoader")
	    protected Element loaderPageOverlay;
	    @FindBy(xpath = "//div[contains(@id,'dvSimplexLoader') and contains(@class,'active')]")
	    protected Element loaderPageOverlay2;
	  

	    @FindBy(id = "divLoader")
	    protected Element divLoader;

	    @FindBy(xpath = "//*[contains(@class,'price-flip-card')]")
	    protected Element vzLoading;
	    
	    @FindBy(xpath = "//iframe[@id='IfProducts']")
	    protected Element IfProducts;
	    
	    @FindBy(xpath = "//iframe[@id='PopupIFrame']")
	    protected Element popupIframe;
	    
	    @FindBy(id = "divProcessLoader")
	    protected Element pleaseWaitLoader;
	    @FindBy(id = "dvProcessLoader")
	    protected Element pleaseWaitLoader2;
	    
	    @FindBy(xpath = "//div[@id='processImageHolder']")
	    protected Element pleaseWaitLoader3;
	    
	    
	  
	    
	    //************** Error Messages****************************
	    @FindBy(xpath = "//li[@class='verify-no-match-found']//div")
	    protected Element noMatchFound;
	    
	    @FindBy(xpath = "//*[@ng-if='accountNotFound']")
	    protected Element noAccountFound;
	    
	    @FindBy(xpath = "//*[@ng-if='isErrorVisible']")
	    protected Element requiredFieldsMissed;
	    
	    @FindBy(xpath = "//div[@id='commonError']")
	    protected Element prodPageCommonError;
	    
	    protected int pageTimeoutInSeconds = 45;
	  
}
