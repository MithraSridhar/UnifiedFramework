package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_ContactInfo_Objects class represent the Page Object class. This
 * contains all the identifier for Simplex ContactInfo Page
 */
public class Simplex_ContactInfo_PageObjects extends CommonPage {

    /**
     * Simplex_ContactInfo_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *            represents data input
     *            
     *            
     */
    public Simplex_ContactInfo_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }

    @FindBy(xpath = "//a[contains(.,'SUMMARY') and contains(@class,'active')]")
    protected Element activeSummaryTab;
    
    protected By activeContactInfoTab =By.xpath("//a[contains(.,'CONTACT INFO') and contains(@class,'active')]");
    
    @FindBy(xpath = "//input[@id='chkSameAsAbove']")
    protected Element chkSameAsAbove;

    @FindBy(xpath = "//input[@id='rdBtnPrefContactN']")
    protected Element rdBtnPrefContactN;

    @FindBy(xpath = "//input[@id='btnCCISave' or @id='MainPageCCI_Div_btnCCISave' or @id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_CustomerContactInformation_btnCCISave']")
    protected Element btnCCISave;

    @FindBy(xpath = "//input[@id='chkOverUseInd']")
    protected Element chkOverUseInd;

    @FindBy(xpath = "//a[contains(.,'CONTACT INFO')]")
    protected Element contactInfoTab;


    @FindBy(xpath = "//input[@alt='Mobile Number' or @id='txtMobileNumber']")
    protected Element enterMTN;


    @FindBy(xpath = "//input[@alt='Email'or @id='txtEmail']")
    protected Element enterEmail;

    @FindBy(xpath = "//input[@alt='Alternate Telephone' or @id='txtAltTelephone']")
    protected Element enterATN;
    
    @FindBy(xpath = "//label[@for='rdbtnEmailNo' or @for = 'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_CustomerContactInformation_rdbtnEmailNo']")
    protected Element EmailUpdateNo;
    
    @FindBy(xpath = "//input[@id='rdbtnSOYes']")
    protected Element streamingYes;
    
    @FindBy(xpath = "//input[@id='rdbtnSONo']")
    protected Element streamingNo;
    
    @FindBy(xpath = "//label[@for='chkOverUseInd']")
    protected Element chkOverUseInd2;
    
    @FindBy(xpath = "//label[@for='chkSameAsAbove']")
    protected Element chkAsSameAbv;
    
    
    
    
	 // **********UI Validations *****for credit fail validation we need to capture MON details  03/22/17
    
    @FindBy(xpath = "//*[@id = 'lblMON']")
    protected Element MON_Label;
    
    @FindBy(xpath = "//*[@id = 'monDisplay']")
    protected Element Display_MON;
    
    @FindBy(xpath = "//iframe[@id='PopupIFrame']")
    protected Element popupIframe;
    
    @FindBy(xpath = "//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_CustomerContactInformation_pnlErrMsg']")
    protected Element errormsg;
    
  //------------------digital Billing Update By Mithra G--------------------------------- 
    
    @FindBy(xpath = "//label[@for='chkEmail']")
    protected Element DBNoEmailCheckBox;

    @FindBy(xpath = "//div[@id='divDeclineDigitalBilling']")
    protected Element DBDeclineMessage;
  
    @FindBy(xpath = "//input[@id='chkDeclineDigitalBilling']")
    protected Element DBDeclineMessageCheckbox;
    
    @FindBy(xpath = "//*[@id = 'lnkCloseMasterPopup']")
    protected Element lnkCloseMasterPopup;
    
    @FindBy(xpath = "//*[@id = 'lnkCloseMasterPopup']//*[@alt = 'modal_close']")
    protected Element CloseMark;    
    
    @FindBy(xpath = "//*[@id = 'lblMonText']")
    protected Element MasterOrderNumber;
  
    @FindBy(xpath = "//*[(@id = 'ctl00_rpViewDetails_ctl03_lnkSvcHeader' or @id = 'ctl00_rpViewDetails_ctl01_lnkSvcHeader' or @id = 'ctl00_rpViewDetails_ctl00_lnkSvcHeader' or @id = 'ctl00_rpViewDetails_ctl02_lnkSvcHeader')and text() = ' BBE & E   ']")
    protected Element BBESection;
    
    @FindBy(xpath = "//*[@id = 'ViewDetailsPopup']")
    protected Element Viewdetailspopup;
    
    @FindBy(xpath = "//*[@id = 'ctl00_rpViewDetails_ctl0<<<>>>_lnkSvcHeader']")
    protected Element ProductDetails;
    
    @FindBy(xpath = "//*[contains(@id , 'ctl00_rpViewDetails') and @class = 'expc_toggle expc_TC']")
    protected CList<Element> TypesofProductsList;
    
    @FindBy(xpath = ".//*[@id='CartDetailsPopupTitle']/div")
    protected Element CartViewDetails_Close;
    
    @FindBy(xpath = "//*[@id = 'dv_Package']//table")
    protected CList<Element> NoOfBBEProducts;
    
    @FindBy(xpath = "//*[@id = 'dv_Package']//table[<<<>>>]")
    protected Element EachBBEProducts;
    
    @FindBy(xpath = "//*[@id = 'dv_Package']//table[<<<>>>]//td[5]/preceding-sibling::td[1]/img")
    protected Element ProductStatus;
    

    @FindBy(xpath = "//div[contains(text(),'View Details')]")
    protected Element C2G_viewDetail_link;    
  
    @FindBy(xpath = "//a[(contains(@id,'ViewDetails'))]/parent::div/following-sibling::div//tr")
    protected CList<Element> viewDetail_Screenshot;
    
    @FindBy(xpath = "//a[@id='monDisplay']")
    protected Element MON_link;
    
    @FindBy(xpath = "//tbody[@id='dv_BBE']//td/child::img[@alt='Added']/../following-sibling::td[contains(text(),'<<<>>>')]")
    protected Element ViewDetails_BBE_added;
    
    @FindBy(xpath = "//tbody[@id='dv_BBE']//td/child::img[@alt='OnProfile']/../following-sibling::td[contains(text(),'<<<>>>')]")
    protected Element ViewDetails_BBE_onprofile;
 
    
    @FindBy(xpath = "//tr//td[5][contains(.,'Auto Pay Video Tracker')]")
    protected Element Auto_Pay_Video_Tracker;
    
    @FindBy(xpath = "//tr//td[5][contains(.,'Auto Pay Data Tracker')]")
    protected Element Auto_Pay_Data_Tracker;
    
    @FindBy(xpath = "//tr//td[5][contains(.,'Auto Pay and Paper Free Discount') and contains(.,'$')]")
    protected Element Auto_Pay_Discount;
    
    @FindBy(xpath = ".//*[@id='CartDetailsPopupTitle']/div")
    protected Element ViewDetails_Close;
    
  //Exchange Options - Added By : Naresh,Madipelly
    @FindBy(xpath = ".//*[@id='CartDetailsPopupTitle']/div")
    protected Element viewDetails_Q2423Discount;
    @FindBy(xpath = "//tbody[@id='dv_VZFiosTVSHE(Overlay)']/tr/td/table/tbody/tr/td[contains(.,'Q2388')]")
    protected Element Q2388ISoc;
    @FindBy(xpath = "//tbody[@id='dv_VZFiosTVSHE(Overlay)']/tr/td/table/tbody/tr/td[contains(.,'Q2389')]")
    protected Element Q2389ISoc;
    @FindBy(xpath = "//child::img[@alt='Added']/../following-sibling::td[contains(text(),'<<<>>>>')]/../../..")
    protected Element ViewDetails_offer;

   

}
