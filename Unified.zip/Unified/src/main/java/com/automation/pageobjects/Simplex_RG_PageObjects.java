package com.automation.pageobjects;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import com.automation.support.CList;
import com.automation.support.Element;
import com.automation.ui.pages.CommonPage;
import com.automation.utilities.ReportStatus;

/**
 * Simplex_RGPage_Objects class represent the Page Object class. This contains
 * all the identifier for Simplex RG Page
 */
public class Simplex_RG_PageObjects extends CommonPage {

    /**
     * Simplex_RG_PageObject class constructor
     * 
     * @param driver
     *            represents the instances of type WebDriver
     * @param windows
     *            represents boolean value either true or false
     * @param report
     *            represents report input
     * @param windows
     *            represents data input
     *            
     *            
     */
    public Simplex_RG_PageObjects(WebDriver driver, boolean windows, ReportStatus report, HashMap<String, String> data) {
	super(driver, windows, report, data);
    }

    @FindBy(xpath = "//div[@class='Simplex_Panel']")
    protected Element simplexPanel;

    @FindBy(xpath = "//*[@id='divDOCC']//button[contains(text(),'Yes')]")
    protected CList<Element> btnYesDoccAgreementList;

    @FindBy(xpath = "//button[contains(@data-modal-action,'YES')]")
    protected Element btnYesDoccAgreement;
    
    @FindBy(xpath = "//input[@id='CN111']")
    protected Element radioBtnNo;

    @FindBy(xpath = "//input[@id='CN120']")
    protected Element radioBtnUpdate;

    @FindBy(xpath = "//label[@for='CN111']")
    protected Element radioBtnNoL1;

    @FindBy(xpath = "//label[@for='CN161']")
    protected Element radioBtnNewResMove;

    @FindBy(xpath = "//label[@for='CN491']")
    protected Element radioBtnNoL2;
    @FindBy(xpath = "//button[@ng-click='salesRequiredCheck()']")
    protected Element saleswindow;

    @FindBy(xpath = "//label[@for='CN261']")
    protected Element radioBtnNoL3;

    @FindBy(xpath = "//label[@for='CN2010']")
    protected Element radioBtnStreamAndGaming;

    @FindBy(xpath = "//label[@for='CN3010']")
    protected Element radioBtnGottaHaveItAll;

    @FindBy(xpath = "//label[@for='CN3020']")
    protected Element checkBoxHBO;

    @FindBy(xpath = "//button[@ng-click='moveNextPage()']")
    protected Element btnNext;

    @FindBy(xpath = "//label[@for='CN3512']")
    protected Element radioBtnDoesNotWant;

    @FindBy(xpath = "//*[contains(text(),'Address Validated')]")
    protected Element labelAlertL1;

    @FindBy(xpath = "//label[@for='CN2020']")
    protected Element radTraditional;

    @FindBy(xpath = "//*[contains(text(),'Alert!')]")
    protected Element labelAlert;

    @FindBy(xpath = "//*[contains(text(),'This location is HFWS.  Advise the customer that there is existing service at this location.')]")
    protected Element alertHFWS;

    @FindBy(xpath = "//label[@for='CN2020']")
    protected Element labAlert;

    @FindBy(xpath = "//label[@for='CN111']")
    protected Element radAlertNo;

    @FindBy(xpath = "//label[@for='CN161']")
    protected Element radNewResMove;

    @FindBy(xpath = "//label[@for='CN410']")
    protected Element radResMoveInAndOut;

    @FindBy(xpath = "//label[@for='CN491']")
    protected Element radNewResMoveoutNo;

    @FindBy(xpath = "//label[@for='CN261']")
    protected Element radSatelliteNo;

    @FindBy(xpath = "//label[@for='CN262']")
    protected Element radAnswerNotProvided;

    @FindBy(xpath = "//label[@for='CN2010']")
    protected Element radGame;

    @FindBy(xpath = "//label[@for='CN3010']")
    protected Element radHaveItAll;

    @FindBy(xpath = "//label[@for='CN3020']")
    protected Element radHBO;

    @FindBy(xpath = "//button[@id='btnCN302']")
    protected Element btnNxtStep;

    @FindBy(xpath = "//label[@for='CN3512']")
    protected Element RadDoesnotwantphone;

    @FindBy(xpath = "//label[@for='CN220']")
    protected Element radAcceptNewNum;

    @FindBy(id = "guidanceQnA")
    protected Element btnRGQnA;

    @FindBy(xpath = "//label[@for='CN300']")
    protected Element rbtnNegotiateOrder;
    //@FindBy(xpath = "//div[@class='qa_set']/ul[contains(@class,'qa_answers')]//label[starts-with(.,'<<<>>>') and not(@aria-checked='true')]")
    @FindBy(xpath = "//div[@class='qa_set']/ul[contains(@class,'qa_answers')]//label[starts-with(.,'<<<>>>')]")
    protected Element RGQuestions;

    @FindBy(xpath = "//div[@class='qa_set']//button[contains(text(),'Next Step')]")
    protected Element btnRGNext;
    @FindBy(xpath = "//div[@class='qa_set']//button[contains(text(),'Next Step')]")
    protected CList<Element> btnRGNextList;

    @FindBy(xpath = "//*[@id='switchType']")
    protected Element txtBTN;
    @FindBy(xpath = "//*[@id='switchType']")
    protected CList<Element> txtBTNList;

    @FindBy(xpath = "//*[@id='divLoadPortEligibility']/div[3]/button")
    protected Element btnBTNxt;

    @FindBy(xpath = "//*[@id='divLoadPortEligibility']/div[3]/button")
    protected CList<Element> btnBTNxtList;

    @FindBy(xpath = "//div[@data-ui-view='repGuidance']//*[contains(.,'<<<>>>')]")
    protected Element getQuestionerType;

    protected By addressValidated = By.xpath("//div[@data-ui-view='repGuidance']//b[contains(.,'Address Validated')]");
    protected By Disconnect = By.xpath("//div[@data-ui-view='repGuidance']//*[contains(.,'LOYAL')]");

    @FindBy(xpath = "//div[contains(@class,'m_end-of-flow')]/p")
    protected Element endOfFlow;
    
    @FindBy(xpath = "//ul[@ng-if='isContetReady']//li[contains(.,'Existing Account For:')]")
    protected Element HFWS_existing_services;
    
    @FindBy(xpath = "//div[@data-ui-view='repGuidance']//a[text()='Click here to View HFWS']")
    protected Element linkHFWS;

    @FindBy(xpath = "//div[@data-ui-view='repGuidance']//p[contains(text(),'This customer will not be eligible for Self install')]")
    protected Element noSelfInstall;

    @FindBy(xpath = "//div[@si-section-name='ProductsandServices']")
    protected Element productsButton;

    @FindBy(xpath = "*//li[@ng-repeat='serviceRelated in ServiceRelated']//a[contains(text(),'Change')]")
    protected Element btnChange;

    @FindBy(xpath = "//ul[not(contains(@class,'hide'))]//li[contains(@ng-show,'Ordering')]//a[contains(.,'Tools')]")
    protected Element IWantTolink;

   // @FindBy(xpath = "*//li[@ng-repeat='serviceRelated in ServiceRelated' or @ng-repeat='orderingMenu in OrderingMenuItems']//a[contains(text(),'Change Existing Services')]")
    @FindBy(xpath = "*//li[@ng-repeat='serviceRelated in ServiceRelated']//a[contains(text(),'Change Existing Services') or contains(text(),'My Offers')]")
    protected Element btnChangeExistingServices;

    @FindBy(xpath = "//ul[not(contains(@class,'hide'))]/li[(contains(.,'Change Existing Services') or contains(.,'My Offers') or contains(.,'PRODUCT TOOLS')) and (not(contains(@class,'hide'))) and @ng-repeat='serviceRelated in ServiceRelated']")
    protected Element waitForChangeServices;

    @FindBy(xpath = "//ul[not(contains(@class,'hide'))]//li[contains(@ng-show,'Ordering')]//a[contains(.,'Change Existing Services') or contains(.,'My Offers')]")
    protected Element Change_Existing_Services_under_I_want_To;
    
    @FindBy(xpath = "//*[@ng-click='orderAddressInfo(order)']")
    protected Element ChangeAddresslink;
    
    @FindBy(xpath = "//input[@id='addressZipCode']")
    protected Element zipCode;
    
    @FindBy(xpath = "//input[@id='addressAddress']")
    protected Element address;
    
    @FindBy(xpath = "//div[not(contains(@class,'ng-hide'))]/ol/li[contains(@data-steps-tab,'<<<>>>') and contains(@class,'active')]")
    protected Element currentActiveTab;
    
    @FindBy(xpath = "//div[contains(@ng-repeat,'multipleAddress')]//p")
    protected Element firstMultipleAddress;
    
    @FindBy(xpath = "//button[@ng-click='moveNextPage()']")
    protected Element btnNext1;
    
    @FindBy(xpath = "//*[contains(text(),'Sales Profile Information')]")
    protected Element salesProfileInformationTab;
    
    @FindBy(xpath = "//button[@ng-click='salesRequiredCheck()']")
    protected Element salesProfileSave;

    @FindBy(xpath = "*//li[@ng-repeat='orderingMenu in OrderingMenuItems']//a[contains(text(),'Change of Ownership')]")
    protected Element ChangeOfOwnership;
    @FindBy(xpath = "*//li[@ng-repeat='account in Account']//a[contains(text(),'Change of Ownership')]")
    protected Element btnChangeOfOwnership;
    @FindBy(xpath = "//p[contains(text(),'More Premium Channels')]")
    protected Element More_Permium_channel;

    @FindBy(xpath = "//li[@data-tab='International-tab']")
    protected Element MoreChannelType;

    @FindBy(xpath = "//div//p[contains(text(),'Fios Arabic')]")
    protected Element Premium_channel_tile;
    @FindBy(xpath = "//div/a[contains(text(),'Update')]")
    protected Element PremiumChannel_Update;
    @FindBy(xpath = "//button[@id='Preview_Order']")
    protected Element btnReviewOrder;
    @FindBy(xpath = " //*[@ng-click='ProceedWithOrder()']")
    protected Element btnCheckout;
    @FindBy(xpath = "*//li[@ng-repeat='orderingMenu in OrderingMenuItems' or @ng-repeat='products in Products']//a[contains(text(),'Programming Only')]")
    protected Element ChangeProgramming;
    @FindBy(xpath = "*//li[@ng-repeat='serviceRelated in ServiceRelated']//a[contains(text(),'Order Pay Per View')]")
    protected Element btnChangePPV;

    @FindBy(xpath = "*//div[@class='w_pendingorder-droplist']/ul/li[1]/a[@ng-click='TriggerStackFlow(stackMenu,order)']")
    protected Element btnChangeStackOrder;

    @FindBy(xpath = "//li[@ng-repeat='serviceRelated in ServiceRelated']/a[contains(text(),'Programming Only')]")
    protected Element btnChangeProgramming;
    @FindBy(xpath = "*//a[@id='btnSaveAndContinue']")
    protected Element SaveAndContinue;
    @FindBy(xpath = "*//input[@id='SaveAndContinue']")
    protected Element SaveAndContinue2;
    @FindBy(xpath = "//button[@ng-click='SuppOrderSubmit(order)']")
    protected Element btnChangeSuppOrder;
    @FindBy(xpath = "//button[@ng-click='CancelOrder(order)']")
    protected Element btnChangeCancelOrder;
    @FindBy(xpath = "//a[@ng-click='SuppDueDateOrderSubmit(order)']")
    protected Element btnChangeDueDate;
    @FindBy(xpath = "//li[@ng-repeat='orderingMenu in OrderingMenuItems']//a[contains(text(),'Loyalty Flow / Disconnect') or contains(text(),'Disconnect')]")
    protected Element btnDisconnect2;

    // ******************************GUI_Validations_Gopal**********************************************//

    @FindBy(xpath = "//*[@data-ui-view= 'connectionsView']")
    protected Element Connections_Link;

    @FindBy(xpath = "//*[@data-reveal-trigger= 'DashboardConnections']")
    protected Element Connections_Plus_Minus_Link;

    @FindBy(xpath = "//*[@ng-click = 'ConnectionsAvailableServicesPopup();']")
    protected Element Connection_Avbl_Services;

    @FindBy(xpath = "//*[@data-open-modal = 'ConnectionsAvailableServices']")
    protected Element Connection_Avbl_Services_Link;

    @FindBy(xpath = "//*[@data-modal = 'connectionsAvailableServicesModal']")
    protected Element Avbl_Services_Window;

    @FindBy(xpath = "//button[contains(text(),'Close')]")
    protected Element Close_Button;

    @FindBy(xpath = "//*[@data-ui-view = 'campaignView']")
    protected Element Campaign_Link;

    @FindBy(xpath = "//*[@id = 'DashboardCampaignsTile']")
    protected Element Campaign_Plus_Link;

    @FindBy(xpath = "//*[@class = 'simplex_panel active']")
    protected Element Dashboard_ProductsServices;

    @FindBy(xpath = "//*[@data-reveal-trigger= 'DashboardCompetitors']")
    protected Element Competitors_Plus_Link;

    @FindBy(xpath = "//*[@data-ui-view = 'competitorsView']")
    protected Element Competitors_Link;

    @FindBy(xpath = "//div[@data-ui-view='campaignView']//div[contains(@ng-repeat,'campaignInformation') and not(contains(@class,'ng-hide'))]")
    protected CList<Element> EachCampaign_Link;

    @FindBy(xpath = "//div[@data-ui-view='campaignView']//div[contains(@ng-repeat,'campaignInformation') and not(contains(@class,'ng-hide'))]//a[contains(text(),'More')]")
    protected CList<Element> MoreLink_Campaign;

    @FindBy(xpath = "//*[text() = 'Campaigns']")
    protected Element Campaign_details;

    @FindBy(xpath = "//*[@ng-click = 'setStateBackToCampaigns()']")
    protected Element Campaign_close_Button;

    @FindBy(xpath = "//*[contains(@ng-click, 'getSelectedCompetitor')]")
    protected Element morelink_Competitors;

    @FindBy(xpath = "//*[@id = 'content']/div[contains(@class, 'row padding-horiz-tiny') and not(contains(@class, 'active'))]")
    protected CList<Element> Eachcompetitor_Link;

    @FindBy(xpath = "//*[@id = 'content']/div[contains(@class, 'row padding-horiz-tiny') and not(contains(@class, 'active'))]//a[contains(text(),'More')]")
    protected CList<Element> MoreLink_Competitor;

    @FindBy(xpath = "//*[@data-open-modal = 'searchCampaigns']")
    protected Element Campaign_Search_Button;

    @FindBy(xpath = "//*[@id = 'campaignTFN']")
    protected Element campaignTFN;

    @FindBy(xpath = "//*[@ng-model = 'campaignName']")
    protected Element campaignName;

    @FindBy(xpath = "//*[@ng-click = 'searchCampaigns()']")
    protected Element search_Campaigns;

    @FindBy(xpath = "//*[@ng-show = 'totalCampaignsFound == 0']")
    protected Element close_Campaigns;

    @FindBy(xpath = "//*[@id = 'comp-guide-link']")
    protected Element Comp_guide_link;

    @FindBy(xpath = "//*[@onclick = 'clearModalOverlay()']")
    protected Element Competitor_close;

    @FindBy(xpath = "//*[@ng-click= 'launchCompetitorGuide()']")
    protected Element Competitor_Guide;

    @FindBy(xpath = "//*[@id = 'nav']//a[contains(@class, 'enabled')]")
    protected Element Competitors_Tab;

    @FindBy(xpath = "//*[@id = 'nav']//a[contains(@class, 'enabled')]")
    protected CList<Element> Competitor_Tab;

    @FindBy(xpath = "//*[@class = 'p-100']")
    protected Element Campaign_Details;

    @FindBy(xpath = "//*[@id = 'overridelink']")
    protected Element override_link;

    @FindBy(xpath = "//div[@id='divRestoreMessage']//input[@id='btnCancelOK']")
    protected Element okButton;

    @FindBy(xpath = "//label[contains(text(),'Answer Not Provided')]")
    protected Element rgbtn1;

    @FindBy(xpath = "//label[@for='CD8611']")
    protected Element rgbtn2;

    @FindBy(xpath = "//label[contains(text(),'Process Disconnect')]")
    protected Element rgbtn3;
    @FindBy(xpath = "//label[@for='CC610']")
    protected Element rgbtn4;
    @FindBy(xpath = "//button[@ng-click='SubmitCancelComments()']")
    protected Element btnCancel;
    @FindBy(xpath = "//textarea[@id='txtRgCancelComment']")
    protected Element CancelComments;

    @FindBy(xpath = "//select[@id='ddlRCWVerizonReasonCategory']")
    protected Element DisconnectCategory;
    @FindBy(xpath = "//select[@id='ddlRCWVerzionDisconnectReasons']")
    protected Element DisconnectReason;

    @FindBy(xpath = "//input[@id='cbxRCWETFConfirmation']")
    protected Element checkbxConfirm;

    @FindBy(xpath = "//input[@id='btnSaveAndContinue']")
    protected Element btnSaveContinue;

    @FindBy(xpath = "//input[@id='Button1g']")
    protected Element disconnectSaveContinue;
    @FindBy(xpath = "*//li[@ng-repeat='orderingMenu in OrderingMenuItems']//a[contains(text(),'Vacation Suspend / Restore')]")
    protected Element btnChangeVacationSuspend;
    @FindBy(xpath = "*//li[@ng-repeat='account in Account']//a[contains(text(),'Vacation Suspend / Restore')]")
    protected Element btnChangeVacationSuspend2;

    @FindBy(xpath = "*//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$vacation$vacation_chkVideo']")
    protected Element SuspendButton;
    @FindBy(xpath = "*//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$vacation$vacation_chkBundle']")
    protected Element SuspendButton2;

    @FindBy(xpath="//input[@id='vacation_chkVacAll']")
    protected Element suspendall;
    @FindBy(xpath = "*//div[@class='w_pendingorder-droplist']")
    protected Element txtStack;

    @FindBy(xpath = "//li[@ng-repeat='serviceRelated in ServiceRelated']//a[contains(text(),'Loyalty Flow / Disconnect') or contains(text(),'Disconnect')]")
    protected Element btnDisconnect;

    @FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$FooterContent$btntabUISaveContinue']")
    protected Element btnFiosSaveContinue;
	
	   @FindBy(xpath = "*//button[@name='RgDontCancel']")
    protected Element DontCancel;
    
    @FindBy(xpath = "*//button[@name='DontCancel']")
    protected Element btnCancelDontCancel;

    @FindBy(xpath = "//select[@id='ddlRCWPendingOrderCancelReasonCodes' or @id='infoCancelReason']")
    protected Element reasonForCancel;

    @FindBy(xpath = "//li/a[@id='ContentPlaceHolder1_rptTabs_lbtnTab_9']")
    protected Element loyalityTab;

    @FindBy(xpath = "//input[@name='ctl00$ctl00$ContentPlaceHolder1$FooterContent$btnSaveAndContinue']")
    protected Element saveCont;

    @FindBy(xpath = "//input[@onClick='javascript: submitWithAcceptance();']")
    protected Element clickProceed;
    @FindBy(xpath = "//textarea[@id='txtCloseNotes']")
    protected Element closingNotesText;

    @FindBy(xpath = "//span[contains(text(),'Connection')]")
    protected Element snapshot;

    ////////////////////
    @FindBy(xpath = "//*[contains(@name,'ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$vacation$vacation_')]")
    protected Element RestoreButton;

    @FindBy(xpath = "//*[contains(@name,'ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$vacation$vacation_')]")
    protected CList<Element> RestoreButtonList;

    // Partial Disconnect
    @FindBy(xpath = "//label[contains(text(),'Process Partial Disconnect')]")
    protected Element PartialDisconnectRadiobtn;
    // InternetDisconnect
    @FindBy(xpath = "//label[contains(text(),'Internet')]")
    protected Element InternetPartialDisconnect;
    // TVdisconnect
    @FindBy(xpath = "//label[contains(text(),'TV')]")
    protected Element TVPartialDisconnect;

    @FindBy(xpath = "//label[contains(text(),'Continue w/Partial Disconnect')]")
    protected Element ContinuePartialDisconnect;

    @FindBy(xpath = "//ul[contains(@class,'qa_answers')]//label[contains(text(),'No')  and not(@aria-checked='true')]")
    protected Element NoPartialDisconnect;

    @FindBy(xpath = "//button[@id='btnCD152']")
    protected Element PartdisconnectNext;

    @FindBy(xpath = "//input[@id='cbxRCWETFConfirmation']")
    protected CList<Element> checkbxConfirmList;

    // Stack Disconnect
    @FindBy(xpath = "//div[@class='pendingorder-droplist_title']")
    protected Element stackdisconnect;

    @FindBy(xpath = "*//div[@class='w_pendingorder-droplist']/ul/li/a[contains(text(),'<<<>>>')]")
    protected Element stackdisconnect1;

    @FindBy(xpath = "//input[@id='Button3']")
    protected CList<Element> btnproceedList;

    @FindBy(xpath = "//input[@id='Button3']")
    protected Element btnproceed;
    
    @FindBy(xpath = "//div[@ng-if='IsInstallStatic']/install-static")
    protected Element AvailableServicesText;

    @FindBy(xpath = "//div[@data-ui-view='guidedflowview']")
    protected Element snapshotText;
    

	//******************Portability Eligible*****************
	@FindBy(xpath = "//*[text()[contains(.,'Portability Eligible')]]//following::p//*[text()[contains(.,'YES')]]")
	protected Element btnPortableEligible;

	@FindBy(xpath = "//*[text()[contains(.,'Portability Eligible')]]")
	protected CList<Element> btnPortableEligibleList;
	
	@FindBy(xpath = "//*[@id='divLoadPortEligibility']//ul[@ng-show[not(contains(.,'!'))]]//button[contains(text(),'Continue')]")
	protected Element btnPortableEligibleContinue;
	
	@FindBy(xpath = "//*[@id='customer_AccNum']")
	protected Element btnPortEligAccNo;

	@FindBy(xpath = "//*[@id='customer_name']")
	protected Element btnPortEligName;

	@FindBy(xpath = "//*[@id='divLoadPortEligibility']//li/button[contains(text(),'Next')]")
	protected Element btnPortEligNext;
	@FindBy(xpath = "//div[@data-section-trigger='dashboard']")
    protected Element dashboardbutton;
	
	@FindBy(xpath = "//input[@id='customer_AccPwd']")
    protected Element password;
	
	@FindBy(xpath = "//div[@data-reveal-content='ErrorMessageProducts']//div[contains(text(),'Service')]")
    protected Element SQEError;
	@FindBy(xpath = "//button[@ng-click='SuppOrderSubmit(order)']")
    protected Element btnResume;
	
	@FindBy(xpath = "//button[@ng-click='CancelConfirmation(selectedOrder)']")		
	    protected Element btnCancel2;
	 @FindBy(xpath = "//label[@for='Cancel_Customer']")
	    protected Element custcancel;
	 @FindBy(xpath = "//textarea[@id='txtCancel']")
	    protected Element CancelComments2;
	 @FindBy(xpath = "//button[@ng-click='SaveCancelOrderDetails(selectedOrder)']")
	    protected Element btnCancel3;
	 @FindBy(xpath = "//li[@ng-repeat='account in Account']//a[contains(text(),'Setup/Modify Auto-Pay')]")
	    protected Element setupAutopay;
	 
	 
	 @FindBy(xpath = "//input[@id='ContentPlaceHolder1_ContentPlaceHolder1_interceptsSection_ctl00_gvIntercepts_chkSelectedTn_0']")
	    protected Element intercept1;
	 @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_interceptsSection_ctl00_btnBasicApply']")
	    protected Element applybtn;
	 @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ContentPlaceHolder1_interceptsSection_ctl00_btnOkMain']")
	    protected Element okbtn;
	 @FindBy(xpath = "//input[@id='ContentPlaceHolder1_FooterContent_btntabUISaveContinue' or @id = 'SaveAndContinue']")
	    protected Element SACbtn;
	 
	 @FindBy(xpath = "//input[@id='ContentPlaceHolder1_ContentPlaceHolder1_interceptsSection_ctl00_txtManualNumberBasic']")
	    protected Element enterTN;
	 @FindBy(xpath = "//select[@id='ContentPlaceHolder1_ContentPlaceHolder1_interceptsSection_ctl00_drpDurationBasic']")
	    protected Element drpmonths;
	 
	 @FindBy(xpath = "//input[@id='btnCancel' or @id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_btnCancel']")
	    protected Element btnDuedateContinue;
	 
 
	 @FindBy(xpath = "//input[@id='txtPartyName']")
	    protected Element callingPartyName;
	 @FindBy(xpath = "//a[@id='ContentPlaceHolder1_ucAddressValidation_btnValidateAddress']")
	    protected Element qualifyAddress;
	 
	 @FindBy(xpath = "//input[@id='rdoNewRoommate']")
	    protected Element newRoomMate;
	 
	 @FindBy(xpath = "//input[@id='btnSaveAndContinue']")
	    protected Element saveAndcnt; 
	 
	 @FindBy(xpath = "//input[@id='txtHouseNumber']")
	    protected Element housename;  
	 @FindBy(xpath = "//input[@id='txtStreetName']")
	    protected Element streetname;
	 @FindBy(xpath = "//input[@id='txtCity']")
	    protected Element city;
	 
	 @FindBy(xpath = "//select[@id='ddlState']")
	    protected Element state;
	 
	 @FindBy(xpath = "//input[@id='txtZip']")
	    protected Element zipcode;
	 
	 @FindBy(xpath = "//li[contains(@class,'active') and contains(@id,'accounttabs')]/a/span[contains(text(),'New Account')]")
	    protected Element newAccount;
 
			 
		@FindBy(xpath = "//*[@ng-repeat = 'serviceRelated in ServiceRelated']/a[contains(text(), 'Renew Bundle/Contract')]")
		protected Element RenewBundle;
		
		@FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_interceptsSection_ctl00_chkSelectAll']")
		protected Element Intercepts;
		
		@FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ContentPlaceHolder1_interceptsSection_ctl00_btnOkMain']")
		protected Element InterceptsOK;
		
		@FindBy(xpath = "//*[@ng-click = 'SubmitCancelComments()']")
		protected Element CancelButton;
		
		@FindBy(xpath = "//*[@id = 'Button3']")
		protected Element ProceedCancel;
		
		@FindBy(xpath = "//*[@id = 'Button4']")
		protected Element NotProceedCancel;
		
		@FindBy(xpath = "//div[@class='simplex_panel-scroll padding-vert-zero ng-scope']/div/ul/li[2]")
	    protected Element activitytimelinetext;
		
		@FindBy(xpath = "//li[@ng-repeat='orderingMenu in OrderingMenuItems']//a[contains(text(),'Add UNEP/TDRL')]")
	    protected Element btnAddUNEPTDRL;
	 
		
		 //Added by Sasikiran -SIT team
		 @FindBy(xpath = "//button[@id='btnSaveAndClose']")                                      
		    protected Element SaveandClose;

		 @FindBy(xpath = "//button[@ng-click='SubmitCancelComments()']")
		 	    protected Element btnCancelatpopupleadtoLoyalty; 
		
		 //Vishnu priya -SIT team
		 @FindBy(xpath = "//div[@class='customer-address']//span[1][@ng-if='ShowProfileAddress']")
		 protected Element address_FirsthalfatHeader;
		 @FindBy(xpath = "//div[@class='customer-address']//span[2][@ng-if='ShowProfileAddress']")
		 protected Element address_SecondhalfatHeader;
		 
		 //Thanooja

		 @FindBy(xpath = "//div[contains(@ng-bind-html,'nfo') and contains(text(),'shipped')]")
		 protected Element msgbar;
		 
		 @FindBy(xpath = "//*[@id = 'txtHouseNumber'  and  @name = 'ctl00$ContentPlaceHolder1$ucAddressValidation$txtHouseNumber']")
		    protected Element HouseNumber;

		@FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ucAddressValidation_ddlStreetDirection']")
		    protected Element StreetDirection;
	
		@FindBy(xpath = "//*[@id = 'txtStreetName' and @name = 'ctl00$ContentPlaceHolder1$ucAddressValidation$txtStreetName']")
		    protected Element StreetName;
	
		@FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ucAddressValidation_ddlStreetType']")
		    protected Element StreetType;
	
		@FindBy(xpath = "//*[@id  = 'ddlStructure' and @name = 'ctl00$ContentPlaceHolder1$ucAddressValidation$ddlStructure']")
		    protected Element StructureType;
	
		@FindBy(xpath = "//*[@id = 'txtStructure']")
		    protected Element StructureName;
	
		@FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ucAddressValidation_txtFloor']")
		    protected Element FloorNumber;
	
		@FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ucAddressValidation_ddlUnit1']")
		    protected Element UnitType;
	
		@FindBy(xpath = "//*[@id = 'txtUnitValue' and @name = 'ctl00$ContentPlaceHolder1$ucAddressValidation$txtUnitValue']")
		    protected Element UnitName;
	
		@FindBy(xpath = "//*[@id = 'txtCity' and @name = 'ctl00$ContentPlaceHolder1$ucAddressValidation$txtCity']")
		    protected Element CityName;
	
		@FindBy(xpath = "//*[@id = 'ddlState' and @name = 'ctl00$ContentPlaceHolder1$ucAddressValidation$ddlState']")
		    protected Element StateName;
	
		@FindBy(xpath = "//*[@id = 'txtZip' and @name= 'ctl00$ContentPlaceHolder1$ucAddressValidation$txtZip']")
		    protected Element ZipCode;
	
		@FindBy(xpath = "//*[@id = 'ContentPlaceHolder1_ucAddressValidation_btnValidateAddress']")
		    protected Element QualifyAddress;
		
		@FindBy(xpath = "//*[contains(@ng-click, 'LaunchOrdering') and contains(text(), 'Correct Service Address')]")
	    protected Element CorrectServiceAddress;
		
		@FindBy(xpath = "//*[@id='SqeResultSection']")
	    protected Element SqeResultSection;
		
		@FindBy(xpath = "//*[@id='rdoNewRoommate']")
	    protected Element newroommate;

	   @FindBy(xpath = "//*[@id='lableSaveAndContinue']")
	    protected Element SaveandContinue;
	   
	   @FindBy(xpath = "//*[contains(@ng-click, 'LaunchOrdering') and contains(text(), 'Get Copper Bundle')]")
	    protected Element GetCopperBundle;

	  @FindBy(xpath = "//*[contains(@ng-click, 'LaunchOrdering') and contains(text(), 'Change LEC Voice')]")
	    protected Element ChangeLECVoice;
	  
	  @FindBy(xpath = "//li[@ng-repeat='products in Products' or @ng-repeat='serviceRelated in ServiceRelated']//a[contains(text(),'High Speed Internet')]")
	    protected Element btnHighSpeedInternet;  
	  
	  @FindBy(xpath = "//ul[not(contains(@class,'hide'))]/li/div/div/div/span/b[contains(text(),'Verizon Voice Link')]")
	    protected Element verizonvoicelink;
		
		@FindBy(xpath = "//label[@for='rdohomealarm_1']")
	    protected Element homealarmsystem;

	   @FindBy(xpath = "//label[@for='rdomedical_02']")
	    protected Element legallyrequireddevices;
	   
	   @FindBy(xpath = "//label[@for='rdoSecurity_1']")
	    protected Element securitydoor;
	   
	   @FindBy(xpath = "//button[contains(@ng-click,'Verizon Voice Link') and contains(text(),'Ok')]")
	    protected Element OkButton;
	   
	   @FindBy(xpath = "//div[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ucServiceTN_divBtnAddEquipment']/label/input[@id='btnAddEquipment']")
	    protected Element addEquipment;

	   @FindBy(xpath = "//select[@id='ddlStandAloneCPE']")
	    protected Element selectpackage;
	   
	   @FindBy(xpath = "//input[@id='btClose']")
	    protected Element ok;
	   
	   @FindBy(xpath = "//input[@id='rdbModemYes']")
	    protected Element rbtModem;
	   @FindBy(xpath = "//input[@id='ucEquipment1_rptProductModem_rdbProductModem_0']")
	    protected Element selectModem;
	   @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_btnSaveAndContinue']")
	    protected Element SaveAndCont;
	   @FindBy(xpath = "//li[@ng-repeat='products in Products' or @ng-repeat='serviceRelated in ServiceRelated' or @ng-repeat='account in Account']//a[contains(text(),'HSI - Add Equipment')]")
	    protected Element addHSI;
	   
	   @FindBy(xpath = "//a[@onclick='BringBCW();']")
	    protected Element clickhere;
	   
	   @FindBy(xpath = "//iframe[@id='extifrmpop']")
	    protected Element Packageframe;
	   
	   @FindBy(xpath = "//*[@ng-repeat='account in Account']//*[contains(.,'Change Billing Name and Address')]")
	    protected Element ChangeBillingAddOption;
	   @FindBy(xpath = "//input[@id='SaveAndContinue']")
	    protected Element btnFDVSaveContinue;
	 
	 
	   @FindBy(xpath = "//div[@class='pendingorder-droplist_title' and contains(text(), '<<<>>>')]")
	    protected Element ReissueReason;
	   
	   @FindBy(xpath = "//*[@ng-click = 'TriggerCancelReissue(selectedOrder)']")
	    protected Element BtnYes;
	 
	   @FindBy(xpath = "//*[text() = 'Dry Loop HSI Account']")
	    protected Element DryLoopHeader;
	
	   @FindBy(xpath = "//*[@for = '<<<>>>']")
	    protected Element DryLooptype;
	 
	   @FindBy(xpath = "//*[@ng-click = 'submit()']")
	    protected Element Btnyes;
	   
	   @FindBy(xpath = "*//li[@ng-repeat='account in Account']//a[contains(text(),'Edit PIN')]")
	    protected Element EditPIN;
	   
	   @FindBy(xpath = "//*[text() = 'Edit PIN Information']")
	    protected Element EditPINInformation;	 
	   
	   @FindBy(xpath = "//*[@id = 'PinNumber']")
	    protected Element TXTPIN;

	   @FindBy(xpath = "//*[@for = 'OptionalPIN']")
	    protected Element RBNOptional;
	   
	   @FindBy(xpath = "//*[@for = 'MandatoryPIN']")
	    protected Element RBNMandatory;
	   
	   @FindBy(xpath = "//*[@ng-click = 'SavePin()']")
	    protected Element Savepin;
	   
	   @FindBy(xpath = "//*[text() = 'Estimated installation time ']")
	    protected Element InstallationTime;
	   
	   @FindBy(xpath = "//*[@data-reveal-content = 'ErrorMessageProducts']")
	    protected Element HOAerror;
	   
	   @FindBy(xpath = "//*[@ng-show = 'notificationMessagesUnGrouped && notificationMessagesUnGrouped.length>0']")
	    protected Element HOAAddressAlert;
	   
	   @FindBy(xpath = "//*[@ng-click = 'CloseAccount()' and @ng-hide = 'closeAccButtonOrderProgress']")
	    protected Element BtnCloseAccount;
	   
	   @FindBy(xpath = "//*[@id = 'closeReasonForCall']")
	    protected Element CloseReasonForCall;
	   
	   @FindBy(xpath = "//*[@id = 'txtCloseNotes']")
	    protected Element TxtCloseNotes;
	   
	   @FindBy(xpath = "//*[@id = 'btnSaveAndClose']")
	    protected Element BtnSaveAndClose;
	   
	   @FindBy(xpath = "//*[@ng-if = '$first']//following::div[@class = 'timeline_content'][1]//*[@class = 'text-small text-grey-4-active ng-binding']")
	    protected Element Timestamp;
	   
	   @FindBy(xpath = "//*[text() = 'REFRESH']")
	    protected Element BtnRefresh;
	   
	   @FindBy(xpath = "//*[@ng-if = '$first']//following::div[@class = 'timeline_content'][1]//*[@class = 'ellipsis clear']")
	    protected Element TxtReasonforCall;
	 
	   @FindBy(xpath = "//a[@id='lbtnTab' and contains(@class,'active')]")
	    protected Element FDVTab;
	   
	   @FindBy(xpath = "//*[@ng-class = 'order.accordionClass' and @aria-expanded = 'true']//div[@class = 'tiny-6 medium-6 large-6 columns pendingorder_status']")
	    protected Element PendingAccountDetails;
	   
	   
	   @FindBy(xpath = "//*[@ng-click = 'SupOrderConfiramSubmit(selectedOrder.MasterOrderNumber)' or @ng-click = 'SupOrderConfiramSubmit(selectedOrder.MasterOrderNumber, selectedOrder)']")
	    protected Element UpdateOrder;


	   @FindBy(xpath = "//a[(@id='ContentPlaceHolder1_rptTabs_rptSubTabs_11_lbtnTab_1' or @id = 'lbtnTab') and contains(@class,'active')]")   //Gopal 03/12
	    protected Element LecSection;
	   
	 //---------------------------------Edit Contact Info------SAC------@Author Bharathi--------------August 2017//
		  @FindBy(xpath="//div/span[2]/a[contains(text(),'Edit')]")
		  protected Element editContact;
		  
		  @FindBy(xpath="/html/body/div[14]")
		  protected Element editPopup;
		  
		  @FindBy(id="CallingPartyVerizonWirelessNumber")
		  protected Element mobNumber;
		  
		  @FindBy(id="CallingPartyEmail")
		  protected Element email;
		  
		  @FindBy(xpath="//div[not(contains(@class,'hide'))]/button[contains(text(),'Save')]")
		  protected Element saveInfo;
		  
		  @FindBy(xpath="//span[contains(text(), 'Please verify (This email address is associated with another account.)')]")
		  protected Element verifyEmailwarning;
		  
		  @FindBy(xpath="//*[contains(@ng-click, 'UpdateCustomerContactInformation')]")
		  protected Element proceedwithEmail;
		  
		  @FindBy(xpath="//div[contains(text(), 'Saved Successfully')]")
		  protected Element saveStatus;
		  
		  @FindBy(xpath="//a[contains(@ng-click, 'CloseCustomerContactInfo()')]")
		  protected Element closeContactInfoPg;
		  
		
		//-------------------------------Change Billing Address-----SAC-------- @Author Bharathi-----------------//

		  @FindBy(xpath="//*[@id='ContainerKnobs']/section/div[2]/div[3]/div[1]/ul[1]/li[2]/a")
		  protected Element productTools;
		  
		  @FindBy(xpath="//*[@id='ContainerKnobs']/section/div[2]/div[3]/div[3]/div/div/ul[5]/li[4]/a")
		  protected Element changeBillingAddress;
	
		//-------------------------------Change PIN-------SAC------ @Author Bharathi-----------------//
		    @FindBy(xpath="//a[contains(text(),'Edit PIN')]")
		    protected Element editPIN;
		   
		    @FindBy(xpath="//div[contains(text(), 'PIN')]")
		    protected Element getPIN;
		   //-------------------------------Change Password------SAC------- @Author Bharathi-----------------//
		    @FindBy(xpath="//ul[not(contains(@class,'hide'))]/li/a[contains(text(),'Change Password')]")
		    protected Element changePwd;
		   

		    
		   // @FindBy(xpath = "//div[@ng-click='newTab()' and not(contains(@aria-label,'Open'))]")
		    //protected Element openaccntbtn;
		    
		    //@FindBy(xpath = "*//div[@class='tool-bar-wrapper-inner']//div[@ng-click='newTab()']")
		    @FindBy(xpath = "*//span[contains(text(),'OPEN')]")
		    protected Element openaccntbtn;		    

		    @FindBy(xpath = "//a[@title='More Options']")
		    protected Element moreOptions;	    
		    
		    @FindBy(xpath = "//a[contains(text(),'CoFEE BACK OFFICE') and @class='ng-binding ng-scope']")
		    protected Element cofeeBackOffice;			    
		    	    
		    @FindBy(xpath = "//*[@id='iduser']")
		    protected Element cofeeBackOfficeLoginTextBox;	
		    
		   @FindBy(xpath = "//li[@ng-repeat='products in Products' or @ng-repeat='serviceRelated in ServiceRelated']/a[contains(text(),'Expedite Services')]")
		    protected Element expdServices;
		   
		   @FindBy(xpath = "//tr[contains(.,'<<<>>>')]/td/span/input[@type='radio' or @type='checkbox']")
		    protected Element BBEOptions;
			
		   @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_btnSaveContinue']")
		    protected Element VASSaveandContinue;
		   
		   @FindBy(xpath = "//span[contains(@class,'AcctNumberIcn')]")
		    protected Element CustomerInfo;
		   @FindBy(xpath = "//a[@data-open-modal='quicklinksmodal']")
		    protected Element QuickLink;
		   
		   @FindBy(xpath = "//label[@for='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl187_0']")
		    protected Element yesIHaveRead1;
		 
		   @FindBy(xpath = "//label[@for='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl209_0']")
		    protected Element yesIHaveRead2;

		   @FindBy(xpath = "//label[@for='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl231_0']")
		    protected Element yesIHaveRead3;
			
			@FindBy(xpath = "//label[@for='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl173_0']")
		    protected Element yesIHaveRead4;
			
			@FindBy(xpath = "//*[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl147']/tbody/tr/td/label[@class='label_radio' and contains(text(),'Yes, I have read')]")
			protected Element yesIHaveRead5;
			
		   @FindBy(xpath = "//ul[@class='jtabs']/li/a")
		    protected Element BTNno;
		   
		   @FindBy(xpath = "//label[@id='ucStreamingOption1_rptStreamingOptions_ctl01_lblchkStreamingOption']")
		    protected Element HBONow;
		   
		   @FindBy(xpath = "//input[@id='ContentPlaceHolder1_ContentPlaceHolder1_btnforward']")
		    protected Element LecSaveAndCont;
		   @FindBy(xpath = "//div[contains(@ng-show,'notificationMessagesUnGrouped')]")
		    protected Element upshellPopup;
		   @FindBy(xpath = "//div[contains(@ng-show,'notificationMessagesUnGrouped')]/div/span[contains(@class,'close')]")
		    protected Element closePopup;


			@FindBy(xpath= "//div[@class='simplex_dashboard-sizer m_dashboard-sizer-lf right']")
		    
		    protected Element btnRGQtn;
		    
		    @FindBy(xpath="//a[@class='qa_edit-answer']")
		    protected CList<Element> radEditRGQtn;
		    
		    @FindBy(xpath="//div[@data-modal='orderContextConfirm']")
		    protected Element modalOrderConfirm;
		    
		    @FindBy(xpath="//button[contains(@data-ng-click, 'CancelOrdercall')]")
			 protected Element btnOrderConfirmYes;
		    
		    @FindBy(xpath="//div[@data-section-trigger='dashboard']")
		    protected Element btnSnapshot;
		    
		    @FindBy(xpath = "//span[@ng-class='headerClass']")
		    protected Element btnHeaderArrow;
		   
		   
		   @FindBy(xpath = "//li[@ng-repeat='orderingMenu in OrderingMenuItems' or @ng-repeat='account in Account']/a[contains(text(),'<<<>>>')]")
		    protected Element EquipmentDropoff;
		   @FindBy(xpath = "//input[@id='txtCustomerName']")
		    protected Element customerName;
		   @FindBy(xpath = "//Select[@id='Drprelation']")
		    protected Element familyRelation;
		   
		   @FindBy(xpath = "//label[@for='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ctl00_chkSelectAll']")
		    protected Element selectAllEquipment;
		   @FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ctl00_rptCPEEquipments_ctl01_ReasonCodesEquipment']")
		    protected Element reasonForDropOff;
		   @FindBy(xpath = "//label[@for='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_ctl00_rptCPEEquipments_ctl01_chkApplyAll']")
		    protected Element applyAll;
		   
		   @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_FooterContent_btnsubmit']")
		    protected Element submitbtn;
		   
		   @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_btnNo']")
		    protected Element btnNo;
		   
		   @FindBy(xpath = "//input[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_btnYes']")
		    protected Element btnYes;
		   
		   @FindBy(xpath = "//div[@data-close-customtip='sharedcart']//span[contains(@class,'close')]")
		    protected Element Smartcartpopup;
			
			@FindBy(xpath = "//*[@id='smartCartEmail']")
		    protected Element smartemail;
		   
		   @FindBy(xpath = "//*[@ng-click='ResumeOrderSmartCart(SmartCartDispDetails.MON)']")
		    protected Element smartResume; 
			
			@FindBy(xpath = "//*[@class='messages-count margin-right-micro ng-binding']")
		    protected Element Popupmessage;
		 
		   @FindBy(xpath = "//*[@ng-click = 'toggleIwantToMenu()']")
		    protected Element ProductTools;
		   
		   @FindBy(xpath = "//*[text() = 'Edit PIN' and @title = 'Links']")
		    protected Element EDITPIN;
		   
		   @FindBy(xpath = "//*[@ng-click = 'CloseAccountPin()']")
		    protected Element CloseLink;
		 

		   @FindBy(xpath = "//li[@ng-repeat = 'products in Products' or @ng-repeat = 'serviceRelated in ServiceRelated']/a[text() = '<<<>>>']")
		    protected Element ProductType;
		   
		   
		   @FindBy(xpath = "*//input[@name='ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$vacation$vacation_chkData']")
		    protected Element SuspendDataButton;
		   
		   
		  
		   
		   @FindBy(xpath = "//*[@ng-click = 'sendReturnKitNavClick();']")
		    protected Element EquipReturnOpt;
		   

		   @FindBy(xpath = "//*[@for = 'sendReturnKitSelect']")
		    protected Element AllEquipment;
		   
		   @FindBy(xpath = "//*[@ng-click = 'sendReturnKitListNextClick();']")
		    protected Element NextBTNEQUIP;
		   
		   @FindBy(xpath = "//*[@for = 'resendreturn_customer_droprefuse']")
		    protected Element RefusetoDrop;
		 
		   @FindBy(xpath = "//*[@for = 'resendreturn_use_billing_address']")
		    protected Element RbtnBillingAddress;
		   
		   @FindBy(xpath = "//*[@ng-click = 'sendReturnKitReturnMethodNextClick();']")
		    protected Element NextReturnKit;
		   
		   @FindBy(xpath = "//*[@for = 'useSuggestedAddress']")
		    protected Element SuggestedAddress;

		   @FindBy(xpath = "//button[contains(@ng-click,  'sendReturnKitStatus.ReturnMethod') and contains(text(), 'Send Return Kit To Selected Address')]")
		    protected Element SendReturnkit;
		   
		   @FindBy(xpath = "//*[text() = 'Equipment Return']")
		    protected Element EquipmentReturnTab;
		   
		   @FindBy(xpath = "//*[text() = 'Equipment Return Method']")
		    protected Element EquipmentReturnMethodTab;
		   
		   @FindBy(xpath = "//span[text() = 'Send Return Kit' and @class = 'line-height-xlarge text-xlarge']")
		    protected Element SendReturnKitTab;
		 
		   @FindBy(xpath = "//*[@class = 'tiny-12 columns padding-left-medium padding-right-medium padding-top-tiny']//button[contains(@ng-click, 'sendReturnKitStatus') and text() = 'OK']")
		    protected Element OKButton;
		   
		   @FindBy(xpath = "//div[@ng-repeat='order in Orders'][1]/div/div/div[contains(@ng-class,'order.accordionClass')]")
		    protected Element expandOrder;
		   
		   // PPV events
		   
		   @FindBy(xpath = "//*[@id = 'accounttabs']")
		    protected Element PPVTAB;
		 
		   
		   @FindBy(xpath = "//*[@for = 'radbtnGenreOption']")
		    protected Element SearchType;
		   
		   @FindBy(xpath = "//*[@id = 'ddlGenreOption']")
		    protected Element EventType;
		 
		   @FindBy(xpath = "//*[@id = 'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_btnGetEvents']")
		    protected Element BtnGetEvents;
		   
		   @FindBy(xpath = "//*[@id = 'btnOK']")
		    protected Element BtnExceedLimit;	   
		   
		    @FindBy(xpath = "//table[contains(@style,'border: solid 1px red')]")
		    protected Element errormessagePPV;
		    		   
		 
		   @FindBy(xpath = "//div[@id='divOneTimeEvents_Avaliable']/table/tbody/tr")
		    protected CList<Element> availableEvents;
		   
		   @FindBy(xpath = "//*[@id = 'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_rptrOneTimeEvents_Avaliable_ctl<<<>>>_chkOneTimeEvent_Avaliable']")
		    protected Element EventIDs;
		   
		   @FindBy(xpath = "//*[@id = 'OneTimeEventsAvaliable']")
		    protected Element OneTimeEvents;
		   
		   @FindBy(xpath = "//*[@id = 'btnAddSelected']")
		    protected Element BtnAddSelectedEvents;
		   
		   @FindBy(xpath = "//*[@id = 'OneTimeEventsOrdered']")
		    protected Element SelectedEvents;
		 
		   @FindBy(xpath = "//*[@id = 'ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_btnSubmit']")
		    protected Element BtnSubmitOrder;
		   
		   @FindBy(xpath = "//*[@id = 'monDisplay']")
		    protected Element MON;
		   
		   @FindBy(xpath = "//*[@id = 'closeReasonForCall']")
		    protected Element DrpcloseReasonForCall;
		   		   
		   @FindBy(xpath = "//*[@id = 'txtCloseNotes']")
		    protected Element NotesText;
		   
		   @FindBy(xpath = "//*[@id = 'btnSaveAndClose']")
		    protected Element BtnSaveClose;
		   
		   @FindBy(xpath = "//span[contains(@class,'vzicon icon-close') and @aria-hidden='true']")
		     protected Element PopupClose;
		   
		   //----------Winback---------@Author Anu ------------------------//
		    @FindBy(xpath="(*//a[contains(text(),'WinBack')])[2]")
		    protected Element winback;
		    
		    @FindBy(xpath="*//button[contains(@ng-click, 'moveNextPage()')]")
		    protected Element nxtbtn; 
		    
		    //----------UNDO CANCEL---------@Author Anu ------------------------//
		    @FindBy(xpath="//*[@ng-click='CancelOrder(order)']")
		    protected Element undocancel;
		    @FindBy(xpath="(//*[@class='button secondary no-icon'])[3]")
		    protected Element cancelno;	
		    @FindBy(xpath="(//*[@cl(//*[@class='button'])[7]ass='button'])[7]")
		    protected Element cancelyes;
		    
		    @FindBy(xpath = "//*[@id = 'txtEmail']") // *Gopal 03/12
		    protected Element EmailID;
		    
		    @FindBy(xpath = "*//button[contains(@onclick , 'closeModal') and text() = 'No']") // *Gopal 03/13
		    protected Element NoCancel;
		    @FindBy(xpath = "//div[@data-reveal-content='ErrorMessageProducts']") // 
		    protected Element errormsg;
		    
		    //--------------ETF ----------@Author Soham--------------//
		    @FindBy(xpath= "//div[contains(@ng-if,'profileService')]/following-sibling::div[contains(@ng-if,'ETF')]/strong")
		    protected Element eftContent;

		    
		    @FindBy(xpath = "//input[@id='btnSaveAndMakeMoreChanges']")
		    protected Element saveAndMakeMoreChanges;
		    @FindBy(xpath = "//li[@ng-show='showSalesProfileSaveBtn']button[@name='next']")
		    protected Element clickSave;
		    
		    @FindBy(xpath = "//input[@id='cbxRCWETFConfirmation']")
		    protected Element isCustomerAwareOfETFRadiobtn;
		    
		    @FindBy(xpath = "//*[@name = 'ctl00$ctl00$ContentPlaceHolder1$ContentPlaceHolder1$vacation$vacation_chkVacAll']")  // Gopal 04/26
		    protected Element SuspendPSTNBundle;
		    
		    // Gopal 05/04 
		    
		    @FindBy(xpath = "//*[@class = 'services-tooltip active']//span") 
		    protected Element NotificationMessage;
		    
		    @FindBy(xpath = "//*[text() = 'Edit PIN']")
		    protected Element EditPINInfo;
		    
		    @FindBy(xpath = "//*[@class = 'w_drop-list panel-options-more-tools' and @style = 'display: inline !important;']//*[@class = 'inline-block' and text() = 'Tools']")
		    protected Element ToolsOption;
		    
		    @FindBy(xpath = "//div[contains(@class,'end-of-flow')]")
		    protected Element EndOfFlow;
		    
		    protected By OPOPage = By.xpath("//div[@ng-if='!ProductsIsReady.value']");
		    
		    @FindBy(xpath = "//*[@data-custom-tip-content='alertNotify']//span[contains(@class, 'vzicon icon-close text-black pointer normal margin-left-micro margin-right-tiny right bg-grey-5 p-5 inline-block margin-top-micro')]") 
		    protected Element AlertMessage;
			
			@FindBy(xpath = "//div[@data-close-customtip='alertNotify' and contains(@class,'active')]/div/div/a[contains(@class,'close') and @aria-hidden='true']") 
		    protected Element MessageAlert;
			
			// Naresh - Techsure
			   @FindBy(xpath = "//span[contains(text(),'Existing Services: Broadband Essentials and Extras')]")
			    protected Element ExistingBBEServices;
			   
			   @FindBy(xpath = "//a[@pppname='Digital Security Pro Bundle']")
			    protected Element ChangeExistingBBEServices;
			   
			   @FindBy(xpath = "//a[@pppname='TechSure Premium']")
			    protected Element ChangeExistingTechSurePremiumBBEServices;
			   @FindBy(xpath = "//a[@pppname='TechSure']")
			    protected Element ChangeExistingTechSureServices;
			   
			   @FindBy(xpath = "//a[@pppname='TechSure Plus']")
			    protected Element ChangeExistingTechSurePlusBBEServices;
			   
			   
			   @FindBy(xpath = "//input[@value='Fixed_0_15.00']")
			    protected Element TechSurePlusService;
			   
			   @FindBy(xpath = "//td[contains(text(),'<<<>>>')]//parent::tr/following-sibling::tr/td/div/div/table/tbody/tr[2]/td/div/table/thead/tr[2]/td/input[@id='txtAdultFirstName']")
			    protected Element adult1FirstNameTechsure;
			   @FindBy(xpath = "//td[contains(text(),'<<<>>>')]//parent::tr/following-sibling::tr/td/div/div/table/tbody/tr[2]/td/div/table/thead/tr[2]/td/input[@id='txtAdultLastName']")
			    protected Element adult1LastNameTechsure;
			   @FindBy(xpath = "//td[contains(text(),'<<<>>>')]//parent::tr/following-sibling::tr/td/div/div/table/tbody/tr[2]/td/div/table/thead/tr[2]/td/input[@id='txtAdultEmail']")
			    protected Element adult1EmailTechsure;
			   
			   
			   // click additional adults
			   @FindBy(xpath = "//td[contains(text(),'<<<>>>')]//parent::tr/following-sibling::tr/td/div/div/table/tbody/tr[2]/td/div/table/thead/tr[3]/td/a[@id='lnkAddAdultSubscription']")
			    protected Element AddAdultSubscritpion;
			   
			   //get existing BBE service details
			   @FindBy(xpath = "//td[contains(text(),'<<<>>>')]//parent::tr/following-sibling::tr/td/div/div/table[@id='tblDGAdultSubscription']/tbody/tr[2]/td/div/table/thead/tr")
			    protected CList<Element> listOfExistingLifeLockAdults;
			   
			   @FindBy(xpath = "//input[@id='chkDGAdultSubscription']")
			    protected Element adultSubscriptionCheckBox;
			   
			   
			   @FindBy(xpath = "//a[contains(text(),'Change')]//parent::td/preceding-sibling::td[1]")
			    protected Element getExistingSuppVasOffer;
			   
			   @FindBy(xpath = "//td[contains(text(),'<<<>>>')]//parent::tr/following-sibling::tr/td/div/div/table[@id='tblDGChildSubscription']/tbody/tr[2]/td/div/table/thead/tr")
			    protected CList<Element> listOfExistingLifeLockChilds;
			   
			   @FindBy(xpath = "//td[contains(text(),'<<<>>>')]//parent::tr/following-sibling::tr/td/div/div/table/tbody/tr[2]/td/div/table/thead/tr")
			    protected CList<Element> existignLifeLockAdults;
			   
			// click additional Childs
			   @FindBy(xpath = "//td[contains(text(),'TechSure Premium')]//parent::tr/following-sibling::tr/td/div/div/table/tbody/tr[2]/td/div/table/thead/tr[<<<>>>]/td/a[@id='lnkAddAdultSubscription']")
			    protected Element AddChildSubscritpion;
			   
			   @FindBy(xpath = "//a[@id='lnkAdultremove2_749004']//parent::td//preceding-sibling::td[3]/input")
			    protected Element adult2FirstNameTechsure;
			   @FindBy(xpath = "//a[@id='lnkAdultremove2_749004']//parent::td//preceding-sibling::td[2]/input")
			    protected Element adult2LastNameTechsure;
			   @FindBy(xpath = "//a[@id='lnkAdultremove2_749004']//parent::td//preceding-sibling::td[1]/input")
			    protected Element adult2EmailTechsure;
			   
			   
			   @FindBy(xpath = "//td[contains(text(),'TechSure Plus')]//parent::tr/following-sibling::tr/td/div/div/table/tbody/tr[2]/td/div/table/thead/tr[<<<>>>]/td/input[starts-with(@id,'txtChildFirstName2')]")
			    protected Element Child1FirstNameTechsure;
			   @FindBy(xpath = "//td[contains(text(),'<<<>>>')]//parent::tr/following-sibling::tr/td/div/div/table/tbody/tr[2]/td/div/table/thead/tr[2]/td/input[@id='txtChildLastName']")
			    protected Element Child1LastNameTechsure;
			   //@FindBy(xpath = "//td[contains(text(),'<<<>>>')]//parent::tr/following-sibling::tr/td/div/div/table/tbody/tr[2]/td/div/table/thead/tr[2]/td/input[@id='txtChildEmail']")
			   // protected Element Child1EmailTechsure;
			   
			   
			   @FindBy(xpath = "//a[@id='lnkChildremove2_749005']//parent::td//preceding-sibling::td[3]/input")
			    protected Element child2FirstNameTechsure;
			   @FindBy(xpath = "//a[@id='lnkChildremove2_749005']//parent::td//preceding-sibling::td[2]/input")
			    protected Element child2LastNameTechsure;
			   @FindBy(xpath = "//a[@id='lnkChildremove2_749005']//parent::td//preceding-sibling::td[1]/input")
			    protected Element child2EmailTechsure;
			   
			   
			   @FindBy(xpath = "//td[contains(text(),'<<<>>>')]/preceding-sibling::td")
			    protected Element SelectTechSureService;
			   
			   @FindBy(xpath = "//input[@value='Fixed_0_30.00']")
			    protected Element TechSurePremiumService;
			   @FindBy(xpath = "//*[@pppname='TechSure']")
			    protected Element TechSureStandalone;
			   @FindBy(xpath = "//input[@id='btnCrmmSubmit']")
			    protected Element VASSubmit;
			   @FindBy(xpath = "//span[contains(text(),'Primary Reason')]")
			    protected Element primaryDisconnectReason;
			   
			   @FindBy(xpath = "//span[contains(text(),'Primary Reason')]//parent::td/following-sibling::td/select")
			    protected Element SelectPrimaryDisconnectReason;
			   @FindBy(xpath = "//select[@id='agencyDD']")
			    protected Element selectAgencyID;
			   //--------------------
			   			   
			   /***************************Mounika************************/
			   
			   @FindBy(xpath = "//input[@pppname='<<<>>>' and (@checked='true' or @checked='checked')]")
     		     protected Element RemoveBBE;
			   
			   @FindBy(xpath = "//select[@id='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ddlPrimaryReasonVAS']")
     		     protected Element reasonForRemoval;
                  
                  @FindBy(xpath = "//a[contains(@id,'ChangeLnk')]")
     		     protected Element ChangeBtn;
                  
                  @FindBy(xpath = "//input[@id='btnCrmmSubmit']")
     		     protected Element Submitbtn;
                  
                  @FindBy(xpath = "//input[@type='radio' and contains(@value,'Yes')]")
     		     protected Element YesButton;
                  
                  @FindBy(xpath="//input[@pppname='TechSure']")
      		    protected Element VASProduct_TechSure_ProductsPage;
      		    
      		    @FindBy(xpath="//input[@pppname='TechSure Premium']")
      		    protected Element VASProduct_TechSurePremium_ProductsPage;
      		    
      		    @FindBy(xpath="//input[@pppname='TechSure Plus']")
      		    protected Element VASProduct_TechSurePlus_ProductsPage;
      		    
      		  @FindBy(xpath="//label[@for='fullcoverage']")
  		    protected Element VASProduct_TechSurePremium_Coverage;
      		  
      		@FindBy(xpath = "//button[contains(@ng-click,'ResumeOrder') and contains(@ng-disabled,'smartCart')]")
      	    protected Element smartCartResume;
		    
      		
      		//Prakash -- Suspension and Restore
      		@FindBy(xpath = "//div[@data-customtooltip='vacationsuspend0']")
      	    protected Element SuspendRestoreAlert;
      		
      		 @FindBy(xpath = "//tr[@id='InternetVacRow']/td/span")
      	    protected CList<Element> allAgreementsRestore;
 			
  			@FindBy(xpath = "//label[@for='ctl00_ctl00_ContentPlaceHolder1_ContentPlaceHolder1_offerWrapper_CRMMOffers_ctl114_0']")
       	    protected Element yesIHaveRead6;  			
  			
  			//Added by PRakash for Snowtickets link - --- 1/7/2019
  			@FindBy(xpath = "//div[contains(text(),'Issues')]")
 			 protected Element Issues;
		  
  			
  			//Added for mutually exclusive Selected Security and Cloud
  			@FindBy(xpath = "//*[@class='warningBox']")
			 protected Element BBE_warning;
  			
  			@FindBy(xpath = "//*[@class='label_check c_on']")
			 protected Element BBE_Existing;
  			
  			@FindBy(xpath = "//li[contains(text(),'Questions and Answers')]")
			 protected Element RGQA;
  			
  			//Pega//
  			
  			@FindBy(xpath = "//li[@ng-repeat='serviceRelated in ServiceRelated']//a[contains(text(),'Compass')]")
			 protected Element Compass;
  			
  			//Vignesh start
  			@FindBy(xpath = "//div[contains(text(),'Return Option(s)')]")
			 protected Element Return_Option;
  			
  			@FindBy(xpath = "//label[contains(text(),'Select All')]")
			 protected Element Return_Option_Select_All_chk_box;
  			
  			
  			@FindBy(xpath = "//button[contains(text(),'Next') and contains(@ng-click,'getSelectedListOfReturnKit')]")
			 protected Element Return_Option_Select_All_Nxt_btn;
  			
  			
  			@FindBy(xpath = "//label[contains(text(),'Customer will drop-off at a Verizon Retail Location')]")
			 protected Element Return_Option_drop_off_radio_btn;
  			
  			
  			@FindBy(xpath = "//input[@id='txtEmail']")
			 protected Element Return_Option_email_box;
  			
  			
  			@FindBy(xpath = "//button[contains(text(),' Email Locations to Customer ')]")
			 protected Element Email_Locations_to_Customer_btn;

  			
  			@FindBy(xpath = "//label[contains(text(),'Email has sent Successfully')]")
			 protected Element Emailing_Locations_sucess_msg;
  		    //Vignesh end
  			
  			@FindBy(xpath = "//div[@data-close-customtip='alertNotify']/div/div/a[contains(@class,'close') and @aria-hidden='true']") 
		    protected Element MessageAlert1;
  		
}
